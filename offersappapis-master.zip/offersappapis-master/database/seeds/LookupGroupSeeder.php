<?php

use Illuminate\Database\Seeder;
use App\Models\Generals\LookupGroup;

class LookupGroupSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        LookupGroup::truncate();

        $insert = array(
            array("id" => 1, "group_name" => "Credit Types"),
            array("id" => 2, "group_name" => "Payment Methods"),
            array("id" => 3, "group_name" => "Credit For"),
            array("id" => 4, "group_name" => "Feature Group"),
            array("id" => 5, "group_name" => "Login Types"),
            array("id" => 6, "group_name" => "Notification Types"),
            array("id" => 7, "group_name" => "Payment Types"),
            array("id" => 8, "group_name" => "Navigation URLs "),
        );

        LookupGroup::insert($insert);
    }
}
