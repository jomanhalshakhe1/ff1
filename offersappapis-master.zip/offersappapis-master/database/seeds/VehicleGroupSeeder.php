<?php

use Illuminate\Database\Seeder;
use App\Models\Accounts\VehicleGroup;

class VehicleGroupSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        VehicleGroup::truncate();

        $insert = array(
            array('id' => 1, 'title' => 'SUV', 'title_ar' => 'SUV'),
            array('id' => 2, 'title' => 'Seedan', 'title_ar' => 'Seedan')
        );

        VehicleGroup::insert($insert);
    }
}
