<?php

use Illuminate\Database\Seeder;
use \App\Models\Accounts\Driver;

class DriverSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Driver::truncate();

        $insert = array(
            array(
                "first_name" => "Guest",
                "last_name" => "Joy",
                "country_code" => "+966",
                "contact_no" => "+966580000004",
                "password" => \Illuminate\Support\Facades\Hash::make('driver@123'),
                "email" => "guest@innvohub.com",
                "is_verified" => 1,
            )
        );

        Driver::insert($insert);
    }
}
