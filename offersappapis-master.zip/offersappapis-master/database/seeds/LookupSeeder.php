<?php

use Illuminate\Database\Seeder;
use App\Models\Generals\Lookup;

class LookupSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Lookup::truncate();

        $insert = array(
            array("id" => 1, "entity_name" => "GIFT", "code" => 1, "group_id" => 1),
            array("id" => 2, "entity_name" => "REFUND", "code" => 2, "group_id" => 1),
            array("id" => 3, "entity_name" => "ADJUSTMENT", "code" => 3, "group_id" => 1),
            array("id" => 4, "entity_name" => "PAYOFF", "code" => 4, "group_id" => 1),
            array("id" => 5, "entity_name" => "CREDIT", "code" => 5, "group_id" => 1),
            array("id" => 6, "entity_name" => "Payment Paid", "code" => 6, "group_id" => 1),
            array("id" => 7, "entity_name" => "Credit Account", "code" => 7, "group_id" => 7),
            array("id" => 8, "entity_name" => "Banking", "code" => 8, "group_id" => 2),
            array("id" => 9, "entity_name" => "Credit and Bank Accounts", "code" => 9, "group_id" => 2),
            array("id" => 10, "entity_name" => "GROUP", "code" => 10, "group_id" => 3),
            array("id" => 11, "entity_name" => "INDIVIDUAL", "code" => 11, "group_id" => 3),
            array("id" => 12, "entity_name" => "Head Navigater", "code" => 12, "group_id" => 4),
            array("id" => 13, "entity_name" => "Sub Navigater", "code" => 13, "group_id" => 4),
            array("id" => 14, "entity_name" => "Super Sub Navigater", "code" => 14, "group_id" => 4),
            array("id" => 15, "entity_name" => "Feature", "code" => 15, "group_id" => 4),
            array("id" => 16, "entity_name" => "Apis", "code" => 16, "group_id" => 4),
            array("id" => 17, "entity_name" => "Office", "code" => 17, "group_id" => 5),
            array("id" => 18, "entity_name" => "Dealer", "code" => 18, "group_id" => 5),
            array("id" => 19, "entity_name" => "Fleet", "code" => 19, "group_id" => 5),
            array("id" => 20, "entity_name" => "Maker", "code" => 20, "group_id" => 5),
            array("id" => 21, "entity_name" => "Consumer", "code" => 21, "group_id" => 5),
            array("id" => 22, "entity_name" => "Technician", "code" => 22, "group_id" => 5),

            array("id" => 23, "entity_name" => "new_offer", "code" => 23, "group_id" => 6),
            array("id" => 24, "entity_name" => "offer_expiry", "code" => 24, "group_id" => 6),
            array("id" => 25, "entity_name" => "offer_expiry_delar", "code" => 25, "group_id" => 6),
            array("id" => 26, "entity_name" => "offer_expired", "code" => 26, "group_id" => 6),
            array("id" => 27, "entity_name" => "add_transaction", "code" => 27, "group_id" => 6),
            array("id" => 28, "entity_name" => "transaction_status", "code" => 28, "group_id" => 6),
            array("id" => 29, "entity_name" => "unredeem_offerend", "code" => 29, "group_id" => 6),
            array("id" => 30, "entity_name" => "paid_unredeem_offerend", "code" => 30, "group_id" => 6),
            array("id" => 31, "entity_name" => "incomplete_paymentfordeal", "code" => 31, "group_id" => 6),
            array("id" => 32, "entity_name" => "likedoffer_endingsoon", "code" => 32, "group_id" => 6),
            array("id" => 33, "entity_name" => "Apple Pay", "code" => 33, "group_id" => 7),
            array("id" => 34, "entity_name" => "Google Pay", "code" => 34, "group_id" => 7),
            array("id" => 35, "entity_name" => "Cards", "code" => 35, "group_id" => 7),
            array("id" => 36, "entity_name" => "REFUNDED", "code" => 36, "group_id" => 6),
            array("id" => 37, "entity_name" => "ADJUSTMENT", "code" => 37, "group_id" => 6),
            array("id" => 38, "entity_name" => "REDEEMED", "code" => 38, "group_id" => 6),
            array("id" => 39, "entity_name" => "Gifts", "code" => 39, "group_id" => 6),
            array("id" => 40, "entity_name" => "Request for notify offer", "code" => 40, "group_id" => 6),
            array("id" => 41, "entity_name" => "Notify Request Availability", "code" => 41, "group_id" => 6),
            array("id" => 42, "entity_name" => "Request for onsite address", "code" => 42, "group_id" => 6),
            array("id" => 43, "entity_name" => "Send address for onsite", "code" => 43, "group_id" => 6),
            array("id" => 44, "entity_name" => "Custom Messages", "code" => 44, "group_id" => 6),

            array("id" => 45, "entity_name" => "Profile", "code" => 45, "group_id" => 8),
            array("id" => 46, "entity_name" => "Transactions", "code" => 46, "group_id" => 8),
            array("id" => 47, "entity_name" => "Deals", "code" => 47, "group_id" => 8),
            array("id" => 48, "entity_name" => "offers", "code" => 48, "group_id" => 8),
            array("id" => 49, "entity_name" => "Guest", "code" => 49, "group_id" => 5),
            array("id" => 50, "entity_name" => "offers", "code" => 50, "group_id" => 7),
            array("id" => 51, "entity_name" => "Coupon Notifications", "code" => 51, "group_id" => 6),
        );

        Lookup::insert($insert);
    }
}
