<?php

use Illuminate\Database\Seeder;
use App\Models\Generals\Deal;

class DealsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Deal::truncate();
        $insert = array(
            array(
                'id' => 1, 
                'title' => 'Car Rental', 
                'thumbnail_url' => 'dummy.png', 
                'sort_order' => 1, 
                'created_at' => date('Y-m-d h:i:s')
            ),
            array(
                'id' => 2, 
                'title' => 'Tyres', 
                'thumbnail_url' => 'dummy.png', 
                'sort_order' => 2, 
                'created_at' => date('Y-m-d h:i:s')
            ),
            array(
                'id' => 3, 
                'title' => 'RSA', 
                'thumbnail_url' => 'dummy.png', 
                'sort_order' => 3, 
                'created_at' => date('Y-m-d h:i:s')
            ),
            array(
                'id' => 4, 
                'title' => 'Cleaning', 
                'thumbnail_url' => 'dummy.png', 
                'sort_order' => 4, 
                'created_at' => date('Y-m-d h:i:s')
            ),
            array(
                'id' => 5, 
                'title' => 'Detailing', 
                'thumbnail_url' => 'dummy.png', 
                'sort_order' => 5, 
                'created_at' => date('Y-m-d h:i:s')
            ),
            array(
                'id' => 6, 
                'title' => 'Batteries', 
                'thumbnail_url' => 'dummy.png', 
                'sort_order' => 6, 
                'created_at' => date('Y-m-d h:i:s')
            ),
            array(
                'id' => 7, 
                'title' => 'Insurance', 
                'thumbnail_url' => 'dummy.png', 
                'sort_order' => 7, 
                'created_at' => date('Y-m-d h:i:s')
            ),
            array(
                'id' => 8, 
                'title' => 'Petrol', 
                'thumbnail_url' => 'dummy.png', 
                'sort_order' => 8, 
                'created_at' => date('Y-m-d h:i:s')
            ),
        );

        Deal::insert($insert);
    }
}
