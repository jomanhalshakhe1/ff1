<?php

use Illuminate\Database\Seeder;
use App\Models\Accounts\User;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::truncate();

        $insert = array(
            "first_name" => "Admin",
            'email' => 'admin@innvohub.com',
            "password" => \Illuminate\Support\Facades\Hash::make('admin@123'),
            "role_id" => 1,
            "org_id" => 1,
            'country_code' => '+966',
            'contact_no' => '888999000',
            'is_verified' => 1
        );

        User::insert($insert);
    }
}
