<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Role;
use App\User;
use App\Driver;
use App\Colour;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call(RoleSeeder::class);
        $this->call(UserSeeder::class);
        $this->call(DriverSeeder::class);
        $this->call(ColourSeeder::class);
        $this->call(VehicleGroupSeeder::class);
        $this->call(DealsSeeder::class);
        $this->call(FeaturesSeeder::class);
        $this->call(RoleFeaturesSeeder::class);
        $this->call(EmailFormatesSeeder::class);
        $this->call(SMSFormatesSeeder::class);
        $this->call(NotificationFormatesSeeder::class);
    }
}