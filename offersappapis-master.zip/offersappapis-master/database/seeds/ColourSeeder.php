<?php

use Illuminate\Database\Seeder;
use App\Models\Generals\Colour;

class ColourSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Colour::truncate();

        $insert = array(
            array('id' => 1, 'title' => 'Black', 'title_ar' => 'Black'),
            array('id' => 2, 'title' => 'White', 'title_ar' => 'White'),
            array('id' => 3, 'title' => 'Gray', 'title_ar' => 'Gray'),
            array('id' => 4, 'title' => 'Silver', 'title_ar' => 'Silver'),
            array('id' => 5, 'title' => 'Blue', 'title_ar' => 'Blue'),
            array('id' => 6, 'title' => 'Red', 'title_ar' => 'Red'),
            array('id' => 7, 'title' => 'Brown', 'title_ar' => 'Brown'),
            array('id' => 8, 'title' => 'Gold', 'title_ar' => 'Gold'),
            array('id' => 9, 'title' => 'Green', 'title_ar' => 'Green'),
            array('id' => 10,'title' => 'Tan', 'title_ar' => 'Tan')
        );

        Colour::insert($insert);
    }
}
