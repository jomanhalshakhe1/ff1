<?php

use Illuminate\Database\Seeder;
use App\Models\Generals\Role;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Role::truncate();
        $insert = array(
            array('id' => 1, 'title' => 'Super Admin', 'login_type_id' => 17),
            array('id' => 2, 'title' => 'Makers', 'login_type_id' => 20),
            array('id' => 3, 'title' => 'Delar', 'login_type_id' => 18),
            array('id' => 4, 'title' => 'Technician', 'login_type_id' => 17),
            array('id' => 5, 'title' => 'Consumer', 'login_type_id' => 21),
            array('id' => 6, 'title' => 'Fleet', 'login_type_id' => 19),
            array('id' => 7, 'title' => 'M & S Technican', 'login_type_id' => 22),
            array('id' => 8, 'title' => 'Delar Technican', 'login_type_id' => 22),
            array('id' => 9, 'title' => 'Guest', 'login_type_id' => 49),
            array('id' => 10, 'title' => 'Tabby', 'login_type_id' => 17),
        );

        Role::insert($insert);
    }
}
