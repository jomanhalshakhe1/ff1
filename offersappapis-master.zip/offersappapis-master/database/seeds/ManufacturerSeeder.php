<?php

use Illuminate\Database\Seeder;
use \App\Models\Generals\Manufacturer;

class ManufacturerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Manufacturer::truncate();

        $insert = array(
            array('id' => 1, 'title' => 'Honda', 'thumbnail_url' => 'dummy.png', 'created_at' => date('Y-m-d h:i:s')),
            array('id' => 2, 'title' => 'Mercedes-Benz', 'thumbnail_url' => 'dummy.png', 'created_at' => date('Y-m-d h:i:s')),
            array('id' => 3, 'title' => 'Ford', 'thumbnail_url' => 'dummy.png', 'created_at' => date('Y-m-d h:i:s')),
            array('id' => 4, 'title' => 'GMC', 'thumbnail_url' => 'dummy.png', 'created_at' => date('Y-m-d h:i:s')),
            array('id' => 5, 'title' => 'Audi', 'thumbnail_url' => 'dummy.png', 'created_at' => date('Y-m-d h:i:s')),
            array('id' => 6, 'title' => 'Rolls-Royce', 'thumbnail_url' => 'dummy.png', 'created_at' => date('Y-m-d h:i:s')),
            array('id' => 7, 'title' => 'Porsche', 'thumbnail_url' => 'dummy.png', 'created_at' => date('Y-m-d h:i:s')),
            array('id' => 8, 'title' => 'BMW', 'thumbnail_url' => 'dummy.png', 'created_at' => date('Y-m-d h:i:s')),
        );

        Manufacturer::insert($insert);
    }
}
