<?php

use Illuminate\Database\Seeder;

class FeaturesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\Models\Generals\Feature::truncate();

        $file_path = database_path('sql/features.sql');

        \Illuminate\Support\Facades\DB::unprepared(
            file_get_contents($file_path)
        );
    }
}
