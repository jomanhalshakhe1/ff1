<?php

use Illuminate\Database\Seeder;
use App\Models\Regulatory\Organization;

class OrganizationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Organization::truncate();

        $insert = array(
            'id' => 1,
            'org_name' => 'Innvohub',
            'org_name_ar' => 'إنفوهوب',
            'code' => 'INNVOHUB',
            'email' => 'admin@innvohub.com',
            'country_code' => '+966',
            'phone' => '888999000',
            'company_type' => 'A',
            'personal_info' => 1
        );

        Organization::insert($insert);
    }
}
