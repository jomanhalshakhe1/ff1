<?php

use Illuminate\Database\Seeder;

class EmailFormatesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
       \App\Models\Generals\EmailFormates::truncate();

        $file_path = database_path('sql/email_formates.sql');

        \Illuminate\Support\Facades\DB::unprepared(
            file_get_contents($file_path)
        );
    }
}
