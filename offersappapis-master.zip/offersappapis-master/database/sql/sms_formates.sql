-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2023 at 01:19 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `innvohub_joy10042023`
--

-- --------------------------------------------------------

--
-- Table structure for table `sms_formates`
--
--
-- Dumping data for table `sms_formates`
--

INSERT INTO `sms_formates` (`id`, `notification_for`, `title`, `notification_info`, `hint`, `customer_message`, `customer_message_ar`, `dealer_message`, `dealer_message_ar`, `operator_message`, `operator_message_ar`, `created_at`, `updated_at`, `status`) VALUES
(1, 27, 'Purchased an Offer', 'When customer purchased any item offer', '{item_name},{customer_name},{transaction_no},{invoice_no},{amount},{discount}', 'New purchase, the transaction number is: {transaction_no}', 'عملية شراء جديدة، رقم العملية هو: {transaction_no}', 'New purchase, the transaction number is: {transaction_no}', 'عملية شراء جديدة، رقم العملية هو: {transaction_no}', 'New purchase, the transaction number is: {transaction_no}', 'عملية شراء جديدة، رقم العملية هو: {transaction_no}', '2023-03-22 14:08:07', NULL, 1),
(2, 36, 'Refund the purchase', 'When admin or deal provider refund purchased deal', '{item_name},{customer_name},{transaction_no},{invoice_no},{amount},{discount}', 'Hi {customer_name}, {item_name} amount has been refunded', 'مرحبا {customer_name}، تم استرداد مبلغ {item_name}', 'Hi {customer_name}, {item_name} amount has been refunded', 'مرحبا {customer_name}، تم استرداد مبلغ {item_name}', 'Hi {customer_name}, {item_name} amount has been refunded', 'مرحبا {customer_name}، تم استرداد مبلغ {item_name}', '2023-03-22 14:15:20', NULL, 1),
(3, 37, 'Transaction Adjustments', 'When admin or dealer adjust amount on purchased item', '{item_name},{customer_name},{transaction_no},{invoice_no},{amount},{discount}', 'Hai {customer_name}, your purchase on {item_name}, adjustment amount: {amount} SAR was added ', 'هلا {customer_name}، تم تعديل قيمة عملية الشراء رقم {item_name} الى: {amount} ريال', '{customer_name} purchased on {item_name}, adjustment amount: {amount} SAR was added ', '{customer_name} تم شراؤها على {item_name}، تمت إضافة مبلغ التسوية: {المبلغ} ريال سعودي ', '{customer_name} purchased on {item_name}, adjustment amount: {amount} SAR was added ', '{customer_name} تم شراؤها على {item_name}، تمت إضافة مبلغ التسوية: {المبلغ} ريال سعودي ', '2023-03-22 14:15:20', NULL, 1),
(4, 38, 'Redeem purchased offer.', 'When customers redeem their purchased offers', '{item_name},{customer_name},{transaction_no},{invoice_no},{amount},{discount}', 'Hi {customer_name}, Offer {item_name} has been redeemed', NULL, 'Hi {customer_name}, Offer {item_name} has been redeemed.', 'مرحبا {customer_name} ، تم استرداد العرض {item_name}.', 'Hi {customer_name}, Offer {item_name} has been redeemed.', 'مرحبا {customer_name} ، تم استرداد العرض {item_name}.', '2023-03-22 14:21:23', NULL, 1),
(5, 40, 'Request for Offer Availability', 'When customer requested item offer availability', '{item_name},{customer_name},{transaction_no},{invoice_no},{amount},{discount}', 'You have requested offer availability for {item_name}', 'لقد طلبت توفر العرض ل {item_name}', '{customer_name} requested for offer availability for {item_name}', '{customer_name} طلب توفر العرض ل {item_name}', '{customer_name} requested for offer availability for {item_name}', '{customer_name} طلب توفر العرض ل {item_name}', '2023-03-22 14:21:23', NULL, 1),
(6, 41, 'Offer Availability Status', 'When technician rejected or accepted offer availability', '{item_name},{customer_name},{transaction_no},{invoice_no},{amount},{discount},{status}', 'Offer availability status for {item_name} is: {status} which was requested by you', 'حالة توفر العرض ل {item_name} هي: {status} التي طلبتها', 'Offer availability status for {item_name} is: {status} which requested by {customer_name}', 'حالة توفر العرض ل {item_name} هي: {status} التي طلبها {customer_name}', 'Offer availability status for {item_name} is: {status} which requested by {customer_name}', 'حالة توفر العرض ل {item_name} هي: {status} التي طلبها {customer_name}', '2023-03-22 14:28:40', NULL, 1),
(7, 42, 'Request for address', 'When technician requested customer\'s current location', '{item_name},{customer_name},{transaction_no},{invoice_no},{amount},{discount}', '{customer_name} requested an address for Transaction Number {transaction_no}', 'طلب {customer_name} عنوانا لرقم المعاملة {transaction_no}', '{customer_name} requested an address for Transaction Number {transaction_no}', 'طلب {customer_name} عنوانا لرقم المعاملة {transaction_no}', '{customer_name} requested an address for Transaction Number {transaction_no}', 'طلب {customer_name} عنوانا لرقم المعاملة {transaction_no}', '2023-03-22 14:32:16', NULL, 1),
(8, 43, 'Send customer current location.', 'When customer send his current location for onsite purchase item offer', '{item_name},{customer_name},{transaction_no},{invoice_no},{amount},{discount}', 'You have successfully sent current location for Transaction Number: {transaction_no}', 'لقد قمت بإرسال الموقع الحالي لرقم المعاملة بنجاح: {transaction_no}', '{customer_name} sent current location for Transaction Number: {transaction_no}', '{customer_name} الموقع الحالي المرسل لرقم المعاملة: {transaction_no}', '{customer_name} sent current location for Transaction Number: {transaction_no}', '{customer_name} الموقع الحالي المرسل لرقم المعاملة: {transaction_no}', '2023-03-22 14:32:16', '2023-03-22 12:33:28', 1);

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
