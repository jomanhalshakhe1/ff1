<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCreditNotes extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('creditnotes', function (Blueprint $table) {
            $table->id();
            $table->enum('report_type', ['S','P','I'])->comment('S-Summary,P-Payout,I- Invoice')->default('S');
            $table->enum('company_type', ['D','F'])->comment('D-Deal Provider,F-Fleet');
            $table->string('invoice_no')->nullable();
            $table->integer('dealer_id')->default(0);
            $table->integer('category_id')->default(0);
           
            $table->date('from_date')->nullable();
            $table->date('to_date')->nullable();
            $table->string('invoice_name')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('creditnotes');
    }
}
