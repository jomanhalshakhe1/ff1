<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePoliciesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('policies', function (Blueprint $table) {
            $table->id();
            $table->string('first_name', 60);
            $table->string('last_name', 60)->nullable();
            $table->date('dob')->nullable();
            $table->string('licence_no', 30)->nullable();
            $table->string('policy_no', 30)->nullable();
            $table->integer('vehicle_group_id')->nullable();
            $table->string('maker', 100)->nullable();
            $table->integer('delar_id');
            $table->integer('created_by');
            $table->timestamps();
            $table->tinyInteger('status')->default(1);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('policies');
    }
}
