<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePaymentSharesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payment_shares', function (Blueprint $table) {
            $table->id();
            $table->float('admin_share')->default(0);
            $table->float('customer_share')->default(0);
            $table->float('vat')->default(0);
            $table->float('pg_fee')->default(0);
            $table->float('pg_share')->default(0);
            $table->float('visamaster_share')->default(0);
            $table->integer('created_by')->nullable();
            $table->integer('updated_by')->nullable();
            $table->timestamps();
            $table->tinyInteger('status')->default(1);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payment_shares');
    }
}
