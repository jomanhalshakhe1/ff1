<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmailFormatesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('email_formates', function (Blueprint $table) {
            $table->id();
            $table->string('title')->nullable();
            $table->text('hint')->nullable();
            $table->text('subject')->nullable();
            $table->text('subject_ar')->nullable();
            $table->text('message')->nullable();
            $table->text('message_ar')->nullable();
            $table->tinyInteger('isinvoice')->default(0);
            $table->tinyInteger('status')->default(1);
            $table->timestamps();
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('email_formates');
    }
}
