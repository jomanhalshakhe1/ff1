<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateItemMasterTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('item_master', function (Blueprint $table) {
            $table->id();
            $table->string('title', 60);
            $table->string('title_ar', 60);
            $table->string('code', 20);
            $table->double('price', 10);
            $table->string('company', 100)->nullable();
            $table->integer('quantity')->default(1);
            $table->string('dimensions', 30)->nullable();
            $table->integer('deal_id');
            $table->integer('delar_id');
            $table->string('thumbnail_url', 100)->nullable();
            $table->string('description', 255)->nullable();
            $table->string('description_ar', 255)->nullable();
            $table->string('volt', 20)->nullable();
            $table->string('ah', 20)->nullable();
            $table->string('size', 20)->nullable();
            $table->string('height', 20)->nullable();
            $table->string('width', 20)->nullable();
            $table->string('viscosity_before', 20)->nullable();
            $table->string('viscosity_after', 20)->nullable();
            $table->timestamps();
            $table->timestamp('deleted_at')->nullable();
            $table->tinyInteger('status')->default(1);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('item_master');
    }
}
