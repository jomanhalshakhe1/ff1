<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDealsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('deals', function (Blueprint $table) {
            $table->id();
            $table->string('title', 30);
            $table->string('title_ar', 30)->nullable();
            $table->double('markup_price')->default(0);
            $table->enum('action_type', ['C', 'D', 'A'])->default('A')
                ->comment('C-ComingSoon,D-Disabled,A-Active');
            $table->string('thumbnail_url', 60);
            $table->tinyInteger('sort_order')->default(0);
            $table->timestamps();
            $table->tinyInteger('status')->default(1);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('deals');
    }
}
