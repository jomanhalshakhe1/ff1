<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFleetDriversTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fleet_drivers', function (Blueprint $table) {
            $table->id();
            $table->integer('fleet_id')->index();
            $table->string('employee_id', 20)->nullable();
            $table->string('first_name', 30);
            $table->string('last_name', 30)->nullable();
            $table->string('email', 30)->nullable();
            $table->string('contact_code', 5)->nullable();
            $table->string('contact_no', 15)->nullable();
            $table->integer('driver_id')->nullable()->index();
            $table->integer('sheet_id');
            $table->timestamps();
            $table->tinyInteger('status')->default(0);
            $table->index(['fleet_id', 'driver_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fleet_drivers');
    }
}
