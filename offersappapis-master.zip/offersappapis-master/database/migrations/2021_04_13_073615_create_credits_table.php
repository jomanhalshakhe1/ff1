<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCreditsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('credits', function (Blueprint $table) {
            $table->id();
            $table->string('transaction_no', 20)->nullable()->index();
            $table->integer('credit_on')->index();
            $table->integer('fleet_id')->nullable()->index();
            $table->float('amount', 8, 2)->nullable();
            $table->integer('quantity')->default(1);
            $table->dateTime('start_date')->nullable();
            $table->dateTime('end_date')->nullable();
            $table->enum('credit_by', ['C', 'B'])->comment('C-Credits,B-Banking');
            $table->string('transaction_id', 20)->nullable();
            $table->text('description');
            $table->integer('created_by');
            $table->timestamps();
            $table->tinyInteger('status')->default(1);
            $table->index(['transaction_no', 'credit_on']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('credits');
    }
}
