<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransactionDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transaction_details', function (Blueprint $table) {
            $table->id();
            $table->string('transaction_no', 20)->index();
            $table->double('price');
            $table->integer('vat');
            $table->integer('joy_share');
            $table->integer('partner_share');
            $table->integer('pg_fee');
            $table->integer('pg_share');
            $table->integer('service_cost')->default(0);
            $table->integer('filter_cost')->default(0);

            $table->string('item_name', 60);
            $table->string('item_name_ar', 100);
            $table->string('thumbnail_url', 100);
            $table->string('dimensions', 30)->nullable();
            $table->string('volt', 20)->nullable();
            $table->string('ah', 20)->nullable();
            $table->string('size', 20)->nullable();
            $table->string('height', 20)->nullable();
            $table->string('width', 20)->nullable();
            $table->text('item_description');
            $table->text('item_description_ar');

            $table->string('offer_name', 60)->nullable();
            $table->string('offer_name_ar', 100)->nullable();
            $table->text('offer_description')->nullable();
            $table->text('offer_description_ar')->nullable();
            $table->text('terms');
            $table->text('terms_ar');
            $table->date('end_date');
            $table->tinyInteger('is_notify')->default(0);
            $table->tinyInteger('on_site')->default(0);

            $table->string('delar_name', 60);
            $table->string('delar_name_ar', 60);
            $table->string('delar_address', 255);
            $table->tinyInteger('status')->default(1);
            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transaction_details');
    }
}
