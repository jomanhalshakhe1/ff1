<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransactionInfoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transaction_info', function (Blueprint $table) {
            //$table->id();
            //$table->timestamps();
            //$table->autoIncrement('transaction_detail_id');
            $table->increments('transaction_detail_id');
            $table->integer('vocher_id');
            $table->integer('ledger_id');
            $table->tinyInteger('is_credit');
            $table->integer('quantity');
            $table->double('rate', 8,2);
            $table->double('discount', 8,2);
            $table->timestamp('transaction_date')->nullable();
            $table->string('mode')->nullable();
            $table->string('reconciliation')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transaction_info');
    }
}
