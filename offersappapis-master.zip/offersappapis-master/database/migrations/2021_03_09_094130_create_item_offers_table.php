<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateItemOffersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('item_offers', function (Blueprint $table) {
            $table->id();
            $table->integer('item_id');
            $table->integer('deal_id');
            $table->string('title', 100)->nullable();
            $table->string('title_ar', 100)->nullable();
            $table->double('price', 10);
            $table->integer('quantity')->default(1);
            $table->integer('discount');
            $table->integer('vat')->default(15);
            $table->integer('service_cost')->default(0);
            $table->date('start_date');
            $table->date('end_date');
            $table->string('description', 255)->nullable();
            $table->string('description_ar', 255)->nullable();
            $table->text('terms')->nullable();
            $table->text('terms_ar')->nullable();
            $table->boolean('vn_access')->default(0)->comment('Vehicle Number Access');
            $table->boolean('pn_access')->default(0)->comment('Plate Number Access');
            $table->boolean('is_notify')->default(0)->comment('Notified Offers');
            $table->boolean('on_site')->default(0)->comment('On site');
            $table->boolean('is_top_deal')->default(0)->comment('Top Deal');
            $table->integer('provider_reference_id')->nullable();
            $table->integer('provider_reference_subid')->nullable();
            $table->timestamps();
            $table->tinyInteger('status')->default(1);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('item_offers');
    }
}
