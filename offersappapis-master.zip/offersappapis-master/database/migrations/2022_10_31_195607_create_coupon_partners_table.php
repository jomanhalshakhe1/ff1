<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCouponPartnersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('coupon_partners', function (Blueprint $table) {
            $table->integer('coupon_id');
            $table->integer('org_id');
            $table->enum('org_type', ['D','F'])->default('D')
                ->comment('D-Delar, F-Fleet');
            $table->integer('status')->default(1);
            $table->primary(['coupon_id', 'org_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('coupon_partners');
    }
}
