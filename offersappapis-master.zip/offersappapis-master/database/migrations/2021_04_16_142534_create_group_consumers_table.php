<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGroupConsumersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('group_consumers', function (Blueprint $table) {
            $table->integer('group_id');
            $table->integer('consumer_id');
            $table->timestamps();
            $table->tinyInteger('status')->default(1);
            $table->primary(['group_id', 'consumer_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('group_consumers');
    }
}
