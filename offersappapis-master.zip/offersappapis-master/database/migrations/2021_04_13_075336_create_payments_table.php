<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePaymentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->string('payment_no', 20)->index();
            $table->string('transaction_no', 20)->index();
            $table->string('invoice_no', 20)->nullable();
            $table->integer('payment_on');
            $table->tinyInteger('payment_type')->default(1)->comment('0-Failed,1-Main Payment,2-Refunded');
            $table->float('amount_by_banking')->default(0);
            $table->float('amount_by_credits')->default(0);
            $table->string('payment_status', 20)->default('pending')->index();
            $table->string('payid', 20);
            $table->string('action_code', 10);
            $table->string('response_code', 20);
            $table->float('response_amount')->default(0);
            $table->string('response_result', 255);
            $table->string('card_token', 60);
            $table->string('card_brand', 25)->nullable();
            $table->timestamps();
            $table->tinyInteger('status')->default(1);
            $table->index(['transaction_no', 'payment_no']);
            $table->index(['transaction_no', 'payment_status']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payments');
    }
}
