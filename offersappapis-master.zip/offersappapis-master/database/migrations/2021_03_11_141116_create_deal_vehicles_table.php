<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDealVehiclesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('deal_vehicles', function (Blueprint $table) {
            //$table->id();
            $table->integer('deal_id');
            $table->integer('item_id');
            $table->integer('group_id');
            $table->integer('offer_id');
            $table->timestamps();
            $table->tinyInteger('status')->default(1);

            $table->primary(['deal_id', 'item_id', 'group_id', 'offer_id']);
            $table->index(['group_id', 'offer_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('deal_vehicles');
    }
}
