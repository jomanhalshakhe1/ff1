<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class GiftCreditsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
       Schema::create('gift_credits', function (Blueprint $table) {
            $table->id();
            $table->double('amount')->default(0);
            $table->string('user_group')->nullable();
            $table->integer('no_of_users')->default(0);
            $table->double('total_afford_amount')->default(0);
            $table->tinyInteger('apply_for')->default(0)->comment('1-on signup, 2- guest to signup, 3- on transaction amount more than 1000');
            $table->integer('credits_expiry')->default(0);
            $table->string('notification_title')->nullable();
            $table->string('notification_title_ar')->nullable();
            $table->text('notification_message')->nullable();
            $table->text('notification_message_ar')->nullable();
            $table->dateTime('start_date')->nullable();
            $table->dateTime('end_date')->nullable();
            $table->timestamps();
            $table->tinyInteger('status')->default(1);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
