<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLocationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('locations', function (Blueprint $table) {
            $table->id();
            $table->integer('org_id' );
            $table->string('street', 60 )->nullable();
            //$table->string('city', 60 )->nullable();
            $table->integer('city')->nullable();
            $table->string('district', 60 )->nullable();
            $table->string('address', 255 )->nullable();
            $table->string('latitude' ,25);
            $table->string('longitude' ,25);
            $table->string('zipcode' ,15)->nullable();
            $table->tinyInteger('primary')->default(0);
            $table->timestamps();
            $table->tinyInteger('status')->default(1);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('locations');
    }
}
