<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVehiclesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('vehicles', function (Blueprint $table) {
            $table->id();
            $table->integer('model')->nullable();
            $table->string('plate_no', 20)->nullable();
            $table->string('policy_no', 20)->nullable();
            $table->integer('colour');
            $table->string('serial_no', 30);
            $table->string('trim', 30)->nullable();
            $table->integer('company');
            $table->string('make_year', 20)->nullable();
            $table->string('licence_no', 20)->nullable();
            $table->integer('group_id');
            $table->integer('owner_id');
            $table->tinyInteger('is_primary')->default(0);
            $table->string('reference_id', 20)->nullable();
            $table->timestamps();
            $table->softDeletes('deleted_at');
            $table->tinyInteger('status')->default(1);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('vehicles');
    }
}
