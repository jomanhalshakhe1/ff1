<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCouponLogsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('coupon_logs', function (Blueprint $table) {
            $table->id();
            $table->string('transaction_no', 20)->nullable();
            $table->integer('driver_id')->default(0);
            $table->integer('coupon_id')->default(0);
            $table->string('coupon_code', 100)->nullable();
            $table->double('discount')->default(0);
            $table->double('savings')->default(0);
            $table->string('reason', 255)->nullable();
            $table->integer('status')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('coupon_logs');
    }
}
