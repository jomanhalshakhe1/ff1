<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNotificationsLogTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('notifications_log', function (Blueprint $table) {
            $table->id();
            $table->integer('notification_id');
            $table->integer('notification_to');
            $table->enum('notification_for',['C','N'])->default('C')->comment('C-Customer,N-NonCustomer');
            $table->timestamp('read_at')->nullable();
            $table->timestamp('read_popup_at')->nullable();
            $table->timestamp('deleted_at')->nullable();
            $table->timestamps();
            $table->tinyInteger('status')->default(1);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('notifications_log');
    }
}
