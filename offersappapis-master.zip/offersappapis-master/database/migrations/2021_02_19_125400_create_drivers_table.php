<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDriversTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('drivers', function (Blueprint $table) {
            $table->id();
            $table->string('first_name', 40);
            $table->string('last_name', 20)->nullable();
            $table->string('email', 60)->nullable();
            $table->string('password', 100);
            $table->string('licence_id', 30)->nullable();
            $table->date('dob')->nullable();
            $table->integer('age')->nullable();
            $table->string('gender', 10)->nullable();
            $table->string('country_code', 5);
            $table->string('contact_no', 15);
            $table->string('profile_pic', 100)->nullable();
            $table->integer('org_id')->nullable();
            $table->tinyInteger('is_verified')->default(0);
            $table->tinyInteger('is_self')->nullable();
            $table->string('licence_file', 100)->nullable();
            $table->string('nationality', 10)->nullable();
            $table->timestamps();
            $table->tinyInteger('status')->default(1);
            $table->softDeletes('deleted_at');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('drivers');
    }
}
