<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNotificationsFormatesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('notifications_formates', function (Blueprint $table) {
            $table->id();
            $table->integer('notification_for')->nullable();
            $table->string('title')->nullable();
            $table->text('notification_info')->nullable();
            $table->text('hint')->nullable();
            $table->enum('type',['P', 'F', 'A'])->default('A')->comment('A-Inapp, F-firbase, P-Popup');
            $table->string('action_type', 25)->nullable();
            $table->text('message_example')->nullable();
            $table->string('notification_title')->nullable();
            $table->text('notification_message')->nullable();
            $table->string('notification_title_ar')->nullable();
            $table->text('notification_message_ar')->nullable();
            $table->text('sms_message')->nullable();
            $table->text('sms_message_ar')->nullable();
            $table->tinyInteger('status')->default(1);
            $table->integer('expired_on')->default(15);
            $table->enum('user_type',['C', 'D'])->default('C')->comment('C-Customer , D-Dealer or technician');
            $table->timestamps();
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('notifications_formates');
    }
}
