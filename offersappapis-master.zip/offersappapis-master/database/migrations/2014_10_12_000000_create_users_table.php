<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('first_name', 40);
            $table->string('last_name', 20)->nullable();
            $table->string('email', 60);
            $table->string('password', 100);
            $table->string('country_code', 5)->nullable();
            $table->string('contact_no', 15)->nullable();
            $table->integer('role_id');
            $table->string('profile_pic', 100)->nullable();
            $table->integer('org_id')->nullable();
            $table->boolean('is_verified')->default(0);
            $table->timestamps();
            $table->tinyInteger('status')->default(1);
            $table->unique(['email', 'role_id']);
            $table->unique(['contact_no', 'role_id']);
            $table->softDeletes('deleted_at');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
