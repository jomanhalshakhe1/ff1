<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCouponsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('coupons', function (Blueprint $table) {
            $table->id();
            $table->string('code', 100)->nullable();
            $table->date('expiry_date')->nullable();
            $table->double('discount')->default(0);
            $table->text('description')->nullable();
            $table->integer('quantity_perhead')->default(0);
            $table->integer('quantity')->default(0);
            $table->integer('quantity_perdeal')->default(0);
            $table->integer('deal_provider')->default(0);
            $table->integer('min_price')->default(0);
            $table->enum('coupon_type', ['D','C'])->default('D')
                ->comment('D-Discount, C-Credits');
            $table->enum('coupon_by', ['P','C','B'])->default('B')
                ->comment('P-Partner, D-Deal Category, B-Both');
            $table->enum('user_type', ['P','G','B'])->default('B')
                ->comment('P-Partner, G-General, B-Both');
            $table->timestamps();
            $table->integer('status')->default(1);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('coupons');
    }
}
