<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSmsFormatesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sms_formates', function (Blueprint $table) {
            $table->id();
            $table->integer('notification_for')->nullable();
            $table->string('title')->nullable();
            $table->text('hint')->nullable();
            $table->text('notification_info')->nullable();
            $table->text('customer_message')->nullable();
            $table->text('customer_message_ar')->nullable();
            $table->text('dealer_message')->nullable();
            $table->text('dealer_message_ar')->nullable();
            $table->text('operator_message')->nullable();
            $table->text('operator_message_ar')->nullable();
            $table->timestamps();
            $table->tinyInteger('status')->default(1);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sms_formates');
    }
}
