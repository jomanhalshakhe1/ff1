<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->string('transaction_no', 20)->index();
            $table->string('invoice_no', 20)->nullable();
            $table->integer('deal_id')->index();
            $table->integer('item_id')->index();
            $table->integer('offer_id')->index();
            $table->integer('location_id')->index();
            $table->integer('quantity')->nullable();
            $table->integer('revised_quantity')->nullable();
            $table->integer('redeem_quantity')->nullable();
            $table->integer('price')->nullable();
            $table->integer('discount');
            $table->integer('vehicle_id')->nullable();
            $table->integer('fleet_id')->nullable();
            $table->integer('service_id')->nullable();
            $table->integer('booking_id')->nullable();
            $table->date('slot_date')->nullable();
            $table->time('start_time')->nullable();
            $table->time('end_time')->nullable();
            $table->tinyInteger('filter_flag')->default(0);
            $table->tinyInteger('payment_with')->default(7);
            $table->tinyInteger('is_approved')->nullable();
            $table->integer('approved_by')->nullable();
            $table->timestamp('approved_at')->nullable();
            $table->integer('created_by');
            $table->timestamps();
            $table->tinyInteger('status')->default(1);
            $table->string('payment_status')->default('pending')->index();
            $table->string('remarks')->nullable();
            $table->index(['transaction_no', 'payment_status']);
            $table->index(['transaction_no', 'deal_id']);
            $table->index(['transaction_no', 'deal_id', 'item_id', 'offer_id']);
        });


    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transactions');
    }
}
