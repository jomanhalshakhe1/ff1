<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateExchangesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('exchanges', function (Blueprint $table) {
            $table->id();
            $table->integer('payment_to');
            $table->double('amount_paid');
            $table->enum('payment_type', ['M', 'B'])->comment('M-Manual, B-Banking');
            $table->enum('payment_for', ['A', 'D', 'F'])->comment('A-Admin, D-Delar, F-Partner');
            $table->date('paid_date')->nullable();
            $table->string('transaction_id', 30)->nullable();
            $table->text('remarks')->nullable();
            $table->integer('created_by');
            $table->integer('updated_by')->nullable();
            $table->timestamps();
            $table->tinyInteger('status')->default(1);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('exchanges');
    }
}
