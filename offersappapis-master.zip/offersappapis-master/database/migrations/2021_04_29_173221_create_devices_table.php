<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDevicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('devices', function (Blueprint $table) {
            $table->id();
            $table->integer('user_id');
            $table->string('ip');
            $table->string('device_type');
            $table->string('device_id');
            $table->string('fcm')->nullable();
            $table->string('version')->nullable();
            $table->string('app_version')->nullable();
            $table->timestamps();
            $table->timestamp('last_access_at')->default(date('Y-m-d H:i:s'));
            $table->tinyInteger('status')->default(1);
            $table->enum('user_type', ['driver', 'user', 'guest'])->default('driver')
                ->comment('driver-Mobile Device fcm token from drivers table id, user-Mobile Device fcm from users table id');
            $table->integer('converted_as')->nullable();
            $table->softDeletes('deleted_at');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('devices');
    }
}
