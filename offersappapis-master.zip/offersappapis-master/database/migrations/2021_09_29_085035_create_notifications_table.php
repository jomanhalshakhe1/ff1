<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNotificationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('notifications', function (Blueprint $table) {
            $table->id();
            $table->enum('notification_type',['I','G'])->default('I')->comment('I-Individual,G-Group');
            $table->integer('notification_for')->nullable();
            $table->string('notification_title', 255);
            $table->text('notification_message')->nullable();
            $table->integer('offer_id')->nullable();
            $table->integer('item_id')->nullable();
            $table->string('transaction_no',100)->nullable();
            $table->integer('created_by')->default(1);
            $table->timestamps();
            $table->tinyInteger('status')->default(1);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('notifications');
    }
}
