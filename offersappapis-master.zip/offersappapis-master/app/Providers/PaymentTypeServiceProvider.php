<?php

namespace App\Providers;

use App\Interfaces\PaymentTypeRepositoryInterface;
use App\Repositories\PaymentTypeRepository;
use Illuminate\Support\ServiceProvider;

class PaymentTypeServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        $this->app->bind( PaymentTypeRepositoryInterface::class, PaymentTypeRepository::class);
    }
}
