<?php

namespace App\Providers;

use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Listeners\SendEmailVerificationNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Event;

class EventServiceProvider extends ServiceProvider
{


    /**
     * The event listener mappings for the application.
     *
     * @var array
     */
    protected $listen = [
        Registered::class => [
            SendEmailVerificationNotification::class,
        ],

         \App\Events\SampleEvent::class=>[
            \App\Listeners\SampleListner::class,
        ],

        
        \App\Events\OrderRefunded::class=>[
            \App\Listeners\RefundNotification::class,
        ],

         \App\Events\OrderAdjustment::class=>[
            \App\Listeners\AdjustmentNotification::class,
        ],
          \App\Events\NewOrderPlaced::class=>[
            \App\Listeners\NewOrderNotification::class,
        ],

         \App\Events\RequestOfferAvailability::class=>[
            \App\Listeners\RequestOfferAvailityNotification::class,
        ],

        \App\Events\OfferRedeemed::class=>[
            \App\Listeners\OfferRedeemedNotification::class,
        ],
         \App\Events\AddressRequested::class=>[
            \App\Listeners\AddressRequestedNotification::class,
        ],
        
        \App\Events\sendAddressForOnsite::class=>[
            \App\Listeners\SendAddressNotification::class,
        ],

         \App\Events\NewOfferCreated::class=>[
            \App\Listeners\NewOfferNotification::class,
        ],

        \App\Events\SendGiftCredits::class=>[
            \App\Listeners\GiftCreditsNotification::class,
        ] ,
         \App\Events\offerAvailabilityUpdated::class=>[
            \App\Listeners\NotifyofferAvailabilityStatus::class,
        ]  ,
        \App\Events\cancelTranaction::class=>[
            \App\Listeners\NotifyCancelTransaction::class,
        ]  ,

        \App\Events\Emails\RefundCreatedEmail::class=>[
            \App\Listeners\Emails\NotifyEmailForRefundOffer::class,
        ] ,

        \App\Events\Emails\AdjustmentCreatedEmail::class=>[
            \App\Listeners\Emails\NotifyEmailForAdjustmentOffer::class,
        ] ,
        
        \App\Events\Emails\PurchasedAnOfferEmail::class=>[
            \App\Listeners\Emails\NotifyEmailForPurchasedOffer::class,
        ] ,

        \App\Events\Emails\RedeemedOfferEmail::class=>[
            \App\Listeners\Emails\NotifyEmailForRedeemedOffer::class,
        ],  

        \App\Events\Emails\EmailActivation::class=>[
            \App\Listeners\Emails\NotifyEmailActivation::class,
        ]  ,
        

        \App\Events\Emails\ChangeMobileNumber::class=>[
            \App\Listeners\Emails\NotifyChangeMobileNumber::class,
        ]  ,

        \App\Events\Emails\RegistrationSuccess::class=>[
            \App\Listeners\Emails\NotifyEmailForRegistration::class,
        ]  ,

          \App\Events\Emails\ConsumerCurrentLocationForAdmin::class=>[
            \App\Listeners\Emails\ConsumerCurrentLocationForAdminListener::class,
        ]  ,

        \App\Events\Emails\OfferAvailabilityStatusForAdmin::class=>[
            \App\Listeners\Emails\OfferAvailabilityStatusForAdminListener::class,
        ] ,

         \App\Events\Emails\VerifyEmailNotificationsEvent::class=>[
            \App\Listeners\Emails\VerifyEmailNotificationsListeners::class,
        ]  ,


    ];

    /**
     * Register any events for your application.
     *
     * @return void
     */
    public function boot()
    {
        parent::boot();

        //
    }
}
