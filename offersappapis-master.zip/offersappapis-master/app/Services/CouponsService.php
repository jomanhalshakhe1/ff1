<?php
/**
 * Created by PhpStorm.
 * User: Vijaya Lakshmi
 * Date: 18-08-2022
 * Time: 10:13 AM
 */

namespace App\Services;

use App\Repositories\CouponsRepository;

class CouponsService
{
    protected $repository;
    /**
     * BoxTypeService constructor.
     *
     * @param CouponsRepository $repository
     */
    public function __construct(CouponsRepository $repository)
    {
        $this->repository = $repository;
    }

     /**
     * Get all coupons details
     *
     * @return $data
     */
     
    function getAllCouponsList(){
        $totalrecords=$this->repository->getTotalRecordsCount();
        $data=$this->repository->getAllRecords();
        $data['total'] = $totalrecords;
        return $data;
    }
 

    /**
     * get coupons details by id.
     *
     * @param  $id
    */
     function getCouponById($id, $withArray){
        $result=$this->repository->findByIdWith($id, $withArray);
        return $result;
     }

    /**
     * Update coupon details.
     *
     * @param $id, $detailsArray
    */
    function updateCouponData($id, $detailsArray){
       return $this->repository->updateData($id, $detailsArray);
    }

     /**
     * Create new  coupon details.
     *
     * @param $detailsArray
     */
    function createCouponData($detailsArray){
       return $this->repository->insertGetId($detailsArray);
    }

     /**
     * Create new  coupon details.
     *
     * @param $detailsArray
     */
    function getCouponByCode($couponCode){
         $where = [
            ['code', '=', $couponCode],
            ['status', '=', 1],
        ];
       return $this->repository->where($where, true);
    }


}