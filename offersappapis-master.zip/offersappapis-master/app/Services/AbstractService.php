<?php
/**
 * Created by PhpStorm.
 * User: Vijaya Lakshmi
 * Date: 17/06/2022
 * Time: 04:27PM
 */

namespace App\Services;

abstract class AbstractService{
    protected $repository;
}