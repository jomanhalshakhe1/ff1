<?php
namespace App\Services\Contracts;

interface IBaseService
{

}
