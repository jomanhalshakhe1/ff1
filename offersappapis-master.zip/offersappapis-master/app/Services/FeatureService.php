<?php
/**
 * Created by PhpStorm.
 * User: Vijaya Lakshmi
 * Date: 19-08-2022
 * Time: 11:20 AM
 */

namespace App\Services;

use App\Repositories\FeaturesRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class FeatureService
{
    protected $repository;
    /**
     * FeatureService constructor.
     *
     * @param FeaturesRepository $repository
     */
    public function __construct(FeaturesRepository $repository)
    {
        $this->repository = $repository;
    }

     /**
     * Get all feature details
     *
     * @return $data
     */
     
    function getAllFeaturesList(){
        $arrayWith=array('main_menu','role_feature');
        $totalrecords=$this->repository->getTotalRecordsCount();
        $data=$this->repository->getAllRecords('',$arrayWith);
        $data['total'] = $totalrecords;
        return $data;
    }
 

    /**
     * get feature details by id.
     *
     * @param  $id
    */
     function getFeatureDataById($id){
        $arrayWith=array('main_menu','role_feature');
        $result=$this->repository->findByIdWith($id, $arrayWith);
        return $result;
     }

    /**
     * Update feature details.
     *
     * @param $id, $detailsArray
    */


    function updateFeaturesData($id, $detailsArray){
       return $this->repository->updateData($id, $detailsArray);
    }

     /**
     * Create new feature details.
     *
     * @param $detailsArray
     */
    function createFeaturesData($detailsArray){
       return $this->repository->insertGetId($detailsArray);
    }


    /**
     * get all main modules
     *
    */
    function getMainModules(){
       
       $where = [
            ['origin_id', '>', 0],
            ['status', '=', 1],
        ];
        $groupById='origin_id';
        $selectFields='origin_id';
        $mainIdsArray=array();
        $mainIds=$this->repository->groupById($selectFields, $groupById, $where);

        foreach($mainIds as $row) {
           $mainIdsArray[]=$row->origin_id;
        }
        
        return $this->repository->whereIn('id', $mainIdsArray);
    }

}