<?php
/**
 * Created by PhpStorm.
 * User: Vijaya Lakshmi
 * Date: 18-08-2022
 * Time: 10:13 AM
 */

namespace App\Services;

use App\Repositories\CouponLogsRepository;
use Illuminate\Support\Facades\Auth;

class CouponsLogsService
{
    protected $repository;
    /**
     * BoxTypeService constructor.
     *
     * @param CouponLogsRepository $repository
     */
    public function __construct(CouponLogsRepository $repository)
    {
        $this->repository = $repository;
    }

     /**
     * Create new  coupon logs details.
     *
     * @param $detailsArray
     */
    function createCouponLogsData($detailsArray){
        $where = [
            ['transaction_no', '=', null],
            ['driver_id', '=', Auth::guard('driver')->id()]
        ];

        if($this->repository->whereCount($where) > 0){
            $where['id'] = $this->repository->where($where, true)->id;
            $this->repository->updateWhereData($where, $detailsArray);
            return $where['id'];
        }
        else{
            $detailsArray['created_at']=date("Y-m-d H:i:s");
            return $this->repository->insertGetId($detailsArray);
        }
    }

    /**
     * Create new  coupon details.
     *
     * @param $detailsArray
     */
    function getTotalCodeApply($couponCode){
         $where = [
            ['coupon_code', '=', $couponCode],
            ['status', '=', 1],
        ];
       return $this->repository->whereCount($where, true);
    }



    /**
     * Update coupon logs details.
     *
     * @param $id, $detailsArray
    */
    function updateCouponLogsData($orderId, $detailsArray){
       $where = [
            ['transaction_no', '=', $orderId]
        ];
       return $this->repository->updateWhereData($where, $detailsArray);
    }


     /**
     * Create new  coupon details.
     *
     * @param $detailsArray
     */
    function getCustomerTotalCodeApply($couponCode){
         $where = [
            ['driver_id', '=', Auth::guard('driver')->id()],
            ['coupon_code', '=', $couponCode],
            ['status', '=', 1],
        ];
       return $this->repository->whereCount($where, true);
    }

    function getCustomerCouponAvailableCount(){
        $where = [
            ['transaction_no', '=', null],
            ['driver_id', '=', Auth::guard('driver')->id()]
        ];
        return $this->repository->whereCount($where);
    }

    function getCustomerCouponAvailableInfo(){
        $where = [
            ['transaction_no', '=', null],
            ['driver_id', '=', Auth::guard('driver')->id()]
        ];
        return $this->repository->where($where, true);
    }
}