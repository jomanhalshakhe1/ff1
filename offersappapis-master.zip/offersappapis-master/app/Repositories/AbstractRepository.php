<?php
/**
 * Created by PhpStorm.
 * User: Vijaya Lakshmi
 * Date: 20-06-2022
 * Time: 09:30
 */

namespace App\Repositories;


use App\Interfaces\BaseInterface;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class AbstractRepository implements BaseInterface
{
    
    protected $model;

    /**
     * AbstractRepository constructor.
     *
     * @param Model $model
     */

    public function __construct(Model $model){
        $this->model = $model;

    }


     /**
     * Get Data based on the any condition
     *
     * @param $criteria
     */

    public function findOneBy( $criteria){
        return $this->model->where($criteria)->first();
    }

     /**
     * Get Data based on the where condition
     *
     * @param $criteria
     */


    public function where( $where, $first = false) {
        if($first){
            $result = $this->model->where($where)->first();
        }else{
            $result = $this->model->where($where)->get();
        }
        return $result;
    }

    
     /**
     * Get data based on the id
     * @param $id
     */

    public function findById($id){
        return $this->model->find( $id );
    }

     /**
     * Get data based on the id
     * @param $id
     */

    public function findByIdWith($id, $withArray = []){
        $list = $this->model;
        if(count($withArray)>0){
            $list =$list->with($withArray);
        }
        $list =$list->where('id', $id)->first();   
        return $list;
    }

     /**
     * Get data based on the id
     * @param $id
     */

    public function getTotalRecordsCount($where = []){


        if(count($where)>0){
            $list =$this->model->where($where)->count();
        } else {
            return $this->model->count();
        }
        
    }

    /**
    * Get all the records based on the no. of records for each request
    * @param $id
    */

    public function getAllRecords($where = [], $withArray = []){

        $pageno = 1; $pagelength = 10;
        if (isset(request()->pagelength, request()->pageno) && !empty(request()->pagelength)) {
            $pagelength = request()->pagelength;
            $pageno = request()->pageno;
        }

        $list = $this->model;
        
        if(count($withArray)>0){
            $list =$list->with($withArray);
        }

        if(count($where)>0){
            $list =$list->where($where);
        }

        $list =$list->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['per_page'] = $pagelength;
        return $data;
    }



    public function getActiveRecords($where = [], $orderBy='DESC'){
        $pageno = 1; $pagelength = 250;
        if (isset(request()->pagelength, request()->pageno) && !empty(request()->pagelength)) {
            $pagelength = request()->pagelength;
            $pageno = request()->pageno;
        }

        $list = $this->model->where('status', 1)->orderBy('id', $orderBy)
            ->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['per_page'] = $pagelength;
        return $data;
    }


    public function getAllActiveRecords($orderBy='DESC'){
        
        $list = $this->model->where('status', 1)->orderBy('id', $orderBy)->get();

        $data['data'] = $list;
        return $data;
    }
    function updateData($id, $arrDetails){
        $result = $this->model->find($id);
        if ($result) {
            $result->update($arrDetails);
            return $result;
        }

        return false;
    }

    function updateWhereData($where = [], $arrDetails){
      return $this->model->where($where)->update($arrDetails);
    }

    function createNew($arrDetails){      
        if($this->model->insert($arrDetails)){
            return true;
        }
        return false;
    }

     /**
     * Get inserted data id
     * @param $arrDetails
     */
    function insertGetId($arrDetails){      
        return $this->model->insertGetId($arrDetails);
    }


    /**
     * Get data based on the where condition or group by
     * @param $id
     */

    public function groupById($selectFields, $groupById, $where = []){
        $query=$this->model->select($selectFields);
        if(count($where)>0){
           $query=$query->where($where);
        } 
        return $query->groupBy($groupById)->get();
    }

    /**
     * Get data based on the wherein condition or group by
     * @param $id
     */

     public function whereIn( $column, array $array) {
       return $this->model->whereIn($column, $array)->get();
    }


      /**
     * Get count based on the where condition
     *
     * @param $criteria
     */
    public function whereCount( $where) {      
       return $this->model->where($where)->count();      
    }


}