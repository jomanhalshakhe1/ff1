<?php
/**
 * Created by PhpStorm.
 * User: Vijaya Lakshmi
 * Date: 18-08-2022
 * Time: 10:14 AM
 */

namespace App\Repositories;

use App\Models\Generals\Coupons\Coupon;
use App\Models\Generals\Coupons\CouponDeal;
use App\Models\Generals\Coupons\CouponPartner;
use App\Repositories\contracts\ICouponsRepository;

class CouponsRepository extends AbstractRepository implements ICouponsRepository
{

    /**
     * @var Coupon
     */
    protected $coupons;

    /**
     * couponssRepository constructor.
     *
     * @param Coupon $coupons
     */
    public function __construct(Coupon $coupons)
    {
        $this->coupons = $coupons;
        parent::__construct($this->coupons);
    }

    public function update_coupon_partners($coupon_id, $partnersArray){
        CouponPartner::where('coupon_id', $coupon_id)->delete();
        CouponPartner::insert($partnersArray);
    }

    public function update_coupon_deals($coupon_id, $dealsArray){
        CouponDeal::where('coupon_id', $coupon_id)->delete();
        CouponDeal::insert($dealsArray);
    }
}