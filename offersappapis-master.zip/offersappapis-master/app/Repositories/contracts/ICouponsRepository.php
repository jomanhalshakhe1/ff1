<?php
/**
 * Created by PhpStorm.
 * User: Vijaya Lakshmi
 * Date: 18-08-2022
 * Time: 10:14 AM
 */

namespace App\Repositories\contracts;

use App\Interfaces\BaseInterface;


interface ICouponsRepository extends BaseInterface
{
    
}