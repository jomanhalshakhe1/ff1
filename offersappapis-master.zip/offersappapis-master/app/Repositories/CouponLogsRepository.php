<?php
/**
 * Created by PhpStorm.
 * User: Vijaya Lakshmi
 * Date: 18-08-2022
 * Time: 10:14 AM
 */

namespace App\Repositories;

use App\Models\Generals\Coupons\CouponLog;
use App\Repositories\contracts\ICouponLogsRepository;

class CouponLogsRepository extends AbstractRepository implements ICouponLogsRepository
{

    /**
     * @var CouponLog
     */
    protected $couponLogs;

    /**
     * CouponLogsRepository constructor.
     *
     * @param CouponLog $couponLogs
     */
    public function __construct(CouponLog $couponLogs)
    {
        $this->couponLogs = $couponLogs;
        parent::__construct($this->couponLogs);
    }

    
}