<?php
/**
 * Created by PhpStorm.
 * User: Uday
 * Date: 19-05-2022
 * Time: 13:39
 */

namespace App\Repositories;


class SharesRepository
{
    /**
     * Return admin share under transaction
     *
     * @return $savings
     */
    public function admin_shares($row)
    {
        $discountedShareJoy = $row['price'] * $row['discount'] / 100;
        $basePriceAfterDiscount = $row['price'] - $discountedShareJoy;
        $customerDiscountAmount = $discountedShareJoy * (100 - $row['joy_share']) / 100;
        $JOYshareRemaingAfterCustomerShare = $discountedShareJoy - $customerDiscountAmount;
        $priceAfterCustomerDiscount = $basePriceAfterDiscount + $JOYshareRemaingAfterCustomerShare;
        $fleetExtraDiscount = $JOYshareRemaingAfterCustomerShare * $row['partner_discount'] / 100;
        $PriceWithFleetExtraDiscount = $priceAfterCustomerDiscount - $fleetExtraDiscount;
        $savings = ($row['price'] - $PriceWithFleetExtraDiscount) * $row['redeem_quantity'];

        return $savings;
    }

    /**
     * Return delar share under transaction
     *
     * @return $savings
     */
    public function delar_shares($row)
    {
        $discountedShareJoy = $row['price'] * $row['discount'] / 100;
        $basePriceAfterDiscount = $row['price'] - $discountedShareJoy;
        $customerDiscountAmount = $discountedShareJoy * (100 - $row['joy_share']) / 100;
        $JOYshareRemaingAfterCustomerShare = $discountedShareJoy - $customerDiscountAmount;
        $priceAfterCustomerDiscount = $basePriceAfterDiscount + $JOYshareRemaingAfterCustomerShare;
        $fleetExtraDiscount = $JOYshareRemaingAfterCustomerShare * $row['partner_discount'] / 100;
        $PriceWithFleetExtraDiscount = $priceAfterCustomerDiscount - $fleetExtraDiscount;
        $savings = ($row['price'] - $PriceWithFleetExtraDiscount) * $row['redeem_quantity'];

        return $savings;
    }

    /**
     * Return partner share under transaction
     *
     * @return $savings
     */
    public function partner_shares($row)
    {
        $discountedShareJoy = $row['price'] * $row['discount'] / 100;
        $basePriceAfterDiscount = $row['price'] - $discountedShareJoy;
        $customerDiscountAmount = $discountedShareJoy * (100 - $row['joy_share']) / 100;
        $JOYshareRemaingAfterCustomerShare = $discountedShareJoy - $customerDiscountAmount;
        $priceAfterCustomerDiscount = $basePriceAfterDiscount + $JOYshareRemaingAfterCustomerShare;
        $fleetExtraDiscount = $JOYshareRemaingAfterCustomerShare * $row['partner_discount'] / 100;
        $PriceWithFleetExtraDiscount = $priceAfterCustomerDiscount - $fleetExtraDiscount;
        $savings = ($row['price'] - $PriceWithFleetExtraDiscount) * $row['redeem_quantity'];

        return $savings;
    }


    /**
     * Return savings under transaction
     *
     * @return $savings
     */
    public function savings($row)
    {
        $discountedShareJoy = $row['price'] * $row['discount'] / 100;
        $basePriceAfterDiscount = $row['price'] - $discountedShareJoy;
        $customerDiscountAmount = $discountedShareJoy * (100 - $row['joy_share']) / 100;
        $JOYshareRemaingAfterCustomerShare = $discountedShareJoy - $customerDiscountAmount;
        $priceAfterCustomerDiscount = $basePriceAfterDiscount + $JOYshareRemaingAfterCustomerShare;
        $fleetExtraDiscount = $JOYshareRemaingAfterCustomerShare * $row['partner_discount'] / 100;
        $PriceWithFleetExtraDiscount = $priceAfterCustomerDiscount - $fleetExtraDiscount;
        $savings = ($row['price'] - $PriceWithFleetExtraDiscount) * $row['redeem_quantity'];

        return $savings;
    }
}