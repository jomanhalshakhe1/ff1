<?php

namespace App\Repositories;
use App\Interfaces\PaymentTypeRepositoryInterface;
use App\Models\Generals\Lookup;

/**
 * Created by PhpStorm.
 * User: Uday
 * Date: 26-04-2022
 * Time: 17:36
 */
class PaymentTypeRepository implements PaymentTypeRepositoryInterface
{
    public function all(){
        $pageno = 1; $pagelength = 10;
        $list = Lookup::where('group_id', 7);
        $totalrecords = $list->count();
        if (isset(request()->pagelength, request()->pageno) && !empty(request()->pagelength)) {
            $pagelength = request()->pagelength;
            $pageno = request()->pageno;
        }
        $list = $list->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;

        return $data;
    }

    public function findById($paymentTypeId){
        return Lookup::where('id', $paymentTypeId)->firstOrFail();
    }

    public function update($paymentTypeId){

        //$paymentType = Lookup::where('id', $paymentTypeId)->firstOrFail();

        Lookup::where('id', $paymentTypeId)->update(request()->only(['entity_name', 'status']));
    }
}