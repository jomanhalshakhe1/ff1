<?php

namespace App\Listeners;

use App\Events\NewOrderPlaced;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

use App\Http\Controllers\Generals\NotificationController;
use App\Models\Accounts\Transaction;
use App\Models\Inventory\ItemOffer;

class NewOrderNotification
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  NewOrderPlaced  $event
     * @return void
     */
    public function handle(NewOrderPlaced $event)
    {

        $transaction = Transaction::where('transaction_no', $event->transaction_no)->first();

        if(!$transaction)
            return false;


         $itemData = ItemOffer::where('id', $transaction['offer_id'])->first();

         $isAdminNotification=0;
         $isTechnicianNotification=0;
         if($itemData->on_site=='1' || $itemData->is_notify=='1'){ 
            $isAdminNotification=1;
            $isTechnicianNotification=1;
         }

         (new NotificationController())->getNotificationFormates($event->transaction_no, $event->notification_for, $transaction, $event->purchasedAmount,'1', $isAdminNotification, $isTechnicianNotification);
    }
}
