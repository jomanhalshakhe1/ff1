<?php

namespace App\Listeners\Emails;

use App\Events\Emails\RedeemedOfferEmail;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Http\Controllers\Generals\EmailController;
class NotifyEmailForRedeemedOffer
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  RedeemedOfferEmail  $event
     * @return void
     */
    public function handle(RedeemedOfferEmail $event)
    {
          (new EmailController())->sendRedeemOfferNotification($event->transaction_no, $event->quantity, '1', '0', '0');
    }
}
