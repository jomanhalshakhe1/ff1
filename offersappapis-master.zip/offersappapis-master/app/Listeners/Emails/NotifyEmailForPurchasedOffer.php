<?php

namespace App\Listeners\Emails;

use App\Events\Emails\PurchasedAnOfferEmail;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Http\Controllers\Generals\EmailController;

class NotifyEmailForPurchasedOffer
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  PurchasedAnOfferEmail  $event
     * @return void
     */
    public function handle(PurchasedAnOfferEmail $event)
    {
        (new EmailController())->sendPurchasedOfferNotification($event->transaction_no, '1', '0', '0');
    }
}
