<?php

namespace App\Listeners\Emails;

use App\Events\Emails\ChangeMobileNumber;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

use App\Http\Controllers\Generals\EmailController;

class NotifyChangeMobileNumber
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  ChangeMobileNumber  $event
     * @return void
     */
    public function handle(ChangeMobileNumber $event)
    {
        (new EmailController())->sendEmaiNotification($event->emailId, $event->name,  $event->otp, $event->userType, $event->templateId);
    }
}
