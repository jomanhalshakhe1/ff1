<?php

namespace App\Listeners\Emails;

use App\Events\Emails\RegistrationSuccess;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Http\Controllers\Generals\EmailController;

class NotifyEmailForRegistration
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  RegistrationSuccess  $event
     * @return void
     */
    public function handle(RegistrationSuccess $event)
    {
        (new EmailController())->sendEmaiNotification($event->emailId, $event->name,  $event->otp, $event->userType, $event->templateId);
    }
}
