<?php

namespace App\Listeners\Emails;

use App\Events\Emails\OfferAvailabilityStatusForAdmin;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Http\Controllers\Generals\EmailController;
class OfferAvailabilityStatusForAdminListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  OfferAvailabilityStatusForAdmin  $event
     * @return void
     */
    public function handle(OfferAvailabilityStatusForAdmin $event)
    {
         (new EmailController())->sendOfferAvailabilityStatus($event->transaction_no, $event->is_available);
    }
}
