<?php

namespace App\Listeners\Emails;

use App\Events\Emails\VerifyEmailNotificationsEvent;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Http\Controllers\Generals\EmailController;

class VerifyEmailNotificationsListeners
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  VerifyEmailNotificationsEvent  $event
     * @return void
     */
    public function handle(VerifyEmailNotificationsEvent $event)
    {
        (new EmailController())->sendEmaiNotification($event->emailId, $event->name,  $event->otp, $event->userType, $event->templateId);
    }
}
