<?php

namespace App\Listeners\Emails;

use App\Events\Emails\EmailActivation;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Http\Controllers\Generals\EmailController;

class NotifyEmailActivation
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  EmailActivation  $event
     * @return void
     */
    public function handle(EmailActivation $event)
    {
         (new EmailController())->sendEmaiNotification($event->emailId, $event->name,  $event->otp, $event->userType, $event->templateId);
    }
}
