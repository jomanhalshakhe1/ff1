<?php

namespace App\Listeners\Emails;
use App\Events\Emails\AdjustmentCreatedEmail;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Http\Controllers\Generals\EmailController;

class NotifyEmailForAdjustmentOffer
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  AdjustmentCreatedEmail  $event
     * @return void
     */
    public function handle(AdjustmentCreatedEmail $event)
    {

        (new EmailController())->sendAdjustAmountNotification($event->transaction_no, $event->adjustmentAmount,'1', '0', '0');
    }
}
