<?php

namespace App\Listeners;

use App\Events\EmailforRefundCreated;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class NotifyEmailforRefund
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        
    }

    /**
     * Handle the event.
     *
     * @param  EmailforRefundCreated  $event
     * @return void
     */
    public function handle(EmailforRefundCreated $event)
    {
        echo "event Listeners";

    }
}
