<?php

namespace App\Listeners;

use App\Events\SendGiftCredits;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Http\Controllers\Generals\NotificationController;
use App\Models\Generals\NotificationsFormats;

class GiftCreditsNotification
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  SendGiftCredits  $event
     * @return void
     */
    public function handle(SendGiftCredits $event)
    {
        if($event->isNewFormate){
            (new NotificationController())->sendNewFormateGiftCreditsToConsumer($event->giftAmount, $event->consumersList, 39, $event->notificationFormat);
        } else {
            (new NotificationController())->sendGiftCreditsToConsumer($event->giftAmount, $event->consumersList, 39, $event->notificationFormat);
        } 
    }
}
