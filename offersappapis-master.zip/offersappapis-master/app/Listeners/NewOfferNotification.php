<?php

namespace App\Listeners;

use App\Events\NewOfferCreated;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Http\Controllers\Generals\NotificationController;


class NewOfferNotification
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  NewOfferCreated  $event
     * @return void
     */
    public function handle(NewOfferCreated $event)
    {
        // (new NotificationController())->sendNewOfferNotification($event->itemId, $event->dealType, $event->offerId, $event->notification_for);
    }
}
