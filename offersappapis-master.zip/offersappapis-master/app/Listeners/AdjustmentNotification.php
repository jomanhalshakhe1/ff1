<?php

namespace App\Listeners;

use App\Events\OrderAdjustment;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

use App\Http\Controllers\Generals\NotificationController;
use App\Models\Accounts\Transaction;

class AdjustmentNotification
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  OrderAdjustment  $event
     * @return void
     */
    public function handle(OrderAdjustment $event)
    {
          $transaction = Transaction::where('transaction_no', $event->transaction_no)->first();

        if(!$transaction)
            return false;

         (new NotificationController())->getNotificationFormates($event->transaction_no, $event->notification_for, $transaction, $event->adjustmentAmount,'1', '1','0');
    }
}
