<?php

namespace App\Listeners;

use App\Events\offerAvailabilityUpdated;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Http\Controllers\Generals\NotificationController;
use App\Models\Accounts\Transaction;
use App\Http\Controllers\Generals\DealController;

class NotifyofferAvailabilityStatus
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  offerAvailabilityUpdated  $event
     * @return void
     */
    public function handle(offerAvailabilityUpdated $event)
    {
        $transaction = Transaction::where('transaction_no', $event->transaction_no)->first();

        if(!$transaction)
            return false;

        $actionType='Available';
        if($event->is_available==2)
           $actionType='Cancelled';
        else if($event->is_available==0)
           $actionType='Rejected';

        $dealShare = new DealController();
        $pricing = $dealShare->bill_price_logic($transaction['transaction_no']);
        $finalPrice = $pricing['final_price'];

         (new NotificationController())->getNotificationFormates($event->transaction_no, $event->notification_for, $transaction, $finalPrice, '1', '1','1', $actionType);
    }
}
