<?php

namespace App\Listeners;

use App\Events\cancelTranaction;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Http\Controllers\Generals\NotificationController;
use App\Models\Accounts\Transaction;

class NotifyCancelTransaction
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  cancelTranaction  $event
     * @return void
     */
    public function handle(cancelTranaction $event)
    {
        $transaction = Transaction::where('transaction_no', $event->transaction_no)->first();

        if(!$transaction)
            return false;
        
        (new NotificationController())->getNotificationFormates($event->transaction_no, $event->notification_for, $transaction, '','1', '1','1', $event->actionType);
    }
}
