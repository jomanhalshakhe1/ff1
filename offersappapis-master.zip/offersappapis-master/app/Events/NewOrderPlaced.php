<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;


class NewOrderPlaced
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $transaction_no;
    public $notification_for;
    public $purchasedAmount;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct($transaction_no, $notification_for, $purchasedAmount)
    {
        $this->transaction_no=$transaction_no;
        $this->notification_for=$notification_for;
        $this->purchasedAmount=$purchasedAmount;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
