<?php
/**
 * Created by PhpStorm.
 * User: Vijaya Lakshmi
 * Date: 20-06-2022
 * Time: 14:13
 */

namespace App\Interfaces;


/**
 * Created by PhpStorm.
 * User: Vijaya Lakshmi
 * Date: 20-06-2022
 * Time: 14:13
 */
interface BaseInterface
{
   public function findById($id);

   public function findOneBy($criteria);

   public function getTotalRecordsCount();

   public function getAllRecords();

   public function getAllActiveRecords();
   
   public function updateData($id, $data);

   public function updateWhereData($where, $data);

   public function createNew($data);

   public function insertGetId($data);

   public function where($where, $first = false);

   public function whereCount($where);
   
   public function groupById($selectFields, $groupById, $where = []);

   public function whereIn($column, array $array);


}