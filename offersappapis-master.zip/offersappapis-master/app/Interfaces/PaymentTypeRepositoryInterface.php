<?php
/**
 * Created by PhpStorm.
 * User: Uday
 * Date: 26-04-2022
 * Time: 18:14
 */

namespace App\Interfaces;


/**
 * Created by PhpStorm.
 * User: Uday
 * Date: 26-04-2022
 * Time: 17:36
 */
interface PaymentTypeRepositoryInterface
{
    public function all();

    public function findById($paymentTypeId);

    public function update($paymentTypeId);
}