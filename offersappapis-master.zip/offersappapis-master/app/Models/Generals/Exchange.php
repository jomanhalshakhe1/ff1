<?php

namespace App\Models\Generals;

use App\Models\Regulatory\Organization;
use Illuminate\Database\Eloquent\Model;

class Exchange extends Model
{
    protected $fillable = ['payment_to', 'amount_paid', 'created_by', 'paid_date'];

    public function company()
    {
        return $this->hasOne(Organization::class,'id','payment_to');
    }
}
