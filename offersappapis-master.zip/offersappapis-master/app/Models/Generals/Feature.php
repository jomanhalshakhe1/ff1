<?php

namespace App\Models\Generals;

use Illuminate\Database\Eloquent\Model;

class Feature extends Model
{
    public function main_feature()
    {
        return $this->belongsTo(Feature::class,'origin_id','id');
    }
}
