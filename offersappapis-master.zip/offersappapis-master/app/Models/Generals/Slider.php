<?php

namespace App\Models\Generals;

use Illuminate\Database\Eloquent\Model;

class Slider extends Model
{
    protected $fillable = ['title', 'thumbnail_url'];
}
