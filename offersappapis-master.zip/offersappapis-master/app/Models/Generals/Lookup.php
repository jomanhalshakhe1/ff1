<?php

namespace App\Models\Generals;

use Illuminate\Database\Eloquent\Model;

class Lookup extends Model
{
    protected $table = 'lookup';
    public $timestamps = false;
}
