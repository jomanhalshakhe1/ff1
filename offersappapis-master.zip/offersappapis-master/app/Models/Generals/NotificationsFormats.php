<?php

namespace App\Models\Generals;

use Illuminate\Database\Eloquent\Model;

class NotificationsFormats extends Model
{
     protected $table = 'notifications_formates';
}
