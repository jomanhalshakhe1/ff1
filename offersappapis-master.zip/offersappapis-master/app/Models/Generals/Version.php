<?php

namespace App\Models\Generals;

use Illuminate\Database\Eloquent\Model;

class Version extends Model
{
    //Get total users foreach version
    public function userlist(){
         return $this->hasMany(Device::class,'app_version','version_no');
    }

 	//Get total users foreach version
    public function device_userlist(){
         return $this->hasMany(Device::class,'app_version','version_no');
    }
}
