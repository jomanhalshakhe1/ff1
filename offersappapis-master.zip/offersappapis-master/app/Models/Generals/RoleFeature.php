<?php

namespace App\Models\Generals;

use Illuminate\Database\Eloquent\Model;

class RoleFeature extends Model
{
    public function features_list()
    {
        return $this->belongsTo(Feature::class,'feature_id','id');
    }

 
}
