<?php

namespace App\Models\Generals;

use Illuminate\Database\Eloquent\Model;

class AppNavigationUrl extends Model
{
    protected $guarded = [];
}
