<?php

namespace App\Models\Generals;

use Illuminate\Database\Eloquent\Model;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use App\Models\Accounts\Transaction;
use App\Models\Generals\NotificationLog;
use App\Models\Regulatory\Location;
use App\Models\Accounts\User;

class Notification extends Model
{
    protected $table = 'notifications';

    public $timestamps = false;

    public function deal()
    {
        return $this->belongsTo(ItemMaster::class,'item_id','id');
    }
    public function offer()
    {
        return $this->belongsTo(ItemOffer::class,'offer_id','id');
    }
    public function transaction()
    {
        return $this->belongsTo(Transaction::class,'transaction_no','transaction_no');
    }

    //Individual notifictions
    public function custom_individual(){
         return $this->hasMany(NotificationLog::class,'notification_id','id')->where('group_id', 0);
    }

    // Group notifications
    public function custom_groups(){
        return $this->hasMany(NotificationLog::class,'notification_id')->with('group_info')->where('group_id', '>', 0)->orderBy('group_id','ASC')->select('group_id' ,'notification_id')->groupBy('group_id','notification_id');
    }

    // get Location
    public function location_info(){
        return $this->belongsTo(Location::class,'location_id','id');
    }

    //get created user details
    public function created_user(){
        return $this->belongsTo(User::class,'created_by','id');
    }

    //get inapp notifications read user details
    public function inapp_views(){
        return $this->hasMany(NotificationLog::class,'notification_id','id')->whereNotNull('read_at');
    }

    //get popup notifications read user details
    public function popup_views(){
        return $this->hasMany(NotificationLog::class,'notification_id','id')->whereNotNull('read_popup_at');
    }

}
