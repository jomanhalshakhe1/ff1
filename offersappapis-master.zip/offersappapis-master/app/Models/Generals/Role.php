<?php

namespace App\Models\Generals;

use App\Models\Accounts\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Role extends Model
{
    public function role_type()
    {
       return $this->belongsTo(Lookup::class, 'login_type_id', 'id');
    }

    public function users()
    {   
        $login_type_id = Role::where('id', Auth::user()->role_id)->pluck('login_type_id')->first();
        if($login_type_id!=17)
            return $this->hasMany(User::class,'role_id','id')->where('org_id',Auth::user()->org_id);
        else
            return $this->hasMany(User::class,'role_id','id');
    }
}
