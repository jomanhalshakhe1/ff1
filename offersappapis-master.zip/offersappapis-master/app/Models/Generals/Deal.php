<?php

namespace App\Models\Generals;

use Illuminate\Database\Eloquent\Model;

class Deal extends Model
{
    //
}
