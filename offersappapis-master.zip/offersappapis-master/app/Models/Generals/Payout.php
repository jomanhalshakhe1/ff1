<?php

namespace App\Models\Generals;

use App\Models\Regulatory\Organization;
use Illuminate\Database\Eloquent\Model;

class Payout extends Model
{
    public function company()
    {
        return $this->hasOne(Organization::class,'id','payment_to');
    }
}
