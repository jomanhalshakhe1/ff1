<?php

namespace App\Models\Generals;

use Illuminate\Database\Eloquent\Model;

class Manufacturer extends Model
{
    protected $fillable = [
         'title',
         'status', 
         'thumbnail_url',
     ];
}
