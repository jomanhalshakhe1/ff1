<?php

namespace App\Models\Generals\Coupons;

use Illuminate\Database\Eloquent\Model;

class Coupon extends Model
{
    protected $guarded = [];

    public function deals() {
        return $this->hasMany(CouponDeal::class,'coupon_id','id')
            ->join('deals', 'deals.id', 'coupon_deals.deal_id')
            ->select('coupon_deals.*')->selectRaw( 'deals.title as deal_name');
    }

    public function partners() {
        return $this->hasMany(CouponPartner::class,'coupon_id','id')
            ->join('organizations', 'organizations.id', 'coupon_partners.org_id')
            ->select('coupon_partners.*', 'organizations.org_name');
    }
}
