<?php

namespace App\Models\Generals\Coupons;

use Illuminate\Database\Eloquent\Model;

class CouponLog extends Model
{
    protected $guarded = [];

    function customer_info(){
    	 return $this->belongsTo('App\Models\Accounts\Driver','driver_id','id');
    }

    function transaction_info(){
    	return $this->belongsTo('App\Models\Accounts\Transaction','transaction_no','transaction_no');
    }

     function coupon_info(){
        return $this->belongsTo('App\Models\Generals\Coupons\Coupon','coupon_id','id');
    }
}
