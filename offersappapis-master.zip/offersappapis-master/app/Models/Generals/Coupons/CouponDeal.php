<?php

namespace App\Models\Generals\Coupons;

use Illuminate\Database\Eloquent\Model;

class CouponDeal extends Model
{
    //
}
