<?php

namespace App\Models\Generals;

use Illuminate\Database\Eloquent\Model;
use App\Models\Accounts\Driver;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
class Feedback extends Model
{
    protected $table = 'feedbacks';

    public function customer()
    {
        return $this->belongsTo(Driver::class,'customer_id','id')->withTrashed();
    }
    public function item()
    {
        return $this->belongsTo(ItemMaster::class,'item_id','id');
    }
    public function offer()
    {
        return $this->belongsTo(ItemOffer::class,'offer_id','id');
    }
}
