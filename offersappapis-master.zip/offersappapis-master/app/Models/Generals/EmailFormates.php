<?php

namespace App\Models\Generals;

use Illuminate\Database\Eloquent\Model;

class EmailFormates extends Model
{
      protected $table = 'email_formates';
}
