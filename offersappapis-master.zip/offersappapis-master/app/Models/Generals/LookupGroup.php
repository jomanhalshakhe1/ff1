<?php

namespace App\Models\Generals;

use Illuminate\Database\Eloquent\Model;

class LookupGroup extends Model
{
    protected $table = 'lookup_group';
}
