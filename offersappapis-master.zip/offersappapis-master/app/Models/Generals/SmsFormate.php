<?php

namespace App\Models\Generals;

use Illuminate\Database\Eloquent\Model;

class SmsFormate extends Model
{
    //
}
