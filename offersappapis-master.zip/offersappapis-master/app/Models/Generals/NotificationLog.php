<?php

namespace App\Models\Generals;
use App\Models\Accounts\ConsumerGroup;
use App\Models\Accounts\User;
use  App\Models\Accounts\Driver;
use App\Models\Generals\Device;

use Illuminate\Database\Eloquent\Model;
class NotificationLog extends Model
{
    protected $table = 'notifications_log';
    public $timestamps = false;

    //Get customer group name
    public function group_info()
    {
        return $this->belongsTo(ConsumerGroup::class,'group_id','id');
    }


    //Get user details
    public function customer_info()
    {
        return $this->belongsTo(Driver::class,'notification_to','id');
    }

    //Get guest user details
    public function guest_users()
    {
        return $this->belongsTo(Device::class,'notification_to','id');
    }

    //Get technicians details
    public function technicians_list()
    {
        return $this->belongsTo(User::class,'notification_to','id');
    }

    //Get unregistered details
    public function unregistered_users()
    {
        return $this->belongsTo(Device::class,'notification_to','id');
    }

    //Get unregistered details
    public function notification_list()
    {
        return $this->belongsTo(Notification::class,'notification_id','id')->where('is_sent','1');
    }
    
}
