<?php

namespace App\Models\Generals;

use App\Models\Accounts\User;
use Illuminate\Database\Eloquent\Model;

class RedeemLog extends Model
{
    //
    protected $table = 'redeem_log';

    public function scanner()
    {
        return $this->belongsTo(User::class,'redeem_by','id')->withTrashed();
    }
}
