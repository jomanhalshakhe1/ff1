<?php

namespace App\Models\Regulatory;

use Illuminate\Database\Eloquent\Model;

class TechnicianLocation extends Model
{
    public function location()
    {
        return $this->hasMany(Location::class,'id','location_id');
    }
}
