<?php

namespace App\Models\Regulatory;

use App\Models\Accounts\User;
use Illuminate\Database\Eloquent\Model;

class Maker extends Model
{
    protected $table = 'organizations';
    protected $guarded = ['id'];

    public function location()
    {
        return $this->hasMany(Location::class,'org_id','id')
            ->join('cities', 'locations.city', '=', 'cities.id')
            ->select('locations.*', 'cities.city as city', 'cities.latitude as citylatitude', 'cities.longitude as citylongitude', 'cities.id as cityid');
    }

    public function locations()
    {
        //return $this->hasMany(Location::class,'org_id','id');
        return $this->hasMany(Location::class,'org_id','id')->leftjoin('cities', 'locations.city', '=', 'cities.id')->select('locations.*', 'cities.city as city');
    }

    public function user()
    {
        return $this->hasOne(User::class,'org_id','id')
            ->where('users.role_id','2')->withTrashed();
    }

}
