<?php

namespace App\Models\Regulatory;

use App\Models\Accounts\FleetDriver;
use App\Models\Accounts\User;
use Illuminate\Database\Eloquent\Model;
use App\Models\Accounts\ConsumerGroup;

class Fleet extends Model
{
    protected $table = 'organizations';
    protected $guarded = ['id'];

    public function location()
    {
        //return $this->belongsTo(Location::class,'id','org_id');
        return $this->belongsTo(Location::class,'id','org_id')
            ->leftjoin('cities', 'locations.city', '=', 'cities.id')
            ->select('locations.*', 'cities.city as city')
            ->selectRaw('locations.city as city_id');
    }

    public function user()
    {
        return $this->hasOne(User::class,'org_id','id')
            ->where('users.role_id','6')->withTrashed();
    }

    public function groups_list()
    {
        return $this->hasMany(ConsumerGroup::class,'id','company');   
    }

    public function drivers()
    {
        return $this->belongsTo(FleetDriver::class,'id', 'fleet_id')
            ->whereNotNull('driver_id');
    }
}
