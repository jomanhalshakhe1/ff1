<?php

namespace App\Models\Regulatory;

use App\Models\Generals\City;
use Illuminate\Database\Eloquent\Model;

class Location extends Model
{
    public function city(){
        return $this->belongsTo(City::class,'city','id');
    }
}
