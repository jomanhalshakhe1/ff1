<?php

namespace App\Models\Regulatory;


use Illuminate\Database\Eloquent\Model;

class OrgDeal extends Model
{
    public function organization()
    {
        return $this->belongsTo(Organization::class,'org_id','id');
    }
    public function orgdeal()
    {
        return $this->belongsTo('App\Models\Generals\Deal','deal_id','id');
    }

    public function items(){
        return $this->hasMany(OrgDeal::class, 'org_id', 'id')
        ->leftjoin('deals', 'org_deals.deal_id', '=', 'deals.id')
        ->select('org_deals.org_id', 'deals.*');
    }
}
