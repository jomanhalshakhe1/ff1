<?php

namespace App\Models\Regulatory;

use Illuminate\Database\Eloquent\Model;

class OrgAccessPermission extends Model
{
    //
}
