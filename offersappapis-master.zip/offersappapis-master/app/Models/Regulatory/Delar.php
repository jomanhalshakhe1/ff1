<?php

namespace App\Models\Regulatory;

use App\Models\Generals\Deal;
use App\Models\Accounts\User;
use Illuminate\Database\Eloquent\Model;

class Delar extends Model
{
    protected $table = 'organizations';
    protected $guarded = ['id'];

    public function location()
    {
        return $this->belongsTo(Location::class,'id','org_id')
            ->leftjoin('cities', 'locations.city', '=', 'cities.id')
            ->select('locations.*', 'cities.city as city')
            ->selectRaw('locations.city as city_id');
    }

    public function deal()
    {
        return $this->hasMany(OrgDeal::class, 'org_id', 'id')
            ->leftjoin('deals', 'org_deals.deal_id', '=', 'deals.id')
            ->select('org_deals.org_id', 'deals.*');
    }

    public function deals()
    {
        return $this->hasMany(OrgDeal::class, 'org_id', 'id')
            ->leftjoin('deals', 'org_deals.deal_id', '=', 'deals.id')
            ->select('org_deals.*', 'deals.title');
    }


    public function user()
    {
        return $this->hasOne(User::class,'org_id','id')
            ->where('users.role_id','3')->withTrashed();
    }
}
