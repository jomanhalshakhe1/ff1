<?php

namespace App\Models\Regulatory;

use Illuminate\Database\Eloquent\Model;

class DealUpload extends Model
{
    //
}
