<?php

namespace App\Models\Regulatory;

use Illuminate\Database\Eloquent\Model;

class Organization extends Model
{
    protected $guarded = ['id'];
}
