<?php

namespace App\Models\Inventory;

use App\Models\Accounts\ManufacturerGroup;
use App\Models\Regulatory\Maker;
use Illuminate\Database\Eloquent\Model;

class Maintenance extends Model
{
    public function manufacturer()
    {
        //return $this->hasMany(ManufacturerGroup::class, 'group_id','id');
        return $this->hasMany(ManufacturerGroup::class, 'item_id','id');
    }

    public function delar()
    {
        return $this->belongsTo(Maker::class,'delar_id','id');
    }

}
