<?php

namespace App\Models\Inventory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use App\Models\Accounts\Transaction;

class ItemOffer extends Model
{
    public function item(){
        return $this->hasOne(ItemMaster::class,'item_id','id');
    }

    public function transactions_list(){
        return $this->hasMany(Transaction::class,'offer_id','id');
    }

    public function locations(){
        //return $this->hasMany(OfferLocation::class,'offer_id','id');
        return $this->hasMany(OfferLocation::class,'offer_id','id')
            ->join('locations', 'offer_locations.location_id', '=', 'locations.id')
            ->join('cities', 'locations.city', '=', 'cities.id')
            ->select('offer_locations.offer_id', 'offer_locations.location_id', 'locations.*', 'cities.city as city', 'cities.city_ar as city_ar',
                'cities.latitude as citylatitude', 'cities.longitude as citylongitude', 'cities.id as cityid');
    }

    public function vehicles()
    {
        return $this->hasMany( DealVehicle::class, 'offer_id', 'id')
            ->join('vehicle_groups', 'vehicle_groups.id', 'deal_vehicles.group_id' )
            ->select('vehicle_groups.id', 'vehicle_groups.title', 'vehicle_groups.title_ar','vehicle_groups.status')
            ->where('vehicle_groups.status', 1);
    }

    public function vehicle_owners(){
        return $this->hasMany( DealVehicle::class, 'offer_id', 'id')
            ->join('vehicles', 'deal_vehicles.group_id', 'vehicles.group_id')
            ->join('vehicle_models', 'vehicle_models.id', 'vehicles.model')
            ->join('vehicle_groups', 'vehicle_groups.id', 'vehicles.group_id' )
            ->join('manufacturers', 'manufacturers.id', 'vehicles.company')
            ->select( 'deal_vehicles.offer_id', 'vehicles.id',
                DB::raw("concat(manufacturers.title, ',',vehicle_models.model, ',', vehicle_groups.title ) as title"),
                DB::raw("concat(manufacturers.title_ar, ',',vehicle_models.model_ar, ',', vehicle_groups.title_ar ) as title_ar"),
                'vehicles.is_primary', 'vehicles.owner_id', 'vehicles.group_id', 'vehicles.plate_no', 'vehicles.serial_no')
            ->where('vehicles.status', 1);
    }

}
