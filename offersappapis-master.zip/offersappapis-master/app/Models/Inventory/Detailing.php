<?php

namespace App\Models\Inventory;

use Illuminate\Database\Eloquent\Model;

class Detailing extends Model
{
    public function offer()
    {
        return $this->hasOne('App\DetailingOffer','detailing_id','id');
    }

    public function delar()
    {
        return $this->belongsTo('App\Organization','delar_id','id');
    }
}
