<?php

namespace App\Models\Inventory;

use App\Models\Accounts\VehicleGroup;
use App\Models\Accounts\VehicleModel;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class DealVehicle extends Model
{
    public function vehicles()
    {
        return $this->hasone( VehicleGroup::class, 'id', 'group_id')
            ->where('status', 1);
    }
}
