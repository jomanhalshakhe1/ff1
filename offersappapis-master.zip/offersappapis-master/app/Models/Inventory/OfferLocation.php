<?php

namespace App\Models\Inventory;

use App\Models\Regulatory\Location;
use Illuminate\Database\Eloquent\Model;

class OfferLocation extends Model
{
    public function location(){
        return $this->belongsTo(Location::class,'location_id','id');
    }
}
