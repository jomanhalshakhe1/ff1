<?php

namespace App\Models\Inventory;

use App\Models\Accounts\VehicleGroup;
use Illuminate\Database\Eloquent\Model;

class Policy extends Model
{
    public function vehicle()
    {
        return $this->belongsTo(VehicleGroup::class,'vehicle_group_id','id');
    }
}
