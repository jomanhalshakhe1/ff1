<?php

namespace App\Models\Inventory;

use App\Models\Accounts\Vehicle;
use Illuminate\Database\Eloquent\Model;
use App\Models\Accounts\User;
use App\Models\Accounts\Driver;

class MaintenanceLog extends Model
{
   // protected $fillable = array('parts', 'transaction_no', 'vehicle_id', 'maintenance', 'item_id', 'user_id', 'created_by');

    protected $guarded = [];

    // Get deal details
    public function item()
    {
        return $this->belongsTo(Maintenance::class,'item_id','id');
    }

    //Get vehicle details
    public function vehicle()
    {
        return $this->belongsTo(Vehicle::class,'vehicle_id','id')->withTrashed();
    }

    //Get scanned by user details
    public function scanner()
    {
        return $this->belongsTo(User::class,'created_by','id')->withTrashed();
    }

    //Get driver details
    public function driver()
    {
        return $this->belongsTo(Driver::class,'user_id','id')->withTrashed();
    }
}
