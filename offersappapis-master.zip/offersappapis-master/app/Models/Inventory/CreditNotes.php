<?php

namespace App\Models\Inventory;

use Illuminate\Database\Eloquent\Model;

class CreditNotes extends Model
{
    protected $table = 'creditnotes';

	public function dealers()
	{
	    return $this->belongsTo('App\Models\Regulatory\Organization','dealer_id','id');
	}

	public function category()
	{
	    return $this->belongsTo('App\Models\Generals\Deal','category_id','id');
	}

	public function created_user()
	{
	    return $this->belongsTo('App\Models\Accounts\User','created_by','id');
	}
	
}
