<?php

namespace App\Models\Inventory;

use App\Models\Generals\Deal;
use App\Models\Generals\Slider;
use App\Models\Regulatory\Delar;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class ItemMaster extends Model
{
    use SoftDeletes;

    protected $table = 'item_master';

    public function minoffer()
    {
        return $this->hasOne(ItemOffer::class,'id','offer_id');
    }

    public function offer()
    {
        return $this->hasOne(ItemOffer::class,'item_id','id');
    }

    public function offers()
    {
        return $this->hasMany(ItemOffer::class,'item_id','id')
         ->where('item_offers.status', '1');
    }

    public function delar()
    {
        return $this->belongsTo(Delar::class,'delar_id','id');
    }

    public function deal()
    {
        return $this->belongsTo(Deal::class,'deal_id','id');
    }

    public function vehicle()
    {
        return $this->hasMany(DealVehicle::class,'item_id', 'id');
    }

    public function slider()
    {
        return $this->hasMany(Slider::class,'item_id', 'id');
    }
}
