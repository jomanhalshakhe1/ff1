<?php

namespace App\Models\Payments;

use Illuminate\Database\Eloquent\Model;

class PaymentGateway extends Model
{
    //
}
