<?php

namespace App\Models\Accounts;

use App\Models\Regulatory\Fleet;
use Illuminate\Database\Eloquent\Model;

class FleetDriver extends Model
{
    public function company()
    {
        return $this->hasOne(Fleet::class,'id', 'fleet_id');
    }

    public function driver()
    {
        return $this->hasOne(Driver::class,'id', 'driver_id');
    }
}
