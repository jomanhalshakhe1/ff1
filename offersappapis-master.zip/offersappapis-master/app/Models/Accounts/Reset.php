<?php

namespace App\Models\Accounts;

use Illuminate\Database\Eloquent\Model;

class Reset extends Model
{
    //
    protected $table = 'password_resets';
    protected $primaryKey = 'email';
    public $timestamps = false;
}
