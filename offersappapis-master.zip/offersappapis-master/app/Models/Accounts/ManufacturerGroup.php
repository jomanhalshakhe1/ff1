<?php

namespace App\Models\Accounts;

use App\Models\Generals\Manufacturer;
use Illuminate\Database\Eloquent\Model;

class ManufacturerGroup extends Model
{
    protected $table = 'manufacturer_groups';

    public function manufacturers()
    {
        return $this->belongsTo(Manufacturer::class, 'group_id','id');
    }
}
