<?php

namespace App\Models\Accounts;

use Illuminate\Database\Eloquent\Model;

class GroupConsumer extends Model
{
    public function group()
    {
        return $this->belongsTo(ConsumerGroup::class,'group_id','id')->with('company');
    }

    public function users()
    {
        return $this->hasMany(Driver::class,'id','consumer_id')
            ->select('id','first_name','last_name', 'licence_id', 'status');
    }

    public function driver()
    {
        return $this->hasOne(Driver::class,'id','consumer_id')
            ->select('id','first_name','last_name', 'licence_id', 'status');
    }

    public function loggedin_devices()
    {
        return $this->hasMany('App\Models\Generals\Device', 'user_id','consumer_id')->where('user_type','driver');
    }
}
