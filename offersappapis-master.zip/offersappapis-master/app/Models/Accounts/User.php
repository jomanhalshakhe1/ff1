<?php

namespace App\Models\Accounts;

use App\Models\Generals\Role;
use App\Models\Regulatory\Organization;
use App\Models\Regulatory\TechnicianLocation;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\DB;
use Tymon\JWTAuth\Contracts\JWTSubject;

class User extends Authenticatable implements JWTSubject
{
    use Notifiable;
    use SoftDeletes;

    protected $table = 'users';
    protected $guarded = ['id'];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    /*
    protected $fillable = [
        'name', 'email', 'password',
    ];
    */

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];

    protected $appends = ['role_name', 'login_type_id', 'org_name'];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function getAuthPassword()
    {
        return $this->password;
    }

    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    public function getJWTCustomClaims()
    {
        return [];
    }

    public function role()
    {
        return $this->belongsTo(Role::class,'role_id','id');
    }

    public function getRoleNameAttribute($value)
    {
        return $this->role->title ?? '';
    }

    public function getLoginTypeIdAttribute($value)
    {
        return $this->role->login_type_id ?? '';
    }

    public function company()
    {
        return $this->belongsTo(Organization::class,'org_id','id');
    }

    public function getOrgNameAttribute($value)
    {
        return $this->company->org_name ?? '';
    }

    public function getDeviceLogIdAttribute()
    {
        return $this->latest_device->id ?? null;
    }

    public function getDeviceIdAttribute()
    {
        return $this->latest_device->device_id ?? null;
    }

    public function getDeviceTypeAttribute()
    {
        return $this->latest_device->device_type ?? null;
    }

    public function tech_locations()
    {
        return $this->hasMany(TechnicianLocation::class,'technician_id','id')
            ->join('locations','locations.id', 'technician_locations.location_id')
            ->select('locations.*', 'technician_locations.technician_id',
            DB::raw("CONCAT(cities.city,' , ',locations.district,', ',locations.street) as city"),
            'cities.id as cityid', 'cities.latitude as citylatitude', 'cities.longitude as citylongitude')
            ->leftjoin('cities', 'locations.city', '=', 'cities.id')
            ->where('locations.status', 1)
            ->where('technician_locations.status', 1);
    }

    // Get logged in device details of the dealer, partner
    public function loggedin_devices()
    {
        return $this->hasMany('App\Models\Generals\Device', 'user_id','id')
                    ->where('user_type','user')
                    ->offset(0)->limit(10)->orderBy('id', 'DESC');
    }

    public function latest_device()
    {
        return $this->hasOne('App\Models\Generals\Device', 'user_id','id')
            ->where('user_type','user')->where('status', 1);
    }
}
