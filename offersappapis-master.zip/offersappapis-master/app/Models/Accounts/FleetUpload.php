<?php

namespace App\Models\Accounts;

use App\Models\Regulatory\Organization;
use Illuminate\Database\Eloquent\Model;

class FleetUpload extends Model
{
    public function company()
    {
        return $this->belongsTo(Organization::class,'fleet_id','id');
    }

    public function activedrivercount()
    {
        return $this->hasMany(FleetDriver::class,'sheet_id', 'id')->where('status', 1);
    }
    public function inactivedrivercount()
    {
        return $this->hasMany(FleetDriver::class,'sheet_id', 'id')->where('status', '!=', 1);
    }
}
