<?php

namespace App\Models\Accounts;

use App\Models\Regulatory\Organization;
use Illuminate\Database\Eloquent\Model;

class ConsumerGroup extends Model
{
    public function company()
    {
        return $this->belongsTo(Organization::class,'company','id')
            ->select('id', 'org_name', 'org_name_ar', 'status');
    }

    public function users()
    {
        return $this->hasMany(Driver::class,'id','id')
            ->select('id','first_name','last_name');
    }
    
    public function consumers()
    {
        return $this->hasMany(GroupConsumer::class,'group_id','id');
    }
}
