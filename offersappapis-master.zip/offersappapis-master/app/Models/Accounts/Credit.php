<?php

namespace App\Models\Accounts;

use App\Models\Inventory\ItemOffer;
use Illuminate\Database\Eloquent\Model;

class Credit extends Model
{
    protected $guarded = ['id'];

    public function consumer()
    {
        return $this->hasMany(ConsumerCredit::class,'credit_id','id');
    }

    public function refund_by()
    {
        return $this->belongsTo('App\Models\Accounts\User','created_by','id');
    }

    public function adjusted_by()
    {
        return $this->belongsTo('App\Models\Accounts\User','created_by','id');
    }

    public function transaction_on()
    {
        return $this->belongsTo(Transaction::class,'transaction_no','transaction_no');
    }

    public function transaction()
    {
        return $this->transaction_on()->with('driver', 'item', 'item.delar');
    }

    public function groups()
    {
        return $this->hasMany(ConsumerCredit::class,'credit_id','id')
            ->where('credit_for', 10);
    }

    public function individuals()
    {
        return $this->hasMany(ConsumerCredit::class,'credit_id','id')
            ->where('credit_for', 11);
    }

    public function item_offer(){
        return $this->hasOne(ItemOffer::class,'id','offer_id');
    }

    public function offer(){
        return $this->item_offer()->with('item');
    }

}
