<?php

namespace App\Models\Accounts;

use Illuminate\Database\Eloquent\Model;

class ConsumerCredit extends Model
{
    protected $guarded = ['id'];

    public function consumers()
    {
        return $this->hasMany(GroupConsumer::class ,'group_id','credit_to')
            ->where('credit_for', 'GROUP');
    }

    public function group_consumers(){
    	 return $this->hasMany(GroupConsumer::class ,'group_id','credit_to');
    }

    function company_info(){
    	 return $this->belongsTo(ConsumerGroup::class,'credit_to','id');
    }
}
