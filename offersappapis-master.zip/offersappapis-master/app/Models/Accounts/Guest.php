<?php

namespace App\Models\Accounts;

use Illuminate\Database\Eloquent\Model;

class Guest extends Model
{
    protected $guard = 'guest';
    protected $table = 'drivers';
    protected $guarded = ['id'];

    public $attributes = ['device_id', 'device_type'];

    public function setDeviceIdAttribute($value)
    {
        $this->attributes['device_id'] = $value;
    }

    public function setDeviceTypeAttribute($value)
    {
        $this->attributes['device_type'] = $value;
    }

    public function getDeviceLogIdAttribute()
    {
        return $this->latest_device->id ?? null;
    }

    public function getDeviceIdAttribute()
    {
        return $this->latest_device->device_id ?? null;
    }

    public function getDeviceTypeAttribute()
    {
        return $this->latest_device->device_type ?? null;
    }

    public function latest_device()
    {
        return $this->hasOne('App\Models\Generals\Device', 'user_id','id')
            ->where('user_type','guest')
            ->where('status', 1);
    }

    public function vehicle()
    {
        return $this->belongsTo(Vehicle::class,'vehicle_id','id');
    }

    public function fleets()
    {
        return $this->hasMany(FleetDriver::class, 'driver_id','id')
            ->join('organizations', 'organizations.id', '=', 'fleet_drivers.fleet_id')
            ->select('employee_id', 'fleet_id', 'driver_id', 'org_name', 'fleet_drivers.status')
            ->where('fleet_drivers.status', '1')->whereNotNull('employee_id');
    }

}
