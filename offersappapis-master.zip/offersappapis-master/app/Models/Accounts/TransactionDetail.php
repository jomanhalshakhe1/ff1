<?php

namespace App\Models\Accounts;

use Illuminate\Database\Eloquent\Model;

class TransactionDetail extends Model
{
    //
}
