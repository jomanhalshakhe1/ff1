<?php

namespace App\Models\Accounts;

use App\Models\Generals\Role;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Casts\Attribute;

class Driver extends Authenticatable implements JWTSubject
{
    use Notifiable;
    use SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guard = 'driver';
    protected $table = 'drivers';
    protected $guarded = ['id'];
    
    // protected $appends  = [ 'device_type','device_id' ];

    public $attributes = ['device_type', 'device_id'];

    /*
    protected $fillable = [
        'name', 'email', 'password',
    ];
    */

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        // 'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        // 'email_verified_at' => 'datetime',
    ];

    public function getAuthPassword()
    {
        return $this->password;
    }

    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }

    public function role()
    {
        return $this->belongsTo(Role::class,'role_id','id');
    }

    public function getRoleNameAttribute($value)
    {
        return "{$this->role->title}";
    }

    public function setDeviceIdAttribute($value)
    {
        $this->attributes['device_id'] = $value;
    }

    public function setDeviceTypeAttribute($value)
    {
        $this->attributes['device_type'] = $value;
    }

    public function getDeviceLogIdAttribute()
    {
        return $this->latest_device->id ?? null;
    }

    public function getDeviceIdAttribute()
    {
        return $this->latest_device->device_id ?? null;
    }

    public function getDeviceTypeAttribute()
    {
        return $this->latest_device->device_type ?? 'android';
    }

    public function vehicle()
    {
        return $this->belongsTo(Vehicle::class,'vehicle_id','id');
    }

    public function fleets()
    {
        return $this->hasMany(FleetDriver::class, 'driver_id','id')
            ->join('organizations', 'organizations.id', '=', 'fleet_drivers.fleet_id')
            ->select('employee_id', 'fleet_id', 'driver_id', 'org_name', 'fleet_drivers.status')
            ->where('fleet_drivers.status', '1')->whereNotNull('employee_id');
    }

    public function fleet_consumer()
    {
        return $this->belongsTo(FleetDriver::class, 'id','driver_id')
            ->join('organizations', 'organizations.id', '=', 'fleet_drivers.fleet_id')
            ->select('employee_id', 'fleet_id', 'driver_id', 'org_name','payment_share')->where('fleet_drivers.status','1')->orderBy('fleet_drivers.id','desc');
    }

    public function fleet_driver()
    {
        return $this->belongsTo(FleetDriver::class, 'id','driver_id');
    }

    public function loggedin_devices()
    {
        return $this->hasMany('App\Models\Generals\Device', 'user_id','id')
            ->where('user_type','driver')->offset(0)->limit(10)->orderBy('id', 'DESC');
    }

    public function latest_device()
    {
        return $this->hasOne('App\Models\Generals\Device', 'user_id','id')
            ->where('user_type','driver')->where('status', 1);
    }

    public function ios_device()
    {
        return $this->hasMany('App\Models\Generals\Device', 'user_id','id')
            ->where('user_type','driver')->where('device_type','ios');
    }

    public function android_device()
    {
         return  $this->hasMany('App\Models\Generals\Device', 'user_id','id')
            ->where('user_type','driver')->where('device_type','android');
    }

    public function transaction_list()
    {
        return $this->hasMany('App\Models\Accounts\Transaction', 'created_by','id')->whereIn('payment_status',['Successful','Requests']);
    }
 
}
