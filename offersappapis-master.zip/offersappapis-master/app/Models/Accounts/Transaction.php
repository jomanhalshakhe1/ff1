<?php

namespace App\Models\Accounts;

use App\Http\Controllers\Generals\DealController;
use App\Models\Generals\Deal;
use App\Models\Generals\Feedback;
use App\Models\Generals\RedeemLog;
use App\Models\Inventory\DealVehicle;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use App\Models\Regulatory\Location;
use App\Models\Accounts\OnsiteLocation;
use App\Models\Accounts\Bill;
use App\Models\Regulatory\Organization;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Transaction extends Model
{
    public $timestamps = false;

    public function deal()
    {
        return $this->belongsTo(Deal::class,'deal_id','id');
    }

    public function item()
    {
        return $this->belongsTo(ItemMaster::class,'item_id','id');
    }

    public function driver()
    {
        return $this->belongsTo(Driver::class,'created_by','id')->withTrashed();
    }

    public function partner()
    {
        return $this->belongsTo(Organization::class,'fleet_id','id');
    }

    public function driver_address()
    {
        return $this->belongsTo(OnsiteLocation::class,'transaction_no','transaction_no')->latest();
    }

    public function approver()
    {
        return $this->belongsTo(User::class,'approved_by','id')->withTrashed();
    }

    public function redeems()
    {
        return $this->belongsTo(RedeemLog::class,'transaction_no','transaction_no');
    }

    public function refund()
    {
        return $this->belongsTo(Credit::class,'transaction_no','transaction_no')
            ->select('id','transaction_no', 'amount', 'description','created_at')
            ->where('credit_on', 2)
            ->where('status', 1);
    }

    public function adjustment()
    {
        return $this->belongsTo(Credit::class,'transaction_no','transaction_no')
            ->select('id','transaction_no', 'amount', 'description','created_at','created_by')
            ->with('adjusted_by')
            ->where('credit_on', 3)
            ->where('status', 1);
    }

    public function location() {
        return $this->belongsTo(Location::class,'location_id','id')
            ->leftjoin('cities', 'locations.city', '=', 'cities.id')
            ->select('locations.*', 'cities.city as city', 'cities.latitude as citylatitude',
                'cities.longitude as citylongitude', 'cities.id as cityid');
    }

    public function trans_location() {
        return $this->belongsTo(Location::class,'location_id','id')
            ->leftjoin('cities', 'locations.city', '=', 'cities.id')
            ->select('locations.*', 'cities.city as city', 'cities.latitude as citylatitude',
                'cities.longitude as citylongitude', 'cities.id as cityid');
    }

    public function feedback() {
        return $this->belongsTo(Feedback::class,'transaction_no','transaction_no');
    }

    public function offer()
    {
        return $this->belongsTo(ItemOffer::class,'offer_id','id');
    }

    public function payment()
    {
        return $this->belongsTo(Payment::class,'transaction_no','transaction_no')
            ->whereIn('payment_status', ['pending', 'Failed', 'Successful', 'Cancelled']);
    }

    public function payment_details() {
        return $this->belongsTo(Payment::class,'transaction_no','transaction_no')
            ->whereIn('payment_status', ['pending', 'Failed', 'Successful']);
    }

    public function vehicle_owners(){
        return $this->hasOne( Vehicle::class, 'id', 'vehicle_id')
            ->join('vehicle_models', 'vehicle_models.id', 'vehicles.model')
            ->join('vehicle_groups', 'vehicle_groups.id', 'vehicle_models.vehicle_group_id' )
            ->join('manufacturers', 'manufacturers.id', 'vehicle_models.maker')
            ->select(  'vehicles.id','vehicle_models.filter_price',
                DB::raw("concat(manufacturers.title, ',',vehicle_models.model, ',', vehicle_groups.title ) as title"),
                DB::raw("concat(manufacturers.title_ar, ',',vehicle_models.model_ar, ',', vehicle_groups.title_ar ) as title_ar"),
                'vehicles.is_primary', 'vehicles.owner_id', 'vehicles.group_id', 'vehicles.plate_no', 'vehicles.serial_no');
    }

    public function paymentinfo()
    {
      return $this->belongsTo(TransactionDetail::class,'transaction_no','transaction_no');
    }

    public function rawdata()
    {
      return $this->belongsTo(TransactionDetail::class,'transaction_no','transaction_no');
    }


}
