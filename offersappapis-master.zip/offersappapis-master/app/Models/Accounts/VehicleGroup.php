<?php

namespace App\Models\Accounts;

use Illuminate\Database\Eloquent\Model;

class VehicleGroup extends Model
{
    protected $fillable = [
        'title',
        'status', 
    ];
}
