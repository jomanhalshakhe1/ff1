<?php

namespace App\Models\Accounts;

use App\Models\Generals\Manufacturer;
use Illuminate\Database\Eloquent\Model;
use App\Models\Regulatory\Organization;

class VehicleModel extends Model
{
    protected $fillable = [
        'vehicle_group_id',
        'status', 
        'model',
        'maker',
    ];

    public function vehiclegroup()
    {
        return $this->belongsTo(VehicleGroup::class,'vehicle_group_id','id');
    }

    public function vehiclemaker()
    {
        return $this->belongsTo(Manufacturer::class,'maker','id');
    }


}
