<?php

namespace App\Models\Accounts;

use App\Models\Generals\Colour;
use App\Models\Generals\Manufacturer;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class Vehicle extends Model
{
    use SoftDeletes;

    public function owner()
    {
        return $this->belongsTo(Driver::class,'owner_id','id')->withTrashed();
    }

    public function groups()
    {
        return $this->belongsTo(VehicleGroup::class,'group_id','id');
    }

    public function manufacturer()
    {
        return $this->belongsTo(Manufacturer::class,'company','id')
            ->select('id', 'title', 'thumbnail_url');
    }

    public function colour()
    {
        return $this->belongsTo(Colour::class,'colour','id');
    }

    public function model()
    {
        return $this->belongsTo(VehicleModel::class,'model','id');
    }


    function driver(){
        return $this->owner();
    }
}
