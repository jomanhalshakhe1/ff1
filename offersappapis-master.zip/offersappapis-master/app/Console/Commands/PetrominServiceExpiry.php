<?php

namespace App\Console\Commands;

use App\Http\Controllers\Users\PetrominController;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class PetrominServiceExpiry extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'petromin_service_expiry:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'After 48hrs, if service not finished, then delete those services in petromin and reject in Joy system';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $count = (new PetrominController())->check_service_exipry();

        Log::info("Check Petromin Offers Expiry, $count services are rejected");

        $this->info('PetrominServiceExpiryCron:Cron Cummand Run successfully!');
    }
}
