<?php

namespace App\Console\Commands;

use App\Http\Controllers\Notifications\CustomNotificationsController;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class SendCustomNotifications extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'SendCustomNotifications:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sechdule Custom Notifications based on the send date';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
       $this->info("Start Sent custom notifications");
       (new CustomNotificationsController)->sendCustomNotificationUsingCron();   
       $this->info('End Sent custom notifications');
    }
}
