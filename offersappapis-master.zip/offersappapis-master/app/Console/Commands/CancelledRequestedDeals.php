<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

use App\Http\Controllers\PaymentController;
use Illuminate\Support\Facades\Log;

class CancelledRequestedDeals extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'CancelledRequestedDeals:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cancel requested offer availablity after 12 hours if technician not yet approve or rejected';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        Log::info("Cancel requested offer availablity");
        (new PaymentController)->cancelRequestedItemAvailability();
    }
}
