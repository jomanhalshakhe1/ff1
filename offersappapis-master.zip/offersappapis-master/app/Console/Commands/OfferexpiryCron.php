<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

use App\Http\Controllers\Generals\SendPushNotification;
use Illuminate\Support\Facades\Log;

class OfferexpiryCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'offerexpiry:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Before Expiring an offer send notification to the offer purchased consumers and offer owner ';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        //return 0;
        Log::info("Sent Offers Expiry notifications to all consumers");

        (new SendPushNotification)->offer_expiry_warning();
        
        $this->info('OfferexpiryCron:Cron Cummand Run successfully!');
    }
}
