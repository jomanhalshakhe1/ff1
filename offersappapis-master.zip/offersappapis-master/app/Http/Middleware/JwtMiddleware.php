<?php

namespace App\Http\Middleware;

use App\Models\Generals\Device;
use Closure;
use Tymon\JWTAuth\Facades\JWTAuth;
use Exception;
use Tymon\JWTAuth\Http\Middleware\BaseMiddleware;
use Illuminate\Support\Facades\Auth;
use App\Models\Accounts\Driver;
use App\Models\Accounts\User;
use App\Models\Regulatory\Organization;

class JwtMiddleware extends BaseMiddleware
{

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        try {

            $prefix = $request->route()->action['prefix'] ?? 'anonymus';
            $prefix = explode('/', $prefix)[0];

            /*
            JWTAuth::parseToken()->authenticate();
            if(Auth::guard('driver')->user())
                $user = Auth::guard('driver')->user();
            if(Auth::guard('guest')->user())
                $user = Auth::guard('guest')->user();
            else if(Auth::guard('technician')->user())
                $user = Auth::guard('technician')->user();
            else if(Auth::user())
                $user = Auth::user();
            */

            $user = JWTAuth::parseToken()->authenticate();
            $userCount=0;
            if($user){ 
                if(Auth::guard('driver')->id() || Auth::guard('guest')->id()){
                    $userCount=Driver::where('id', $user->id)->where('is_verified', 1)->where('status', 1)->count();
                    if($userCount > 0) {
                        if(Auth::guard('guest')->id()) {
                            $where = array(
                                'user_type' => 'guest',
                                'device_id' => Auth::guard('guest')->user()->device_id,
                                'device_type' => Auth::guard('guest')->user()->device_type,
                                'user_id' => Auth::guard('guest')->id(),
                            );
                            $userCount = 1;
                        } else if(Auth::guard('driver')->id()){
                            $where = array(
                                'user_type' => 'driver',
                                'device_id' => Auth::guard('driver')->user()->device_id,
                                'device_type' => Auth::guard('driver')->user()->device_type,
                                'user_id' => Auth::guard('driver')->id(),
                            );
                            $deviceLogCnt = Device::where($where)->count();
                            $userCount = $deviceLogCnt > 0 ? 1 : 2;
                        }
                    }
                } else {
                   $userData=User::where('id',$user->id)->where('is_verified', 1)->where('status', 1)->with('company')->first();

                   if($userData){
                        $st=$userData->company ? $userData->company->status : 0;
                        if(!$st){
                            return response()->json([
                                'status' => 'failed',
                                'message' => 'Your organization was blocked',
                                'message_ar' => 'تم حظر مؤسستك'], 401);
                        }
                        $userCount=1;

                        if($prefix == 'technician' || $prefix == 'dealer'){
                            $where = array(
                                'user_type' => 'user',
                                'device_id' => Auth::guard('technician')->user()->device_id,
                                'device_type' => Auth::guard('technician')->user()->device_type,
                                'user_id' => Auth::guard('technician')->id()
                            );

                            $deviceLogCnt = Device::where($where)->count();
                            $userCount = $deviceLogCnt > 0 ? 1 : 2;
                        }
                   } else {
                     $userCount=0;
                   }
                }

                if($userCount == 0){
                    return response()->json([
                        'status' => 'failed',
                        'message' => 'Your account was blocked',
                        'message_ar' => 'تم حظر حسابك'], 401);
                } else if($userCount == 2){
                    return response()->json([
                        'status' => 'failed',
                        'message' => 'Token is Invalid',
                        'message_ar' => 'الرمز غير صالح'], 401);
                }
            }
        } catch (Exception $e) {
            if ($e instanceof \Tymon\JWTAuth\Exceptions\TokenInvalidException){
                return response()->json([
                    'status' => 'failed',
                    'message' => 'Token is Invalid',
                    'message_ar' => 'الرمز غير صالح'], 401);
            }else if ($e instanceof \Tymon\JWTAuth\Exceptions\TokenExpiredException){
                return response()->json([
                    'status' => 'failed',
                    'message' => 'Token is Expired',
                    'message_ar'=> 'انتهت صلاحية الرمز'], 401);
            }else{
                return response()->json([
                    'status' => 'failed',
                    'message' => 'Authorization Token not found',
                    'message_ar'=> 'لم يتم العثور على رمز التفويض'], 401);
            }
        }
        return $next($request);
    }
}