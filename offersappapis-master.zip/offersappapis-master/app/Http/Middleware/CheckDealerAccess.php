<?php

namespace App\Http\Middleware;

use Closure;
use App\Models\Regulatory\Organization;
use App\Models\Regulatory\OrgAccessPermission;
use Illuminate\Support\Facades\Session;

class CheckDealerAccess
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        $dealer_token = $request->header('dealer-token');
        $dealer_access_permission = OrgAccessPermission::where('dealer_token',$dealer_token)->first();
        //dd($dealer_token);
        
        if ($dealer_access_permission) {
            Session::put('dealer_access_id', $dealer_access_permission->org_id);
            return $next($request);
        }
        if (strpos($request->url(), '/dealeraccess/') !== false) {
            return response()->json(['status'=>'failed', 'result' => [], 'message' => 'Unauthorized Organization']);
        }
        return redirect()->back();
        //return $next($request);
    }
}
