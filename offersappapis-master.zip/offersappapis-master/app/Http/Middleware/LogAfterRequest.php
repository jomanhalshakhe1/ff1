<?php

namespace App\Http\Middleware;

use App\Models\Generals\Device;
use Closure;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class LogAfterRequest
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        return $next($request);
    }

    public function terminate($request, $response)
    {
        $url=$request->fullUrl();
        $ip=$request->ip();
        $resp = '';
        //if($response->status() != 200)
            $resp = $response->original ?? '';

        $user_id = $contact_no = $request_from = $version_no = $device_type = '';
        $prefix = $request->route()->action['prefix'] ?? 'anonymus';
        $prefix = explode('/', $prefix)[0];
        if($prefix == 'api'){
            if(Auth::id()){
                $user_id = Auth::id();
                $contact_no = Auth::user()->contact_no;
            }
        }
        else if($prefix == 'consumer'){
            if(Auth::guard('driver')->id()){
                $user_id = Auth::guard('driver')->id();
                $contact_no = Auth::guard('driver')->user()->contact_no;
                $devices = Device::where('user_type', 'driver')->where('user_id', $user_id)->select('device_type', 'app_version')->first();
                if($devices)
                {
                    $device_type = $devices->device_type;
                    $version_no = $devices->app_version;
                    Device::where('user_type', 'driver')->where('user_id', $user_id)
                        ->update(['last_access_at' => date('Y-m-d H:i:s')]);
                }
            }
        }
        else if($prefix == 'customer'){
            if(Auth::guard('driver')->id()){
                $user_id = Auth::guard('driver')->id();
                $contact_no = Auth::guard('driver')->user()->contact_no;
                $device_type = Auth::guard('driver')->user()->device_type;
                $device_log_id = Auth::guard('driver')->user()->device_log_id;

                $where = [ 'user_type' => 'driver', 'user_id' => $user_id, 'device_type' => $device_type ];
                $devices = Device::where('id', $device_log_id)->first();
                if($devices)
                {
                    $device_type = $devices->device_type;
                    $version_no = $devices->app_version;
                    Device::where($where)->update(['last_access_at' => date('Y-m-d H:i:s')]);
                }
            }
        }
        else if($prefix == 'dealer' || $prefix == 'technician'){
            if(Auth::guard('technician')->id()){
                $user_id = Auth::guard('technician')->id();
                $contact_no = Auth::guard('technician')->user()->contact_no;
                $device_type = Auth::guard('technician')->user()->device_type;
                $device_log_id = Auth::guard('technician')->user()->device_log_id;

                $where = [ 'user_type' => 'user', 'user_id' => $user_id, 'device_type' => $device_type ];
                $devices = Device::where('id', $device_log_id)->first();

                if($devices)
                {
                    $device_type = $devices->device_type;
                    $version_no = $devices->app_version;
                    Device::where($where)->update(['last_access_at' => date('Y-m-d H:i:s')]);
                }
            }
        }

        if($prefix != 'anonymus' && $prefix != 'api') {
            $r = array(
                'user_id' => $user_id,
                'contact_no' => $contact_no,
                'version_no' => $version_no,
                'device_type' => $device_type,
                'ip' => $ip,
                'url' => $url,
                'request_type' => $request->method() ?? '',
                'request' => $request->all() ?? '',
                'request_from' => $prefix,
                'response' => $resp,
                'response_status' => $response->status() ?? '',
            );
            $logname = $prefix . ': '. stripslashes(substr($url, strpos($url, $prefix) + strlen($prefix)));
            if($contact_no != '')
                $logname .= ", (".$contact_no.": ".$version_no.")";

            Log::info($logname, $r);
        }
    }
}
