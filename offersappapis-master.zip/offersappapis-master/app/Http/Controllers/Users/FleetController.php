<?php

namespace App\Http\Controllers\Users;

use App\Http\Controllers\Controller;
use App\Models\Accounts\Driver;
use App\Models\Accounts\FleetDriver;
use App\Models\Accounts\FleetUpload;
use App\Imports\ConsumerImport;
use App\Models\Generals\Role;
use App\Models\Regulatory\Location;
use App\Models\Regulatory\Fleet;
use App\Models\Accounts\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\Accounts\ConsumerGroup;
use App\Models\Accounts\Transaction;
use App\Http\Controllers\Generals\PayoutController;
use App\Models\Generals\Payout;

class FleetController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $pageno = 1; $pagelength = 10; 
            $totalrecords = Fleet::where('company_type', 'F')->with('location')->count();

            $login_type_id = Role::where('id',Auth::user()->role_id)->pluck('login_type_id')->first();

            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;

                if($login_type_id=='17'){
                     $list = Fleet::where('company_type', 'F')->with('location', 'user')
                    ->orderBy('id', 'desc')
                    ->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();
                } else {
                     $list = Fleet::where('id', Auth::user()->org_id)->where('company_type', 'F')->with('location', 'user')
                    ->orderBy('id', 'desc')
                    ->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();
                }
               
                $data['data'] = $list;
                $data['current_page'] = $pageno;
                $data['total'] = $totalrecords;
                $data['per_page'] = $pagelength;
                return response()->json(['status' => 'success', 'data' => $data], 200);
            }else{
                $list = Fleet::where('company_type', 'F')->with('location', 'user')->get();
            }
        }else{
            $list = Fleet::where('company_type', 'F')->with('location', 'user')->get();
        }
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /*
     * Prefix: api, Access: admin
     * Send active partner organizations list
     */
    public function active_fleets(){
        $list = Fleet::where('company_type', 'F')->where('status', 1);
        if(Auth::user()->login_type_id!=17){
           $list =$list->where('id', Auth::user()->org_id);
        }
        $list =$list->get();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }


    /*
     * Prefix: api, Access: admin
     * Send partner organizations list having active customers
     */
    public function fleet_with_customers(){
        $list = Fleet::where('company_type', 'F')->where('status', 1)->has('drivers', '>', 0)
            ->select('id', 'org_name', 'org_name_ar', 'phone', 'email' )->get();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request['location'] = json_decode($request['location'], true);
        $request['phone'] = $request['country_code'].$request['phone'];
        $request['admin_contact_no'] =$request['admin_country_code'].$request['admin_contact_no'];
        $validator = Validator::make($request->all(),
            [
                'org_name' => ['required', 'string', 'max:100' ],
                'org_name_ar' => ['required', 'string', 'max:100' ],
                'vat_no'=>['required', 'max:20'],
                'country_code' => ['required', 'max:5'],
                'phone' => ['required', 'max:15', 'unique:organizations,phone,NULL,id'],
                'email' => ['required', 'max:60', 'email', 'unique:organizations,email,NULL,id'],
                'admin_contact_no' => ['required', 'max:15', 'unique:users,contact_no,NULL,id,deleted_at,NULL'],
                'admin_email_id' => ['required', 'max:60', 'email', 'unique:users,email,NULL,id,deleted_at,NULL'], 
                'location.street' => ['string', 'max:60' ],
                'location.city' => ['required', 'max:60' ],
                'location.district' => ['string', 'max:60' ],
                'location.address' => ['string', 'max:255' ],
                'location.zipcode' => ['max:20' ],
                'location.latitude' => ['required', 'numeric', 'between:0,180'],
                'location.longitude' => ['required', 'numeric', 'between:0,180'],
                'thumbnail' => ['required', 'mimes:jpeg,jpg,png', 'max:500' ],
                'personal_info' => '',
                'payment_share' => '',
                'extra_discount' => '',
                'is_email_verified'=>['required'],
            ],

            [
                'admin_contact_no.required'=>'Contact number is required for  dealer admin',
                'admin_contact_no.max'=>'Contact number must not exceed 15 characters for  dealer  admin',
                'admin_contact_no.unique'=>'Contact number is already exited with us for  dealer  admin',
                'admin_email_id.required'=>'Email id is required for dealer admin',
                'admin_email_id.max'=>'Email id must not exceed 60 characters for  dealer admin',
                'admin_email_id.min'=>'Email id must be 3 characters for  dealer admin',
                'admin_email_id.unique'=>'Email id is already exited with us for  dealer  admin',
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/fleet/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/fleet/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('fleet/', $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $request['category'] = 1; // Car Rental
            $request['company_type'] = 'F'; // Fleet
            $request['created_by'] = Auth::id();
            $request['created_at'] = date('Y-m-d H:i:s');
            $org = Fleet::create($request->except('thumbnail', 'location'));

            $location = $request['location'];
            $location['org_id'] = $org['id'];
            $location['primary'] = 1;
            $location['created_at'] = date('Y-m-d H:i:s');
            Location::insert($location);

            /*$fleetuser = array(
                'email' => $request['email'],
                'first_name' => $request['org_name'],
                'contact_no' => $request['contact_no'],
            );*/

            $insert = array(
                "first_name" => $request['org_name'],
                "email" => $request['admin_email_id'],
                "password" => Hash::make('fleet@123'),
                "role_id" => 6, // Fleet
                "org_id" => $org['id'], // Fleet Organization
                "profile_pic" => $request['thumbnail_url'],
                'created_at' => date('Y-m-d H:i:s'),
                'country_code' => $request['admin_country_code'],
                'contact_no' => $request['admin_contact_no'],
                'is_verified' => 1,
                'is_email_verified'=>$request['is_email_verified']
            );

            User::insert($insert); // Fleet account for web

            return response()->json(['status'=>'success', 'message'=> 'Maker created successfully'], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Maker creation failed', "error" => $e ], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $list = Fleet::where('id', $id)->with('location','user')->first();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request['location'] = json_decode($request['location'], true);
        $request['phone'] = $request['country_code'].$request['phone'];


        $validator = Validator::make($request->all(),
            [
                'org_name' => ['required', 'string', 'max:100' ],
                'org_name_ar' => ['required', 'string', 'max:100' ],
                'vat_no'=>['required', 'max:20'],
                'country_code' => ['required', 'max:5'],
                'phone' => ['required', 'string', 'max:15', 'unique:organizations,phone,'.$id.',id' ],
                'email' => ['required', 'email', 'max:60', 'unique:organizations,email,'.$id.',id' ],
                'location.street' => ['string', 'max:60' ],
                'location.city' => ['required', 'max:60' ],
                'location.district' => ['string', 'max:60' ],
                'location.address' => ['string', 'max:255' ],
                'location.zipcode' => ['max:20' ],
                'location.latitude' => ['required', 'numeric', 'between:0,180'],
                'location.longitude' => ['required', 'numeric', 'between:0,180'],
                'personal_info' => '',
                'payment_share' => '',
                'extra_discount' => '',
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/fleet/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/fleet/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('fleet/', $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $request['updated_at'] = date('Y-m-d H:i:s');
            $request['updated_by'] = Auth::id();
            Fleet::where('id', $id)->update($request->except('thumbnail', 'location'));

            $location = $request['location'];
            $location['updated_at'] = date('Y-m-d H:i:s');
            Location::where('primary', 1)->where('org_id', $id)->update($location);

            return response()->json(['status'=>'success', 'message'=> 'Fleet updated successfully'], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Fleet updation failed', 'error' => $e ], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /** 
     * Prefix: customer, Access: customer
     * Customer can register with fleet company as an employee using fleet code or registered employee id
     * Referance function: apply_coupon
     * @param  $request
     * @return \Illuminate\Http\Response
     */
    public function verify_fleet(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'code' => ['required']
            ],[
                'code.required' => 'Company code or driver id is required!'
            ]
        );

        if ($validator->fails()) {
            $errors = [];

            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(Fleet::where('code', $request['code'])->where('company_type', 'F')->count() > 0){
            $fleet = Fleet::where('code', $request['code'])->where('company_type', 'F')->first();
            $fleetDriver = Driver::where('id', Auth::guard('driver')->id())->first();

            try {
              $fleatDriverData = FleetDriver::where('fleet_id',  $fleet->id)->where('driver_id',  $fleetDriver->id)->orderBy('id', 'desc')->first();

               if(!empty($fleatDriverData)){
                    $fleet->employee_id=$fleatDriverData->employee_id;
                    if(!$fleatDriverData->status){
                        FleetDriver::where('id', $fleatDriverData->id)
                        ->update([
                            'updated_at'=>date('Y-m-d H:i:s'),
                            'driver_id' => Auth::guard('driver')->id(),
                            'status' => 1
                        ]);
                    } else {
                       return response()->json([
                            'status' => "failed",
                            "response" => "Already you have verified for this company",
                            "response_ar" => "لقد تحققت بالفعل من هذه الشركة",
                        ], 400);
                    }
                    
                } else {

                   $fleetCnt = FleetDriver::where('fleet_id', $fleet->id)->count();
                   $fleet->employee_id = $fleet->id . sprintf('%05d', $fleetCnt);

                    FleetDriver::insert([
                        'fleet_id' => $fleet->id,
                        'driver_id' => $fleetDriver->id,
                        'first_name' => $fleetDriver->first_name,
                        'last_name' => $fleetDriver->last_name,
                        'email' => $fleetDriver->email,
                        'employee_id' => $fleet->employee_id,
                        'status' => 1,
                        'created_at'=>date('Y-m-d H:i:s'),
                    ]);                   
                }
               
                return response()->json(['status' => "success", "data" => $fleet ], 200);
            }
            catch (\Exception $e){
                return response()->json(['status' => "failed", "response" => "Something went wrong", "error" => $e], 400);
            }
        }
        else{ // check with employee Id
            $fleet_id = FleetDriver::where('employee_id', $request['code'])->pluck('fleet_id')->first();
            if(!$fleet_id)
                return response()->json([
                    'status' => "failed",
                    "response" => "Fleet not found",
                    "response_ar" => "الأسطول غير موجود",
                ], 400);

            $fleet = Fleet::where('id', $fleet_id)->where('company_type', 'F')->first();
            $fleet->employee_id = $request['code'];

            try {
                if(FleetDriver::where('fleet_id', $fleet_id)->where('employee_id', $request['code'])->count() > 0) {

                    $fleatDriverData = FleetDriver::where('fleet_id', $fleet_id)->where('employee_id', $request['code'])->first();
                    if(!$fleatDriverData->status){
                        FleetDriver::where('id', $fleatDriverData->id)
                            ->update([
                                'updated_at'=>date('Y-m-d H:i:s'),
                                'driver_id' => Auth::guard('driver')->id(),
                                'status' => 1
                            ]);

                        return response()->json(['status' => "success", "data" => $fleet], 200);
                    }

                    return response()->json([
                        'status' => "failed",
                        "response" => "Already you have verified for this company",
                        "response_ar" => "لقد تحققت بالفعل من هذه الشركة",
                    ], 400);
                }

                FleetDriver::where('fleet_id', $fleet_id)->where('employee_id', $request['code'])
                    ->update([
                        'updated_at' => date('Y-m-d H:i:s'),
                        'driver_id' => Auth::guard('driver')->id(),
                        'status' => 1
                    ]);

                return response()->json(['status' => "success", "data" => $fleet], 200);

            }catch (\Exception $e){
                return response()->json(['status' => "failed", "response" => "Something went wrong", "error" => $e], 400);
            }
        }

    }

    /** 
     * When customer wanted to delete verified companies
     * @param Request $request
     * Access: by customer app: customer
     * 
     * @return \Illuminate\Http\Response
    */
    function deleteVerifiedCompany(Request $request){
        $validator = Validator::make($request->all(),
            [
                'employee_code' => ['required'],
                'fleet_id' => ['required']
            ],[
                'employee_code.required' => 'Employee code is required!',
                'fleet_id.required' => 'Fleet id is required!'
            ]
        );

        if ($validator->fails()) {
            $errors = [];

            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try {
            $fleatDriverid = FleetDriver::where('fleet_id', $request['fleet_id'])->where('employee_id', $request['employee_code'])->where('driver_id', Auth::guard('driver')->id())->pluck('id')->count();

            if($fleatDriverid>0){
                FleetDriver::where('fleet_id', $request['fleet_id'])->where('employee_id', $request['employee_code'])->where('driver_id', Auth::guard('driver')->id())
                    ->update([
                        'status' => 0
                    ]);
                return response()->json(['status' => "success"], 200);
            } else {
                return response()->json([
                    'status' => "failed",
                    "response" => "Company code or employee id not found",
                    "response_ar" => "لم يتم العثور على رمز الشركة أو معرف الموظف",
                ], 400);
            }
        } catch (\Exception $e){
            return response()->json(['status' => "failed", "response" => "Something went wrong", "error" => $e], 400);
        }
    }

    /** 
     * import data from excel sheet based on the partner and store into db
     * @param Request $request
     * Access: admin, partner prefix: api
     * 
     * @return \Illuminate\Http\Response
    */

    public function upload_users(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'fleet_id'  => 'required',
            'consumer_file'  => 'required|mimes:xls,xlsx,csv,txt'
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "res" =>"wrong", "response" => $errors ], 400);
        }

        try{
            $path = $request->file('consumer_file')->getRealPath();
            //$data = Excel::load($path)->get();
            $data = Excel::toArray(new ConsumerImport, $request->file('consumer_file'));
            //if($data[0])
                //$data = $data[0];

            //Excel Validation
            $validator = Validator::make($data[0],[
                '*.employeeid'  => 'required|distinct|unique:fleet_drivers,employee_id,NULL,employee_id,fleet_id,'.$request['fleet_id'],
                '*.firstname'  => 'required',
                //'*.email'  => 'required',
                //'*.countrycode'  => 'required',
                //'*.contactno'  => 'required'
            ]);
            if ($validator->fails()) {
                $errors = [];
                foreach(json_decode($validator->messages()) as $key => $value)
                    $errors[] = $value[0];
                return response()->json([ 'status' => "Failed", "response" => $errors ], 400);
            }

        }
        catch (\Exception $e){
            return response()->json(['status' => "failed", "response" => "Invalid File Format", "error" => $e], 400);
        }

        if ($file=$request->file('consumer_file')) {
            $extension = $file->extension()?: 'png';
            $destinationPath = public_path() . '/uploads/fleet/consumers/';
            $safeName = Str::random(10) . '.' . $extension;
            $file->move($destinationPath, $safeName);
            $request['uploaded_file'] = '/uploads/fleet/consumers/'.$safeName;
        }

        $fleetUpload = array(
            'fleet_id'    => $request['fleet_id'],
            'uploaded_file'    => $request['uploaded_file'],
            'success_rows'    => 0,
            'failed_rows'    => 0,
            'total_rows'    => 0,
            'created_by' => Auth::id(),
            'created_at' => date('Y-m-d H:i:s')
        );

        $sheet_id = FleetUpload::insertGetId($fleetUpload);

        $inserted = 0;$totalRows=0;

        if(count($data) > 0)
        {
            foreach (array_chunk($data,1000) as $chunk)
            {
                foreach($chunk as $value) {
                    foreach ($value as $row) {
                        $totalRows++;

                        $insert_data[] = array(
                            'employee_id' => $row['employeeid'],
                            'first_name' => $row['firstname'],
                            'last_name'   => $row['lastname'],
                            'email'   => isset($row['email']) && !empty($row['email'])?$row['email']:null,
                            'country_code'   => isset($row['countrycode']) && !empty($row['countrycode'])?$row['countrycode']:null,
                            'contact_no'   => isset($row['contactno']) && !empty($row['contactno'])?$row['contactno']:null,
                            'fleet_id' => $request['fleet_id'],
                            'sheet_id' => $sheet_id,
                            'created_at' => date('Y-m-d H:i:s')
                        );
                    }

                    $inserted += FleetDriver::insertOrIgnore($insert_data);
                    $insert_data = [];
                }
            }
        }

        $fleetUpload = array(
            'success_rows'    => $inserted,
            'failed_rows'    => $totalRows - $inserted,
            'total_rows'    =>$totalRows
        );

        FleetUpload::where('id', $sheet_id)->update($fleetUpload);

        return response()->json(['status' => "success", "message" => "Consumers file uploaded successfully", "data" => $fleetUpload  ], 200);
    }


    /** 
     * Get all uploaded members list with excel based on logged in user type
     * @param Request $request
     * Access: admin, partner prefix: api
     * 
     * @return \Illuminate\Http\Response
    */
    public function fleet_uploads(Request $request)
    {
        $login_type_id = Role::where('id',Auth::user()->role_id)->pluck('login_type_id')->first();

        // if($login_type_id == 19){ // Fleet Company
        //     $list = FleetUpload::where('fleet_id', Auth::user()->org_id )->with('company')->orderBy('id', 'desc')->get();
        // }else{
        //     $list = FleetUpload::with('company')->orderBy('id', 'desc')->get();
        // }

        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $pageno = 1; $pagelength = 10; 
            if($login_type_id == 19){ // Fleet Company
                $totalrecords = FleetUpload::where('fleet_id', Auth::user()->org_id )->with('company')->orderBy('id', 'desc')->count();
            }else{
                $totalrecords = FleetUpload::with('company')->orderBy('id', 'desc')->count();
            }
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;

                if($login_type_id == 19){ // Fleet Company
                    $list = FleetUpload::where('fleet_id', Auth::user()->org_id )->with('company')->withCount('activedrivercount')->withCount('inactivedrivercount')->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();
                }else{
                    $list = FleetUpload::with('company')->withCount('activedrivercount')->withCount('inactivedrivercount')->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();
                }
                $data['data'] = $list;
                $data['current_page'] = $pageno;
                $data['total'] = $totalrecords;
                $data['per_page'] = $pagelength;
                return response()->json(['status' => 'success', 'data' => $data], 200);
            }else{
                if($login_type_id == 19){ // Fleet Company
                    $list = FleetUpload::where('fleet_id', Auth::user()->org_id )->with('company')->withCount('activedrivercount')->withCount('inactivedrivercount')->orderBy('id', 'desc')->get();
                } else {
                    $list = FleetUpload::with('company')->withCount('activedrivercount')->withCount('inactivedrivercount')->orderBy('id', 'desc')->get();
                }
                return response()->json(['status' => "success", "data" => $list ], 200);
            }
        } else {
            if($login_type_id == 19){ // Fleet Company
                $list = FleetUpload::where('fleet_id', Auth::user()->org_id )->with('company')->withCount('activedrivercount')->withCount('inactivedrivercount')->orderBy('id', 'desc')->get();
            }else{
                $list = FleetUpload::with('company')->withCount('activedrivercount')->withCount('inactivedrivercount')->orderBy('id', 'desc')->get();
            }
        }
        return response()->json(['status' => "success", "data" => $list ], 200);
    }


    /** 
     * Get all uploaded members list based on logged in user type
     * @param $request, $id - here id is partner id
     * Access: admin, partner prefix: api
     * 
     * @return \Illuminate\Http\Response
    */
    public function uploaded_members(Request $request, $id)
    {
        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $pageno = 1; $pagelength = 10; 
            $totalrecords = FleetDriver::with('company')->where('sheet_id', $id)->count();
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
            }

            $list = FleetDriver::with('company')->where('sheet_id', $id);
            if(Auth::user()->login_type_id == 19) // Partner Login
                $list = $list->where('fleet_id', Auth::user()->org_id);

            $list = $list->skip( ($pageno-1)*$pagelength )->take($pagelength)
                    ->orderBy('id', 'desc')->get();
            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status' => 'success', 'data' => $data], 200);
        }else{
            $list = FleetDriver::with('company')->where('sheet_id', $id)->get();
            return response()->json(['status' => "success", "data" => $list ], 200);
        }
    }

    /** 
     * Get all Activated members list based on the logged in user type
     * @param $request
     * Access: admin, partner prefix: api
     * 
     * @return \Illuminate\Http\Response
    */
    public function activated_members(Request $request)
    {
        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $pageno = 1; $pagelength = 10;
            $totalrecords = FleetDriver::with('company')->whereNotNull('driver_id')->count();
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
            }
            $list = FleetDriver::with('company')->whereNotNull('driver_id');
            if(Auth::user()->login_type_id == 19) // Partner Login
                $list = $list->where('fleet_id', Auth::user()->org_id);

            $list = $list->skip( ($pageno-1)*$pagelength )->take($pagelength)
                    ->orderBy('id', 'desc')->get();
            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status' => 'success', 'data' => $data], 200);
        }else{
            $list = FleetDriver::with('company')->whereNotNull('driver_id')->get();
            return response()->json(['status' => "success", "data" => $list ], 200);
        }
    }

    /**
     * Activate partner members information based on the fleet driver id
     * @param $id
     * 
     * @return \Illuminate\Http\Response
    */
    public function activeUserInfo($id)
    {
        $list = FleetDriver::with( 'driver')->where('id', $id)->first();
        return response()->json(['status' => "success", "data" => $list ], 200);
    }

    /**
     * deactivate partner members
     * @param $fleet_driver_id
     * 
     * @return \Illuminate\Http\Response
    */
    public function deactive_employee($fleet_driver_id)
    {
        FleetDriver::where('id', $fleet_driver_id)->update(['status' => 0, 'updated_at' => date('Y-m-d H:i:s')]);
        return response()->json(['status' => "success", "message" => 'Employee Deactivated Successfully' ], 200);
    }

    /**
     * Add new partner members to each partner
     * @param $request
     * 
     * @return \Illuminate\Http\Response
     */
    function add_partner_employee(Request $request){
        try{
            $contactNo=$request['contact_no'];
            $request['contact_no'] = $request['country_code'].$request['contact_no'];
            $validator = Validator::make($request->all(),[
                'first_name' => 'required|max:100',
                'fleet_id' => 'required',
                'employee_id' => 'required',
                'country_code' => 'required|max:5',
                'contact_no' => 'required|max:15|unique:drivers,contact_no,NULL,id,deleted_at,NULL',
               
            ]);

            if ($validator->fails()) {
                $errors = [];
                foreach(json_decode($validator->messages()) as $key => $value)
                    $errors[] = $value[0];
                return response()->json([ 'status' => "failed", "response" => $errors ], 400);
            }

            $request['status']=0;
            $fleetId=FleetDriver::insertGetId($request->all());

            $request['gender']=NULL;
            $request['licence_id']=NULL;
            $request['nationality']=NULL;
            $request['dob']=NULL;
            $request['contact_no']=$contactNo;
                 
            return $this->updateFleetDriverDetails($request, $fleetId);

        }
        catch(\Exception $e){
            //return $e;
            return response()->json(['status' => 'failed', 'response' => 'Failed to add Driver', 'e'=>$e->getMessage()], 400);
        }
    }

    /**
     * Update fleet driver details
     * @param $request, $id
     * @return $data
     */
    public function updateUserInfo(Request $request, $id) {
        return $this->updateFleetDriverDetails($request, $id);
    }

    /**
     * Update fleet driver details using activate or deactivate
     * @param $request, $id
     * @return
     */
    function updateFleetDriverDetails($request, $id){
       try{
            $fleet_driver = FleetDriver::where('id', $id)->first();
            if(!$fleet_driver->employee_id)
                return response()->json(['status' => 'failed', 'response' => 'Member id not found'], 400);

            // if($fleet_driver->driver_id != '')
            //     return response()->json(['status' => 'failed', 'response' => 'Member already activated.'], 400);


            $contactno = $fleet_driver->country_code.$fleet_driver->contact_no;
            $check_empidfleet = FleetDriver::where('fleet_id', $fleet_driver->fleet_id)->where('employee_id', $fleet_driver->employee_id)->where('status', 1)->count();

            if($check_empidfleet > 0)
                return response()->json(['status' => 'failed', 'response' => 'Member already activated'], 400);

            $check_driver = Driver::where('contact_no', $contactno)->first();

            $contactNo=$request['country_code'].$request['contact_no'];
            $fleerDriver = array(
                'first_name'   => $request['first_name'],
                'last_name'   => $request['last_name'],
                'email'   => $request['email'],
                'country_code'   => $request['country_code'],
                'contact_no'   =>$contactNo,
                'status' =>$request->status
            );

            $request['dob']=($request['dob']!='' && $request['dob']!='null') ? $request['dob'] : NULL;
            $request['email']=($request['email']!='' && $request['email']!='null') ? $request['email'] : '';

            $request['gender']=($request['gender']!='' && $request['gender']!='null') ? $request['gender'] : '';

            $request['nationality']=($request['nationality']!='' && $request['nationality']!='null') ? $request['nationality'] : '';
           
            $request['licence_id']=($request['licence_id']!='' && $request['licence_id']!='null') ? $request['licence_id'] : '';
               
            $driver_data = [
                'first_name' => $request['first_name'],
                'last_name' => $request['last_name'],
                'email' => $request['email'],
                'country_code' => $request['country_code'],
                'contact_no' => $contactNo,
                'gender' => $request['gender'],
                'licence_id' => $request['licence_id'],
                'nationality' => $request['nationality'],
                'is_verified' => isset($request['is_verified']) ? $request['is_verified'] : '0' ,
                'dob'=>$request['dob'],
                'status'=>$request->status,  
            ];


            if(config('app.env') == 'local'){
                if ($file=$request->file('thumbnail')) {
                    $extension = $file->extension()?: 'png';
                    $destinationPath = public_path() . '/uploads/drivers/profiles/';
                    $safeName = Str::random(10) . '.' . $extension;
                    $file->move($destinationPath, $safeName);
                    $driver_data['profile_pic'] = '/uploads/drivers/profiles/'.$safeName;
                }
            } else {
                $file_name = Storage::disk('s3')->put('drivers/profiles/', $request->file('thumbnail'));
                $driver_data['profile_pic'] = Storage::disk('s3')->url($file_name);
            }

            if(config('app.env') == 'local'){
                if ($file=$request->file('licence')) {
                    $extension = $file->extension()?: 'png';
                    $destinationPath = public_path() . '/uploads/drivers/licences/';
                    $safeName = Str::random(10) . '.' . $extension;
                    $file->move($destinationPath, $safeName);
                    $driver_data['licence_file'] = '/uploads/drivers/licences/'.$safeName;
                }
            } else {
                $file_name = Storage::disk('s3')->put('drivers/licences/', $request->file('licence'));
                $driver_data['licence_file'] = Storage::disk('s3')->url($file_name);
            }
                
            if($check_driver){
                $check_empdriver = FleetDriver::where('employee_id', $fleet_driver->employee_id)
                    ->where('driver_id', $check_driver->id)->where('status', 1)->count();

                $check_fleetdriver = FleetDriver::where('fleet_id', $fleet_driver->fleet_id)
                    ->where('driver_id', $check_driver->id)->where('status', 1)->count();

                if ($check_empdriver <= 0 && $check_fleetdriver <= 0) {

                    $fleerDriver['driver_id']= $check_driver->id;
                    $fleerDriver['updated_at']= date('Y-m-d H:i:s');
                    
                    $driver_data['updated_at']= date('Y-m-d H:i:s');
                    FleetDriver::where('id', $id)->update($fleerDriver);

                    Driver::where('id', $check_driver->id)
                        ->update($driver_data);

                    return response()->json(['status' => 'success', 'response' => 'Consumer Activated Successfully11'], 200);
                } else {
                    return response()->json(['status' => 'failed', 'response' => 'Consumer already assigned.'], 400);
                }

            } else {
                $driver_id=$fleet_driver->driver_id; 
                $driver_data[ 'password']=Hash::make('0000');
                if(!$fleet_driver->driver_id){
                    $driver_id = Driver::insertGetId($driver_data);
                } else {
                    Driver::where('id', $fleet_driver->driver_id)
                        ->update($driver_data);
                } 
                   
                $fleerDriver['driver_id']=  $driver_id;
                $fleerDriver['updated_at']= date('Y-m-d H:i:s');
                
                FleetDriver::where('id', $id)->update($fleerDriver);

                FleetDriver::where('id', $id)->update(['driver_id' => $driver_id, 'status' => $request->status, 'updated_at' => date('Y-m-d H:i:s')]);

                return response()->json(['status' => 'success', 'response' => 'Consumer Activated Successfully'], 200);
            }
        }
        catch(\Exception $e){
            return response()->json(['status' => 'failed', 'response' => 'Failed to update Consumer', "error" => $e->getMessage()], 400);
        }
    }

    /**
    * Get admin user details based on the user id
    * @param $id
    *
    * @return \Illuminate\Http\Response
    */   
    public function adminuser($id) {
        $list = User::where('id', $id)->where('role_id', 6)->with('company')->first();
        return response()->json(['status' => 'success', 'message'=> 'Admin Details', 'data' => $list], 200);
    }

    /**
    * Get Partner companies of the particular driver
    * @param $driver id, $pageno, $pagelength as $request
    *
    * @return \Illuminate\Http\Response
    */
    public function driver_fleet_companies(Request $request, $driver_id)
    { 
        $customerData=Driver::where('id',  $driver_id)->first();
         $list = FleetDriver::where('driver_id', $driver_id)
                  ->with('company','company.groups_list')->where('status',1);
        $pageno = 1; $pagelength = 10;
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }
                        
        $totalrecords = $list->count();

        $list = $list->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;
        return response()->json(['status' => 'success', 'data' => $data, "customer_data"=>$customerData], 200);    
    }



    /**
     * get all information related to dealer reagard total earnings, categories,
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
    */
    public function show_info($id)
    {
        $org_details = Fleet::where('id', $id)->with('location')->first();

        $adminInfo = User::with('loggedin_devices')->where('org_id', $id)->where('role_id',6)->orderBy('id','ASC')->first();

        $groupsList = ConsumerGroup::withCount('consumers')->where('company', $id)->get();   

        $data['groups_list']=$groupsList;
        $data['user_info']=$adminInfo;
        $data['org_details']=$org_details;

        // Payouts information calculation
        $todayDate=date("Y-m-d");

        $paid_date = Payout::where('status', 1)->where('payment_to', $id)->orderBy('id', 'desc')->pluck('paid_date')->first();

        $paid_date = $paid_date ? $paid_date : '2021-10-01';

        $toDate = date('Y-m-d', strtotime($todayDate .' -1 day'));

        //Calculate total partner shares
        $totalPartnerShare = (new PayoutController)->getPartnerShareLimit($id, $paid_date, $toDate);

         // Get payouts information of the dealer
         $payouts = Payout::where('payment_to',$id)
            ->orderBy('id', 'desc')
            ->skip(0)->take(10)->get();

        $amount_paid = Payout::where('status', 1)
                ->where('payment_to', $id)->where('paid_date', $paid_date)
                ->orderBy('id', 'desc')->pluck('amount_paid')->first();
        $amount_paid = $amount_paid ? $amount_paid : 0;

        $fleetDrivers=FleetDriver::where('fleet_id', $id);
        $totalEmployees= $fleetDrivers->count();//Total employees
        $fleetDrivers = $fleetDrivers->skip(0)->take(10)->get();

        $counterArray['employee_counter']=$totalEmployees;
        $counterArray['total_partner_share']=$totalPartnerShare;
        $counterArray['total_payouts']=$amount_paid;

        $data['counters']=$counterArray;
        $data['fleet_drivers']=$fleetDrivers;// Get latest fleet drivers

        //Get address list
        $addressList = Location::with('city')->where('org_id', $id)->get();
        $data['address_list']=$addressList;
        $data['payouts_list']=$payouts;

        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    /**
    * get fleet drivers list using fleet id
    * @param Request $request, $orgId
    *
    * @return \Illuminate\Http\Response
    */
    function getFleetDriversList(Request $request, $orgId){

        $pageno = 1; $pagelength = 10;
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = FleetDriver::where('fleet_id', $orgId);
        $totalrecords = $list->count();
        $list =$list->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    /**
    * When admin wanted to assign fleet to customer
    * @param Request $request
    *
    * @return \Illuminate\Http\Response
    */
    public function assign_fleeto_customer(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'fleet_id' => ['required'],
                'status' => ['required'],
                'customer_id' => ['required']
            ] 
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try{
            $fleatDriverData = FleetDriver::where('driver_id', $request->customer_id)->where('fleet_id', $request->fleet_id)->orderBy('id', 'desc')->first();

            if(!empty($fleatDriverData)){
                if(!$fleatDriverData->status){
                    FleetDriver::where('id', $fleatDriverData->id)
                    ->update([
                        'updated_at'=>date('Y-m-d H:i:s'),
                        'driver_id' => $request->customer_id,
                        'status' => 1
                    ]);
                } else {
                   return response()->json([
                    'status' => "failed",
                    "response" => "Already you have assigned customer for this company" 
                   ], 400);

                }
                
            } else {
                $fleetDriver = Driver::where('id',  $request->customer_id)->first();

                $fleetCnt = FleetDriver::where('fleet_id', $request->fleet_id)->count();
                $employee_id = $request->fleet_id . sprintf('%05d', $fleetCnt);

                FleetDriver::insert([
                    'fleet_id' =>$request->fleet_id,
                    'driver_id' => $request->customer_id,
                    'first_name' => $fleetDriver->first_name,
                    'last_name' => $fleetDriver->last_name,
                    'email' => $fleetDriver->email,
                    'employee_id' => $employee_id,
                    'status' => $request->status,
                    'created_at'=>date('Y-m-d H:i:s'),
                ]);                   
            }

            return response()->json(['status' => "success"], 200);
        }
        catch (\Exception $e){
            return response()->json(['status' => "failed", "response" => "Something went wrong", "error" => $e->getMessage()], 400);
        }    
    }

    /**
    *  When admin wanted to assign fleet to customer
    *  @param Request $request
    *
    *  @return \Illuminate\Http\Response
    */
    public function edit_customerto_fleet(Request $request, $id)
    {
        $validator = Validator::make($request->all(),
            [
                'fleet_id' => ['required'],
                'status' => ['required'],
                'customer_id' => ['required']
            ] 
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try{
           
            $fleatDriverData = FleetDriver::where('driver_id', $request->customer_id)->where('fleet_id', $request->fleet_id)->where('id', $id)->orderBy('id', 'desc')->first();

            if(!empty($fleatDriverData)){
                
                    FleetDriver::where('id', $fleatDriverData->id)
                    ->update([
                        'updated_at'=>date('Y-m-d H:i:s'),
                        'driver_id' => $request->customer_id,
                        'status' => $request->status
                    ]);
                 
                
            } else{ 
                return response()->json([
                    'status' => "failed",
                    'response' => "Fleet driver details not found" 
                ], 400);
            }

            return response()->json(['status' => "success"], 200);
        }
        catch (\Exception $e){
            return response()->json(['status' => "failed", "response" => "Something went wrong", "error" => $e->getMessage()], 400);
        }
        
    } 

    /**
    * Get fleet driver details based on the customer id and id
    * @param $id, $customerId
    * @return \Illuminate\Http\Response
    */
    function getFleetDriverInfo($id, $customerId){

        $fleetData = FleetDriver::where('driver_id', $customerId)->where('id', $id)->with('company','company.groups_list')->first();
        return response()->json(['status' => "success", "data" => $fleetData ], 200);
    }
}
