<?php

namespace App\Http\Controllers\Users;

use App\Http\Controllers\Controller;
use App\Models\Accounts\User;
use App\Models\Regulatory\Organization;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public $adminRole;
    public function __construct()
    {
        $this->adminRole = 4;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $loginTypeId=isset($request->login_type_id) ? $request->login_type_id : '17';
        $list = User::join('roles', 'users.role_id', 'roles.id')->where('roles.login_type_id', $loginTypeId)->select('users.*');

        if($request->login_type_id!=17 && Auth::user()->login_type_id!=17){
          $list =$list->where('org_id',Auth::user()->org_id);
        }

        $pageno = 0; $pagelength = 0; 
        $totalrecords = $list->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
            $list = $list->skip( ($pageno-1)*$pagelength )->take($pagelength);
        }  
            
        $list=$list->get();
          
        $data['data'] = $list;
        $data['current_page'] =$pageno ? $pageno : '1';
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength ? $pagelength : '200';
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request['contact_no'] = $request['country_code'].$request['contact_no'];
        $orgId=$this->getAdminOrginization();
        $request['org_id']=isset($request['org_id']) ? $request['org_id'] : $orgId;

        $validator = Validator::make($request->all(),[
            'first_name' => 'required|max:100',
            'last_name' => 'max:100',
            'email'    => ['required', 'string', 'email', 'unique:users,email,NULL,id,deleted_at,NULL', 'max:60'],
            'country_code' => 'required|max:5',
            'contact_no' => ['required', 'max:15', 'unique:users,contact_no,NULL,id,deleted_at,NULL'],
            'status' => 'required',
            'thumbnail' => ['required', 'mimes:jpeg,jpg,png', 'max:500' ],
            'role_id' => 'required',
            'org_id'=>'required',
            'is_email_verified'=>'required',
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/admins/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['profile_pic'] = '/uploads/admins/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('admins/', $request->file('thumbnail'));
            $request['profile_pic'] = Storage::disk('s3')->url($file_name);
        }

        try{
            //$request['org_id'] = Organization::where('company_type', 'A')->pluck('id')->first();
            $request['password'] = Hash::make('admin@123');
            //$request['role_id'] = $this->adminRole; //Admin
            $request['created_at'] = date('Y-m-d H:i:s');

            User::create($request->except('thumbnail'));
            return response()->json(['status' => 'success', 'response' => 'Successfully added an Admin'], 200);
        }
        catch(\Exception $e){
            return response()->json(['status' => 'failed', 'response' => 'Failed to add Admin', "error" => $e], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $list = User::where('id', $id)->first();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $orgId=$this->getAdminOrginization();
        $request['org_id']=isset($request['org_id']) ? $request['org_id'] : $orgId;

        $request['contact_no'] = $request['country_code'].$request['contact_no'];
        $validator = Validator::make($request->all(),[
            'first_name' => 'required|max:100',
            'last_name' => 'max:100',
            'email' => ['required', 'max:60', 'email', 'unique:users,email,'.$id.',id,deleted_at,NULL'],
            'country_code' => 'required|max:5',
            'contact_no' => ['required', 'max:15', 'unique:users,contact_no,'.$id.',id,deleted_at,NULL'],
            'status' => 'required',
            'role_id' => 'required',
            'org_id'=>'required',
            'is_email_verified'=>'required',
           // 'thumbnail' => ['mimes:jpeg,jpg,png', 'max:500' ],
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        //Check logged in user is partner or dealer then they can't modify other company admin details
        $userData=User::where('id', $id)->with('role')->first();
        if(Auth::user()->login_type_id!=17 && $userData->org_id!=Auth::user()->org_id){ 
            return response()->json(['status' => 'failed', 'response' => "You can't modify other company admin users information"], 400);   
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/admins/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['profile_pic'] = '/uploads/admins/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('admins/', $request->file('thumbnail'));
            $request['profile_pic'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $request['updated_at'] = date('Y-m-d H:i:s');

            User::where('id', $id)->update($request->except('thumbnail'));
            return response()->json(['status' => 'success', 'response' => 'Successfully updated an Admin'], 200);
        }
        catch(\Exception $e){
            return response()->json(['status' => 'failed', 'response' => 'Failed to update Admin', "error" => $e], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
       $login_type_id =Auth::user()->login_type_id;
       //$list = User::where('id', $id)->first();

       $list =User::join('roles', 'users.role_id', 'roles.id')->select('users.*','roles.login_type_id')->where('users.id', $id)->first();

       if($list){
           $loginTypeId=$list->login_type_id;
           if($login_type_id!=$loginTypeId && $login_type_id!=17){
             return response()->json(['status' => 'failed', 'response' => "You don't have rights to delete other admins"], 400);
           }

           $list=User::where('id', $id)->delete();
            return response()->json(['status' => 'success', 'response' => 'Admin details deleted successfully'], 200);

       } else {
          return response()->json(['status' => 'failed', 'response' => 'Admin details not found'], 400);
       }
    }

    function getAdminOrginization(){
        $orgId=Organization::where('company_type', 'A')->pluck('id')->first();
        return $orgId;
    }


    function getOrganizationsList($companyType){
        $list = Organization::where('company_type', $companyType)
            ->where('status', 1)
            ->orderBy('org_name', 'ASC');

        if(Auth::user()->login_type_id!=17){
          $list =$list->where('id',Auth::user()->org_id);
        }

        $list = $list->get();

        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

}
