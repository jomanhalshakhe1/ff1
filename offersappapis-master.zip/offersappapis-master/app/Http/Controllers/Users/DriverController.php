<?php
//Import required controllers, models and dependencies
namespace App\Http\Controllers\Users;

use App\Http\Controllers\Controller;
use App\Models\Accounts\Driver;
use App\Models\Accounts\FleetDriver;
use App\Models\Accounts\Reset;
use App\Models\Generals\Device;
use App\Models\Accounts\Vehicle;
use App\Models\Generals\Role;
use Illuminate\Contracts\Auth\Guard;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Mockery\Exception;
use Illuminate\Support\Str;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Generals\SendPushNotification;
use App\Http\Controllers\Generals\EmailController;
use App\Events\Emails\ChangeMobileNumber;
use App\Http\Controllers\Users\CreditsController;
use App\Http\Controllers\TransactionController;
use App\Models\Accounts\ConsumerGroup;
use App\Http\Controllers\Users\ConsumerGroupController;
use App\Http\Controllers\Generals\NotificationController;
use App\Http\Controllers\Generals\FavouriteController;
use App\Models\Regulatory\Fleet;

class DriverController extends Controller
{
    public function __construct(Guard $guard)
    {
        $this->driver = $guard->user();
    }

    /**
     * Display a listing of the resource.
     *
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $login_type_id = Auth::user()->login_type_id;

        $pageno = 1; $pagelength = 10;
        $list = Driver::with('fleets');
        if($login_type_id == 19) // Fleet Company
        {
            $org_id = Auth::user()->org_id;
            $list = $list->whereHas('fleets' , function($query) use ($org_id){
                // only effective customer list
                $query->where('fleet_drivers.fleet_id', $org_id);
            });
            $list = $list->with(['fleets' => function($query) use ($org_id){
                // only effective fleet drivers
                $query->where('fleet_drivers.fleet_id', $org_id);
            }]);
        }

        if(explode('/', $request->route()->getPrefix())[0] == 'api'){

            $totalrecords = $list->count();
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)){
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
            }
            $list = $list->orderBy('id', 'desc')
                ->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status' => 'success', 'data' => $data], 200);
        }else{
            $list = $list->where('status', 1)->get();
            return response()->json(['status' => 'success', 'data' => $list], 200);
        }
    }

    /*
     * Access: Admin, Parner, Prefix: api, Method Type: Get, POST
     * Send active consumerss list
     * $org_id - partner id - it is optional
     * Can get list by partner
     * Fetch records by pagination in post request method
     */
    public function active_customers(Request $request, $fleet_id = null) {

        $isPartner = false;
        if(isset($request->fleet_id) && $request->fleet_id>0){
          $fleet_id=$request->fleet_id; 
        }

        $isPartner=$this->checkFleetIdIsPartner($fleet_id);

        if(Auth::user()->login_type_id == 19 || ($isPartner)) // Fleet Company
        {
            $list = Driver::join('fleet_drivers', 'drivers.id', 'fleet_drivers.driver_id')
                ->select('drivers.*', 'fleet_drivers.employee_id')
                ->where('fleet_drivers.status', 1)
                ->where('drivers.status', 1)
                ->where('drivers.is_verified', 1);

            if(isset($request->fleet_id) && $request->fleet_id>0){
               $fleet_id=$request->fleet_id;
            }

            if(Auth::user()->login_type_id == 19){ // Fleet Company
                $list = $list->where('fleet_drivers.fleet_id', Auth::user()->org_id );
            } else if($fleet_id) {
                if(Fleet::where('company_type', 'F')->where('id', $fleet_id)->first())
                    $list = $list->where('fleet_drivers.fleet_id', $fleet_id );
            }  
        } else {
            // All users for admin
            $list = Driver::select('drivers.*', DB::raw(" '' as employee_id"))
                        ->where('is_verified', 1)->where('id','!=', 1)->where('drivers.status', 1);

        }

        // If deleted users from all users list
        if(isset($request->deleted_users) && $request->deleted_users!=''){
            $arr=explode(',',$request->deleted_users);
            $list=$list->whereNotIn('drivers.id',$arr);
        }

        if(isset($request->search_keyword) && !empty($request->search_keyword)){
            $list = $list->where('drivers.first_name','LIKE',"%{$request->search_keyword}%");
            $list = $list->orWhere('drivers.last_name','LIKE',"%{$request->search_keyword}%");
            $list = $list->orWhere('drivers.contact_no','LIKE',"%{$request->search_keyword}%");
            $list = $list->orWhere('drivers.email','LIKE',"%{$request->search_keyword}%");
        }

        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $totalrecords = $list->count();

            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
            $list = $list->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

            $data['data'] = $list;
            $data['current_page'] =$pageno ? $pageno : '1';
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength ? $pagelength : '200';

            return response()->json(['status' => 'success', 'data' => $data], 200);
        }
        else{
            $list = $list->get();
            return response()->json(['status' => 'success', 'data' => $list], 200);
        }
    }

    function checkFleetIdIsPartner($fleetId){
        $isPartner=false;
        if(Fleet::where('company_type', 'F')->where('id', $fleetId)->count()){
            $isPartner=true;
        }

        if(Fleet::where('company_type', 'A')->where('id', $fleetId)->count()){
            $isPartner=false;
        }

        return $isPartner;
    }

    /*
     * Prefix: api, Access: admin
     * Account deleted customer list should be listed in accounts > customers > deleted
     */
    public function deleted_customers(Request $request)
    {
        $pageno = 1; $pagelength = 10;
        $list = Driver::with('fleets')->whereNotNull('deleted_at')->withTrashed();

        if(Auth::user()->login_type_id == 19) // Fleet Company
        {
            $org_id = Auth::user()->org_id;
            $list = $list->whereHas('fleets' , function($query) use ($org_id){
                // only effective customer list
                $query->where('fleet_drivers.fleet_id', $org_id);
            });
            $list = $list->with(['fleets' => function($query) use ($org_id){
                // only effective fleet drivers
                $query->where('fleet_drivers.fleet_id', $org_id);
            }]);
        }

        $totalrecords = $list->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)){
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }
        $list = $list->orderBy('id', 'desc')
            ->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request['contact_no'] = $request['country_code'].$request['contact_no'];
        $validator = Validator::make($request->all(),[
            'first_name' => 'required|max:100',
            'last_name' => 'max:100',
           // 'dob' => 'required',
            'country_code' => 'required|max:5',
            'email' => ['nullable', 'max:60', 'unique:drivers,email,NULL,id,deleted_at,NULL'],
            'contact_no' => 'required|max:15|unique:drivers,contact_no,NULL,id,deleted_at,NULL',
            'licence_id' => 'max:100',
            'status' => 'required',
            'is_email_verified'=>'required',
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if($request->email!=''){
            if(Driver::where('email', $request->email)->whereNull('deleted_at')->count()>0){
                 return response()->json(['status' => 'failed', 'response' => 'Email id already existed'], 400);
            }
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/drivers/profiles/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['profile_pic'] = '/uploads/drivers/profiles/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('drivers/profiles/', $request->file('thumbnail'));
            $request['profile_pic'] = Storage::disk('s3')->url($file_name);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('licence')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/drivers/licences/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['licence_file'] = '/uploads/drivers/licences/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('drivers/licences/', $request->file('licence'));
            $request['licence_file'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $request['password'] = Hash::make('0000');
            $request['created_at'] = date('Y-m-d H:i:s');

            if(Auth::user()->login_type_id == 19) // Fleet Company
            {
                $request['org_id'] = Auth::user()->org_id;
            }

            $driver_id = Driver::insertGetId($request->except('licence', 'thumbnail'));

            if(Auth::user()->login_type_id == 19) // Fleet Company
            {
                $fleet_id = Auth::user()->org_id;
                $fleetCnt = FleetDriver::where('fleet_id', $fleet_id)->count();
                $employee_id = $fleet_id . sprintf('%05d', $fleetCnt);

                $driver_data = [
                    'employee_id' =>$employee_id,
                    'email' =>$request->email,
                    'first_name' => $request->first_name,
                    'last_name' => $request->last_name,
                    'country_code' => $request->country_code,
                    'contact_no' => $request->contact_no,
                    'driver_id'=> $driver_id,
                    'status' => 1,
                    'fleet_id'=>Auth::user()->org_id
                ];

                FleetDriver::insert($driver_data);
            }


            return response()->json(['status' => 'success', 'response' => 'Successfully added a Driver'], 200);
        }
        catch(\Exception $e){
            //return $e;
            return response()->json(['status' => 'failed', 'response' => 'Failed to add Driver', 'e'=>$e->getMessage()], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $list = Driver::where('id', $id)->first();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request['contact_no'] = $request['country_code'].$request['contact_no'];
        $validator = Validator::make($request->all(),[
            'first_name' => 'required|max:100',
            'last_name' => 'max:100',
            'country_code' => 'required|max:5',
            'email' => 'nullable|max:60|unique:drivers,email,'.$id.',id,deleted_at,NULL',
            'contact_no' => 'required|max:15|unique:drivers,contact_no,'.$id.',id,deleted_at,NULL',
            'licence_id' => 'max:100',
            'status' => 'required',
            'is_email_verified'=>'required',
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if($request->email!='' && $request->email!='null'){
            if(Driver::where('email', $request->email)->where('id','!=',$request->id)->count()>0){
                 return response()->json(['status' => 'failed', 'response' => 'Email id already existed'], 400);
            }
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/drivers/profiles/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['profile_pic'] = '/uploads/drivers/profiles/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('drivers/profiles/', $request->file('thumbnail'));
            $request['profile_pic'] = Storage::disk('s3')->url($file_name);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('licence')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/drivers/licences/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['licence_file'] = '/uploads/drivers/licences/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('drivers/licences/', $request->file('licence'));
            $request['licence_file'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $request['updated_at'] = date('Y-m-d H:i:s');
            Driver::where('id', $id)->update($request->except('licence', 'thumbnail', 'fleets'));
            $token ='';
            //if(!$request['status']) // if user set as inactive, delete their active sessions
                //$token = $this->deactivate_session($id);

            return response()->json([
                'status' => 'success',
                'response' => 'Driver Updated Successfully',
                'token' => $token,
                'user' => Driver::find($id)
            ], 200);
        }
        catch(\Exception $e){
            return response()->json(['status' => 'failed', 'response' => 'Failed to update Driver', "error" => $e], 400);
        }
    }

    public function update_fleet($fleets){

        foreach ($fleets as $fleet)
        {
             if($fleet['employee_id'] == '')
             {
                 $fleetDriver = Driver::where('id', Auth::guard('driver')->id())->first();
                 FleetDriver::insert([
                     'fleet_id' => $fleet['fleet_id'],
                     'driver_id' => $fleetDriver->id,
                     'first_name' => $fleetDriver->first_name,
                     'last_name' => $fleetDriver->last_name,
                     'email' => $fleetDriver->email
                 ]);
             }
             else{
                 FleetDriver::where('fleet_id', $fleet['fleet_id'])->where('employee_id', $fleet['employee_id'])
                     ->update([ 'driver_id' => Auth::guard('driver')->id() ]);
             }
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try{
            Driver::where('id', $id)->delete();
            return back()->with('success','Driver Successfully Deleted');
        }
        catch(\Exception $e){
            Log::info("DriverController::destroy ".Auth::user()->first_name."".Auth::user()->last_name." Failed to delete Driver".$e);
            return redirect()->back()->with('failed','Failed to delete Driver');
        }
    }

    public function signup(Request $request)
    {
        if(substr($request['contact_no'], 0,1) != '+')
            $request['contact_no'] = $request['country_code'].ltrim($request['contact_no'], '0');

        $rules = array(
                'first_name'    => ['required', 'string', 'max:20' ],
                'country_code'    => ['required', 'string', 'max:5'],
                'contact_no'    => ['required', 'string', 'max:15', 'unique:drivers,contact_no,NULL,id,deleted_at,NULL' ],
                'email'    => ['nullable', 'email', 'max:60', 'unique:drivers,email,NULL,id,deleted_at,NULL'  ],
                //'password'    => ['required', 'string', 'max:60' ],
                //'read_otpcode'    => ['required', 'string'],
        );

        $messages = array(
            'first_name.required' => 'Name field is required',
            'first_name.max' => 'Name should be max 20 characters',
            'contact_no.required' => array(
                'en' => 'Contact No. Required',
                'ar' => 'رقم الاتصال مطلوب',
            ),
            'contact_no.unique' => array(
                'en' => 'This number is registered with us, please login directly',
                'ar' => 'هذا الرقم مسجل لدينا، الرجاء تسجيل الدخول مباشرة',
            ),
            'email.required' => array(
                'en' => 'Email Required',
                'ar' => 'البريد الإلكتروني (مطلوب',
            ),
            'email.unique' => array(
                'en' => 'This email is registered with us, please login directly',
                'ar' => 'تم تسجيل هذا البريد الإلكتروني معنا ، يرجى تسجيل الدخول مباشرة',
            )
        );

        $validator = Validator::make($request->all(),$rules , $messages);

        if ($validator->fails()) {
            $errors = []; $errors_ar = [];
            foreach(json_decode($validator->messages()) as $key => $value){
                $errors[] = is_object($value[0]) ? $value[0]->en : $value[0];
                $errors_ar[] = is_object($value[0]) ? $value[0]->ar : $value[0];
            }

            return response()->json([ 'status' => "failed", "response" => $errors, "response_ar" => $errors_ar ], 400);
        }

        // Validate OTP before signup
        if(explode('/', request()->route()->getPrefix())[0] == 'customer') {
            if (Reset::where([['email', $request['contact_no']], ['token', $request['OTP']], ['user_type', 'Driver']])->count() > 0)
                Reset::where('email', $request['contact_no'])->where('user_type', 'Driver')->delete();
            else
                return response()->json([
                    'status' => 'failed',
                    'message' => 'Invalid OTP',
                    'message_ar' => 'OTP غير صحيح',
                ], 400);
        }

        // assign the last word of first name to last name
        $name = trim($request->first_name);
        $names = explode(" ",$name);
        $last_name = count($names) > 1 ? array_pop($names) : '';
        $first_name = trim(str_replace($last_name, '', $name ));

        $inputdata = array(
            'first_name' => $first_name,
            'last_name' => $last_name,
            'country_code' => $request->country_code,
            'contact_no' => $request['contact_no'],
            'email' => $request->email,
            'is_verified' => 1,
            'password' => Hash::make('0000'),
            'created_at' => date('Y-m-d H:i:s')
        );

        $data = [];
        try {
            $user = Driver::insertGetId($inputdata);
            $user = Driver::find($user);
            $token = JWTAuth::fromUser($user);
            $data['user'] = $user;
            $data["token"] = $token;

            $device_log = $request->device_info;
            $device_log['user_id'] = $user->id;
            $device_log['user_type'] = 'driver';

            $read_otpcode = '';
            if(isset($request['read_otpcode']) && !empty($request['read_otpcode'])){
                $read_otpcode = $request['read_otpcode'];
            }
            if(!isset($request['OTP'])){
                $this->send_otp($user->contact_no, $read_otpcode, 'sameclass');
            }
            $this->device_data($device_log);

            return response()->json([
                'status' => 'success',
                'message' => 'Signup Successfully',
                'message_ar' => 'تم التسجيل بنجاح',
                'response' => $data
            ], 200);
        }
        catch (Exception $e){
            return response()->json([
                'status' => 'failed',
                'message' => 'Signup Failed',
                'message_ar' => 'فشل انشاء الحساب',
            ], 400);
        }
    }

    public function device_data($data){
        $data['app_version'] = (substr($data['app_version'], 0,1) == 'v') ? ltrim($data['app_version'], 'v') : $data['app_version'];
        if($data['device_type'] == 'A')
            $data['device_type'] = 'android';
        if($data['device_type'] == 'android/ios')
            $data['device_type'] = 'android';

        $input['user_id'] = $data['user_id'];
        $input['device_id'] = $data['device_id'];
        $input['device_type'] = $data['device_type'];
        $input['device_model'] = isset($data['device_model']) ? $data['device_model'] : $data['device_type'];
        $input['version'] = $data['version'];
        $input['fcm'] = $data['fcm'];
        $input['app_version'] = $data['app_version'];
        $input['ip'] = $_SERVER['REMOTE_ADDR'];
        $input['user_type'] = $data['user_type'];
        $input['status'] = 1;
        if(Auth::guard('driver')->id()){
            // update login user device type to session
            Auth::guard('driver')->user()->device_type = $data['device_type'];
            Auth::guard('driver')->user()->device_id = $data['device_id'];
        }

        $where = array(
            "device_type" => $data["device_type"],
            "device_id" => $data["device_id"],
        );

        $newLog = false;
        // Already has any login on the same device
        if(Device::where($where)->whereIn('user_type', ['driver', 'guest'])->count() > 0) {
            // yes
            if(Device::where($where)->where('user_type', 'driver')->whereNull('user_id')->count() > 0) {
                // Unregistered device - convert to customer and delete log
                Device::where($where)->where('user_type', 'driver')->whereNull('user_id')
                    ->update([
                        'converted_as' => $data['user_id'],
                        'updated_at' => date('Y-m-d H:i:s')
                    ]);

                Device::where($where)->where('user_type', 'driver')->whereNull('user_id')->delete();

                $newLog = true;
            }

            if(Device::where($where)->where('user_type', 'driver')->whereNotNull('user_id')->count() > 0){
                // Driver log
                if(Device::where($where)->where('user_type', 'driver')->where('user_id', $data['user_id'])->count() > 0) {
                    // Same user - Update log
                    $input['updated_at'] = date('Y-m-d H:i:s');
                    Device::where($where)->where('user_type', 'driver')->where('user_id', $data['user_id'])->update($input);
                }
                else {
                    // Not Same user - Delete log for other drivers, Create Customer log
                    $newLog = true;
                }
            }

            if(Device::where($where)->where('user_type', 'guest')->count() > 0){
                // Has Guest log - convert guest to driver login and delete guest log
                Device::where($where)->where('user_type', 'guest')->update(['converted_as' => $data['user_id']]);
                Device::where($where)->where('user_type', 'guest')->delete();

                $newLog = true;
            }

            // Delete other user logs on this device
            Device::where($where)->where('user_type', 'driver')->where('user_id', '!=', $data['user_id'])->delete();
            // Delete other device logins of the same user
            $where = array(
                "device_type" => $data["device_type"],
                "user_type" => 'driver',
                "user_id" => $data["user_id"],
            );
            Device::where($where)->where('device_id', '!=', $data['device_id'])->delete();
        }
        else {
            // Login on other device for customer
            // no log available. Create New log
            $newLog = true;
        }

        $where = array(
            "device_type" => $data["device_type"],
            "user_id" => $data["user_id"],
            "user_type" => 'driver',
        );

        // Delete Technician other device logins
        Device::where($where)->where('device_id', '!=', $data['device_id'])->delete();

        if($newLog) {
            // create guest user log
            $input['created_at'] = date('Y-m-d H:i:s');
            Device::insertGetId($input);
        }

    }

    public function signin(Request $request)
    {
        $data = [];
        $validator = Validator::make($request->all(),
            [
                'contact_no' => ['required', 'string'],
                //'password' => ['required', 'string'],
                //'read_otpcode' => ['required', 'string'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $driverData=Driver::where('contact_no', $request['contact_no'])->first();

        if(empty($driverData))
        {
            return response()->json([
                'status' => "failed",
                "response" => 'Invalid UserId',
                "response_ar" => 'هوية مستخدم غير صالحه',
            ], 400);
        } else{
            if($driverData->is_verified == 2){
                // 2 - Rejected
                return response()->json([
                    'status' => 'failed',
                    'message' => 'Your account was blocked',
                    'message_ar' => 'تم حظر حسابك'], 401);
            }
        }

        $request['password'] = '0000';
        $request['status'] = 1;
        $credentials = $request->only('contact_no', 'password', 'status');

        try {
            if (! $token = Auth::guard('driver')->attempt($credentials)) {
                return response()->json([
                    'status' => 'failed',
                    'response' => "Invalid Credentials",
                    'response_ar' => "بيانات الاعتماد غير صالحة",
                    'data' => $data], 400);
            }
        } catch (JWTException $e) {
            return response()->json(['status' => 'failed','response' => 'could_not_create_token', 'data' => $data], 500);
        }

        Auth::guard('driver')->user()->device_type = 'android';
        $data["Driver"] = Auth::guard('driver')->user();
        $token = JWTAuth::fromUser($data["Driver"]);
        $data["Token"]= $token;

        $read_otpcode = '';
        if(isset($request['read_otpcode']) && !empty($request['read_otpcode'])){
            $read_otpcode = $request['read_otpcode'];
        }
        
        $this->send_otp($data["Driver"]['contact_no'], $read_otpcode, 'sameclass');

        if(isset($request->device_info)) {
            $device_log = $request->device_info;
            $device_log['user_id'] = $data["Driver"]['id'];
            $device_log['user_type'] = 'driver';

            $this->device_data($device_log);
        }

        return response()->json(['status'=>'success','response' => "Success",'data' => $data], 200);
    }

    /*
     * Prefix: customer, Access: customer
     * Update customer profile
     */
    public function update_profile(Request $request)
    {
        $id = Auth::guard('driver')->id();
        $rules = array(
            'first_name'    => ['required', 'string', 'max:20' ],
            'last_name'    => ['max:20' ],
            'email'    => ['required', 'string', 'email', 'max:60', 'unique:drivers,email,'.$id.',id,deleted_at,NULL'],
            'contact_no'    => ['required', 'string', 'max:15', 'unique:drivers,contact_no,'.$id.',id,deleted_at,NULL'],
            //'dob' => ['required', 'string'],
            //'age' => ['required'],
            //'gender' => ['required', 'string'],
            //'licence_id' => ['required', 'string'],
            //'nationality' => ['required', 'string'],
            //'is_self' => ['required'],
        );

        $messages = array(
            'first_name.required' => 'Name field is required',
            'first_name.max' => 'Name should be max 20 characters',
            'contact_no.required' => array(
                'en' => 'Contact No. Required',
                'ar' => 'رقم الاتصال مطلوب',
            ),
            'contact_no.unique' => array(
                'en' => 'This number is registered with us, please login directly',
                'ar' => 'هذا الرقم مسجل لدينا، الرجاء تسجيل الدخول مباشرة',
            ),
            'email.required' => array(
                'en' => 'Email Required',
                'ar' => 'البريد الإلكتروني (مطلوب',
            ),
            'email.unique' => array(
                'en' => 'This email is registered with us, please login directly',
                'ar' => 'تم تسجيل هذا البريد الإلكتروني معنا ، يرجى تسجيل الدخول مباشرة',
            )
        );

        $validator = Validator::make($request->all(),$rules , $messages);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $inputdata = array(
            'email' => $request->email,
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'contact_no' => $request->contact_no,
            'age' => $request->age,
            'gender' => $request->gender,
            'licence_id' => $request->licence_id,
            'dob' => $request->dob,
            'nationality' => $request->nationality,
            'is_self' => $request->is_self,
            'updated_at' => date('Y-m-d H:i:s')
        );

        try {
           $driveData=Driver::where('id', Auth::guard('driver')->id())->first();
            $fleets = $request['fleets'];
            $this->update_fleet($fleets);

            if($driveData->email!=$request->email){
                $inputdata['is_email_verified']=0;
            }

            Driver::where('id', Auth::guard('driver')->id())->update($inputdata);
            $data['user'] = Driver::where('id', Auth::guard('driver')->id())->first();

            return response()->json([
                'status' => 'success',
                'message' => 'Profile Updated Successfully',
                'message_ar' => 'تم تحديث الملف الشخصي بنجاح',
                'response' => $data
            ], 200);
        }
        catch (Exception $e){
            return response()->json(['status' => 'failed', 'message' => 'Profile Update Failed'], 400);
        }
    }

    public function getUserInfo(Request $request)
    {
        $user = Driver::whereId(Auth::guard('driver')->id())->with(['vehicle', 'fleets' ])->first();

        return response()->json([ 'status' => "success", "user" => $user ], 200);
    }

    public function request_verification(Request $request)
    {
        if(substr($request['contact_no'], 0,1) != '+')
            $request['contact_no'] = $request['country_code'].ltrim($request['contact_no'], '0');

        $rules = array(
            'first_name'    => ['required', 'string', 'max:20' ],
            'email'    => ['nullable', 'email', 'max:60', 'unique:drivers,email,NULL,id,deleted_at,NULL' ],
            'country_code'    => ['required', 'string', 'max:5' ],
            'contact_no'    => ['required', 'string', 'max:15', 'unique:drivers,contact_no,NULL,id,deleted_at,NULL' ],
        );
        $messages = array(
            'first_name.required' => 'Name field is required',
            'first_name.max' => 'Name should be max 20 characters',
            'contact_no.required' => array(
                'en' => 'Contact No. Required',
                'ar' => 'رقم الاتصال مطلوب',
            ),
            'contact_no.unique' => array(
                'en' => 'This number is registered with us, please login directly',
                'ar' => 'هذا الرقم مسجل لدينا، الرجاء تسجيل الدخول مباشرة',
            ),
            'email.required' => array(
                'en' => 'Email Required',
                'ar' => 'البريد الإلكتروني (مطلوب',
            ),
            'email.unique' => array(
                'en' => 'This email is registered with us, please login directly',
                'ar' => 'تم تسجيل هذا البريد الإلكتروني معنا ، يرجى تسجيل الدخول مباشرة',
            )
        );

        $validator = Validator::make($request->all(),$rules , $messages);

        if ($validator->fails()) {
            $errors = []; $errors_ar = [];
            foreach(json_decode($validator->messages()) as $key => $value){
                $errors[] = is_object($value[0]) ? $value[0]->en : $value[0];
                $errors_ar[] = is_object($value[0]) ? $value[0]->ar : $value[0];
            }

            return response()->json([ 'status' => "failed", "response" => $errors, "response_ar" => $errors_ar ], 400);
        }

        try{
            $contactNo = $request['contact_no'];
            $read_otpcode = '';
            if(isset($request['read_otpcode']) && !empty($request['read_otpcode'])){
                $read_otpcode = $request['read_otpcode'];
            }
            $this->send_otp($contactNo, $read_otpcode, 'sameclass');

            return response()->json([
                'status' => 'success',
                'response' => 'Contact No. verified for customer account',
                'response_ar' => 'رقم الاتصال التحقق لحساب العميل',
            ], 200);
        }
        catch (\Exception $e){
            return response()->json(['status' => 'failed', 'response' => 'Invalid Contact No.', 'response_ar' => 'رقم الاتصال غير صحيح', ], 400);
        }
    }

    public function verify_otp(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'contact_no' => ['required', 'string'],
                'OTP' => ['required', 'string', 'min:4']
            ]
        );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(!Driver::where('contact_no', $request->contact_no)->get())
            return response()->json(['status'=>'failed', 'message'=> 'Invalid User'], 400);

        // otp is 0000 update
        if($request->OTP == '0000' && env('APP_OTP') != 'production') {
            Reset::where('email' , $request->contact_no)->where('user_type' , 'Driver')->update(array('token' => '0000'));

            if(isset($request->device_info)){
                $user = Driver::where('contact_no', $request->contact_no)->first()->toArray();
                $device_log = $request->device_info;
                $device_log['user_id'] = $user['id'];
                $device_log['user_type'] = 'driver';
                $this->device_data($device_log);
            }
        }

        // Dummy login for app verfication from the store
        if($request->OTP == '8492'
            && env('APP_OTP') == 'production'
            && env('PARTNER_CONTACT') == $request->contact_no
        ) { // Set for application to deploy the app
            Reset::where('email' , $request->contact_no)->update(array('token' => '8492'));
        }

        if(Reset::where([['email', $request->contact_no ],[ 'token' , $request->OTP ],[ 'user_type' , 'Driver' ]] )->count() > 0)
        {
            Driver::where('contact_no', $request->contact_no)->update(['is_verified' => 1]);
            Reset::where('email', $request->contact_no)->where('user_type', 'Driver')->delete();

            $user = Driver::where('contact_no', $request->contact_no)->first()->toArray();
            unset($user['password']);

            // $this->sendRegistryMail($user);
            if(isset($request->device_info)){
                $device_log = $request->device_info;
                $device_log['user_id'] = $user['id'];
                $device_log['user_type'] = 'driver';
                $this->device_data($device_log);
            }

            return response()->json([
                'status'=>'success',
                'message'=> 'OTP Verified',
                'message_ar'=> 'تم التحقق من كلمة المرور لمرة واحدة',
            ], 200);
        }

        return response()->json([
            'status'=>'failed',
            'message'=> 'Invalid OTP',
            'message_ar'=> 'كلمة مرور صالحة لمرة واحدة',
        ], 400);
    }

    public function send_otp($contact_no = '', $readotpcode = null, $routecall = null)
    {
        $readotpcode = $readotpcode ? $readotpcode : '';
        $routecall = $routecall ? $routecall : 'sameclass';

        $otp = mt_rand(1000, 9999);
        //$otp = '0000';

        if($contact_no == '')
            $contact_no = Driver::where('id', Auth::guard('driver')->id())->pluck('contact_no')->first();

        if($contact_no == null || $contact_no == '')
            return response()->json(['status'=>'failed', 'message'=> 'Contact no shoud not be empty'], 400);

        $userData=Reset::where('email', $contact_no)->where('user_type', 'Driver')->first();
        //if(!Reset::find($contact_no))
         if(empty($userData))
            Reset::insert(array('email' => $contact_no, 'user_type' => 'Driver', 'token' => $otp, 'created_at' => date('Y-m-d H:i:s')));
        else
            Reset::where('email', $contact_no)->where('user_type' , 'Driver')->update(array('token' => $otp, 'user_type' => 'Driver', 'created_at' => date('Y-m-d H:i:s')));

        $text = 'JOY Application OTP is: '.$otp;
        //return $this->send_sms($contact_no, $text);
        if(isset($routecall) && $routecall == 'sameclass'){
            (new SendPushNotification)->send_sms($contact_no, $otp, $readotpcode);
        }else{
            (new SendPushNotification)->send_sms($contact_no, $otp, $readotpcode);
        }
        return response()->json([
            'status' => 'success',
            'message' => 'SMS sent Successfully',
            'message_ar' => 'تم إرسال الرسائل القصيرة بنجاح',
        ]);
    }

    public function change_password(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'new_password'    => ['required', 'string', 'min:6'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $update['Password'] = Hash::make($request['new_password']);
        try{
            Driver::where('id', Auth::guard('driver')->id())->update($update);
            Log::info("UserController::changePassword ".Auth::guard('driver')->user()->first_name."".Auth::guard('driver')->user()->last_name." Password Updated");
            return response()->json(['status' => 'success', 'message' => 'Password Updation Successfully']);
        }
        catch(Exception $e){
            return response()->json(['status' => 'failed', 'message' => 'Password Updation Failed'], 400);
        }
    }

    public function forgotpswd(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'contact_no'    => ['required', 'string', 'max:15'],
                //'read_otpcode'    => ['required', 'string'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(Driver::where('contact_no' , $request['contact_no'] )->count() > 0) {
            $read_otpcode = '';
            if(isset($request['read_otpcode']) && !empty($request['read_otpcode'])){
                $read_otpcode = $request['read_otpcode'];
            }
            $this->send_otp($request['contact_no'], $read_otpcode, 'sameclass');
            return response()->json([
                'status'=>'success',
                'message'=> 'OTP sent to requested mail',
                'message_ar'=> 'تم إرسال كلمة المرور لمرة واحدة إلى البريد المطلوب',
            ], 200);

        }else{
            return response()->json([
                'status'=>'failed',
                'message'=> 'Invalid User ID',
                'message_ar'=> 'هوية مستخدم غير صالحه',
            ], 400);
        }
    }

    public function reset_password(Request $request)
    {
        if($request->isMethod('post'))
        {
            $validator = Validator::make($request->all(),
                [
                    'contact_no'    => ['required', 'string', 'max:15'],
                    'new_password'    => ['required', 'string', 'max:60'],
                ]
            );

            if ($validator->fails()) {
                $errors = [];
                foreach(json_decode($validator->messages()) as $key => $value)
                    $errors[] = $value[0];
                return response()->json([ 'status' => "failed", "response" => $errors ], 400);
            }

            if(Driver::where('contact_no' , $request->contact_no )->count() > 0) {

                $password = Hash::make($request->new_password);
                Driver::where('contact_no', $request->contact_no)->update(['password' => $password ]);

                return response()->json([
                    'status'=>'success',
                    'message'=> 'Password Reset Succuessfull',
                    'message_ar'=> 'نجح إعادة تعيين كلمة المرور',
                ], 200);

            }else{
                return response()->json([
                    'status'=>'failed',
                    'message'=> 'Invalid User ID',
                    'message_ar'=> 'هوية مستخدم غير صالحه',
                ], 400);
            }
        }
    }

    public function verify_user(Request $request){

        Driver::where('contact_no', $request->contact_no)->update(['isVerified' => 1]);

        return response()->json([
            'status' => "success",
            "response" => "User was successfuly verified",
            "response_ar" => "تم التحقق من المستخدم بنجاح",
        ], 200);
    }

    public function update_licence(Request $request){

        if(config('app.env') == 'local'){
            if ($file=$request->file('licence')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/drivers/licences/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['licence_file'] = '/uploads/drivers/licences/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('drivers/licences/', $request->file('licence'));
            $request['licence_file'] = Storage::disk('s3')->url($file_name);
        }

        try{
            Driver::whereId(Auth::guard('driver')->id())->update(['licence_file' => $request['licence_file']]);

            return response()->json([
                'status' => "success",
                "response" => "Licence file updated successfully",
                "response_ar" => "تم تحديث ملف الترخيص بنجاح",
                "file_path" => $request['licence_file']
            ], 200);
        }catch (Exception $e){

            return response()->json([ 'status' => "success", "response" => "Licence file update failed" ], 400);
        }
    }

    public function update_dp(Request $request){

        if(config('app.env') == 'local'){
            if ($file=$request->file('dp')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/drivers/profiles/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['profile_pic'] = '/uploads/drivers/profiles/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('drivers/profiles/', $request->file('dp'));
            $request['profile_pic'] = Storage::disk('s3')->url($file_name);
        }

        try{
            Driver::whereId(Auth::guard('driver')->id())->update(['profile_pic' => $request['profile_pic']]);

            return response()->json([
                'status' => "success",
                "response" => "Profile Pic updated successfully",
                "response_ar" => "تم تحديث صورة الملف الشخصي بنجاح",
                "file_path" => $request['profile_pic']
            ], 200);
        }catch (Exception $e){

            return response()->json([ 'status' => "success", "response" => "Profile pic update failed" ], 400);
        }
    }

    public function send_sms($contacts, $sms_text){
        try {
            $account_sid = 'AC4f677e211b813324dcbff8f7c353ee9c';
            $auth_token = '623d5014e6d581a130b6de3b8ffa9fdb';
            $twilio_number = '+12565402397';

            try {
                $client = new Client($account_sid, $auth_token);
                $client->messages->create(
                    $contacts,
                    array(
                        'from' => $twilio_number,
                        'body' => $sms_text
                    )
                );
                return response()->json([ 'status' => "success", "response" => "Message Sent" ], 200);
            }
            catch(Exception $e){
                return response()->json([ 'status' => "failed", "response" => "Message Sent Failed" ], 400);
            }

        }
        catch (Exception $e) {
            return response()->json([ 'status' => "failed", "response" => "Message Sent Failed" ], 400);
            // return false;
        }
    }

	public function sample_sms($contacts = ''){

        $to = $contacts;
        $text = 'Test SMS from NEXMO, Test Account';

        /*
        $zaheer = array('api_key' => '7bd9541d', 'api_secret' => 'st6K9k0mSU92kNFW' );
        $uday = array('api_key' => '82e0a9db', 'api_secret' => 'iaA32CCrvaEdpe4G' );
        $abdul = array('api_key' => 'd81cdaa6', 'api_secret' => 'buBWHiwBdzB03Yga' );
        */
        /* Pass Mobile Number With Country Code in to*/

        $url = 'https://rest.nexmo.com/sms/json?' . http_build_query([
                'api_key' => '82e0a9db',
                'api_secret' => 'iaA32CCrvaEdpe4G',
                'to' => $to,
                'from' => '12192072598',
                'text' => $text
            ]);

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        return $response;
	}

	/*
	 * Access: customer, Prefix: customer
	 * Before going to login customer can request to change their email from here
	 */
    public function changephone_email(Request $request) {
        $validator = Validator::make($request->all(),
            [
                'email'    => ['required', 'string', 'email', 'max:60'],
            ]
        );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $check_email = Driver::where('email', $request['email'])->first();
            if(!$check_email)
                return response()->json([
                    'status' => "failed",
                    "response" => "Entered Email not found.",
                    "response_ar" => "البريد الإلكتروني المدخل غير موجود.",
                ], 400);

            //send OTP to entered Email
            $otp = mt_rand(1000, 9999);

            try{
             // Send notification to user

                event(new ChangeMobileNumber($request['email'], $check_email->first_name, $otp, 'Driver', '1'));
            } catch(\Exception $e){
                return response()->json([
                    'status' => "failed",
                    "response" => "Failed to send mail. Please try again later",
                    "response_ar" => "فشل إرسال البريد. يرجى إعادة المحاولة لاحقا",
                ], 400);
            }

            Reset::where('email', $request['email'])->where('user_type', 'Driver')->delete();
            $update_otp = Reset::insert(['email' => $request['email'], 'token' => $otp, 'user_type' => 'Driver', 'created_at' => date('Y-m-d H:i:s')]);

            if($update_otp){
                return response()->json([
                    'status' => "success",
                    "response" => "OTP sent to your registered email. Please check your Email Inbox",
                    "response_ar" => "تم إرسال كلمة المرور لمرة واحدة إلى بريدك الإلكتروني المسجل. يرجى التحقق من صندوق البريد الإلكتروني الخاص بك",
                ]);
            }else{
                return response()->json([
                    'status' => "failed",
                    "response" => "OTP sent failed",
                    "response_ar" => "فشل إرسال كلمة المرور لمرة واحدة",
                ], 400);
            }

        }catch (\Exception $e){
            return response()->json([
                'status' => "failed",
                "response" => "Email id failed",
                "response_ar" => "Email id failed"
            ], 400);
        }
    }

    public function changephone_verifyotp(Request $request) {
        $validator = Validator::make($request->all(),
            [
                'email'    => ['required', 'string', 'email', 'max:60'],
                'OTP'    => ['required', 'string', 'min:4'],
            ]
        );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{

             // otp is 0000 update
            if($request->OTP == '0000' && env('APP_ENV') != 'production') {
                Reset::where('email' , $request->email)->where('user_type' , 'Driver')->update(array('token' => '0000'));
            }

            if(Reset::where([['email', $request->email],[ 'token' , $request->OTP ],[ 'user_type' , 'Driver' ]] )->count() > 0) {

                Reset::where('email', $request['email'])->where('user_type', 'Driver')->delete();
                //Update email verification
                Driver::where('email', $request->email)->update(['is_email_verified'=>'1']);

                $driver = Driver::where('email', $request->email)->first();

                return response()->json([
                    'status' => "success",
                    "response" => "OTP Verified Successfully",
                    "response_ar" => "تم التحقق من كلمة المرور لمرة واحدة بنجاح",
                    'data' => $driver ]);
            }else{
                return response()->json([
                    'status' => "failed",
                    "response" => "Invalid OTP",
                    "response_ar" => "كلمة مرور صالحة لمرة واحدة",
                ], 400);
            }
        }catch (\Exception $e){
            return response()->json(['status' => "failed", "response" => "OTP failed" ], 400);
        }
    }

    public function change_phone(Request $request) {
        $validator = Validator::make($request->all(),
            [
                'email' => 'required|string|email|max:60',
                'new_phone_country_code' => 'required|max:5',
                'new_contact_no' => 'required|max:15',
            ]
        );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $new_phone = $request['new_phone_country_code'].$request['new_contact_no'];

            // Check old number and newly entered number is same or not
            $check_contact_no_new = Driver::where('contact_no', $new_phone)->where('email', '=', $request->email)->count();
            if($check_contact_no_new){
                $errors = [];
                $errors[] = "New Contact number should not be same as old contact number";
                return response()->json(['status' => 'failed', 'response' => $errors ], 400);
            }

            //Check newly entered contact number is already existed or not
            if(Driver::where('contact_no', $new_phone)->where('email', '!=', $request->email)->count() > 0){
                $errors = [];
                $errors[] = "New Contact number already used";
                return response()->json(['status' => 'failed', 'response' => $errors ], 400);
            }

            //Send OTP to verify and login with new contact number
            $read_otpcode = '';
            if(isset($request['read_otpcode']) && !empty($request['read_otpcode'])){
                $read_otpcode = $request['read_otpcode'];
            }
            $this->send_otp($new_phone, $read_otpcode, 'sameclass');
            return response()->json([
                'status' => "success",
                "response" => "OTP sent to your new phone number.",
                "response_ar" => "تم إرسال كلمة المرور لمرة واحدة إلى رقم هاتفك الجديد."
            ]);

        }catch (\Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Change new phone number failed" ], 400);
        }
    }

    /*
     * Access: customer, Prefix: customer
     * Update new contact no. for customer
     */
    public function update_newphone(Request $request) {
        $validator = Validator::make($request->all(),
            [
                'email' => 'required|string|email|max:60',
                'OTP' => 'required|max:4',
                'new_phone_country_code' => 'required|max:5',
                'new_contact_no' => 'required|max:15',
            ]
        );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $new_phone = $request['new_phone_country_code'].$request['new_contact_no'];

             // Check old number and newly entered number is same or not
            $check_contact_no_new = Driver::where('contact_no', $new_phone)->where('email', '=', $request->email)->count();
            if($check_contact_no_new){
                $errors = [];
                $errors[] = "New Contact number should not be same as old contact number";
                return response()->json(['status' => 'failed', 'response' => $errors ], 400);
            }

            //Check newly entered contact number is already existed or not
           
            if(Driver::where('contact_no', $new_phone)->where('email', '!=', $request->email)->count() > 0){
                return response()->json([
                    'status' => 'failed',
                    'message' => "New Contact number already used",
                    'message_ar' => "رقم الاتصال الجديد مستخدم بالفعل"
                ], 400);
            }

            // otp is 0000 update
            if($request->OTP == '0000' && env('APP_ENV') != 'production') {
                Reset::where('email' , $new_phone)->where('user_type' , 'Driver')->update(array('token' => '0000'));
            }

            if(Reset::where([['email', $new_phone],[ 'token' , $request->OTP ],[ 'user_type' , 'Driver' ]] )->count() > 0) {
                $driver = Driver::where('email', $request->email)
                    ->update([
                        'country_code' => $request->new_phone_country_code,
                        'contact_no' => $new_phone,
                        'updated_at' => date('Y-m-d H:i:s')
                    ] );

                if($driver){
                    return response()->json([
                        'status' => "success",
                        "response" => "New phone number updated successfully.",
                        "response_ar" => "تم تحديث رقم الهاتف الجديد بنجاح."
                    ]);
                }else{
                    return response()->json([
                        'status' => "failed",
                        "response" => "Update new phone number failed.",
                        "response_ar" => "فشل تحديث رقم الهاتف الجديد.",
                    ], 400);
                }
            }else{
                return response()->json([
                    'status' => "failed",
                    "response" => "Invalid OTP.",
                    'response_ar'=> 'كلمة مرور صالحة لمرة واحدة',
                ], 400);
            }
        }catch (\Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Update new phone number failed" ], 400);
        }
    }

    function preferred_language(Request $request){
          $validator = Validator::make($request->all(),
            [
                'language_preference' => 'required|string'
            ]
        );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{

             $inputdata = array(
                'preferred_language' => $request->language_preference,
                'updated_at' => date('Y-m-d H:i:s')
            );
             Driver::where('id', Auth::guard('driver')->id())->update($inputdata);
            $data['user'] = Driver::where('id', Auth::guard('driver')->id())->first();

            return response()->json([
                'status' => 'success',
                'message' => 'Language preference updated successfully',
                'message_ar' => 'تم تحديث الملف الشخصي بنجاح',
                'response' => $data
            ], 200);

        } catch (\Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Failed to set driver language preference","error"=>$e->getMessage() ], 400);
        }
    }

   /**
   * When drivers wanted to delete their account from app
   * @param $request
   * @return \Illuminate\Http\Response
   */
    public function send_otp_delete_account(Request $request){
        $driver_id = Auth::guard('driver')->id();
        $user = Driver::find($driver_id);
        if(!$user)
            return response()->json([ 'status' => "failed", "response" => "User not found",], 400);
        try{
        // Send OTP
         $read_otpcode = '';
        if(isset($request['read_otpcode']) && !empty($request['read_otpcode'])){
            $read_otpcode = $request['read_otpcode'];
        }

        $this->send_otp($user->contact_no, $read_otpcode, 'sameclass');

        return response()->json([
                'status' => 'success',
                'message' => 'OTP sent to your registered mobile number',
                'message_ar' => 'يتم إرسال كلمة المرور لمرة واحدة إلى رقم هاتفك المحمول المسجل'
            ], 200);

        } catch (\Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Failed to send OTP to your registered mobile number ","response_ar"=>"فشل إرسال كلمة المرور لمرة واحدة إلى رقم هاتفك المحمول المسجل", "error"=>$e->getMessage() ], 400);
        }  
    }
    
    /** 
     * Verify OTP to delete account
     * @param $request
     * @return \Illuminate\Http\Response
     */
    function verifyDeleteAccountOTP(Request $request){
        // User OTP Verification
        $validator = Validator::make($request->all(),
            [
                'contact_no' => ['required', 'string'],
                'OTP' => ['required', 'string', 'min:4']
            ]
        );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        $data=Driver::where('contact_no', $request->contact_no)->get();
        if($data)
        {
            // otp is 0000 update
            if($request->OTP == '0000' && env('APP_OTP') != 'production') {
                Reset::where('email' , $request->contact_no)->where('user_type' , 'Driver')->update(array('token' => '0000'));
            }
             
            if(Reset::where([['email', $request->contact_no ],[ 'token' , $request->OTP ],[ 'user_type' , 'Driver' ]] )->count() > 0)
            {
                
                return response()->json([
                    'status'=>'success',
                    'message'=> 'OTP Verified',
                    'message_ar'=> 'التحقق من كلمة المرور لمرة واحدة',
                    'data' => $data
                ], 200);
            }

            return response()->json([
                'status'=>'failed',
                'message'=> 'Invalid OTP',
                'message_ar'=> 'كلمة مرور صالحة لمرة واحدة',
            ], 400);
        }

        return response()->json([
            'status'=>'failed',
            'message'=> 'Invalid User',
            'message_ar'=> 'هوية مستخدم غير صالحه',
        ], 400);
    }

    /**
     * After verified OTP then delete his customer account
     * @param $request
     * @return \Illuminate\Http\Response
     */
    function delete_account(Request $request){
         // User OTP Verification
        $validator = Validator::make($request->all(),
            [
                'contact_no' => ['required', 'string'],
                'OTP' => ['required', 'string', 'min:4']
            ]
        );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $driver_id = Auth::guard('driver')->id();
        $user = Driver::where('contact_no', $request->contact_no )->where('id', $driver_id)->first();
        if(!$user)
            return response()->json([ 'status' => "failed", "response" => "User not found",], 400);
        $count=Reset::where([['email', $request->contact_no ],[ 'token' , $request->OTP ],[ 'user_type' , 'Driver' ]] )->count();
        
        if(!$count)
        {
            return response()->json([
                'status'=>'failed',
                'message'=> 'Invalid OTP',
                'message_ar'=> 'كلمة المرور لمرة واحدة غير صالحة',
                'data' => $user
            ], 400);
        }
        
        try{
            $device_log['user_id'] = $driver_id;
            $device_log['user_type'] = 'driver';
            $this->disable_device_data($device_log, 'delete');

            $token = JWTAuth::fromUser($user);
            JWTAuth::invalidate($token);
            Session::flush();
            Auth::logout();

            Driver::where('id', $driver_id)->delete();
            return response()->json([
                'status' => 'success',
                'message' => 'You have successfully deleted your account',
                'message_ar' => 'لقد نجحت في حذف حسابك',
            ], 200);

        } catch (\Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Failed to delete user account","error"=>$e->getMessage() ], 400);
        }
    }
    
   /**
   * When driver wanted to logged out from app
   *
   * @param $device details
   * @return \Illuminate\Http\Response
   */
    public function logout(Request $request){
        $driver_id = Auth::guard('driver')->id();
        $user = Driver::find($driver_id);
        if(!$user)
            return response()->json([ 'status' => "failed", "response" => "User not found",], 400);

        if(isset(Auth::guard('driver')->user()->device_log_id)){
            $device_log_id = Auth::guard('driver')->user()->device_log_id;
            Device::where('id', $device_log_id)->delete();
        }

        $token = JWTAuth::fromUser($user);
        JWTAuth::invalidate($token);
        Session::flush();
        Auth::guard('driver')->logout();

        return response()->json([
            'status' => 'success',
            'message' => 'You have successfully logout your account',
            'message_ar' => 'لقد نجحت في حذف حسابك',
        ], 200);
    }


   /*
   * When driver wanted to logged out or delete account  from app then disable device details to stop sending push notifications
   * @param $device details
   */
    public function disable_device_data($data, $actionType){

        $where = array(
            "user_id" => $data["user_id"],
            "user_type" => $data["user_type"],
        );

        if(isset($data["device_type"]))
            $where["device_type"] = $data["device_type"];

        if($actionType=='loggedout'){
            $where['device_id']=$data["device_id"];
            $deviceInfo=Device::where($where)->orderBy('id','desc')->first();

            if(!empty($deviceInfo)){
                $id=$deviceInfo->id;
                Device::where('id', $id)->delete();
            }
        } else {
            $input['status']=0;
            $input['updated_at'] = date('Y-m-d H:i:s');
            Device::where($data)->update($input);
            Device::where($data)->delete();
        }
    }


    /* Deactivate seession details
    * @return \Illuminate\Http\Response
    */
    public function deactivate_session($user_id){
        $user = Driver::find($user_id);
        if(!$user)
            return response()->json([ 'status' => "failed", "response" => "User not found",], 400);

        $token = JWTAuth::fromUser($user);
        JWTAuth::invalidate($token);

        return $token;

        return response()->json([
            'status' => 'success',
            'message' => 'You have successfully logout your account',
            'message_ar' => 'لقد نجحت في حذف حسابك',
        ], 200);
    }

    /* Get Payment gateway configaration detaild
    * @return \Illuminate\Http\Response
    */
    function configuration_details(){

        $configArray['pg_userid']=env('TERMINAL_ID','joy');
        $configArray['pg_pwd']=env('URWAY_PASSWORD','joy@123');
        $configArray['pg_merchantid']=env('MERCHANT_KEY','f41697cbcce14b3ae7b0b6ba572df6695dbd9191a3ccc98baca2cc911daf3b11');


        $configArray['pg_url']=env('MERCHANT_KEY','f41697cbcce14b3ae7b0b6ba572df6695dbd9191a3ccc98baca2cc911daf3b11');
         return response()->json([
            'status' => 'success',
            'data' => $configArray,
        ], 200);
    }

    /**
     * get all information related to customer reagard fleet, credits, total deals purchased,
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show_info($id)
    {
        $list = Driver::with('loggedin_devices')->where('id', $id)->withTrashed()->first();
        // Get credit information like available credits, consumed and exipired credits
        $credits_info=(new CreditsController)->getCreditsInfo($id);

        // Get total savings of the particular customer
        $savings=(new TransactionController)->getTotalSavings($id);

        // Total Purchased Orders
        $transacationArray = (new TransactionController)->getCustomerTransactionCounts($id, 'driver');

        //Get Consumer groups list
        $data['groups_list']=(new ConsumerGroupController)->getDriverGroupsList($id,1,10);

        $data['notifications_list']=(new NotificationController)->getUserNotificationsList($id,'C');

        $data['favourites_list']=(new FavouriteController)->get_customer_favourites($id);

        $data['user_info']=$list;
        $data['credits_info']=$credits_info;
        $data['savings']=number_format($savings,2);
        $data['transaction_counts']=$transacationArray;

        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    /*
     * Access: customer, prefix: customer
     */
    public function add_unregistered_devices(Request $request){
        $rules = array(
            'device_id'    => ['required'],
            // 'fcm'    => ['required'],
            'device_type'    => ['required'],
            'version'    => ['required'],
            'app_version'    => ['required'],
        );

        $validator = Validator::make($request->all(),$rules);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $data = $request->all();
        $data['user_id'] = null;
        $data['user_type'] = 'driver';
        try{
            $this->device_data($data);

            return response()->json([
                'status' => 'success',
                'message' => 'Device data registered',
                'message_ar' => 'تم تسجيل بيانات الجهاز',
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'failed',
                'message' => 'Device data not registered',
                'message_ar' => 'بيانات الجهاز غير مسجلة',
                "error" => $e->getMessage()], 400);
        }
    }

    /**
    *  Get fleet driver details based on the customer id and id
    *  @param $id, $customerId
    *  @return \Illuminate\Http\Response
    */

    function getFleetDriverInfo($customerId){
        $list=FleetDriver::select('org.id','org.org_name')
             ->join('organizations as org', 'org.id', 'fleet_drivers.fleet_id')
             ->where('fleet_drivers.driver_id', $customerId)
             ->where('fleet_drivers.status', 1)
             ->where('org.status', 1)
             ->get();

        return response()->json(['status' => "success", "data" => $list ], 200);
    }
}
