<?php

namespace App\Http\Controllers\Users;

use App\Http\Controllers\Controller;
use App\Models\Accounts\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use PHPUnit\Util\Exception;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use App\Models\Accounts\Driver;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $list = User::all();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'first_name'    => ['required', 'string', 'max:30' ],
                'last_name'    => ['max:30' ],
                'email'    => ['required', 'string', 'email', 'max:60', 'unique:users,deleted_at,NULL'],
                'contact_no'    => ['required', 'string', 'max:15' ],
                'role_id' => ['required'],
                'status' => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $inputdata = array(
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'contact_no' => $request->contact_no,
            'role_id' => $request->role_id,
            'status' => $request->status,
            'created_at' => date('Y-m-d H:i:s')
        );

        try {
            User::insert($inputdata);
            return response()->json(['status' => 'success', 'Response' => 'User Created Successfully', 'data' => $inputdata], 200);
        }
        catch (Exception $e){
            return response()->json(['status' => 'failed', 'message' => 'User Creation Failed'], 400);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $list = User::whereId($id)->first();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $id = Auth::id();

        $request['contact_no'] = $request['country_code'].$request['contact_no'];
        $validator = Validator::make($request->all(),
            [
                'first_name'    => ['required', 'string', 'max:30' ],
                'last_name'    => ['max:30' ],
                'email'    => ['required', 'string', 'email', 'max:60', 'unique:users,email,'.$id.',id,deleted_at,NULL'],
                'contact_no' => ['required', 'string', 'max:15', 'unique:users,contact_no,'.$id.',id,deleted_at,NULL'],
                //'role_id' => ['required'],
                'ProfileUrl'=> ['mimes:jpeg,jpg,png', 'max:200' ],
                //'status' => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $upload_path = '';
        if(Auth::user()->login_type_id == 19)
            $upload_path = 'fleet/';
        else
            $upload_path = 'users/';

        if(config('app.env') == 'local'){
            if ($file=$request->file('ProfileUrl')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/'.$upload_path;
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['profile_pic'] = '/uploads/'.$upload_path.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put($upload_path, $request->file('ProfileUrl'));
            $request['profile_pic'] = Storage::disk('s3')->url($file_name);
        }

        try {
            $request['updated_at'] = date('Y-m-d H:i:s');
            User::where('id', $id)->update($request->except('ProfileUrl'));
            return response()->json(['status' => 'success', 'Response' => 'User Updated Successfully'], 200);
        }
        catch (Exception $e){
            return response()->json(['status' => 'failed', 'message' => 'User Updation Failed'], 200);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function getUserInfo()
    {
        $user = User::where('id', Auth::id())
            ->select('id', 'first_name', 'last_name', 'email', 'country_code', 'contact_no', 'profile_pic', 'role_id', 'org_id')
            ->first();

        return response()->json([ 'status' => "success", "user" => $user ], 200);
    }


    public function profile(Request $request)
    {
        $userid = Auth::id();

        if($request->isMethod('post'))
        {
            $rules = [
                'first_name' => ['required', 'string', 'max:20'],
                'contact_no'    => ['required', 'regex:/^([0-9\s\-\+\(\)]*)$/', 'min:8', 'max:15'],
                'ProfileUrl'=> ['mimes:jpeg,jpg,png', 'max:200' ],
                'last_name' => 'max:40'
            ];

            $validator = Validator::make($request->all(),$rules, [
                'ProfileUrl.max' => 'File Size should be exceed 200kb',
                'contact_no.regex' => 'Enter a valid contact No',
            ] );

            if ($validator->fails()) {
                return redirect()->back()
                    ->withErrors($validator)
                    ->withInput();
            }

            if(config('app.env') == 'local'){
                if ($file=$request->file('ProfileUrl')) {
                    $extension = $file->extension()?: 'png';
                    $destinationPath = public_path() . '/uploads/users/';
                    $safeName = Str::random(10) . '.' . $extension;
                    $file->move($destinationPath, $safeName);
                    $request['profile_pic'] = '/uploads/users/'.$safeName;
                }
            }else{
                $file_name = Storage::disk('s3')->put('users/', $request->file('ProfileUrl'));
                $request['profile_pic'] = Storage::disk('s3')->url($file_name);
            }

            try{
                $user= User::where('id', $userid)->update($request->except('_token','_method', 'ProfileUrl'));
                return back()->with('success','Profile Updated Successfully');
            }
            catch(\Exception $e){
                //return $e;
                return redirect()->back()->with('failed','Failed to Update Profile');
            }

        }

        $user = User::find($userid);
        return view('auth.profile', compact('user'));
    }

    public function logout(){
        Auth::logout();
        return redirect('/');
    }

    public function changepswd(Request $request)
    {
        if($request->isMethod('post'))
        {
            $rules = array( 'pass_confirmation' => ['required', 'min:8', 'max:45' ] );

            $validator = Validator::make($request->all(), $rules );

            if ($validator->fails()) {
                return redirect()->back()
                    ->withErrors($validator)
                    ->withInput();
            }

            $userid = Auth::id();
            $usercnt = User::where('id' , $userid )->count();

            if($usercnt > 0) {

                $user = User::where('id', $userid)->first();

                if (isset($request['CurrentPassword'])) {
                    if (Hash::check($request['CurrentPassword'], $user->Password)) {

                        $update['password'] = Hash::make($request['pass_confirmation']);

                        if ($request['CurrentPassword'] != $request['pass_confirmation']) {
                            $res = User::where('id', $userid)->update($update);

                            if ($res) {
                                Log::info("UserController::changePassword " . Auth::user()->first_name . "" . Auth::user()->last_name . " Password Updated");
                                return back()->with('success', 'Password Updated Successfully');
                            } else
                                return back()->with('failed', 'Password Updation Failed');
                        } else {
                            return back()->with('failed', 'Current and New Password Should not be same');
                        }
                    } else {
                        return back()->with('failed', 'Your Current Password is wrong');
                    }

                }
                else
                {
                    $update['password'] = Hash::make($request['pass_confirmation']);
                    try {
                        User::where('id', $userid)->update($update);
                        Log::info("UserController::changePassword " . Auth::user()->first_name . "" . Auth::user()->last_name . " Password Updated");
                        return back()->with('success', 'Password Updated Successfully');
                    }catch (Exception $e){
                        return back()->with('failed', 'Password Updation Failed');
                    }

                }


            }else{
                return back()->with('failed','Invalid User ID');
            }
        }

        return view('auth.changepassword');
    }

    public function register(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'first_name'    => ['required', 'string', 'max:30' ],
                'email'    => ['required', 'string', 'email', 'max:60', 'unique:users,deleted_at,NULL'],
                'contact_no'    => ['required', 'string', 'max:15' ],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $inputdata = array(
            'email' => $request->email,
            'password' => Hash::make('0000'),
            'first_name' => $request->first_name,
            'contact_no' => $request->contact_no,
            'role_id' => 2,
            'status' => 2,
            'created_at' => date('Y-m-d H:i:s')
        );

        try {
            User::insert($inputdata);
            return response()->json([
                'status' => 'success',
                'Response' => 'User Created Successfully',
                'data' => User::where('email', $request->email)->first()
            ], 200);
        }
        catch (Exception $e){
            return response()->json(['status' => 'failed', 'message' => 'User Creation Failed'], 400);
        }
    }

    public function approve($id = null){

        try {
            User::where('id', $id)->update([
                'status' => 1,
                'updated_at' => date('Y-m-d H:i:s')
            ]);

            Log::info('User Id: '. $id. ' was approved');
            return response()->json(['status' => 'success', 'message' => 'User Approved Successfully'], 200);
        }
        catch (Exception $e){
            return response()->json(['status' => 'failed', 'message' => 'User Creation Failed'], 400);
        }
    }

	public function userlist()
    {
		$list = User::with('company', 'rules')->get();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }



     public function getallpartnerandadmin(){

        $fleets = DB::select("select id, org_name from organizations where company_type = 'F' and status = 1");

        $admins = DB::select("select id, org_name from organizations where status = 1 and company_type = 'A'");
        $data = array('fleets' => $fleets, 'admins' => $admins);
        return response()->json(['status'=> 'success', 'data'=> $data ], 200);
    }

    /**
     * Get driver or provider details
     * @access Admin portal
     * 
     * @return \Illuminate\Http\Response
    */
    function getDriverOrProviderInfo($id, $userType){
        if($userType=='driver'){
            $list = Driver::whereId($id)->first();
            return response()->json(['status'=> 'success', 'data'=> $list ], 200);
        } else {
            $list = User::whereId($id)->with('company')->first();
            return response()->json(['status'=> 'success', 'data'=> $list ], 200);
        }
    }

}
