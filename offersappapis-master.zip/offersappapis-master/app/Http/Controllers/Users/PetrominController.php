<?php

namespace App\Http\Controllers\Users;

use App\Http\Controllers\Controller;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\TabbyTransactionController;
use App\Http\Controllers\TransactionController;
use App\Models\Accounts\Driver;
use App\Models\Accounts\Payment;
use App\Models\Accounts\Transaction;
use App\Models\Accounts\Vehicle;
use App\Models\Generals\RedeemLog;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use Carbon\Carbon;
use Illuminate\Http\Request;
use GuzzleHttp;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class PetrominController extends Controller
{
    public $base_url = 'https://t23.ntsc.app/api/';

    public function __construct()
    {
        $this->base_url = env('PETROMIN_URL');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $url = 'services/due';
        $data = $this->get($url);

        return response()->json($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /*
     * Book petromin service after successful transaction
     */
    public function add_service($transaction_no)
    {
        $body = $this->petrominBookingRequest($transaction_no);

        try{
            $data = $this->post('services', $body);
        }catch (\Exception $e){
            Log::error("Petromin service booking failed: Transaction No.:". $transaction_no);
            $data = array('status' => 'failed', 'data' => []);
        }

        return response()->json($data);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $url = 'services/'.$id;
        $data = $this->get($url);

        return response()->json($data);
    }

    public function redeem_check($id)
    {
        $url = 'services/'.$id;
        $data = $this->get($url);

        $booking_status = $data['data']->bookingStatus;
        if($booking_status == 1)
        {
            // we can redeem transaction in joy
            // $this->redeem_joy_transaction($id);
        }

        return response()->json($data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $url = 'services/'.$id;
        try{
            $data = $this->delete($url);
        }catch (\Exception $e){
            Log::error("Petromin cancel service booking failed: Transaction No.:". $id);
            $data = array('status' => 'failed', 'data' => []);
        }

        return response()->json($data);
    }

    public function drivers_list(){
        $url = 'drivers';
        $data = $this->get($url);

        return response()->json($data);
    }

    public function add_driver(){
        $url = 'drivers';
        $input = array(
            "id" => 0,
            "name" => "Joy-Primary",
            "uniqueId" => "joy_driver",
            "attributes" => (object)array()
        );
        $data = $this->post($url, $input);

        return response()->json($data);
    }

    public function vehicles_list(){
        $url = 'vehicles';
        $data = $this->get($url);

        return response()->json($data);
    }

    public function add_vehicle($vehicle_id = null){
        $url = 'vehicles';

        if(!$vehicle_id) {
            // Set default input
            $input = array(
                "id" => 0,
                "label" => "Seedan",
                "garage" => "1039",
                "model" => "cadilac",
                "vehicleType" => "car",
                "deviceId" => 0,
                "attributes" => (object)array()
            );
        }else {
            $vehicle = Vehicle::join('vehicle_models', 'vehicle_models.id', 'vehicles.model')
                ->join('vehicle_groups', 'vehicle_groups.id', 'vehicles.group_id' )
                ->join('manufacturers', 'manufacturers.id', 'vehicles.company')
                ->select( 'vehicles.id', 'vehicle_models.model', "vehicles.plate_no")
                ->selectRaw('manufacturers.title as vehicle_type')
                ->selectRaw('vehicle_groups.title as vehicle_group')
                ->where('vehicles.id', $vehicle_id)->first();

            $input = array(
                "id" => 0,
                "label" => $vehicle['model'].' '.$vehicle['vehicle_group'],
                "category" => $vehicle['vehicle_type'],
                "deviceId" => 0,
                "vehicleLicensePlate" => $vehicle['plate_no'],
                "attributes" => (object)array()
            );
        }
        try{
            $data = $this->post($url, $input);
        }catch (\Exception $e){
            Log::error("Vehicle creation failed for petromin. Vehicle Id.:". $vehicle_id);
            $data = array('status' => 'failed', 'data' => []);
        }

        return response()->json($data);
    }

    private function petrominBookingRequest($transaction_no){

        $customer_unique_id = $this->get_customer_id();
        $customer_vehicle_id = $this->get_customer_vehicle_id($transaction_no);

        $trans = Transaction::where('transaction_no', $transaction_no)->first();
        $payment = Payment::where('transaction_no', $transaction_no)->first();
        $item = ItemMaster::where('id', $trans['item_id'])->first();
        $offer = ItemOffer::where('id', $trans['offer_id'])->first();

         $request = array(
             "service" => [
                 "id" => 0,
                 "updatedBy" => "",
                 "status" => "required",
                 "name" => $item['title'],
                 "description" => $item['description'],
                 "contactNumber" => 0,
                 "odometer" => 34534000,
                 "quantity" => $trans['quantity'],
                 "cost" => $payment['amount_by_banking'] + $payment['amount_by_credits'],
                 "address" => null,
                 "coordinate" => "30.00,50.00",
                 "vehicleId" => $customer_vehicle_id, // 140330
                 "deviceId" => "",
                 "driverUniqueId" => $customer_unique_id, // "innvohub_uday"
                 "garageId" => "",
                 "maintenanceId" => "",
                 "files" => "",
                 "createdTime" => "",
                 "serviceTime" => Carbon::now(),
                 "expireTime" => Carbon::now()->addDays(7),
                 "userId" => 0,
                 "engineHours" => 0,
                 "tag1" => "",
                 "tag2" => "",
                 "tag3" => "",
                 "refNum" => $transaction_no, // "5458723",
                 "refdate" => Carbon::now(),
                 "areaId" => "",
                 "attributes" => [
                     "updateMaintenance" => false,
                     "mileage" => 0,
                     "hours" => 0,
                     "date" => 0,
                     "status" => true,
                     "mailTo" => "",
                     "email" => [
                     ]
                 ],
                 "invoiceType" => 1
             ],
             "serviceExpenseCollection" => array(
                 [
                     "quantity" => $trans['quantity'],
                     "cost" => $payment['amount_by_banking'] + $payment['amount_by_credits'],
                     "expenseSubTypeId" => $offer['provider_reference_subid'], // 912160
                     "expenseTypeId" => $offer['provider_reference_id'], // 684
                     "serviceId" => 0
                 ]
            )
         );

         return $request;
    }

    private function get_customer_id(){
        $customer = Auth::guard('driver')->user();

        // convert unique id to hex code
        $str = explode( ' ', trim($customer['first_name']))[0].'__'.$customer['id'];
        $unique_id = bin2hex($str);
        $original_id = pack("H*",$unique_id); // encrypt hex code to original string

        return $unique_id;
    }

    private function get_customer_vehicle_id($transaction_no){
        $vehicle_id = Transaction::where('transaction_no', $transaction_no)->pluck('vehicle_id')->first();

        $vehicle = Vehicle::where('id', $vehicle_id)->first();
        if(!$vehicle)
            return "140330"; // if vehicle was deleted, send dummy id

        if(!$vehicle['reference_id']) {
            $res = $this->add_vehicle($vehicle['id']);
            $res = (array)$res->getData();
            if($res['status'] == 'success'){
                // update new reference id to the respective vehicle
                $reference_id = $res['data']->id;
                Vehicle::where('id', $vehicle_id)->update(['reference_id' => $reference_id]);
                return $reference_id;
            } else{
                // send some dummy value
                return "140330";
            }
        }
        else{
            return $vehicle['reference_id'];
        }
    }

    private function get($url){
        $client = new \GuzzleHttp\Client();
        try {
            $response = $client->get($this->base_url . $url,
                ['headers' => $this->headers()]
            );
            return json_decode($response->getBody(), true);
        }catch (\Exception $e){
            return array( "status" => "failed", "statusCode" => "400", "error" => $e);
        }
    }

    private function post($url, $body){
        $client = new \GuzzleHttp\Client([
            // Base URI is used with relative requests
            'base_uri' => $this->base_url,
            // You can set any number of default request options.
            'timeout'  => 3.0,
            'headers' => $this->headers(),
        ]);

        $url = $this->base_url.$url;
        // $data string variable is defined same as above.

        try {
            // Provide the body as a string.
            $response = $client->request('POST', $url, ['json' => $body]);
            $status = $response->getStatusCode();

            return json_decode($response->getBody(), true);
        }catch (\Exception $e) {
            // Log::critical($e);
            return array( "status" => "failed", "statusCode" => "400", "error" => $e);
        }
    }

    private function delete($url){
        $client = new \GuzzleHttp\Client();
        try {
            $response = $client->delete($this->base_url . $url,
                ['headers' => $this->headers()]
            );

            return json_decode($response->getBody(), true);
        }catch (\Exception $e){
            return array( "status" => "failed", "statusCode" => "400", "error" => $e);
        }
    }

    private function headers(){
        $cred = array(
            'user' => env('PETROMIN_URL', 'joy@ntsc.sa'),
            'pass' => env('PETROMIN_PSWD', 'JOY123')
        );

        $base64 = base64_encode($cred['user'].":".$cred['pass']);
        $header = [
            'Content-Type' => 'application/json',
            "Accept" => "application/json",
            'Authorization' => "Basic " . $base64
        ];

        return $header;
    }

    // Cron Job
    public function check_service_exipry(){

        $list = Transaction::whereNotNull('service_id')->where('payment_status', 'Successful')
            ->whereRaw('created_at > NOW() - INTERVAL 48 HOUR')->get();

        foreach($list as $row){

            $offer = ItemOffer::where('id', $row['offer_id'])->first();

            if($offer['vn_access'] || $offer['pn_access']){
                // vin no or plate no was required for this transaction
                if ($offer['vn_access'] && Vehicle::where('id', $list['vehicle_id'])->whereNull('serial_no')->count() > 0) {
                    // Reject Joy Transaction and delete petromin service
                    $this->reject_transaction($row['transaction_no'], $row['service_id']);
                }

                if ($offer['pn_access'] && Vehicle::where('id', $list['vehicle_id'])->whereNull('plate_no')->count() > 0) {
                    // Reject Joy Transaction and delete petromin service
                    $this->reject_transaction($row['transaction_no'], $row['service_id']);
                }
            }
        }

        return count($list);
    }

    /*
     * This function uses from cron job
     * & Call from cancel service by deal provider
     */
    private function reject_transaction($transaction_no, $service_id){

        $msg = "Server rejected offer due to not adding of vin no., plate no. to their transaction vehicle";

        Transaction::where('transaction_no', $transaction_no)
            ->update(['payment_status' => 'Cancelled', 'remarks' => $msg]);

        // delete petromin service
        try{
            $res = $this->destroy($service_id);
            $res = (array)$res->getData();

            if($res['status'] == 'success'){

                // Void Authorize payments
                $payment = Payment::where('transaction_no', $transaction_no)->first();
                $action_code = 9; // Void Authorization
                if($payment['payment_on'] == 50){
                    // Tabby
                    (new TabbyTransactionController())->captureTabbypayment($payment['payid'], $payment['amount_by_banking'], $action_code);
                } else if($payment['payment_on'] == 33 || $payment['payment_on'] == 35){
                    $result = (new PaymentController())->unlock_payments($payment['payid'], $payment['amount_by_banking'], $_SERVER['SERVER_ADDR'], $action_code);
                    $resultData = $result['data'];

                    $paymentArray['payment_status'] = $result['payment_status'];
                    $paymentArray['response_result'] = $result['Response'];

                    if (!empty($resultData)) {
                        $paymentArray['response_code'] = $resultData->responseCode;
                        $paymentArray['response_amount'] = $resultData->amount;
                    }
                }

                $paymentArray['action_code'] = $action_code;
                $paymentArray['updated_at'] = date('Y-m-d H:i:s');


                Payment::where('transaction_no', $transaction_no)->update($paymentArray);

                return true;
            }
            else
                return false;

        }catch (\Exception $e){
            Log::error("Petromin cancel service booking failed: Transaction No.:". $service_id);
            return false;
        }
    }

    /*
     * Access: deal provider, prefix: dealeraccess
     */
    public function redeem_service($service_id){

        $trans = Transaction::where('service_id', $service_id)->first();
        if(!$trans)
            return response()->json(['status' => 'failed', 'message' => 'Invalid Transaction'], 400);

        $offer = ItemOffer::where('id', $trans['offer_id'])->where('item_id', $trans['item_id'])->first();

        if ($offer['end_date'] < date("Y-m-d"))
            return response()->json([
                'status' => "failed",
                "message" => "This Offer was expired",
                "message_ar" => "انتهت صلاحية هذا العرض"], 400);

        $res = (new TransactionController())->redeem_offer_quantity($trans['transaction_no'], 1);

        if($res)
            return response()->json(['status' => 'success', 'message' => 'Transaction redeemed succcessfully']);
        else
            return response()->json(['status' => 'failed', 'message' => 'Redeem Transaction was failed'], 400);
    }

    /*
     * Access: deal provider, prefix: dealeraccess
     */
    public function cancel_service($service_id){

        $trans = Transaction::where('service_id', $service_id)->first();
        if(!$trans)
            return response()->json(['status' => 'failed', 'message' => 'Invalid Transaction'], 400);

        $res = $this->reject_transaction($trans['transaction_no'], $service_id);

        if($res)
            return response()->json(['status' => 'success', 'message' => 'Transaction redeemed succcessfully']);
        else
            return response()->json(['status' => 'failed', 'message' => 'Cancel Transaction was failed'], 400);

    }

    /*
     * Access: deal provider, prefix: dealeraccess
     */
    public function change_status(Request $request){

        $validator = Validator::make($request->all(),
            [
                'status' => ['required' ],
                'service_ids' => 'required|array',
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $service_ids = $request->service_ids;
        $status = $request->status;
        $data = array();

        $i = 0;
        foreach($service_ids as $service_id){

            $data[$i]['service_id'] = $service_id;
            $data[$i]['request'] = $status;

            if(Transaction::where('service_id', $service_id)->count() > 0) {

                if ($status == 'redeem')
                    $this->redeem_service($service_id);
                else if ($status == 'cancel')
                    $this->cancel_service($service_id);

                $data[$i]['status'] = 'Successful';
            }
            else
                $data[$i]['status'] = 'Invalid Service Id';

            $i++;
        }

        return response()->json(['status' => 'success', 'message' => 'Transaction '.$status.' succcessfully', 'data' => $data]);
    }

}
