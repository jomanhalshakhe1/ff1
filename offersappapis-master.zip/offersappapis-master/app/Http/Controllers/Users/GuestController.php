<?php

namespace App\Http\Controllers\Users;

use App\Http\Controllers\Controller;
use App\Models\Accounts\Guest;
use App\Models\Generals\Device;
use App\Models\Generals\Role;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Http\Request;
use App\Http\Requests;

class GuestController extends Controller
{
    public $guest;
    

    public function __construct()
    {
        $this->guest = Role::where('login_type_id', 49)->pluck('id')->first(); // 49 - Guest
    }

    public function index(Request $request)
    {
        $pageno = 1; $pagelength = 10;
        $list = Device::where('user_type', 'guest');

        if(isset($request->searchby_keyword) && $request->searchby_keyword!=''){
            $searchKey=$request->searchby_keyword;
            $dt=date("Y-m-d", strtotime($searchKey));
           
            if(is_numeric(strtotime($searchKey)) ){
                $dt=date("Y-m-d", strtotime($searchKey));
        
                $list = $list->where('last_access_at','>=',$dt." 00:00:00");
                $list = $list->where('last_access_at','<=',$dt." 23:59:59");

            } else {
                $list =$list->where('device_type','LIKE',"%{$searchKey}%");
                $list =$list->orWhere('device_model','LIKE',"%{$searchKey}%");
                $list =$list->orWhere('version','LIKE',"%{$searchKey}%"); 
                $list =$list->orWhere('app_version','LIKE',"%{$searchKey}%");
     
            }
        }

       // If deleted users from all guest users list
        if(isset($request->deleted_users) && $request->deleted_users!=''){
            $arr=explode(',',$request->deleted_users);
            $list=$list->whereNotIn('id',$arr);
        }

        $totalrecords = $list->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = $list->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();
        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    public function signin(Request $request)
    {
        $data = [];
        $request['contact_no'] = '+966580000004';
        $request['password'] = '0000';
        $request['status'] = 1;
        $credentials = $request->only('contact_no', 'password', 'status');

        try {
            if (! $token = Auth::guard('guest')->attempt($credentials)) {
                return response()->json([
                    'status' => 'failed',
                    'response' => "Invalid Credentials",
                    'response_ar' => "بيانات الاعتماد غير صالحة",
                    'data' => $data], 400);
            }
        } catch (JWTException $e) {
            return response()->json(['status' => 'failed','response' => 'could_not_create_token', 'data' => $data], 500);
        }

        Auth::guard('guest')->user()->device_type = 'android';
       

        $device_log = $request->device_info;
        $device_log['user_id'] = Auth::guard('guest')->id();
        $device_log['user_type'] = 'guest';

        $this->device_data($device_log);

        $data["guest"]= Auth::guard('guest')->user();
        $token = JWTAuth::fromUser($data["guest"]);
        $data["Token"]= $token;

        return response()->json(['status'=>'success','response' => "Success",'data' => $data], 200);
    }

    public function device_data($data){
        $input['user_id'] = $data['user_id'];
        $input['device_id'] = $data['device_id'];
        $input['device_type'] = $data['device_type'];
        $input['device_model'] = isset($data['device_model']) ? $data['device_model'] : $data['device_type'];
        $input['version'] = $data['version'];
        $input['fcm'] = $data['fcm'];
        $input['app_version'] = $data['app_version'];
        $input['ip'] = $_SERVER['REMOTE_ADDR'];
        $input['user_type'] = $data['user_type'];
        $input['status'] = 1;

        $where = array(
            "device_type" => $data["device_type"],
            "device_id" => $data["device_id"],
        );

        $newLog = true;
        // Already has any login on the same device
        if(Device::where($where)->whereIn('user_type', ['driver', 'guest'])->count() > 0) {
            // yes
            if(Device::where($where)->where('user_type', 'driver')->whereNull('user_id')->count() > 0) {
                // Unregistered device - convert to guest and delete log
                Device::where($where)->where('user_type', 'driver')->whereNull('user_id')
                    ->update([
                        'converted_as' => $data['user_id'],
                        'updated_at' => date('Y-m-d H:i:s')
                    ]);

                Device::where($where)->where('user_type', 'driver')->whereNull('user_id')->delete();
            }

            if(Device::where($where)->where('user_type', 'driver')->whereNotNull('user_id')->count() > 0){
                // Driver log - delete log
                Device::where($where)->where('user_type', 'driver')->whereNotNull('user_id')->delete();
            }

            if(Device::where($where)->where('user_type', 'guest')->count() > 0){
                // Has Guest log - Update log
                $input['updated_at'] = date('Y-m-d H:i:s');
                Device::where($where)->where('user_type', 'guest')->update($input);

                $newLog = false;
            }
        }

        if($newLog) {
            // create guest user log
            $input['created_at'] = date('Y-m-d H:i:s');
            Device::insertGetId($input);
        }
    }


    public function unregistered_devices(Request $request)
    {
        $pageno = 1; $pagelength = 10;
        $list = Device::whereNull('user_id');

        if(isset($request->unregistered_type) && $request->unregistered_type!=''){
            if($request->unregistered_type=='customer'){
                $request->unregistered_type='driver';
            } else {
                $request->unregistered_type='user';
            }
            $list = $list->where('user_type', $request->unregistered_type);
        } else {
            $list = $list->whereIn('user_type', ['driver', 'user']);
        }

         // If deleted users from all guest users list
        if(isset($request->deleted_users) && $request->deleted_users!=''){
            $arr=explode(',',$request->deleted_users);
            $list=$list->whereNotIn('id',$arr);
        }
        
        if(isset($request->searchby_keyword) && $request->searchby_keyword!=''){
            $searchKey=$request->searchby_keyword;
            $dt=date("Y-m-d", strtotime($searchKey));
           
            if(is_numeric(strtotime($searchKey)) ){
                $dt=date("Y-m-d", strtotime($searchKey));
        
                $list = $list->where('last_access_at','>=',$dt." 00:00:00");
                $list = $list->where('last_access_at','<=',$dt." 23:59:59");

            } else {
                $list =$list->where('device_type','LIKE',"%{$searchKey}%");
                $list =$list->orWhere('device_model','LIKE',"%{$searchKey}%");
                $list =$list->orWhere('version','LIKE',"%{$searchKey}%"); 
                $list =$list->orWhere('app_version','LIKE',"%{$searchKey}%");
     
            }
        }


        $totalrecords = $list->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = $list->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();
        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    public function getUserInfo(Request $request)
    {
        $user = Guest::whereId(Auth::guard('guest')->id())->with(['vehicle', 'fleets' ])->first();

        return response()->json([ 'status' => "success", "user" => $user ], 200);
    }
}
