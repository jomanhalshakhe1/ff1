<?php

namespace App\Http\Controllers\Users;

use App\Http\Controllers\Controller;
use App\Models\Generals\Role;
use App\Models\Accounts\User;
use App\Models\Regulatory\TechnicianLocation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Http\Controllers\Generals\NotificationController;
use App\Models\Generals\RedeemLog;
use App\Models\Accounts\Transaction;

class DelarTechnicianController extends Controller
{
    public $delarTechnician;
    public function __construct()
    {
        $this->delarTechnician = 8;
    }

    public function index(Request $request)
    {
        $pageno = 1; $pagelength = 10;
        $list = User::where('role_id', $this->delarTechnician)->with('company');
        
        $totalrecords = $list->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        if(isset($request->org_id) && $request->org_id>0){
           $list =$list->where('org_id', $request->org_id);
        } else if(Auth::user()->login_type_id != 17){
            $list = $list->where('org_id', Auth::user()->org_id );
        }

        $list = $list->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\response
     */
    public function create(Request $request)
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\response
     */
    public function store(Request $request)
    {
        $request['contact_no'] = $request['country_code'].$request['contact_no'];
        $validator = Validator::make($request->all(),[
            'first_name' => 'required|max:100',
            'last_name' => 'max:100',
            //'email' => 'required|max:100|unique:users,email,NULL,id,deleted_at,NULL',
            'email' => ['required', 'email', 'max:100', 'unique:users,email,NULL,id,deleted_at,NULL'],
            'country_code' => 'required|max:5',
            'contact_no' => 'required|max:15|unique:users,contact_no,NULL,id,deleted_at,NULL',
            'org_id' => 'required',
            'status' => 'required',
            'thumbnail' => 'nullable|mimes:jpeg,jpg,png|max:500',
            'locations.*' => 'required',
        ]);


        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/delar_technician/profiles/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['profile_pic'] = '/uploads/delar_technician/profiles/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('delar_technician/profiles/', $request->file('thumbnail'));
            $request['profile_pic'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $request['is_verified'] = 1;
            $request['password'] = Hash::make('0000');
            $request['role_id'] = $this->delarTechnician; //technician delar
            $request['created_at'] = date('Y-m-d H:i:s');

            $user = User::create($request->except('locations', 'thumbnail'));
            $userId = $user->id;

            $request['locations'] = json_decode($request['locations'], true);
            $technician_location = [];
            foreach($request['locations'] as $tech_location) {
                $technician_location[] = [
                    'technician_id' => $userId,
                    'location_id' => $tech_location['location_id'],
                    'created_at' => date('Y-m-d H:i:s')
                ];
            }
            if(count($technician_location)> 0){
                TechnicianLocation::insert($technician_location);
            }

            return response()->json(['status' => 'success', 'response' => 'Successfully added a Delar Technician'], 200);
        }
        catch(\Exception $e){
            return response()->json(['status' => 'failed', 'response' => 'Failed to add Delar Technician', "error" => $e ], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\response
     */
    public function show($id)
    {
        $list = User::with('tech_locations')->where('id', $id)->first();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\response
     */
    public function update(Request $request, $id)
    {
        $request['contact_no'] = $request['country_code'].$request['contact_no'];
        $validator = Validator::make($request->all(),[
            'first_name' => 'required|max:100',
            'last_name' => 'max:100',
            //'email' => 'nullable|max:100|unique:users,email,'.$id.',id,deleted_at,NULL',
            'email' => ['required', 'email', 'max:100', 'unique:users,email,'.$id.',id,deleted_at,NULL' ],
            'country_code' => 'required|max:5',
            'contact_no' => 'required|max:15|unique:users,contact_no,'.$id.',id,deleted_at,NULL',
            'org_id' => 'required',
            //'status' => 'required',
            'thumbnail' => 'nullable|mimes:jpeg,jpg,png|max:500',
            'locations.*' => 'required',
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/delar_technician/profiles/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['profile_pic'] = '/uploads/delar_technician/profiles/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('delar_technician/profiles/', $request->file('thumbnail'));
            $request['profile_pic'] = Storage::disk('s3')->url($file_name);
        }

        //Check organization id changed or not
        $techData = User::where('id', $id)->first();
        if(empty($techData)){
             return response()->json(['status' => 'failed', 'response' => 'Technician details not found'], 400);
        }

        if($techData->org_id!=$request->org_id){
             return response()->json(['status' => 'failed', 'response' => "Technician's organization details not allowed to modify"], 400);
        }

         //Not allowed to modify other company's technicians
        if(Auth::user()->login_type_id!=17 && $techData->org_id!=Auth::user()->org_id){ 
            return response()->json(['status' => 'failed', 'response' => "You can't modify other company technician information"], 400);   
        }


        try{

            $request['updated_at'] = date('Y-m-d H:i:s');
            User::where('id', $id)->update($request->except('locations', 'thumbnail'));

            $request['locations'] = json_decode($request['locations'], true);
            $technician_location = [];
            TechnicianLocation::where('technician_id', $id)->delete();
            foreach($request['locations'] as $tech_location) {
                $technician_location[] = [
                    'technician_id' => $id,
                    'location_id' => $tech_location['location_id'],
                    'created_at' => date('Y-m-d H:i:s')
                ];
            }
            if(count($technician_location)> 0){
                TechnicianLocation::insert($technician_location);
            }

            return response()->json(['status' => 'success', 'response' => 'User Updated Successfully'], 200);
        }
        catch(\Exception $e){
            return response()->json(['status' => 'failed', 'response' => 'Failed to update User', "error" => $e ], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\response
     */
    public function destroy($id)
    {
        try{
            User::where('id', $id)->delete();
            //return back()->with('success','User Successfully Deleted');
            return response()->json(['status' => 'success', 'response' => 'User Deleted Successfully'], 200);
        }
        catch(\Exception $e){
            Log::info("UserController::destroy ".Auth::user()->first_name."".Auth::user()->last_name." Failed to delete User".$e);
            return redirect()->back()->with('failed','Failed to delete User');
        }
    }

    /**
     * Get all the information about technicians including counts
     *
     * @param  int  $id
     * @return \Illuminate\Http\response
     */
    public function show_info($id)
    {
        $list = User::with('tech_locations','loggedin_devices')->where('id', $id)->first();
         
        $data['user_info']=$list;

        //$scannedTotal=RedeemLog::where('redeem_by', $id)->count();

        $scannedTotal = Transaction::where('approved_by', $id)
                                    ->where('redeem_quantity', '>', 0)
                                    ->count();

        $countersArray['scanned_total']=$scannedTotal;

        $rejectedTotal=Transaction::where('approved_by', $id)->where('payment_status', 'Rejected')->count();
        $countersArray['rejected_total']=$rejectedTotal;
              
        $acceptedTotal=Transaction::where('approved_by', $id)->where('payment_status', 'Successful')->count();

        $countersArray['accepted_total']=$acceptedTotal;

        $countersArray['total_amount']=0;

        $data['counters']=$countersArray;

        $data['notifications_list']=(new NotificationController)->getUserNotificationsList($id,'N');
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

}
