<?php

namespace App\Http\Controllers\Users;

use App\Http\Controllers\Controller;
use App\Models\Regulatory\Location;
use App\Models\Regulatory\Maker;
use App\Models\Accounts\User;
use App\Models\Inventory\Maintenance;
use App\Models\Inventory\MaintenanceLog;
use App\Models\Regulatory\OrgDeal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use App\Http\Controllers\Generals\NotificationController;
use App\Models\Generals\RedeemLog;
use App\Models\Accounts\Transaction;
use App\Models\Generals\Role;

class MakerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(Request $request)
    {
        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $pageno = 1; $pagelength = 10; 
            $totalrecords = Maker::where('company_type', 'M')->count();
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
            }
            $login_type_id = Role::where('id',Auth::user()->role_id)->pluck('login_type_id')->first();
            $list = Maker::where('company_type', 'M')->with('locations', 'user');

            if($login_type_id=='20'){
                $list=$list->where('id', Auth::user()->org_id);
            }

            $list=$list->orderBy('id', 'desc')
                ->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;

            return response()->json(['status' => 'success', 'data' => $data], 200);
        }else{
            $list = Maker::where('company_type', 'M')->where('status', 1)
                ->with('locations', 'user')
                ->orderBy('id', 'desc')
                ->get();
        }
        return response()->json(['status' => 'success', 'data' => $list ], 200);
    }

    public function active_makers(Request $request)
    {
        $list = Maker::with('locations', 'user')
            ->where('company_type', 'M')
            ->where('status', 1)->get();

        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    public function address($id)
    {
        $list = Maker::where('id', $id)->with(['location' => function ($query) use($id) {
            $query->where('org_id', $id);
        }])->first();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request['location'] = json_decode($request['location'], true);
        $request['phone'] = $request['country_code'].$request['phone']; 
        $request['admin_contact_no'] =$request['admin_country_code'].$request['admin_contact_no'];

        $validator = Validator::make($request->all(),
            [
                'org_name' => ['required', 'string', 'max:100' ],
                'org_name_ar' => ['required', 'string', 'max:100' ],
                'vat_no'=>['required', 'max:20'],
                'country_code' => ['required', 'max:5'],
                'phone' => ['required', 'max:15', 'unique:organizations,phone,NULL,id'],
                'email' => ['required', 'email', 'max:60', 'unique:organizations,email,NULL,id'],
                'admin_contact_no' => ['required', 'max:15', 'unique:users,contact_no,NULL,id,deleted_at,NULL'],
                'admin_email_id' => ['required', 'max:60', 'email', 'unique:users,email,NULL,id,deleted_at,NULL'],  
                'location.street' => ['string', 'max:60' ],
                'location.city' => ['required', 'max:60' ],
                'location.district' => ['string', 'max:60' ],
                'location.address' => ['string', 'max:255' ],
                'location.zipcode' => ['string', 'max:20' ],
                'location.latitude' => ['required', 'numeric', 'between:0,180'],
                'location.longitude' => ['required', 'numeric', 'between:0,180'],
                'thumbnail' => ['required', 'mimes:jpeg,jpg,png', 'max:500' ],
                // 'is_email_verified'=>['required'],
                'is_trusted'=>['required']
            ],

            [
                'admin_contact_no.required'=>'Contact number is required for  dealer admin',
                'admin_contact_no.max'=>'Contact number must not exceed 15 characters for  dealer  admin',
                'admin_contact_no.unique'=>'Contact number is already exited with us for  dealer  admin',
                'admin_email_id.required'=>'Email id is required for dealer admin',
                'admin_email_id.max'=>'Email id must not exceed 60 characters for  dealer admin',
                'admin_email_id.min'=>'Email id must be 3 characters for  dealer admin',
                'admin_email_id.unique'=>'Email id is already exited with us for  dealer  admin',
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/maker/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/maker/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('maker/', $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        try{
           //$request['category'] = 9; // Maintenance & services module
            $request['company_type'] = 'M'; // Maker
            $request['created_by'] = Auth::id();
            $request['created_at'] = date('Y-m-d H:i:s');
            $org = Maker::create($request->except('thumbnail', 'location'));

            $insert = array(
                'org_id' => $org['id'],
                'deal_id' => 9,
                'status' => 1,
                'created_at' => date('Y-m-d H:i:s')
            );
            OrgDeal::insertGetId($insert);

            $location = $request['location'];
            $location['org_id'] = $org['id'];
            $location['primary'] = 1;
            $location['created_at'] = date('Y-m-d H:i:s');
            Location::insert($location);

            $insert = array(
                "first_name" => $request['org_name'],
                "email" => $request['admin_email_id'],
                "password" => Hash::make('maker@123'),
                "role_id" => 2, // Maker
                "org_id" => $org['id'], // Maker Organization
                "profile_pic" => $request['thumbnail_url'],
                'created_at' => date('Y-m-d H:i:s'),
                'country_code' => $request['admin_country_code'],
                'contact_no' => $request['admin_contact_no'],
                'is_verified' => 1,
                // 'is_email_verified'=>$request['is_email_verified']
            );
            User::insert($insert); // Maker account for web

            return response()->json(['status'=>'success', 'message'=> 'Maker created successfully'], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Maker creation failed', "error" => $e ], 400);
        }
    }

    public function add_address(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'org_id' => ['required'],
                'street' => ['required', 'string', 'max:60' ],
                //'city' => ['required', 'string', 'max:60' ],
                'city' => ['required', 'max:60' ],
                'district' => ['required','string', 'max:60' ],
                'zipcode' => ['required', 'string', 'max:20' ],
                'latitude' => ['required', 'numeric', 'between:0,180'],
                'longitude' => ['required', 'numeric', 'between:0,180'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $request['created_at'] = date('Y-m-d H:i:s');
        try{
            Location::insert($request->all());
            return response()->json(['status' => 'success', 'message'=> 'Location created successfully', ], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Location creation failed', "error" => $e ], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $list = Maker::where('id', $id)->with(['location' => function ($query) use($id) {
            $query->where('org_id', $id);
            $query->where('primary', 1);
        }])->first();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }


       /**
     * get all information related to dealer reagard total earnings, categories,
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show_info($id)
    {

        $list = Maker::where('id', $id)->with(['location' => function ($query) use($id) {
            $query->where('org_id', $id);
            $query->where('primary', 1);
        }])->first();

        $adminInfo = User::with('loggedin_devices')->where('org_id', $id)->where('role_id',2)->orderBy('id','ASC')->first();

        $techniciansList = User::where('org_id', $id)->where('role_id',7)->get();

        $addressList = Location::with('city')->where('org_id', $id)->get();
        
        $data['notifications_list']=(new NotificationController)->getUserNotificationsList($adminInfo->id,'N');

       // $scannedTotal=MaintenanceLog::where('created_by', $id)->count();

       $scannedTotal=Maintenance::join('maintenance_logs as ml','ml.item_id', 'maintenances.id')
            ->where('maintenances.delar_id',$id)->count();


        $totalOffers=Maintenance::where('delar_id', $id)->count();

        $countersArray['total_offers']=$totalOffers;
        $countersArray['scanned_total']=$scannedTotal;
        $countersArray['total_amount']=0;
        $data['counters']=$countersArray;
        
        $data['org_info']=$list;
        $data['technicians_list']=$techniciansList;
        $data['user_info']=$adminInfo;
        $data['address_list']=$addressList;
        
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }



    public function address_info($maker_id, $address_id = null)
    {
        $locations = Location::select('locations.*', 'cities.city as city', 'locations.city as cityid')
            ->where('locations.id', $address_id)
            ->leftjoin('cities', 'locations.city', '=', 'cities.id')->first();
        $maker = Maker::where('id', $maker_id)->first();
        $maker['location'] = $locations;

        return response()->json(['status' => 'success', 'data' => $maker], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request['location'] = json_decode($request['location'], true);
        $request['phone'] = $request['country_code'].$request['phone'];
        $validator = Validator::make($request->all(),
            [
                'org_name' => ['required', 'string', 'max:100' ],
                'org_name_ar' => ['required', 'string', 'max:100' ],
                //'code' => ['required', 'string', 'max:20', 'unique:organizations,code,'.$id.',id'],
                 'vat_no'=>['required', 'max:20'],
                'country_code' => ['required', 'max:5'],
                'phone' => ['required', 'string', 'max:15', 'unique:organizations,phone,'.$id.',id' ],
                'email' => ['required', 'email', 'max:60', 'unique:organizations,email,'.$id.',id' ],
                'location.street' => ['string', 'max:60' ],
                'location.city' => ['required', 'max:60' ],
                'location.district' => ['string', 'max:60' ],
                'location.address' => ['string', 'max:255' ],
                'location.zipcode' => ['string', 'max:20' ],
                'location.latitude' => ['required', 'numeric', 'between:0,180'],
                'location.longitude' => ['required', 'numeric', 'between:0,180'],
                'is_trusted'=>['required']
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/maker/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/maker/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('maker/', $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $request['updated_by'] = Auth::id();
            $request['updated_at'] = date('Y-m-d H:i:s');
            Maker::where('id', $id)->update($request->except('thumbnail', 'location'));

            $location = $request['location'];
            $location['updated_at'] = date('Y-m-d H:i:s');
            Location::where('primary', 1)->where('org_id', $id)->update($location);

            return response()->json(['status'=>'success', 'message'=> 'Maker updated successfully'], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Maker updation failed', 'error' => $e ], 400);
        }
    }

    public function edit_address(Request $request, $id)
    {
        $validator = Validator::make($request->all(),
            [
                'org_id' => ['required'],
                'street' => ['required', 'string', 'max:60' ],
                //'city' => ['required', 'string', 'max:60' ],
                'city' => ['required', 'max:60' ],
                'district' => ['required','string', 'max:60' ],
                'zipcode' => ['required', 'string', 'max:20' ],
                'latitude' => ['required', 'numeric', 'between:0,180'],
                'longitude' => ['required', 'numeric', 'between:0,180'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $request['updated_at'] = date('Y-m-d H:i:s');
        try{
            Location::where('id', $id)->update($request->all());
            return response()->json(['status' => 'success', 'message'=> 'Location updated successfully', ], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Location update failed', "error" => $e ], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function validate_mns_code(Request $request) {
        if(isset($request->org_id) && !empty($request->org_id)) {
            $validator = Validator::make($request->all(), [
                'code' => ['required', 'string', 'max:20', 'unique:organizations,code,'.$request->org_id ],
                'org_id' => ['required'],
            ]);
            if ($validator->fails()) {
                $errors = [];
                foreach(json_decode($validator->messages()) as $key => $value)
                    $errors[] = $value[0];
                return response()->json([ 'status' => "failed", "response" => $errors ], 400);
            }else{
                return response()->json(['status' => 'success', 'message'=> 'Valid Code', ], 200);
            }
        }else{
            $validator = Validator::make($request->all(), [
                'code' => ['required', 'string', 'max:20', 'unique:organizations' ],
            ]);
            if ($validator->fails()) {
                $errors = [];
                foreach(json_decode($validator->messages()) as $key => $value)
                    $errors[] = $value[0];
                return response()->json([ 'status' => "failed", "response" => $errors ], 400);
            }else{
                return response()->json(['status' => 'success', 'message'=> 'Valid Code', ], 200);
            }
        }
    }

    public function adminuser($id) {
        //$list = User::where('id', $id)->where('role_id', 2)->with('company')->first();

        $list = User::where('id', $id)->with('company')->first();
        return response()->json(['status' => 'success', 'message'=> 'Admin Details', 'data' => $list], 200);
    }
    
}
