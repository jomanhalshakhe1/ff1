<?php

namespace App\Http\Controllers\Users;

use App\Http\Controllers\Controller;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\TabbyTransactionController;
use App\Http\Controllers\TransactionController;
use App\Models\Accounts\Payment;
use App\Models\Accounts\Transaction;
use App\Models\Accounts\VehicleModel;
use App\Models\Generals\Colour;
use App\Models\Accounts\Vehicle;
use App\Models\Accounts\VehicleGroup;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;
use Mockery\Exception;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class VehicleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $list = Vehicle::with('groups', 'manufacturer','colour' )->whereStatus(1)->get();
        return response()->json([ 'status' => "success", "data" => $list ], 200);
    }

    public function colours()
    {
        $list = Colour::all();
        return response()->json([ 'status' => "success", "data" => $list ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'make_year' => ['required' ],
                'owner_id' => ['required' ],
                'company' => ['required' ],
                'model' => ['required' ],
                'group_id' =>['required' ],
                'serial_no' => ["nullable", 'unique:vehicles,serial_no,NULL,id,deleted_at,NULL'],
                'plate_no' => ["nullable", 'unique:vehicles,plate_no,NULL,id,deleted_at,NULL'],
                'status'=>['required' ],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $count = VehicleModel::join('manufacturers', 'manufacturers.id', 'vehicle_models.maker')
            ->join('vehicle_groups', 'vehicle_groups.id', 'vehicle_models.vehicle_group_id')
            ->where('vehicle_models.id', $request['model'])
            ->where('vehicle_models.maker', $request['company'])
            ->where('vehicle_models.vehicle_group_id', $request['group_id'])
            ->count();

        if(!$count) {
            return response()->json([ 'status' => "failed", "message" => "Invalid Vehicle Input" ], 400);
        }

        try{
            $inputdata = array(
                'model' => $request['model'],
                'plate_no' => $request['plate_no'] ? $request['plate_no'] : '',
                'policy_no' => $request['policy_no'] ?  $request['policy_no'] : '',
                'colour' => $request['colour'],
                'serial_no' => $request['serial_no'] ? $request['serial_no'] : '',
                'trim' => $request['trim'], // user for veihcle registation year
                'company' => $request['company'],
                'group_id' => $request['group_id'],
                'make_year' => $request['make_year'],
                'owner_id' => $request['owner_id'],
                'licence_no' => $request['licence_no'] ? $request['licence_no'] : '',
                'status' => isset($request['status']) ? $request['status'] : 1,
                'created_at' => date('Y-m-d H:i:s')
            );
            if(isset($request['is_primary']) && $request['is_primary'] == 1){
                Vehicle::where('owner_id', $request['owner_id'])->update(['is_primary' => 0]);
                $inputdata['is_primary'] = 1;
            }

            Vehicle::insert($inputdata);
            return response()->json([ 'status' => "success", "response" => "Vehicle Added Successfully" ], 200);
        }
        catch (Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Vehicle Added Failed" ], 400);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $info = Vehicle::with('groups', 'manufacturer', 'model', 'colour')->whereId($id)->withTrashed()->first();
        return response()->json([ 'status' => "success", "data" => $info ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $validator = Validator::make($request->all(),
            [
                'make_year' => ['required' ],
                'owner_id' => ['required' ],
                'company' => ['required' ],
                'model' => ['required' ],
                'group_id' =>['required' ],
                'serial_no' => ['nullable', 'unique:vehicles,serial_no,'.$id.',id,deleted_at,NULL'],
                'plate_no' => ["nullable", 'unique:vehicles,plate_no,'.$id.',id,deleted_at,NULL'],
                'status'=>['required' ],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $count = VehicleModel::join('manufacturers', 'manufacturers.id', 'vehicle_models.maker')
            ->join('vehicle_groups', 'vehicle_groups.id', 'vehicle_models.vehicle_group_id')
            ->where('vehicle_models.id', $request['model'])
            ->where('vehicle_models.maker', $request['company'])
            ->where('vehicle_models.vehicle_group_id', $request['group_id'])
            ->count();

        if(!$count) {
            return response()->json([ 'status' => "failed", "message" => "Invalid Vehicle Input" ], 400);
        }

        try{
            $inputdata = array(
                'model' => $request['model'],
                'plate_no' => $request['plate_no'],
                'policy_no' => $request['policy_no'],
                'colour' => $request['colour'],
                'serial_no' => $request['serial_no'],
                'trim' => $request['trim'], // user for veihcle registation year
                'company' => $request['company'],
                'group_id' => $request['group_id'],
                'make_year' => $request['make_year'],
                'owner_id' => $request['owner_id'],
                'licence_no' => $request['licence_no'],
                'status' => $request['status'],
                'updated_at' => date('Y-m-d H:i:s')
            );

            if(isset($request['is_primary']) && $request['is_primary'] == 1){
                Vehicle::where('owner_id', $request['owner_id'])->update(['is_primary' => 0]);
                $inputdata['is_primary'] = 1;
            }

            $check_transactions = false;
            if(Vehicle::where('id', $id)->whereNull('plate_no')->count() == 1 &&  !empty($vehicle['plate_no']))
            {
                // check transactions for petromin related services
                $check_transactions = true;
            }

            Vehicle::where('id', $id)->update($inputdata);

            if($check_transactions){
                // do verification on this vehicle related transactions for petromin
                $this->verify_vehicle_transaction($id);
            }

            return response()->json([ 'status' => "success", "response" => "Vehicle Updated Successfully" ], 200);
        }
        catch (Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Vehicle Update Failed" ], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /*
     * Access: Customer, Prefix: customer
     * Store customer vehicles from the app
     * Req: vehilces was an array
     */
    public function add_driver_vehicles(Request $request)
    {
        $rules = array(
            'vehicles' => 'required|array',
            'vehicles.*.model' => "required",
            'vehicles.*.group_id' => "required",
            'vehicles.*.company' => "required",
            'vehicles.*.make_year' => "required",
            'vehicles.*.serial_no' => ["nullable", 'unique:vehicles,serial_no,NULL,id,deleted_at,NULL'],
            'vehicles.*.plate_no' => ["nullable", 'unique:vehicles,plate_no,NULL,id,deleted_at,NULL'],
        );

        $messages = array(
            'vehicles.*.model.required' => array(
                'en' => "Vehicle Model is required",
                'ar' => 'موديل المركبة مطلوب',
            ),
            'vehicles.*.group_id.required' => array(
                'en' => "Vehicle Group is required",
                'ar' => 'مجموعة المركبات مطلوبة',
            ),
            'vehicles.*.company.required' => array(
                'en' => "Maker is required",
                'ar' => 'صانع مطلوب',
            ),
            'vehicles.*.make_year.required' => array(
                'en' => "Make Year is required",
                'ar' => 'مطلوب جعل السنة',
            ),
            'vehicles.*.serial_no.unique' => array(
                'en' => "This Vin No. is already exists",
                'ar' => 'رقم فين موجود بالفعل',
            ),
            'vehicles.*.plate_no.unique' => array(
                'en' => "This Plate No. is already exists",
                'ar' => 'رقم اللوحة موجود بالفعل',
            ),
        );

        $validator = Validator::make($request->all(), $rules, $messages);

        if ($validator->fails()) {
            $errors = []; $errors_ar = [];
            foreach(json_decode($validator->messages()) as $key => $value){
                $errors[] = is_object($value[0]) ? $value[0]->en : $value[0];
                $errors_ar[] = is_object($value[0]) ? $value[0]->ar : $value[0];
            }

            return response()->json([ 'status' => "failed", "response" => $errors, "response_ar" => $errors_ar ], 400);
        }

        $vehicles = $request->vehicles;
        $input_check = true;
        foreach($vehicles as $vehicle) {
                $count = VehicleModel::join('manufacturers', 'manufacturers.id', 'vehicle_models.maker')
                    ->join('vehicle_groups', 'vehicle_groups.id', 'vehicle_models.vehicle_group_id')
                    ->where('vehicle_models.id', $vehicle['model'])
                    ->where('vehicle_models.maker', $vehicle['company'])
                    ->where('vehicle_models.vehicle_group_id', $vehicle['group_id'])
                    ->count();

            if(!$count && $input_check) {
                $input_check = false;
                $errors = "Invalid Vehicle Input";
                $errors_ar = "إدخال المركبة غير صحيح";
            }
        }

        if(!$input_check)
            return response()->json([ 'status' => "failed", "response" => $errors, "response_ar" => $errors_ar ], 400);

        try{
            $owner_id = Auth::guard('driver')->id();
            $count = Vehicle::where('owner_id', $owner_id)->where('status',1)->count();

            $i = 0;
            foreach ($vehicles as $vehicle)
            {
                $inputdata = array(
                    'model' => $vehicle['model'],
                    'plate_no' => $vehicle['plate_no'],
                    'policy_no' => $vehicle['policy_no'],
                    'colour' => $vehicle['colour'],
                    'serial_no' => $vehicle['serial_no'],
                    'trim' => $vehicle['trim'], // user for veihcle registation year
                    'company' => $vehicle['company'],
                    'group_id' => $vehicle['group_id'],
                    'make_year' => $vehicle['make_year'],
                    'owner_id' => $owner_id,
                    'status' => isset($vehicle['status']) ? $vehicle['status'] : 1,
                    'created_at' => date('Y-m-d H:i:s')
                );

                if($i == 0 && $count == 0){
                    $inputdata['is_primary'] = 1;
                    $i++;
                }

                Vehicle::insert($inputdata);
            }

            return response()->json([
                'status' => "success",
                "response" => "Vehicle Added Successfully",
                "response_ar" => "تمت إضافة السيارة بنجاح",
            ], 200);
        }
        catch (Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Vehicle Add Failed" ], 400);
        }
    }

    /*
     * Access: Customer, Prefix: customer
     * Update customer vehicles from the app
     */
	public function edit_driver_vehicles(Request $request)
    {
        $rules = array(
            'vehicles' => 'required|array',
            'vehicles.*.model' => "required",
            'vehicles.*.group_id' => "required",
            'vehicles.*.company' => "required",
            'vehicles.*.make_year' => "required",
        );

        $messages = array(
            'vehicles.*.model.required' => array(
                'en' => "Vehicle Model is required",
                'ar' => 'موديل المركبة مطلوب',
            ),
            'vehicles.*.group_id.required' => array(
                'en' => "Vehicle Group is required",
                'ar' => 'مجموعة المركبات مطلوبة',
            ),
            'vehicles.*.company.required' => array(
                'en' => "Maker is required",
                'ar' => 'صانع مطلوب',
            ),
            'vehicles.*.make_year.required' => array(
                'en' => "Make Year is required",
                'ar' => 'مطلوب جعل السنة',
            ),
        );

        $validator = Validator::make($request->all(), $rules, $messages);

        if ($validator->fails()) {
            $errors = []; $errors_ar = [];
            foreach(json_decode($validator->messages()) as $key => $value){
                $errors[] = is_object($value[0]) ? $value[0]->en : $value[0];
                $errors_ar[] = is_object($value[0]) ? $value[0]->ar : $value[0];
            }

            return response()->json([ 'status' => "failed", "response" => $errors, "response_ar" => $errors_ar ], 400);
        }

        $vehicles = $request->vehicles;
        $input_check = true;
        foreach($vehicles as $vehicle) {
            $count = VehicleModel::join('manufacturers', 'manufacturers.id', 'vehicle_models.maker')
                ->join('vehicle_groups', 'vehicle_groups.id', 'vehicle_models.vehicle_group_id')
                ->where('vehicle_models.id', $vehicle['model'])
                ->where('vehicle_models.maker', $vehicle['company'])
                ->where('vehicle_models.vehicle_group_id', $vehicle['group_id'])
                ->count();

            if(!$count && $input_check) {
                $input_check = false;
                $errors = "Invalid Vehicle Input";
                $errors_ar = "إدخال المركبة غير صحيح";
            }
        }

        if(!$input_check)
            return response()->json([ 'status' => "failed", "response" => $errors, "response_ar" => $errors_ar ], 400);

        try{
            foreach ($vehicles as $vehicle)
            {
                $check_transactions = false;
                if(Vehicle::where('id', $vehicle['id'])->whereNull('plate_no')->count() == 1 &&  !empty($vehicle['plate_no']))
                {
                    // check transactions for petromin related services
                    $check_transactions = true;
                }

                $inputdata = array(
                    'model' => $vehicle['model'],
                    'plate_no' => $vehicle['plate_no'],
                    'policy_no' => $vehicle['policy_no'],
                    'colour' => $vehicle['colour'],
                    'serial_no' => $vehicle['serial_no'],
                    'trim' => $vehicle['trim'], // user for veihcle registation year
                    'company' => $vehicle['company'],
                    'group_id' => $vehicle['group_id'],
                    'make_year' => $vehicle['make_year'],
                    'updated_at' => date('Y-m-d H:i:s')
                );

                Vehicle::where('id', $vehicle['id'])->update($inputdata);

                if($check_transactions){
                    // do verification on this vehicle related transactions for petromin
                    $this->verify_vehicle_transaction($vehicle['id']);
                }
            }

            return response()->json([
                'status' => "success",
                "response" => "Vehicle Edited Successfully",
                "response_ar" => "تم تحرير السيارة بنجاح",
            ], 200);
        }
        catch (Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Vehicle Edit Failed" ], 400);
        }
    }

    /*
     * Access: Customer, Prefix: customer
     * delete customer vehicles from the app
     */
	public function delete_driver_vehicle(Request $request, $id = null)
    {
        try{
            $customerId = Auth::guard('driver')->id();
            $vehicleData=Vehicle::where('id', $id)->first();

            if($vehicleData->is_primary){
                Vehicle::where('owner_id', $customerId)->update(['is_primary' => 0]);

                $sql="select * from vehicles 
                    where ( 
                    id = IFNULL((select min(id) from vehicles where id > ".$id." and `owner_id`= '".$vehicleData->owner_id."' AND `status` = 1),0) 
                    or  id = IFNULL((select max(id) from vehicles where id < ".$id." and `owner_id`= '".$vehicleData->owner_id."' AND `status` = 1),0)
                  )";

                $vehicles=DB::select($sql);

                if(count($vehicles)){
                    $primaryId=$vehicles['0']->id;
                    if(count($vehicles)>1){
                        $primaryId=$vehicles['1']->id;
                    }
                    Vehicle::whereId($primaryId)->update(['is_primary' => 1]);
                }
            }

            Vehicle::whereId($id)->delete();

            return response()->json([
                'status' => "success",
                "response" => "Vehicle Deleted Successfully",
                "response_ar" => "تم حذف المركبة بنجاح",
            ], 200);
        }
        catch (Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Vehicle Delete Failed" ], 400);
        }
    }

    /*
     * Access: Customer app, Admin, prefix: customer, api
     * Get all vehicles list of customer
     * Get all driver vehicles list for customer profile on admin portal
     */
    public function driver_vehicles($driverId = null){

        if(!$driverId) {
            // customer app request
            $driverId = Auth::guard('driver')->id();
            $list = Vehicle::where('owner_id', $driverId)->where('status', 1);
        }
        else{
            // Admin portal request: Active records only
            $list = Vehicle::where('owner_id', $driverId)->where('status', 1);
        }

        $list = $list->with('groups', 'manufacturer', 'model')
                        ->orderBy('id', 'desc')->get();

        return response()->json([ 'status' => "success", "data" => $list ], 200);
    }

    /*
     * Access: Customer app, prefix: customer
     * Get all vehicles list for the offer
     * Vehicle group will be applicable to those particular offers ( cleaning & detailing), and for other deals all vehicles will be applicable
     */
    public function deal_vehicles_list($offer_id = null){

        $deal_id = ItemOffer::where('id', $offer_id)->pluck('deal_id')->first();
        if($deal_id == 4 || $deal_id == 5) // Cleaning & detailing
        {
            $list = Vehicle::join('deal_vehicles', 'vehicles.group_id', '=', 'deal_vehicles.group_id')
                ->where('deal_vehicles.offer_id', $offer_id)
                ->where('vehicles.owner_id', Auth::guard('driver')->id())
                ->where('vehicles.status', 1)
                ->with('groups', 'manufacturer', 'model')->get();
        }
        else{
            $list = Vehicle::where('owner_id', Auth::guard('driver')->id())
                ->where('status', 1)
                ->with('groups', 'manufacturer', 'model')->get();
        }

        return response()->json([ 'status' => "success", "data" => $list ], 200);
    }

    /*
     * Access: Customer, Prefix: customer
     * update the primary customer vehicle from the app
     */
	public function update_default_vehicle($vehicle_id){
        // update default vehicle
        Vehicle::where('owner_id', Auth::guard('driver')->id())->update(['is_primary' => 0]);

        Vehicle::where('owner_id', Auth::guard('driver')->id())
            ->where('id', $vehicle_id)
            ->update(['is_primary' => 1]);

        return response()->json([
            'status' => "success",
            "response" => "Default vehicle updated successfully",
            "response_ar" => "تم تحديث السيارة الافتراضية بنجاح",
        ], 200);
    }

    /*
     * Access: Customer, Prefix: customer
     * update vin no. to the customer vehicles from the app
     * This is we use on vin no, was empty and going to purchase offer which required vin no
     */
    public function assign_vin(Request $request){

        $vehicle_id = $request['vehicle_id'];
        $rules = array(
            'vehicle_id' => 'required',
            'serial_no' => ['required', 'unique:vehicles,serial_no,'.$vehicle_id.',id,deleted_at,NULL'],
        );

        $messages = array(
            'vehicle_id.required' => array(
                'en' => "Vehicle Id required",
                'ar' => 'معرف السيارة مطلوب',
            ),
            'serial_no.required' => array(
                'en' => "Vin No. is required",
                'ar' => 'رقم فين مطلوب',
            ),
            'serial_no.unique' => array(
                'en' => "This Vin No. is already exists",
                'ar' => 'رقم فين موجود بالفعل',
            ),
        );

        $validator = Validator::make($request->all(), $rules, $messages);

        if ($validator->fails()) {
            $errors = []; $errors_ar = [];
            foreach(json_decode($validator->messages()) as $key => $value){
                $errors[] = is_object($value[0]) ? $value[0]->en : $value[0];
                $errors_ar[] = is_object($value[0]) ? $value[0]->ar : $value[0];
            }

            return response()->json([ 'status' => "failed", "response" => $errors, "response_ar" => $errors_ar ], 400);
        }

        try{
            Vehicle::where('id', $request['vehicle_id'])->update([
                'serial_no' => $request['serial_no'],
                'updated_at' => date('Y-m-d H:i:s')
            ]);

            return response()->json([
                'status' => "success",
                "response" => "Vehicle Indentity Number updated Successfully",
                "response_ar" => "تم تحديث رقم المسافة البادئة للمركبة بنجاح"
            ], 200);
        }
        catch (Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Vehicle update Failed" ], 400);
        }
    }

    /*
     * Access: Customer, Prefix: customer
     * update plate no. to the customer vehicles from the app
     * This is we use on plate no, was empty and going to purchase offer which required plate no
     */
    public function assign_plateno(Request $request){

        $vehicle_id = $request['vehicle_id'];
        $rules = array(
            'vehicle_id' => 'required',
            'plate_no' => ['required', 'unique:vehicles,plate_no,'.$vehicle_id.',id,deleted_at,NULL'],
        );

        $messages = array(
            'vehicle_id.required' => array(
                'en' => "Vehicle Id required",
                'ar' => 'معرف السيارة مطلوب',
            ),
            'plate_no.required' => array(
                'en' => "Plate No. is required",
                'ar' => 'رقم اللوحة مطلوب',
            ),
            'plate_no.unique' => array(
                'en' => "This Plate No. is already exists",
                'ar' => 'رقم اللوحة موجود بالفعل',
            ),
        );

        $validator = Validator::make($request->all(), $rules, $messages);

        if ($validator->fails()) {
            $errors = []; $errors_ar = [];
            foreach(json_decode($validator->messages()) as $key => $value){
                $errors[] = is_object($value[0]) ? $value[0]->en : $value[0];
                $errors_ar[] = is_object($value[0]) ? $value[0]->ar : $value[0];
            }

            return response()->json([ 'status' => "failed", "response" => $errors, "response_ar" => $errors_ar ], 400);
        }

        try{
            Vehicle::where('id', $request['vehicle_id'])->update([
                'plate_no' => $request['plate_no'],
                'updated_at' => date('Y-m-d H:i:s')
            ]);

            try{
                $this->verify_vehicle_transaction($request['vehicle_id']);
            }catch (Exception $e){
                Log::error("Transaction for petromin was failed. Vehicle ID: ".$request['vehicle_id'] );
            }

            return response()->json([
                'status' => "success",
                "response" => "Vehicle plate no. updated successfully",
                "response_ar" => "رقم لوحة المركبة. تم التحديث بنجاح",
            ], 200);
        }
        catch (Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Vehicle update Failed" ], 400);
        }
    }

    /*
     * Access: Customer, Prefix: customer
     * update Vin No and plate no. to the customer vehicles from the app
     * This is we use on serial_no (vin no), plate no. was empty and going to purchase offer which required vin no, plate no
     */
    public function assign_vn_pn(Request $request){

        $vehicle_id = $request['vehicle_id'];
        $rules = array(
            'vehicle_id' => 'required',
            'serial_no' => ['required', 'unique:vehicles,serial_no,'.$vehicle_id.',id,deleted_at,NULL'],
            'plate_no' => ['required', 'unique:vehicles,plate_no,'.$vehicle_id.',id,deleted_at,NULL'],
        );

        $messages = array(
            'vehicle_id.required' => array(
                'en' => "Vehicle Id required",
                'ar' => 'معرف السيارة مطلوب',
            ),
            'serial_no.required' => array(
                'en' => "Vin No. is required",
                'ar' => 'رقم فين مطلوب',
            ),
            'serial_no.unique' => array(
                'en' => "This Vin No. is already exists",
                'ar' => 'رقم فين موجود بالفعل',
            ),
            'plate_no.required' => array(
                'en' => "Plate No. is required",
                'ar' => 'رقم اللوحة مطلوب',
            ),
            'plate_no.unique' => array(
                'en' => "This Plate No. is already exists",
                'ar' => 'رقم اللوحة موجود بالفعل',
            ),
        );

        $validator = Validator::make($request->all(), $rules, $messages);

        if ($validator->fails()) {
            $errors = []; $errors_ar = [];
            foreach(json_decode($validator->messages()) as $key => $value){
                $errors[] = is_object($value[0]) ? $value[0]->en : $value[0];
                $errors_ar[] = is_object($value[0]) ? $value[0]->ar : $value[0];
            }

            return response()->json([ 'status' => "failed", "response" => $errors, "response_ar" => $errors_ar ], 400);
        }

        try{
            Vehicle::where('id', $request['vehicle_id'])->update([
                'serial_no' => $request['serial_no'],
                'plate_no' => $request['plate_no'],
                'updated_at' => date('Y-m-d H:i:s')
            ]);

            try{
                $this->verify_vehicle_transaction($request['vehicle_id']);
            }catch (Exception $e){
                Log::error("Transaction for petromin was failed. Vehicle ID: ".$request['vehicle_id'] );
            }

            return response()->json([
                'status' => "success",
                "response" => "Vehicle plate no. updated successfully",
                "response_ar" => "رقم لوحة المركبة. تم التحديث بنجاح",
            ], 200);
        }
        catch (Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Vehicle update Failed" ], 400);
        }
    }

    /**
     * Access: Admin, Prefix: api
    * Get all vehicles list of the drivers for active or inactive drivers
    * @param $request
    * @return \Illuminate\Http\Response
    */
    public function get_all_customer_vehicles(Request $request){

        $pageno = 1; $pagelength = 10;
         
        $list = Vehicle::select('vehicles.*')->with('groups', 'manufacturer', 'model','driver','colour')
                ->join('drivers', 'drivers.id','=','vehicles.owner_id');
                 
        $login_type_id = Auth::user()->login_type_id;
        if($login_type_id == 19) // Fleet Company
        {
            $org_id = Auth::user()->org_id;
            $list=$list->join('fleet_drivers','fleet_drivers.driver_id','=','drivers.id')
                  ->where('fleet_drivers.status', '1')
                  ->where('fleet_drivers.fleet_id', $org_id)
                  ->whereNotNull('fleet_drivers.employee_id');
        }      

        if(isset($request->customer_id) && !empty($request->customer_id)){
           $list = $list->where('vehicles.owner_id', $request->customer_id);
        }

        $totalrecords = $list->withTrashed()->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)){
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = $list->orderBy('vehicles.id', 'desc')
            ->skip( ($pageno-1)*$pagelength )->take($pagelength)->withTrashed()->get();

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    public function verify_vehicle_transaction($vehicle_id){

        // Fetch open transactions, which are not registered in petromin
        $list = Transaction::join('item_master', 'item_master.id', 'transactions.item_id')
                ->join('organizations', 'organizations.id', 'item_master.delar_id')
                ->where('organizations.code', 'PETROMIN')
                ->where('transactions.payment_status', 'Successful')
                ->where('transactions.vehicle_id', $vehicle_id)
                ->whereNull('transactions.service_id')
                ->select('transactions.*')->get();

        foreach($list as $row) {
            try {
                $res = (new PetrominController())->add_service($row['transaction_no']);
                $res = (array)$res->getData();
                if ($res['status'] == 'success') {
                    $service_id = $res['data']->service->id;
                    Transaction::where('transaction_no', $row['transaction_no'])->update(['service_id' => $service_id]);

                    if ($res['data']->service->bookingStatus == 0) {
                        // Successful booking, then Capture payment
                        $this->update_transaction_payment($row['transaction_no'], 5);
                    }else{
                        // on failed booking, delete the service
                        try {
                            /*$res = (new PetrominController())->destroy($service_id);
                            $res = (array)$res->getData();

                            if($res['status'] == 'success'){
                                $this->update_transaction_payment($row['transaction_no'], 9);
                            }*/

                            // $this->update_transaction_payment($row['transaction_no'], 9);
                        } catch (\Exception $e){
                            Log::error("Petromin cancel service booking failed: Transaction No.:". $row['transaction_no']);
                        }
                    }
                } else {
                    // Cancel the transaction
                    // Void Authorize the payment
                    // $this->update_transaction_payment($row['transaction_no'], 9);
                }
            } catch (\Exception $e) {
                Log::error("Petromin service booking initiation failed: Transaction No.:" . $row['transaction_no']);
            }
        }
    }

    public function update_transaction_payment($transaction_no, $actionCode)
    {
        $paymentData = Payment::where('transaction_no', $transaction_no)->first();
        if($paymentData->payment_on == 50){
            // capture or reject payments by Tabby
            (new TabbyTransactionController())->captureTabbypayment($paymentData->payid, $paymentData->amount_by_banking, $actionCode);
            $paymentArray['payment_status'] = ($actionCode == 5 ? 'Successful' : 'Cancelled');
            $paymentArray['response_result'] = ($actionCode == 5 ? 'Successful' : 'Cancelled');
        } else if($paymentData->payment_on == 33 || $paymentData->payment_on == 35){
            // capture or reject payments by urway
            // 33 - Apple Pay, 35 - Credit Cards
            $result = (new PaymentController())->unlock_payments($paymentData->payid, $paymentData->amount_by_banking, $_SERVER['REMOTE_ADDR'], $actionCode);
            $resultData = $result['data'];

            if($result['payment_status'] != 'Successful'){
                $msg = 'Payment '.($actionCode == 5 ? "Capture" : "rejection"). " was failed from payment gateway. Please try again";

                Log::error($msg." : ".$transaction_no);
                return $msg;
            }

            $paymentArray['payment_status'] = $result['payment_status'];
            $paymentArray['response_result'] = $result['Response'];

            if (!empty($resultData)) {
                $paymentArray['response_code'] = $resultData->responseCode;
                $paymentArray['response_amount'] = $resultData->amount;
            }
        }

        $paymentArray['action_code']= $actionCode;
        $paymentArray['updated_at'] = date('Y-m-d H:i:s');

        Payment::where('transaction_no', $transaction_no)->where('id', $paymentData->id)->update($paymentArray);

        if($actionCode == 5)
            $msg = "Transaction was successful on petromin service";
        else
            $msg = "Transaction will be rejected, due to petromin service was failed";

        $transData = array(
            'remarks' => $msg,
            'is_approved' => $actionCode == 5 ? 1 : 0,
            'payment_status' => $actionCode == 5 ? 'Successful' : 'Rejected',
            'approved_by' => 1,
            'approved_at' => date('Y-m-d H:i:s')
        );

        Transaction::where('transaction_no', $transaction_no)->update($transData);

        if($actionCode == 5) {
            // update invoice no to the transaction
            (new TransactionController())->update_transaction_invoice_no($transaction_no);
        }
    }

}
