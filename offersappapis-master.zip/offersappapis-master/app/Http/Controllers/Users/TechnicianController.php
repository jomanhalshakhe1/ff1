<?php

namespace App\Http\Controllers\Users;

use App\Http\Controllers\Controller;
use App\Models\Generals\Device;
use App\Models\Regulatory\Maker;
use App\Models\Regulatory\OrgDeal;
use App\Models\Regulatory\TechnicianLocation;
use App\Models\Accounts\Reset;
use App\Models\Generals\Slider;
use App\Models\Accounts\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Http\Controllers\Generals\SendPushNotification;
use App\Http\Controllers\Generals\EmailController;
use App\Models\Regulatory\Location;
use App\Events\Emails\ChangeMobileNumber;
use App\Events\Emails\RegistrationSuccess;
use App\Http\Controllers\Generals\NotificationController;
use App\Models\Generals\RedeemLog;
use App\Models\Accounts\Transaction;
use App\Models\Inventory\Maintenance;
use App\Models\Inventory\MaintenanceLog;

class TechnicianController extends Controller
{
    public $msTechnician;
    public $NonMsTechnician;
    public function __construct()
    {
        $this->msTechnician = 7; // Only for M & S Deals - M & S Technician
        $this->NonMsTechnician = 8; // Other than M & S Deals - Delar Technician
    }

    public function index(Request $request)
    {
        $pageno = 1; $pagelength = 10;
        $list = User::where('role_id', $this->msTechnician)->with('company');
        $totalrecords = $list->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        if(isset($request->org_id) && $request->org_id>0) {
           $list =$list->where('org_id', $request->org_id);
        } else if(Auth::user()->login_type_id!=17){
          $list =$list->where('org_id', Auth::user()->org_id);
        }

        $list = $list->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();
        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\response
     */
    public function create(Request $request)
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\response
     */
    public function store(Request $request)
    {
        $request['contact_no'] = $request['country_code'].$request['contact_no'];
        $validator = Validator::make($request->all(),[
            'first_name' => 'required|max:100',
            'last_name' => 'max:100',
            //'email' => 'required|max:100|email|unique:users,email,NULL,id,deleted_at,NULL',
            'email' => ['required', 'email', 'max:100', 'unique:users,email,NULL,id,deleted_at,NULL'],
            'country_code' => 'required|max:5',
            'contact_no' => 'required|max:15|unique:users,contact_no,NULL,id,deleted_at,NULL',
            'org_id' => 'required',
            'status' => 'required',
            'thumbnail' => 'nullable|mimes:jpeg,jpg,png|max:500',
            'is_verified'=>'required',
            'is_email_verified'=>'required',
            //'locations.*' => 'required',
        ]);


        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/technician/profiles/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['profile_pic'] = '/uploads/technician/profiles/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('technician/profiles/', $request->file('thumbnail'));
            $request['profile_pic'] = Storage::disk('s3')->url($file_name);
        }

        try{
            
            $request['password'] = Hash::make('0000');
            $request['role_id'] = $this->msTechnician; //technician
            $request['created_at'] = date('Y-m-d H:i:s');

            $user = User::create($request->except('locations', 'thumbnail'));
            $userId = $user->id;

            $request['locations'] = json_decode($request['locations'], true);
            $technician_location = [];
            foreach($request['locations'] as $tech_location) {
                $technician_location[] = [
                    'technician_id' => $userId,
                    'location_id' => $tech_location['location_id'],
                    'created_at' => date('Y-m-d H:i:s')
                ];
            }
            if(count($technician_location)> 0){
                TechnicianLocation::insert($technician_location);
            }

            return response()->json(['status' => 'success', 'response' => 'Successfully added a Technician'], 200);
        }
        catch(\Exception $e){
            return response()->json(['status' => 'failed', 'response' => 'Failed to add Technician', "error" => $e ], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\response
     */
    public function show($id)
    {
        $list = User::with('tech_locations')->where('id', $id)->first();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\response
     */
    public function update(Request $request, $id)
    {
        $request['contact_no'] = $request['country_code'].$request['contact_no'];
        $validator = Validator::make($request->all(),[
            'first_name' => 'required|max:100',
            'last_name' => 'max:100',
            //'email' => 'required|max:100|unique:users,email,'.$id.',id,deleted_at,NULL',
            'email' => ['required', 'email', 'max:100', 'unique:users,email,'.$id.',id,deleted_at,NULL'],
            'country_code' => 'required|max:5',
            'contact_no' => 'required|max:15|unique:users,contact_no,'.$id.',id,deleted_at,NULL',
            'org_id' => 'required',
            'thumbnail' => 'nullable|mimes:jpeg,jpg,png|max:500',
            'is_verified'=>'required',
            'is_email_verified'=>'required',
            //'locations.*' => 'required',
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        //Check organization id changed or not
        $techData = User::where('id', $id)->first();
        if(empty($techData)){
             return response()->json(['status' => 'failed', 'response' => 'Technician details not found'], 400);
        }

        if($techData->org_id!=$request->org_id){
             return response()->json(['status' => 'failed', 'response' => "Technician's organization details not allowed to modify"], 400);
        }

        //Not allowed to modify other company's technicians
        if(Auth::user()->login_type_id!=17 && $techData->org_id!=Auth::user()->org_id){ 
            return response()->json(['status' => 'failed', 'response' => "You can't modify other company technician information"], 400);   
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/technician/profiles/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['profile_pic'] = '/uploads/technician/profiles/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('technician/profiles/', $request->file('thumbnail'));
            $request['profile_pic'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $request['updated_at'] = date('Y-m-d H:i:s');
            User::where('id', $id)->update($request->except('locations', 'thumbnail'));

            $request['locations'] = json_decode($request['locations'], true);
            $technician_location = [];
            if(isset($request['locations']) && !empty($request['locations'])) {
                TechnicianLocation::where('technician_id', $id)->delete();
                foreach($request['locations'] as $tech_location) {
                    $technician_location[] = [
                        'technician_id' => $id,
                        'location_id' => $tech_location['location_id'],
                        'created_at' => date('Y-m-d H:i:s')
                    ];
                }
            }
            if(count($technician_location)> 0){
                TechnicianLocation::insert($technician_location);
            }

            return response()->json(['status' => 'success', 'response' => 'User Updated Successfully'], 200);
        }
        catch(\Exception $e){
            return response()->json(['status' => 'failed', 'response' => 'Failed to update User', "error" => $e ], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\response
     */
    public function destroy($id)
    {
        try {
            User::where('id', $id)->delete();
            return back()->with('success','User Successfully Deleted');
        } catch(\Exception $e){
            Log::info("UserController::destroy ".Auth::user()->first_name."".Auth::user()->last_name." Failed to delete User".$e);
            return redirect()->back()->with('failed','Failed to delete User');
        }
    }

    public function signin(Request $request)
    {
        // M & S and Dealer Technican Login
        $data = [];
        $validator = Validator::make($request->all(),
            [
                'contact_no' => ['required', 'string'],
                //'password' => ['required', 'string'],
                //'read_otpcode' => ['required', 'string'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        // Login only to 18 - Dealer Admin, 20 - Service Provider Admin, 22 - Technician
        $userData = User::where('contact_no',$request['contact_no'])->where('status', 1)
                        ->whereHas('role', function($q){
                            $q->whereIn('login_type_id', [18, 20, 22]);
                        })
                        ->with('company')->first();

        if($userData)
        {
            if($userData->is_verified == 2){
                // 2 - Rejected
                return response()->json([
                    'status' => 'failed',
                    'message' => 'Your account was blocked',
                    'message_ar' => 'تم حظر حسابك'], 401);
            }

            $st=$userData->company ? $userData->company->status : 0;
             if(!$st){
                return response()->json([
                    'status' => "failed",
                    "response" => 'Organization was blocked',
                    "response_ar" => 'تم حظر المنظمة',
                ], 400);
             }

            if(User::where('contact_no', $request['contact_no'])->where('is_verified', 1)
                    ->whereHas('role', function($q){
                        $q->whereIn('login_type_id', [18, 20, 22]);
                    })->count() == 0)
                return response()->json([
                    'status' => "failed",
                    "response" => 'User not verified',
                    "response_ar" => 'لم يتم التحقق من المستخدم',
                ], 400);
        }
        else
            return response()->json([
                'status' => "failed",
                "response" => 'Invalid UserId',
                "response_ar" => 'هوية مستخدم غير صالحه',
            ], 400);

        $userId = User::where('contact_no', $request['contact_no'])->where('status', 1)
                        ->whereHas('role', function($q){
                            $q->whereIn('login_type_id', [18, 20, 22]);
                        })->pluck('id')->first();

        try {
            if (! $token = Auth::loginUsingId($userId)) {
                return response()->json([
                    'status' => 'failed',
                    'response' => "Invalid Credentials",
                    'response_ar' => "بيانات الاعتماد غير صالحة",
                ], 400);
            }
        } catch (JWTException $e) {
            return response()->json(['status' => 'failed','response' => 'could_not_create_token', 'data' => $data], 500);
        }

        Auth::user()->device_type = 'android';
        $data["User"]= Auth::user();
        $token = JWTAuth::fromUser($data["User"]);
        $data["Token"]= $token;

        if(isset($request->device_info)){
            $device_log = $request->device_info;
            $device_log['user_id'] = $data["User"]['id'];
            $device_log['user_type'] = 'user';
            $this->device_data($device_log);
        }
        $read_otpcode = '';
        if(isset($request['read_otpcode']) && !empty($request['read_otpcode'])){
            $read_otpcode = $request['read_otpcode'];
        }
        $this->send_otp($data["User"]['contact_no'], $read_otpcode, 'sameclass');

        if(isset($data["User"]['company']['company_type']) && $data["User"]['company']['company_type'] == 'M')
            $data["User"]['is_dealer'] = 0;
        else
            $data["User"]['is_dealer'] = 1;

        if(OrgDeal::where('org_id', Auth::user()->org_id)->where(function ($qry){
                $qry->where('deal_id', 2) // Tires
                    ->orWhere('deal_id',6); // Battaries
            })->where('status', 1)->count() > 0)
            $data["User"]['is_notifier'] = 1;
        else
            $data["User"]['is_notifier'] = 0;

        return response()->json(['status'=>'success','response' => "Success",'data' => $data], 200);
    }

    public function request_verification(Request $request)
    {
        $request['contact_no'] = $request['country_code'].ltrim($request['contact_no'], '0');
        $rules = array(
            'first_name'    => ['required', 'string', 'max:20' ],
            'email'    => ['required', 'string', 'email', 'unique:users,email,NULL,id,deleted_at,NULL', 'max:60'],
            'country_code'    => ['required', 'string', 'max:5' ],
            'contact_no'    => ['required', 'string', 'max:15', 'unique:users,contact_no,NULL,id,deleted_at,NULL' ],
        );
        $messages = array(
            'first_name.required' => 'Name field is required',
            'first_name.max' => 'Name should be max 20 characters',
            'contact_no.required' => array(
                'en' => 'Contact No. Required',
                'ar' => 'رقم الاتصال مطلوب',
            ),
            'contact_no.unique' => array(
                'en' => 'This number is registered with us, please login directly',
                'ar' => 'هذا الرقم مسجل لدينا، الرجاء تسجيل الدخول مباشرة',
            ),
            'email.required' => array(
                'en' => 'Email Required',
                'ar' => 'البريد الإلكتروني (مطلوب',
            ),
            'email.unique' => array(
                'en' => 'This email is registered with us, please login directly',
                'ar' => 'تم تسجيل هذا البريد الإلكتروني معنا ، يرجى تسجيل الدخول مباشرة',
            )
        );

        $validator = Validator::make($request->all(),$rules , $messages);

        if ($validator->fails()) {
            $errors = []; $errors_ar = [];
            foreach(json_decode($validator->messages()) as $key => $value){
                $errors[] = is_object($value[0]) ? $value[0]->en : $value[0];
                $errors_ar[] = is_object($value[0]) ? $value[0]->ar : $value[0];
            }

            return response()->json([ 'status' => "failed", "response" => $errors, "response_ar" => $errors_ar ], 400);
        }

        try{
            $mail = explode('@',$request['email'])[1];
            $cnt = Maker::where('email', 'like', '%'.$mail.'%')->whereIn('company_type', ['M', 'D'])->count();
            if($cnt == 0)
                return response()->json([
                    'status' => 'failed',
                    'response' => 'Invalid mail extension. Failed to add technician',
                    'response_ar' => 'ملحق بريد غير صالح. فشل في إضافة فني',
                ], 400);
            else{
                $contactNo = $request['contact_no'];
                $this->send_otp($contactNo,'','');

                $dealer = Maker::where('email', 'like', '%'.$mail.'%')->whereIn('company_type', ['M', 'D'])->first();

                return response()->json([
                    'status' => 'success',
                    'response' => 'Email verified for dealer organization',
                    'response_ar' => 'تم التحقق من البريد الإلكتروني لمنظمة تاجر',
                    'organization' => $dealer
                ], 200);
            }
        }
        catch (\Exception $e){
            return response()->json([
                'status' => 'failed',
                'response' => 'Failed to add technician',
                'response_ar' => 'فشل في إضافة فني'], 400);
        }
    }

    public function signup(Request $request)
    {
        $request['contact_no'] = $request['country_code'].ltrim($request['contact_no'],'0');
        $rules = array(
            'first_name'    => ['required', 'string', 'max:20' ],
            'email'    => ['required', 'string', 'email', 'unique:users,email,NULL,id,deleted_at,NULL', 'max:60'],
            'country_code'    => ['required', 'string', 'max:5' ],
            'contact_no'    => ['required', 'string', 'max:15', 'unique:users,contact_no,NULL,id,deleted_at,NULL' ],
            'OTP' => ['required', 'string', 'min:4'],
            //'read_otpcode'    => ['required', 'string'],
        );

        $messages = array(
            'first_name.required' => 'Name field is required',
            'first_name.max' => 'Name should be max 20 characters',
            'contact_no.required' => array(
                'en' => 'Contact No. Required',
                'ar' => 'رقم الاتصال مطلوب',
            ),
            'contact_no.unique' => array(
                'en' => 'This number is registered with us, please login directly',
                'ar' => 'هذا الرقم مسجل لدينا، الرجاء تسجيل الدخول مباشرة',
            ),
            'email.required' => array(
                'en' => 'Email Required',
                'ar' => 'البريد الإلكتروني (مطلوب',
            ),
            'email.unique' => array(
                'en' => 'This email is registered with us, please login directly',
                'ar' => 'تم تسجيل هذا البريد الإلكتروني معنا ، يرجى تسجيل الدخول مباشرة',
            )
        );

        $validator = Validator::make($request->all(),$rules , $messages);

        if ($validator->fails()) {
            $errors = []; $errors_ar = [];
            foreach(json_decode($validator->messages()) as $key => $value){
                $errors[] = is_object($value[0]) ? $value[0]->en : $value[0];
                $errors_ar[] = is_object($value[0]) ? $value[0]->ar : $value[0];
            }

            return response()->json([ 'status' => "failed", "response" => $errors, "response_ar" => $errors_ar ], 400);
        }

        if(Reset::where([['email', $request['contact_no']],[ 'token' , $request['OTP']] ,[ 'user_type' , 'User' ]] )->count() > 0)
            Reset::where('email', $request['contact_no'])->where('user_type', 'User')->delete();
        else
            return response()->json([
                'status'=>'failed',
                'message'=> 'Invalid OTP',
                'message_ar'=> 'OTP غير صحيح',
            ], 400);

        try{

            // assign the last word of first name to last name
            $name = trim($request->first_name);
            $names = explode(" ",$name);
            $last_name = count($names) > 1 ? array_pop($names) : '';
            $first_name = trim(str_replace($last_name, '', $name ));

            $request['first_name'] = $first_name;
            $request['last_name'] = $last_name;
            $request['password'] = Hash::make('0000');
            $request['is_verified'] = 1;
            $request['created_at'] = date('Y-m-d H:i:s');

            $mail = explode('@',$request['email'])[1];
            $delar = Maker::where('email', 'like', '%'.$mail.'%')
                ->whereIn('company_type', ['M', 'D'])->first();
            $request['org_id'] = $delar->id;

            if($delar->company_type == 'M')
            {
                // M & S services - Deal Id = 9
                $request['role_id'] = $this->msTechnician; //M & S technician
            }
            else
                $request['role_id'] = $this->NonMsTechnician; //Delar technician

            User::create($request->except('OTP'));

            try{
                // Send notification to user
                event(new RegistrationSuccess($request['email'], $request['first_name'], '' , 'User', '1'));
            }catch(\Exception $e){
                Log::error('Technicain registration sent mail failed'. json_encode($e));
            }

            return response()->json([
                'status' => 'success',
                'response' => 'Successfully registered as a Technician',
                'response_ar' => 'تم التسجيل بنجاح كفني'
            ], 200);
        }
        catch(\Exception $e){
            //return $e;
            return response()->json([
                'status' => 'failed',
                'response' => 'Failed to add Technician',
                'response_ar' => 'فشل في إضافة فني',
            ], 400);
        }
    }

    public function update_profile(Request $request)
    {
        $id = Auth::guard('technician')->id();
        $rules = array(
            'first_name'    => ['required', 'string', 'max:20' ],
            'email'    => ['required', 'string', 'email', 'unique:users,email,'.$id.',id,deleted_at,NULL', 'max:60'],
            'country_code'    => ['required', 'string', 'max:5' ],
            'contact_no'    => ['required', 'string', 'max:15', 'unique:users,contact_no,'.$id.',id,deleted_at,NULL' ],
            //'dob' => ['required', 'string'],
            //'age' => ['required'],
            //'gender' => ['required', 'string'],
            //'nationality' => ['required', 'string'],
            //'is_self' => ['required'],
        );

        $messages = array(
            'first_name.required' => 'Name field is required',
            'first_name.max' => 'Name should be max 20 characters',
            'contact_no.required' => array(
                'en' => 'Contact No. Required',
                'ar' => 'رقم الاتصال مطلوب',
            ),
            'contact_no.unique' => array(
                'en' => 'This number is registered with us, please login directly',
                'ar' => 'هذا الرقم مسجل لدينا، الرجاء تسجيل الدخول مباشرة',
            ),
            'email.required' => array(
                'en' => 'Email Required',
                'ar' => 'البريد الإلكتروني (مطلوب',
            ),
            'email.unique' => array(
                'en' => 'This email is registered with us, please login directly',
                'ar' => 'تم تسجيل هذا البريد الإلكتروني معنا ، يرجى تسجيل الدخول مباشرة',
            )
        );

        $validator = Validator::make($request->all(),$rules , $messages);

        if ($validator->fails()) {
            $errors = []; $errors_ar = [];
            foreach(json_decode($validator->messages()) as $key => $value){
                $errors[] = is_object($value[0]) ? $value[0]->en : $value[0];
                $errors_ar[] = is_object($value[0]) ? $value[0]->ar : $value[0];
            }

            return response()->json([ 'status' => "failed", "response" => $errors, "response_ar" => $errors_ar ], 400);
        }

        $inputdata = array(
            'email' => $request->email,
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'contact_no' => $request->contact_no,
            'age' => $request->age,
            'gender' => $request->gender,
            'dob' => $request->dob,
            'nationality' => $request->nationality,
            'is_self' => $request->is_self,
            'updated_at' => date('Y-m-d H:i:s')
        );

        if(isset($request->org_id) && $request->org_id != '')
            $inputdata['org_id'] = $request->org_id;

        try {
            User::where('id', $id)->update($inputdata);
            $data['user'] = User::where('id', $id)->first();

            return response()->json([
                'status' => 'success',
                'message' => 'Profile Updated Successfully',
                'message_ar' => 'تم تحديث الملف الشخصي بنجاح',
                'response' => $data], 200);
        }
        catch (\Exception $e){
            return response()->json([
                'status' => 'failed',
                'message' => 'Profile Update Failed',
                'message_ar' => 'فشل تحديث ملف التعريف',
            ], 400);
        }
    }

    public function getUserInfo(Request $request)
    {
        //return $request->header();
        $user = User::whereId(Auth::guard('technician')->id())->with('vehicle', 'organization')->first();

        return response()->json([ 'status' => "success", "user" => $user ], 200);
    }

    public function verify_otp(Request $request)
    {
        // M & S Technican User OTP Verification
        $validator = Validator::make($request->all(),
            [
                'contact_no' => ['required', 'string'],
                'OTP' => ['required', 'string', 'min:4']
            ]
        );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(User::where('contact_no', $request->contact_no)->get())
        {
            // otp is 0000 update
            if($request->OTP == '0000' && env('APP_OTP') != 'production') {
                Reset::where('email' , $request->contact_no)->where('user_type' , 'User')->update(array('token' => '0000'));
                if(isset($request->device_info)){
                    $user = User::where('contact_no', $request->contact_no)->first()->toArray();
                    $device_log = $request->device_info;
                    $device_log['user_id'] = $user['id'];
                    $device_log['user_type'] = 'user';
                    $this->device_data($device_log);
                }
            }
            if($request->OTP == '8492'
                && env('APP_OTP') == 'production'
                && env('PARTNER_CONTACT') == $request->contact_no
            ) { // Set for application to deploy the app
                Reset::where('email' , $request->contact_no)->update(array('token' => '8492'));
            }

            if(Reset::where([['email', $request->contact_no ],[ 'token' , $request->OTP ],[ 'user_type' , 'User' ]] )->count() > 0)
            {
                User::where('contact_no', $request->contact_no)->update(['is_verified' => 1]);
                Reset::where('email', $request->contact_no)->where('user_type', 'User')->delete();

                $user = User::where('contact_no', $request->contact_no)->first()->toArray();
                unset($user['password']);

                if(isset($request->device_info)){
                    $device_log = $request->device_info;
                    $device_log['user_id'] = $user['id'];
                    $device_log['user_type'] = 'user';
                    $this->device_data($device_log);
                }
                $user = User::where('contact_no', $request->contact_no)->first();
                $data['User'] = $user;
                $data["User"]['is_dealer'] = 0;

                return response()->json([
                    'status'=>'success',
                    'message'=> 'OTP Verified',
                    'message_ar'=> 'التحقق من كلمة المرور لمرة واحدة',
                    'data' => $data
                ], 200);
            }

            return response()->json([
                'status'=>'failed',
                'message'=> 'Invalid OTP',
                'message_ar'=> 'كلمة مرور صالحة لمرة واحدة',
            ], 400);
        }

        return response()->json([
            'status'=>'failed',
            'message'=> 'Invalid User',
            'message_ar'=> 'هوية مستخدم غير صالحه',
        ], 400);
    }

    public function send_otp($contact_no = '', $readotpcode = null, $routecall = null)
    {
        $otp = mt_rand(1000, 9999);
        //$otp = '0000';

        if($contact_no == '')
            $contact_no = User::where('id', Auth::guard('technician')->id())->pluck('contact_no')->first();

        if($contact_no == null || $contact_no == '')
            return response()->json(['status'=>'failed', 'message'=> 'Contact no shoud not be empty'], 400);

        $userData=Reset::where('email', $contact_no)->where('user_type', 'User')->first();

        if(empty($userData))
            Reset::insert(array('email' => $contact_no, 'user_type' => 'User', 'token' => $otp, 'created_at' => date('Y-m-d H:i:s')));
        else
            Reset::where('email' , $contact_no)->where('user_type' , 'User')->update(array('token' => $otp, 'user_type' => 'User', 'created_at' => date('Y-m-d H:i:s')));

        if(isset($routecall) && $routecall == 'sameclass'){
            (new SendPushNotification)->send_sms($contact_no, $otp, $readotpcode);
        }else{
            (new SendPushNotification)->send_sms($contact_no, $otp, $readotpcode);
        }
        return response()->json([
            'status' => 'success',
            'message' => 'SMS sent Successfully',
            'message_ar' => 'تم إرسال الرسائل القصيرة بنجاح',
        ]);
    }

    public function change_password(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'new_password'    => ['required', 'string', 'min:6'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $update['password'] = Hash::make($request['new_password']);
        try{
            User::where('id', Auth::guard('technician')->id())->update($update);
            Log::info("UserController::changePassword ".Auth::user()->first_name."".Auth::user()->last_name." Password Updated");
            return response()->json(['status' => 'success', 'message' => 'Password Updation Successfully']);
        }
        catch(\Exception $e){
            return response()->json(['status' => 'failed', 'message' => 'Password Updation Failed'], 400);
        }
    }

    public function forgotpswd(Request $request)
    {
        if($request->isMethod('post'))
        {
            $validator = Validator::make($request->all(),
                [
                    'contact_no'    => ['required', 'string', 'max:15'],
                    //'read_otpcode'    => ['required', 'string'],
                ]
            );

            if ($validator->fails()) {
                $errors = [];
                foreach(json_decode($validator->messages()) as $key => $value)
                    $errors[] = $value[0];
                return response()->json([ 'status' => "failed", "response" => $errors ], 400);
            }

            $usercnt = User::where('contact_no' , $request['contact_no'] )->count();

            if($usercnt > 0) {
                $read_otpcode = '';
                if(isset($request['read_otpcode']) && !empty($request['read_otpcode'])){
                    $read_otpcode = $request['read_otpcode'];
                }
                $this->send_otp($request['contact_no'], $read_otpcode, 'sameclass');
                return response()->json([
                    'status'=>'success',
                    'message'=> 'OTP sent to requested mail',
                    'message_ar'=> 'تم إرسال كلمة المرور لمرة واحدة إلى البريد المطلوب',
                ], 200);

            }else{
                return response()->json(['status'=>'failed', 'message'=> 'Invalid User ID'], 400);
            }
        }
    }

    public function reset_password(Request $request)
    {
        if($request->isMethod('post'))
        {
            $validator = Validator::make($request->all(),
                [
                    'contact_no'    => ['required', 'string', 'max:15'],
                    'new_password'    => ['required', 'string', 'max:60'],
                ]
            );

            if ($validator->fails()) {
                $errors = [];
                foreach(json_decode($validator->messages()) as $key => $value)
                    $errors[] = $value[0];
                return response()->json([ 'status' => "failed", "response" => $errors ], 400);
            }

            $usercnt = User::where('contact_no' , $request->contact_no )->count();

            if($usercnt > 0) {

                $password = Hash::make($request->new_password);
                User::where('contact_no', $request->contact_no)->update(['password' => $password ]);

                return response()->json(['status'=>'success', 'message'=> 'Password Reset Succuessfull'], 200);

            }else{
                return response()->json(['status'=>'failed', 'message'=> 'Invalid User ID'], 400);
            }
        }
    }

    public function verify_user(Request $request){

        User::where('contact_no', $request->contact_no)->update(['is_verified' => 1]);

        return response()->json([
            'status' => "success",
            "response" => "User was successfuly verified",
            "response_ar" => "تم التحقق من المستخدم بنجاح",
        ], 200);
    }

    public function update_dp(Request $request){

        if(config('app.env') == 'local'){
            if ($file=$request->file('dp')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/technician/profiles/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['profile_pic'] = '/uploads/technician/profiles/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('technician/profiles/', $request->file('dp'));
            $request['profile_pic'] = Storage::disk('s3')->url($file_name);
        }

        try{
            User::whereId(Auth::guard('technician')->id())->update(['profile_pic' => $request['profile_pic']]);

            return response()->json([
                'status' => "success",
                "response" => "Profile Pic updated successfully",
                "response_ar" => "تم تحديث صورة الملف الشخصي بنجاح",
                "file_path" => $request['profile_pic']
            ], 200);
        }catch (\Exception $e){

            return response()->json([
                'status' => "success",
                "response" => "Profile pic update failed",
                "response_ar" => "فشل تحديث الملف الشخصي الموافقة المسبقة عن علم",
            ], 400);
        }
    }

    public function device_data($data){
        $data['app_version'] = (substr($data['app_version'], 0,1) == 'v') ? ltrim($data['app_version'], 'v') : $data['app_version'];
        if($data['device_type'] == 'A')
            $data['device_type'] = 'android';
        if($data['device_type'] == 'android/ios')
            $data['device_type'] = 'android';

        $input['user_id'] = $data['user_id'];
        $input['device_id'] = $data['device_id'];
        $input['device_type'] = $data['device_type'];
        $input['device_model'] = isset($data['device_model']) ? $data['device_model'] : $data['device_type'];
        $input['version'] = $data['version'];
        $input['fcm'] = $data['fcm'];
        $input['user_type'] = $data['user_type'];
        $input['app_version'] = $data['app_version'];
        $input['ip'] = $_SERVER['REMOTE_ADDR'];
        $input['status'] = 1;

        if(Auth::guard('technician')->id()){
            // update login user device type to session
            Auth::guard('technician')->user()->device_type = $data['device_type'];
        }

        $where = array(
            "device_type" => $data["device_type"],
            "device_id" => $data["device_id"],
            "user_type" => 'user',
        );

        $newLog = false;
        // Already has any login on the same device
        if(Device::where($where)->count() > 0) {
            // yes
            if(Device::where($where)->whereNull('user_id')->count() > 0) {
                // Unregistered device - convert to Techincian and delete log
                Device::where($where)->whereNull('user_id')
                    ->update([
                        'converted_as' => $data['user_id'],
                        'updated_at' => date('Y-m-d H:i:s')
                    ]);

                Device::where($where)->whereNull('user_id')->delete();

                $newLog = true;
            }

            if(Device::where($where)->whereNotNull('user_id')->count() > 0){
                // Technician log
                if(Device::where($where)->where('user_id', $data['user_id'])->count() > 0) {
                    // Same user - Update log
                    $input['updated_at'] = date('Y-m-d H:i:s');
                    Device::where($where)->where('user_id', $data['user_id'])->update($input);
                }
                else {
                    // Not Same user - Delete log for other technicians, Create Techincian log
                    $newLog = true;
                }
            }

            // Delete other user logs on this device
            Device::where($where)->where('user_id', '!=', $data['user_id'])->delete();
            // Delete other device logins of the same user
            $where = array(
                "device_type" => $data["device_type"],
                "user_type" => 'user',
                "user_id" => $data["user_id"],
            );
            Device::where($where)->where('device_id', '!=', $data['device_id'])->delete();
        }
        else {
            // Login on other device for Techincian
            // no log available. Create New log
            $newLog = true;
        }

        // Delete Technician other device logins
        $where['user_id'] = $data["user_id"];
        unset($where['device_id']);
        Device::where($where)->where('device_id', '!=', $data['device_id'])->delete();

        if($newLog) {
            // create Techincian user log
            $input['created_at'] = date('Y-m-d H:i:s');
            Device::insertGetId($input);
        }

    }

    public function changephone_email(Request $request) {
        $validator = Validator::make($request->all(),
            [
                'email'    => ['required', 'string', 'email', 'max:60'],
            ]
        );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $check_email = User::where('email', $request['email'])->first();
            if($check_email) {
                //send OTP to entered Email
                
                $otp = mt_rand(1000, 9999);
                //$otp = '0000';
                //$this->send_mail($email, $otp);

                //(new EmailController)->sendMobileNumberChangeMail($request['email'], $check_email->first_name, $otp);
                try{
                 // Send notification to user
                 event(new ChangeMobileNumber($request['email'], $check_email->first_name, $otp, 'User', '1'));

                } catch(\Exception $e){
                     return response()->json([
                        'status' => "failed",
                        "response" => "Failed to send mail. Please try again later",
                        "response_ar" => "فشل إرسال البريد. يرجى إعادة المحاولة لاحقا",
                    ], 400);
                }
                Reset::where('email', $request['email'])->where('user_type', 'User')->delete();

                $update_otp = Reset::insert(['email' => $request['email'],'user_type' => 'User', 'token' => $otp, 'created_at' => date('Y-m-d H:i:s')]);
                
                if($update_otp){
                    return response()->json([
                        'status' => "success",
                        "response" => "OTP sent to your registered email. Please check your Email Inbox",
                        "response_ar" => "تم إرسال كلمة المرور لمرة واحدة إلى بريدك الإلكتروني المسجل. يرجى التحقق من صندوق البريد الإلكتروني الخاص بك"
                    ]);
                }else{
                    return response()->json([
                        'status' => "failed",
                        "response" => "OTP sent failed",
                        "response_ar" => "فشل إرسال كلمة المرور لمرة واحدة",
                    ], 400);
                }
            }else{
                return response()->json([
                    'status' => "failed",
                    "response" => "Entered Email not found.",
                    "response_ar" => "البريد الإلكتروني المدخل غير موجود.",
                ], 400);
            }
        }catch (\Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Email id failed" ], 400);
        }
    }

    public function changephone_verifyotp(Request $request) {
        $validator = Validator::make($request->all(),
            [
                'email'    => ['required', 'string', 'email', 'max:60'],
                'OTP'    => ['required', 'string', 'min:4'],
            ]
        );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
                         // otp is 0000 update
            if($request->OTP == '0000' && env('APP_ENV') != 'production') {
                Reset::where('email' , $request->email)->where('user_type' , 'User')->update(array('token' => '0000'));
            }

            if(Reset::where([['email', $request->email],[ 'token' , $request->OTP ],[ 'user_type' , 'User' ]] )->count() > 0) {
                 Reset::where('email', $request['email'])->where('user_type', 'User')->delete();
                 
                $user = User::where('email', $request->email)->first();
                return response()->json([
                    'status' => "success",
                    "response" => "OTP Verified Successfully",
                    "response_ar" => "تم التحقق من كلمة المرور لمرة واحدة بنجاح",
                    'data' => $user
                ]);
            }else{
                return response()->json([
                    'status' => "failed",
                    "response" => "Invalid OTP",
                    "response_ar" => "كلمة مرور صالحة لمرة واحدة",
                ], 400);
            }
        }catch (\Exception $e){
            return response()->json([ 'status' => "failed", "response" => "OTP failed" ], 400);
        }
    }

    public function change_phone(Request $request) {
        $validator = Validator::make($request->all(),
            [
                'email' => 'required|string|email|max:60',
                'new_phone_country_code' => 'required|max:5',
                'new_contact_no' => 'required|max:15',
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{

            $new_phone = $request['new_phone_country_code'].$request['new_contact_no'];

            // Check old number and newly entered number is same or not
            $check_contact_no_new = User::where('contact_no', $new_phone)->where('email', '=', $request->email)->count();
            if($check_contact_no_new){
                $errors = [];
                $errors[] = "New Contact number should not be same as old contact number";
                return response()->json(['status' => 'failed', 'response' => $errors ], 400);
            }

            //Check newly entered contact number is already existed or not
            $check_contact_no_new = User::where('contact_no', $new_phone)->where('email', '!=', $request->email)->count();
            if($check_contact_no_new){
                $errors = [];
                $errors[] = "New Contact number already used";
                return response()->json(['status' => 'failed', 'response' => $errors ], 400);
            }

            //Send OTP to verify and login with new contact number
            $read_otpcode = '';
            if(isset($request['read_otpcode']) && !empty($request['read_otpcode'])){
                $read_otpcode = $request['read_otpcode'];
            }
            $this->send_otp($new_phone, $read_otpcode, 'sameclass');
            return response()->json([
                'status' => "success",
                "response" => "OTP sent to your new phone number.",
                "response_ar" => "تم إرسال كلمة المرور لمرة واحدة إلى رقم هاتفك الجديد.",
            ]);

        }catch (\Exception $e){
            return response()->json([
                'status' => "failed",
                "response" => "Change new phone number failed",
                "response_ar" => "فشل تغيير رقم الهاتف الجديد",
            ], 400);
        }
    }

    public function update_newphone(Request $request) {
        $validator = Validator::make($request->all(),
            [
                'email' => 'required|string|email|max:60',
                'otp' => 'required|max:4',
                'new_phone_country_code' => 'required|max:5',
                'new_contact_no' => 'required|max:15',
            ]
        );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $new_phone = $request['new_phone_country_code'].$request['new_contact_no'];

             // Check old number and newly entered number is same or not
            $check_contact_no_new = User::where('contact_no', $new_phone)->where('email', '=', $request->email)->count();
            if($check_contact_no_new){
                $errors = [];
                $errors[] = "New Contact number should not be same as old contact number";
                return response()->json(['status' => 'failed', 'response' => $errors ], 400);
            }

            //Check newly entered contact number is already existed or not
            $check_contact_no_new = User::where('contact_no', $new_phone)->where('email', '!=', $request->email)->count();
            if($check_contact_no_new > 0){
                $errors = [];
                $errors[] = "New Contact number already used";
                $errors_ar[] = "رقم الاتصال الجديد مستخدم بالفعل";
                return response()->json(['status' => 'failed', 'response' => $errors, 'response_ar' => $errors_ar ], 400);
            }

            // otp is 0000 update
            if($request->otp == '0000') {
                Reset::where('email' , $new_phone)->where('user_type' , 'User')->update(array('token' => '0000'));
            }

            if(Reset::where([['email', $new_phone],[ 'token' , $request->otp ],[ 'user_type' ,'User' ]] )->count() > 0) {
                $user = User::where('email', $request->email)->update(['contact_no' => $new_phone, 'country_code' => $request->new_phone_country_code, 'updated_at' => date('Y-m-d H:i:s')] );
                if($user){
                    return response()->json([
                        'status' => "success",
                        "response" => "New phone number updated successfully.",
                        "response_ar" => "تم تحديث رقم الهاتف الجديد بنجاح.",
                    ]);
                }else{
                    return response()->json([
                        'status' => "failed",
                        "response" => "Update new phone number failed",
                        "response_ar" => "فشل تحديث رقم الهاتف الجديد",
                    ], 400);
                }
            } else {
                return response()->json([
                    'status' => "failed",
                    "response" => "Invalid OTP",
                    "response_ar" => "OTP غير صحيح",
                ], 400);
            }
        }catch (\Exception $e){
            return response()->json([
                'status' => "failed",
                "response" => "Update new phone number failed",
                "response_ar" => "فشل تحديث رقم الهاتف الجديد",
            ], 400);
        }
    }

    /**
     * API: partner app, Prefix: dealer
     * Access: delar admin, technician
     * Created for the developer testing
     * Find the eligible tedhnicians to approve or reject transactiond
     *
     * @param  $transaction_no
     * @return $response
     */
    public function eligible_technicians($transaction_no){

        return DB::select("select d.id, a.transaction_no, d.contact_no, d.first_name, d.last_name,
          d.is_verified, d.role_id, d.status, b.delar_id, d.org_id, a.payment_status, a.location_id,
          d.location_id as technicain_location, a.quantity, a.revised_quantity, a.redeem_quantity
        from transactions as a
          join item_master as b on a.item_id = b.id
          JOIN item_offers as c on a.offer_id = c.id
          left join (select a.id, a.contact_no, a.first_name, a.last_name, a.org_id, a.is_verified, a.role_id, a.status , b.location_id
              from users as a left JOIN technician_locations as b on a.id = b.technician_id
              where ((location_id is null and role_id = 3) or (location_id is not null and role_id = 8))) as d
          on b.delar_id = d.org_id or a.location_id = d.location_id
        where a.transaction_no = '".$transaction_no."'");

    }

   /**
   * When drivers wanted to delete their account from app
   * @param $request
   * @return \Illuminate\Http\Response
   */
    public function send_otp_delete_account(Request $request){
        $user_id = Auth::id();
        $user = User::find($user_id);
        if(!$user)
            return response()->json([ 'status' => "failed", "response" => "User not found",], 400);
        try{
        // Send OTP
         $read_otpcode = '';
        if(isset($request['read_otpcode']) && !empty($request['read_otpcode'])){
            $read_otpcode = $request['read_otpcode'];
        }

        $this->send_otp($user->contact_no, $read_otpcode, 'sameclass');
         return response()->json([
                'status' => 'success',
                'message' => 'OTP sent to your registered mobile number',
                'message_ar' => 'يتم إرسال كلمة المرور لمرة واحدة إلى رقم هاتفك المحمول المسجل'
            ], 200);

        } catch (\Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Failed to send OTP to your registered mobile number ","response_ar"=>"فشل إرسال كلمة المرور لمرة واحدة إلى رقم هاتفك المحمول المسجل", "error"=>$e->getMessage() ], 400);
        }  
    }
    
    /** 
     * Verify OTP to delete account
     * @param $request
     * @return \Illuminate\Http\Response
     */
    function verifyDeleteAccountOTP(Request $request){
        // User OTP Verification
        $validator = Validator::make($request->all(),
            [
                'contact_no' => ['required', 'string'],
                'OTP' => ['required', 'string', 'min:4']
            ]
        );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        $data=User::where('contact_no', $request->contact_no)->get();
        if($data)
        {
            // otp is 0000 update
            if($request->OTP == '0000' && env('APP_OTP') != 'production') {
                Reset::where('email' , $request->contact_no)->where('user_type' , 'User')->update(array('token' => '0000'));
            }
             
            if(Reset::where([['email', $request->contact_no ],[ 'token' , $request->OTP ],[ 'user_type' , 'User' ]] )->count() > 0)
            {
                
                return response()->json([
                    'status'=>'success',
                    'message'=> 'OTP Verified',
                    'message_ar'=> 'التحقق من كلمة المرور لمرة واحدة',
                    'data' => $data
                ], 200);
            }

            return response()->json([
                'status'=>'failed',
                'message'=> 'Invalid OTP',
                'message_ar'=> 'كلمة مرور صالحة لمرة واحدة',
            ], 400);
        }

        return response()->json([
            'status'=>'failed',
            'message'=> 'Invalid User',
            'message_ar'=> 'هوية مستخدم غير صالحه',
        ], 400);
    }

   /*
   * When technician wanted to delete their account from app
   *
   * @return \Illuminate\Http\Response
   */

    public function delete_account(Request $request){

         $validator = Validator::make($request->all(),
            [
                'contact_no' => ['required', 'string'],
                'OTP' => ['required', 'string', 'min:4']
            ]
        );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $user_id = Auth::id();
        $user = User::where('contact_no', $request->contact_no )->where('id', $user_id)->first();

        if(!$user)
             return response()->json([ 'status' => "failed", "response" => "User not found",], 400);
         
        else if($user->role_id==2 || $user->role_id==3){
            return response()->json([
                'status' => "failed",
                "message" => "Admin details can't delete",
                "message_ar"=>"لا يمكن حذف تفاصيل المشرف"
            ], 400);
        } 

        $count=Reset::where([['email', $request->contact_no ],[ 'token' , $request->OTP ],[ 'user_type' , 'User' ]] )->count();
        if(!$count)
        {
            return response()->json([
                'status'=>'failed',
                'message'=> 'Invalid OTP',
                'message_ar'=> 'كلمة المرور لمرة واحدة غير صالحة',
                'data' => $user
            ], 400);
        }
        try{
            $device_log['user_id'] = $user_id;
            $device_log['user_type'] = 'user';
            $this->disable_device_data($device_log, 'delete');

            User::where('id', $user_id)->delete();

            $token = JWTAuth::fromUser($user);
            JWTAuth::invalidate($token);
            Auth::logout();
            

            return response()->json([
                'status' => 'success',
                'message' => 'You have successfully deleted your account',
                'message_ar' => 'لقد نجحت في حذف حسابك',
            ], 200);
         

        } catch (\Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Failed to delete user account","error"=>$e->getMessage() ], 400);
        }
    }


   /**
   * When technician wanted to logged out from app
   *
   * @param $device details
   * @return \Illuminate\Http\Response
   */
    public function logout(Request $request){
        $user_id = Auth::id();
        $user = User::find($user_id);
        if(!$user)
            return response()->json([ 'status' => "failed", "response" => "User not found",], 400);

        if(isset(Auth::user()->device_log_id)){
            $device_log_id = Auth::user()->device_log_id;
            Device::where('id', $device_log_id)->delete();
        }

        $token = JWTAuth::fromUser($user);
        JWTAuth::invalidate($token);
        Auth::logout();

        return response()->json([
            'status' => 'success',
            'message' => 'You have successfully logout your account',
            'message_ar' => 'لقد نجحت في حذف حسابك',
        ], 200);
    }


   /**
    * When technician wanted to logged out or delete account  from app then disable device details to stop sending push notifications
    *
    * @param $device details 
   */
    public function disable_device_data($data, $actionType){
        $input['status']=0;
        $input['updated_at'] = date('Y-m-d H:i:s');

        $where = array(
            "user_id" => $data["user_id"],
            "user_type" => $data["user_type"],
        );

        if($actionType=='loggedout'){ 
            $where['device_id']=$data["device_id"];
            $deviceInfo=Device::where($where)->orderBy('id','desc')->first();  
             
            if(!empty($deviceInfo)){
                $id=$deviceInfo->id;
                $input['updated_at'] = date('Y-m-d H:i:s');
                Device::where('id', $id)->update($input);
            }
        } else {
            Device::where($data)->update($input);
        }
    }

    /**
     * Get all the information about technicians including counts
     *
     * @param  int  $id
     * @return \Illuminate\Http\response
    */
    public function show_info($id)
    {
        try{
            $list = User::with('tech_locations','loggedin_devices')->where('id', $id)->first();
            if(!$list){
                return response()->json(['status' => 'failed', 'message' => 'Technician details not found'], 400);
            }

            $data['user_info']=$list;
             
            $countersArray=array();
            if($list->role_id==8){
                $scannedTotal=RedeemLog::where('redeem_by', $id)->count();

                $countersArray['scanned_total']=$scannedTotal;

                $rejectedTotal=Transaction::where('approved_by', $id)->where('payment_status', 'Rejected')->count();
                $countersArray['rejected_total']=$rejectedTotal;
                      
                $acceptedTotal=Transaction::where('approved_by', $id)->where('payment_status', 'Successful')->count();
                $countersArray['accepted_total']=$acceptedTotal;

            } else if($list->role_id==7){
                 $scannedTotal=MaintenanceLog::where('created_by', $id)->count();
                 $countersArray['scanned_total']=$scannedTotal;
            }

            $countersArray['total_amount']=0;

            $data['counters']=$countersArray;

            $data['notifications_list']=(new NotificationController)->getUserNotificationsList($id,'N');

            return response()->json(['status' => 'success', 'data' => $data], 200);
        } catch(\Exception $e){
             return response()->json(['status' => 'failed', 'message' => 'Failed to get technician information','error'=>$e->getMessage()], 400);
        }
    }

    public function add_unregistered_devices(Request $request){
        $rules = array(
            'device_id'    => ['required'],
            // 'fcm'    => ['required'],
            'device_type'    => ['required'],
            'version'    => ['required'],
            'app_version'    => ['required'],
        );

        $validator = Validator::make($request->all(),$rules);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $data = $request->all();
        $data['user_id'] = null;
        $data['user_type'] = 'user';
        try{
            $this->device_data($data);

            return response()->json([
                'status' => 'success',
                'message' => 'Device data registered',
                'message_ar' => 'تم تسجيل بيانات الجهاز',
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'failed',
                'message' => 'Device data not registered',
                'message_ar' => 'بيانات الجهاز غير مسجلة',
                "error" => $e->getMessage()], 400);
        }
    }

    /**
    * get technician details along with his originzation addresses list
    * @param int $technicianId
    * @return \Illuminate\Http\response
    */
    function providers_addresses($technicianId){
         try{
            // Get technician details
            $list = User::with('tech_locations')->where('id', $technicianId)->first();

            $data['user_info']=$list;

            //Get Organization's addresses list

            $orgAddress=Location::select('locations.*',
                DB::raw("CONCAT(cities.city,' , ',locations.district,', ',locations.street) as city"),
                'cities.id as cityid', 'cities.latitude as citylatitude', 'cities.longitude as citylongitude')
                ->leftjoin('cities', 'locations.city', '=', 'cities.id')
                ->where('locations.org_id', $list->org_id)
                ->where('locations.status', 1)->get();

            $data['organization_addresses']=$orgAddress;

            return response()->json([
                'status' => 'success',
                'data' => $data
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'failed',
                'message' => 'Device data not registered',
                'message_ar' => 'بيانات الجهاز غير مسجلة',
                "error" => $e->getMessage()], 400);
        }
         
    }

    /**
     * update dealer or service provider's technicians address details
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\response
     */
    public function update_technician_location(Request $request, $id)
    {
       
        $validator = Validator::make($request->all(),[
            'locations.*' => 'required',
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }    
        try{
            $request['locations'] = json_decode($request['locations'], true);
            $technician_location = [];
            if(isset($request['locations']) && !empty($request['locations'])) {
                TechnicianLocation::where('technician_id', $id)->delete();
                foreach($request['locations'] as $tech_location) {
                    $technician_location[] = [
                        'technician_id' => $id,
                        'location_id' => $tech_location['location_id'],
                        'created_at' => date('Y-m-d H:i:s')
                    ];
                }
            }
            if(count($technician_location)> 0){
                TechnicianLocation::insert($technician_location);
            }

            return response()->json(['status' => 'success', 'response' => "Technician's location updated successfully"], 200);
        }
        catch(\Exception $e){
            return response()->json(['status' => 'failed', 'response' => 'Failed to update technician location', "error" => $e->getMessage()], 400);
        }
    }

    /**
     * Get Active technicians along with searching
     * @param $request
     * @return \Illuminate\Http\response
     */
    function getActiveTechnicians(Request $request){

        $validator = Validator::make($request->all(),[
            'technician_type' => 'required',
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }  

        $pageno=1;$pagelength=20;

        $request->role_id= $this->NonMsTechnician;
        if($request->technician_type=='ms_technician'){
           $request->role_id=$this->msTechnician;
        }
        
         // If deleted users from all guest users list
        if(isset($request->deleted_users) && $request->deleted_users!=''){
            $arr=explode(',',$request->deleted_users);
            $list=$list->whereNotIn('id',$arr);
        }


        $list = User::where('role_id', $request->role_id)->with('company')->where('status',1);

        if($request->org_id){
           $list =$list->where('org_id', $request->org_id);
        }

       if(isset($request->search_keyword) && !empty($request->search_keyword)){
              $list = $list->where('first_name','LIKE',"%{$request->search_keyword}%");
              $list = $list->orWhere('last_name','LIKE',"%{$request->search_keyword}%");
              $list = $list->orWhere('contact_no','LIKE',"%{$request->search_keyword}%");
              $list = $list->orWhere('email','LIKE',"%{$request->search_keyword}%");
        }

       
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
             $list = $list->skip( ($pageno-1)*$pagelength )->take($pagelength);
        }
        
        $totalrecords = $list->count();
        $list = $list->orderBy('id', 'desc')->get();

        $data['data'] = $list;
        $data['current_page'] =$pageno ? $pageno : '1';
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength ? $pagelength : '20';
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }
}
