<?php

namespace App\Http\Controllers\Users;

use App\Http\Controllers\Controller;
use App\Models\Accounts\ConsumerGroup;
use App\Models\Accounts\Driver;
use App\Models\Accounts\GroupConsumer;
use App\Models\Regulatory\Fleet;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Models\Accounts\FleetDriver;

class ConsumerGroupController extends Controller
{
    public function index(Request $request)
    {

        $pageno = 1; $pagelength = 10;
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = ConsumerGroup::with('company')
                ->withCount( ['consumers' => function($q){ $q->where('status', 1); }]);

        if(Auth::user()->login_type_id == 19){ // Fleet Company
            $list = $list->where('company', Auth::user()->org_id );
        }
        if($request->org_id){
             $list = $list->where('company', $request->org_id);
        }

        $totalrecords = $list->count();

        $list = $list->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;

        return response()->json([ 'status' => "success", "data" => $data ], 200);
    }

    /*
     * Access: Admin, Parner, Prefix: api, Method Type: Get, POST
     * Send active consumer groups list
     * $org_id - partner id - it is optional
     * Can get list by partner
     * Fetch records by pagination in post request method
     */
    public function active_consumer_groups(Request $request, $org_id = null)
    {
        $list = ConsumerGroup::with('company')
                ->withCount( ['consumers' => function($q){ $q->where('status', 1); }])
                ->Has( 'consumers', '>' , 0)
                ->where('status', 1);

        // If deleted users from all users list
        if(isset($request->deleted_users) && $request->deleted_users!=''){
            $arr=explode(',',$request->deleted_users);
            $list=$list->whereNotIn('id',$arr);
        }

        if(isset($request->fleet_id) && $request->fleet_id>0){
            $org_id=$request->fleet_id;
        }

        if(Auth::user()->login_type_id == 19){ // Fleet Company
            $list = $list->where('company', Auth::user()->org_id );
        } else if($org_id) {
            if(Fleet::where('company_type', 'F')->where('id', $org_id)->first())
                $list = $list->where('company', $org_id );
        }  

        if(isset($request->search_keyword) && !empty($request->search_keyword)){
              $list = $list->where('title','LIKE',"%{$request->search_keyword}%");;
        }

        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $totalrecords = $list->count();

            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
            $list = $list->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

            $data['data'] = $list;
            $data['current_page'] =$pageno ? $pageno : '1';
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength ? $pagelength : '200';
            return response()->json([ 'status' => "success", "data" => $data ], 200);
        } else {
            $list = $list->get();
            return response()->json([ 'status' => "success", "data" => $list ], 200);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'title' => ['required' ],
                'description' => ['required' ],
                'company' => ['required' ],
                'status' => ['required' ],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try{
            $inputdata = array(
                'title' => $request['title'],
                'description' => $request['description'],
                'company' => $request['company'],
                'status' => $request['status'],
                'created_at' => date('Y-m-d H:i:s')
            );

            ConsumerGroup::insert($inputdata);
            return response()->json([ 'status' => "success", "response" => "Group Added Successfully" ], 200);
        }
        catch (\Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Group Added Failed", "error" => $e ], 400);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $list = ConsumerGroup::with('company')->withCount( ['consumers' => function($q){
            $q->where('status', 1);
        }])->where('id', $id)->first();

        return response()->json([ 'status' => "success", "data" => $list ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(),
            [
                'title' => ['required' ],
                'description' => ['required' ],
                'company' => ['required' ],
                'status' => ['required' ]
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try{
            $inputdata = array(
                'title' => $request['title'],
                'description' => $request['description'],
                'company' => $request['company'],
                'status' => $request['status'],
                'updated_at' => date('Y-m-d H:i:s')
            );

            ConsumerGroup::where('id', $id)->update($inputdata);
            return response()->json([ 'status' => "success", "response" => "Group Updated Successfully" ], 200);
        }
        catch (\Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Group Update Failed", "error" => $e ], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function fetch_group()
    {
        $list = GroupConsumer::with('group')->get();
        return response()->json([ 'status' => "success", "data" => $list ], 200);
    }

    public function assign_users(Request $request, $id = null)
    {
        $validator = Validator::make($request->all(), [
            "users"    => "required|array|min:2",
            "users.*"  => "required|distinct|min:1",
            'users.*.id' => 'required|distinct|integer',
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try{
            GroupConsumer::where('group_id' , $id)->delete();
            $groupuser = [];
            foreach($request->users as $user){
                $groupuser[] = array(
                    'group_id' => $id,
                    'consumer_id' => $user['id'],
                    'status' => 1,
                    'created_at' => date('Y-m-d H:i:s')
                );
            }
            GroupConsumer::insert($groupuser);
            return response()->json([ 'status' => "success", "response" => "Group User Added Successfully" ], 200);
        }
        catch (\Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Group User Added Failed", "error" => $e ], 400);
        }
    }

    public function groupuserinfo($group_id = null)
    {
        $data = ConsumerGroup::where('id', $group_id)->first();   

        $list = Driver::join('group_consumers' , function($join) use ($group_id){
            $join->on('group_consumers.consumer_id', '=', 'drivers.id')
                ->where('group_consumers.group_id', '=', $group_id);
        })->join('fleet_drivers', 'drivers.id', 'fleet_drivers.driver_id')
            ->whereNotNull('group_consumers.consumer_id')
            ->where('drivers.status', 1)
            ->where('drivers.is_verified', 1)
            ->where('fleet_drivers.status', 1)
            ->where('fleet_drivers.fleet_id', $data->company)
            ->select('drivers.*', 'fleet_drivers.employee_id')->get();
        
        $data['users'] = $list;
        
        return response()->json([ 'status' => "success", "data" => $data ], 200);
    }

    public function unassignedgroupusers(Request $request, $group_id = null) {

        $data = ConsumerGroup::where('id', $group_id)->first();

        $list = Driver::leftJoin('group_consumers' , function($join) use ($group_id){
                $join->on('group_consumers.consumer_id', '=', 'drivers.id')
                    ->where('group_consumers.group_id', '=', $group_id);
            })->join('fleet_drivers', 'drivers.id', 'fleet_drivers.driver_id')
            ->whereNull('group_consumers.consumer_id')
            ->where('drivers.status', 1)
            ->where('drivers.is_verified', 1)
            ->where('fleet_drivers.status', 1)
            ->where('fleet_drivers.fleet_id', $data->company)
            ->select('drivers.*', 'fleet_drivers.employee_id');
            
            if(isset($request->empid) && !empty($request->empid)){
                $empid = $request->empid;
                $list->where(function($subquery) use ($empid){
                    $subquery->where('drivers.first_name',  'like', '%'.$empid.'%')
                    ->orwhere('fleet_drivers.employee_id',  'like', '%'.$empid.'%');
                });
            }
        $list = $list->get();

        return response()->json([ 'status' => "success", "data" => $list ], 200);
    }


    /** 
    * Get Groups list of the each driver based on the driver id
    *
    * @param $driverId
    * @return $list
    */
    function get_customer_groups_list(Request $request, $driverId){

        try{
            $list = GroupConsumer::where('consumer_id', $driverId)
                    ->with('group')
                    ->withCount( ['group' => function($q){ $q->where('status', 1); }])
                    ->Has( 'group', '>' , 0)
                    ->where('status','1');


            $totalrecords = $list->count();
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
                $list = $list->skip( ($pageno-1)*$pagelength )->take($pagelength);
            }  
                
            $list=$list->get();
              
            $data['data'] = $list;
            $data['current_page'] =$pageno ? $pageno : '1';
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength ? $pagelength : '200';
            return response()->json(['status' => 'success', 'data' => $data], 200);

        } catch(\Exception $e){
            //return $e;
            return response()->json(['status' => 'failed', 'response' => 'Failed to assign group to customer', 'e'=>$e->getMessage()], 400);
        }
    }


    /**  
    * Get Groups list of the each driver based on the driver id
    * @param $driverId
    * @return $list
    */
    function getDriverGroupsList($driverId, $pageno, $pagelength){
        
        $list = GroupConsumer::where('consumer_id', $driverId)
                ->with('group')
                ->withCount( ['group' => function($q){ $q->where('status', 1); }])
                ->Has( 'group', '>' , 0)
                ->where('status','1')
                ->skip(($pageno-1)*$pagelength)
                ->take($pagelength)
                ->get();
        return $list;
    }

    

    /**
     * Assign or reassign groups to fleet details
     * @param $request
     * @return \Illuminate\Http\Response
     */

    function assignGroupDetails(Request $request){
        $validator = Validator::make($request->all(),[
            'group_id' => 'required',
            'consumer_id' => 'required',
            'status' => 'required',
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try{
            $groupData=GroupConsumer::where('group_id', $request->group_id)->where('consumer_id', $request->consumer_id)->first();

            $data['group_id']=$request->group_id;
            $data['consumer_id']=$request->consumer_id;
            $data['status']=$request->status;

            if(!empty($groupData)){
                $data['updated_at']=date('Y-m-d H:i:s');
                GroupConsumer::where('group_id', $request->group_id)->where('consumer_id', $request->consumer_id)->update($data);
            } else {
                $data['created_at']=date('Y-m-d H:i:s');
                GroupConsumer::insert($data);
            }
            return response()->json(['status' => 'success', 'response' => 'Successfully assigned group to customer'], 200);
        } catch(\Exception $e){
            //return $e;
            return response()->json(['status' => 'failed', 'response' => 'Failed to assign group to customer', 'e'=>$e->getMessage()], 400);
        }
    }

    /**
     * Get active groups lists
     * @param $fleetId
     * @return \Illuminate\Http\Response
     */ 
    function activeGroupsList($fleetId){
        $list = ConsumerGroup::where('company', $fleetId)->where('status',1)->get();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

}
