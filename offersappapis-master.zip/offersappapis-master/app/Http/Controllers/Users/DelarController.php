<?php

namespace App\Http\Controllers\Users;

use App\Http\Controllers\Controller;
use App\Models\Accounts\Reset;
use App\Models\Generals\Device;
use App\Models\Generals\Role;
use App\Models\Regulatory\Delar;
use App\Models\Regulatory\Location;
use App\Models\Accounts\User;
use App\Models\Regulatory\OrgDeal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Http\Controllers\Generals\SendPushNotification;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers\Generals\NotificationController;
use App\Http\Controllers\TransactionController;
use App\Models\Accounts\Transaction;
use App\Http\Controllers\Generals\PayoutController;
use App\Models\Generals\Payout;


class DelarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $pageno = 1; $pagelength = 10;
        $list = Delar::where('company_type', 'D')->with('location', 'deals', 'user');

         $login_type_id = Role::where('id',Auth::user()->role_id)->pluck('login_type_id')->first();
          if($login_type_id=='18'){
            $list=$list->where('id', Auth::user()->org_id);
          }
        $totalrecords = $list->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }
        $list = $list->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;

        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    public function address($id)
    {
        $list = Delar::where('id', $id)->with(['location' => function ($query) use($id) {
            $query->where('org_id', $id);
        }])->first();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    public function delars_list(Request $request, $deal_id)
    {
        // only actives
        if($deal_id == 9){ // M & S service providers list
            //$list = Delar::where('category', $deal_id)->with('location', 'deal')->where('status', 1)->get();
            $list = Delar::select('organizations.*')->where('company_type', 'M')->with('location', 'deal')->where('status', 1)->orderBy('org_name','ASC');
        } else{


            $list = Delar::select('organizations.*')
                ->join('org_deals', 'organizations.id', '=', 'org_deals.org_id')
                ->where('org_deals.deal_id', $deal_id)
                ->where('organizations.status', 1);

            if(Auth::user()->login_type_id==18){
                $list = $list->where('organizations.id', Auth::user()->org_id);
            }

            $list = $list->orderBy('organizations.org_name','ASC')
                ->with('location', 'deal');
        }

        if(isset($request->search_keyword) && !empty($request->search_keyword)){
            $list = $list->where('organizations.org_name','LIKE',"%{$request->search_keyword}%");
            $list = $list->orWhere('organizations.phone','LIKE',"%{$request->search_keyword}%");
            $list = $list->orWhere('organizations.email','LIKE',"%{$request->search_keyword}%");
        }

        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {

            $totalrecords = $list->count();

            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
            $list = $list->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

            $data['data'] = $list;
            $data['current_page'] =$pageno ? $pageno : '1';
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength ? $pagelength : '200';
            return response()->json([ 'status' => "success", "data" => $data ], 200);
        } else {
            $list = $list->get();
            return response()->json([ 'status' => "success", "data" => $list ], 200);
        }
         
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       
        $request['location'] = json_decode($request['location'], true);
        $request['phone'] = $request['country_code'].$request['phone'];
        $request['admin_contact_no'] =$request['admin_country_code'].$request['admin_contact_no'];
         

        $validator = Validator::make($request->all(),
            [
                'org_name' => ['required', 'string', 'max:100' ],
                'org_name_ar' => ['required', 'string', 'max:100' ],
                'vat_no' => ['required', 'max:20' ],
                //'code' => ['required', 'string', 'max:20', 'unique:organizations'],
                'country_code' => ['required', 'max:5'],
                'phone' => ['required', 'max:15', 'unique:organizations,phone,NULL,id'],
                'email' => ['required', 'email', 'max:60', 'unique:organizations,email,NULL,id'],
                'admin_contact_no' => ['required', 'max:15', 'unique:users,contact_no,NULL,id,deleted_at,NULL'],
                'admin_email_id' => ['required', 'max:60', 'email', 'unique:users,email,NULL,id,deleted_at,NULL'], 
                'location.street' => ['string', 'max:60' ],
                'location.city' => ['required', 'max:60' ],
                'location.district' => ['string', 'max:60' ],
                'location.zipcode' => ['string', 'max:20' ],
                'location.latitude' => ['required', 'numeric', 'between:0,180'],
                'location.longitude' => ['required', 'numeric', 'between:0,180'],
                'category.*' => ['required'],
                'is_email_verified'=>['required'],
                'thumbnail' => ['required', 'mimes:jpeg,jpg,png', 'max:500' ],
            ],

            [
                'admin_contact_no.required'=>'Contact number is required for  dealer admin',
                'admin_contact_no.max'=>'Contact number must not exceed 15 characters for  dealer  admin',
                'admin_contact_no.unique'=>'Contact number is already exited with us for  dealer  admin',
                'admin_email_id.required'=>'Email id is required for dealer admin',
                'admin_email_id.max'=>'Email id must not exceed 60 characters for  dealer admin',
                'admin_email_id.min'=>'Email id must be 3 characters for  dealer admin',
                'admin_email_id.unique'=>'Email id is already exited with us for  dealer  admin',
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
     

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/delar/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/delar/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('delar/', $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $insert = array(
                'org_name' => $request['org_name'],
                'org_name_ar' => $request['org_name_ar'],
                'code' => $request['code'],
                'vat_no'=>$request['vat_no'],
                'country_code' => $request['country_code'],
                'phone' => $request['phone'],
                'email' => $request['email'],
                'company_type' => 'D', // Delar Type
                'thumbnail_url' => $request['thumbnail_url'],
                'created_by' => Auth::id(),
                'created_at' => date('Y-m-d H:i:s')
            );

            $delar_id = Delar::insertGetId($insert);

            $location = $request['location'];
            $location['org_id'] = $delar_id;
            $location['primary'] = 1;
            $location['created_at'] = date('Y-m-d H:i:s');
            Location::insert($location);

            $request['category'] = json_decode($request['category'], true);
            if(count($request->category) > 0){
                foreach ($request->category as $key => $dealidrow) {
                    if(OrgDeal::where('org_id', $delar_id)->where('deal_id', $dealidrow)->count() == 0){
                        $insert = array(
                            'org_id' => $delar_id,
                            'deal_id' => $dealidrow,
                            'status' => 1, //$request['status'],
                            'created_at' => date('Y-m-d H:i:s')
                        );
                        OrgDeal::insertGetId($insert);
                    }
                }
            }

            $insert = array(
                "first_name" => $request['org_name'],
                "email" => $request['admin_email_id'],
                "password" => Hash::make('delar@123'),
                "role_id" => 3, // Delar
                "org_id" => $delar_id, // Delar Organization
                "profile_pic" => $request['thumbnail_url'],
                'created_at' => date('Y-m-d H:i:s'),
                'country_code' => $request['admin_country_code'],
                'contact_no' => $request['admin_contact_no'],
                'is_verified' => 1,
                'is_email_verified'=>$request['is_email_verified']
            );

            User::insert($insert); // Delar account for web

            return response()->json(['status'=>'success', 'message'=> 'Delar created successfully'], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Delar creation failed'], 400);
        }
    }

    public function add_address(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'org_id' => ['required'],
                'street' => ['required', 'string', 'max:60' ],
                'city' => ['required', 'max:60' ],
                'district' => ['string', 'max:60' ],
                'zipcode' => ['required', 'string', 'max:20' ],
                'latitude' => ['required', 'numeric', 'between:0,180'],
                'longitude' => ['required', 'numeric', 'between:0,180'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $request['created_at'] = date('Y-m-d H:i:s');
        try{
            Location::insert($request->all());
            return response()->json(['status' => 'success', 'message'=> 'Location created successfully', ], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Location creation failed', "error" => $e ], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $list = Delar::where('id', $id)->with('deal')
                ->with(['location' => function ($query) use($id) {
                    $query->where('org_id', $id);
                    $query->where('primary', 1);
                }])->first();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    public function address_info($delar_id, $address_id = null)
    {
        $locations = Location::where('id', $address_id)->first();
        $delar = Delar::where('id', $delar_id)->first();
        $delar['location'] = $locations;

        return response()->json(['status' => 'success', 'data' => $delar], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    public function edit_address(Request $request, $id)
    {
        $validator = Validator::make($request->all(),
            [
                'org_id' => ['required'],
                'street' => ['required', 'string', 'max:60' ],
                'city' => ['required', 'max:60' ],
                'district' => ['string', 'max:60' ],
                'zipcode' => ['required', 'string', 'max:20' ],
                'latitude' => ['required', 'numeric', 'between:0,180'],
                'longitude' => ['required', 'numeric', 'between:0,180'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $request['updated_at'] = date('Y-m-d H:i:s');
        try{
            Location::where('id', $id)->update($request->all());
            return response()->json(['status' => 'success', 'message'=> 'Location updated successfully', ], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Location update failed', "error" => $e ], 400);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request['location'] = json_decode($request['location'], true);
        $request['phone'] = $request['country_code'].$request['phone'];
        $validator = Validator::make($request->all(),
            [
                'org_name' => ['required', 'string', 'max:100' ],
                'org_name_ar' => ['required', 'string', 'max:100' ],
                //'code' => ['required', 'string', 'max:20', 'unique:organizations,code,'.$id.',id'],
                'vat_no'=>['required', 'max:20'],
                'country_code' => ['required', 'max:5'],
                'phone' => ['required', 'string', 'max:15', 'unique:organizations,phone,'.$id.',id' ],
                'email' => ['required', 'email', 'max:60', 'unique:organizations,email,'.$id.',id' ],
                'location.street' => ['string', 'max:60' ],
                'location.city' => ['required', 'max:60' ],
                'location.district' => ['string', 'max:60' ],
                'location.zipcode' => ['string', 'max:20' ],
                'location.latitude' => ['required', 'numeric', 'between:0,180'],
                'location.longitude' => ['required', 'numeric', 'between:0,180'],
                'category.*' => ['required'],
                //'thumbnail' => ['mimes:jpeg,jpg,png', 'max:500' ],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/delar/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/delar/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('delar/', $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $insert = array(
                'org_name' => $request['org_name'],
                'org_name_ar' => $request['org_name_ar'],
                'code' => $request['code'],
                'vat_no'=>$request['vat_no'],
                'country_code' => $request['country_code'],
                'phone' => $request['phone'],
                'email' => $request['email'],
                'updated_by' => Auth::id(),
                'updated_at' => date('Y-m-d H:i:s'),
                'status' => $request['status']
            );

            if($request->file('thumbnail'))
                $insert['thumbnail_url'] = $request['thumbnail_url'];

            Delar::where('id', $id)->update($insert);

            $location = $request['location'];
            $location['updated_at'] = date('Y-m-d H:i:s');
            Location::where('primary', 1)->where('org_id', $id)->update($location);

            $request['category'] = json_decode($request['category'], true);
            DB::beginTransaction();
            if(count($request->category) > 0){
                OrgDeal::where('org_id', $id)->delete();

                foreach ($request->category as $key => $dealidrow) {
                    $check_org_deal = OrgDeal::where('org_id', $id)->where('deal_id', $dealidrow)->count();
                    if($check_org_deal > 0){
                        $insert = array(
                            'org_id' => $id,
                            'deal_id' => $dealidrow,
                            'status' => 1, //$request['status'],
                            'updated_at' => date('Y-m-d H:i:s')
                        );
                        OrgDeal::where('org_id', $id)->where('deal_id', $dealidrow)->update($insert);
                    }else{
                        $insert = array(
                            'org_id' => $id,
                            'deal_id' => $dealidrow,
                            'status' => 1, //$request['status'],
                            'created_at' => date('Y-m-d H:i:s'),
                            'updated_at' => date('Y-m-d H:i:s')
                        );
                        OrgDeal::insertGetId($insert);
                    }
                }
            }
            DB::commit();

            return response()->json(['status'=>'success', 'message'=> 'Delar updated successfully'], 200);
        }
        catch (\Exception $e)
        {
            DB::rollback();
            return response()->json(['status'=>'failed', 'message'=> 'Delar updation failed'], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function accounts(){

    }

    public function validate_dealprovider_code(Request $request) {
        if(isset($request->org_id) && !empty($request->org_id)) {
            $validator = Validator::make($request->all(), [
                'code' => ['required', 'string', 'max:20', 'unique:organizations,code,'.$request->org_id.',id,company_type,D' ],
                'org_id' => ['required'],
            ]);
            if ($validator->fails()) {
                $errors = [];
                foreach(json_decode($validator->messages()) as $key => $value)
                    $errors[] = $value[0];
                return response()->json([ 'status' => "failed", "response" => $errors ], 400);
            }else{
                return response()->json(['status' => 'success', 'message'=> 'Valid Code', ], 200);
            }
        }else{
            $validator = Validator::make($request->all(), [
                'code' => ['required', 'string', 'max:20', 'unique:organizations' ],
            ]);
            if ($validator->fails()) {
                $errors = [];
                foreach(json_decode($validator->messages()) as $key => $value)
                    $errors[] = $value[0];
                return response()->json([ 'status' => "failed", "response" => $errors ], 400);
            }else{
                return response()->json(['status' => 'success', 'message'=> 'Valid Code', ], 200);
            }
        }
    }

    public function delar_companies(){
        $login_type_id = Role::where('id', Auth::user()->role_id)->pluck('login_type_id')->first();
        $list = Delar::where('company_type', 'D')
            ->where('status', 1)
            ->orderBy('org_name', 'ASC')
            ->with('location', 'deal');

        if($login_type_id == 18) // Delar organizations only
            $list = $list->where('id', Auth::user()->org_id);

        $list = $list->get();

        return response()->json(['status' => 'success', 'data' => $list, "user" => Auth::user(), "test" => "test"], 200);
    }

    public function device_data($data){
        $input['user_id'] = $data['user_id'];
        $input['device_id'] = $data['device_id'];
        $input['device_type'] = $data['device_type'];
        $input['device_model'] = isset($data['device_model']) ? $data['device_model'] : $data['device_type'];
        $input['version'] = $data['version'];
        $input['fcm'] = $data['fcm'];
        $input['user_type'] = $data['user_type'];
        $input['app_version'] = $data['app_version'];
        $input['ip'] = $_SERVER['REMOTE_ADDR'];
        $input['created_at'] = date('Y-m-d H:i:s');
        $input['status'] = 1;

        $where = array(
            "device_id" => $data["device_id"],
            "user_id" => $data["user_id"],
            "user_type" => $data["user_type"],
        );
        $deviceInfo=Device::where($where)->orderBy('id','desc')->get();

        //Make status=0 for particular user 
        $inputArray['status'] = 0;
        $inputArray['updated_at'] = date('Y-m-d H:i:s');
        Device::where('user_id', $where['user_id'])->where('user_type', $where['user_type'])->update($inputArray);

        if(count($deviceInfo) == 0){
            $input['created_at'] = date('Y-m-d H:i:s');
            Device::insert($input);
        } else {
            $id=$deviceInfo['0']->id;
            $input['updated_at'] = date('Y-m-d H:i:s');
            Device::where('id', $id)->update($input);
        }
    }

    public function active_locations(Request $request, $delar_id) {
        // Api used for specific deal provider locations

        if (!isset($delar_id) || $delar_id == '') {
            $errors = [];
            $errors[] = 'Delar provider required';
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $offer_locations = Location::select('locations.*',
                DB::raw("CONCAT(cities.city,' , ',locations.district,', ',locations.street) as city"),
                'cities.id as cityid', 'cities.latitude as citylatitude', 'cities.longitude as citylongitude')
                ->leftjoin('cities', 'locations.city', '=', 'cities.id')
                ->where('locations.org_id', $delar_id)
                ->where('locations.status', 1)->get();

            if(count($offer_locations) > 0){
                return response()->json(['status'=>'success', 'data'=> $offer_locations], 200);
            }else{
                return response()->json(['status'=>'failed', 'message'=> 'No locations were found'], 400);
            }
        }catch (\Exception $e) {
            return response()->json(['status'=>'failed', 'message'=> 'Something went wrong', "error" => $e ], 400);
        }
    }

    public function adminuser($id) {
        $list = User::where('id', $id)->where('role_id', 3)->with('company')->first();
        return response()->json(['status' => 'success', 'message'=> 'Admin Details', 'data' => $list], 200);
    }


     function preferred_language(Request $request){
         $validator = Validator::make($request->all(),
            [
                'language_preference' => 'required|string'
            ]
        );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{

            $inputdata = array(
                'preferred_language' => $request->language_preference,
                'updated_at' => date('Y-m-d H:i:s')
            );

            $userId=Auth::user()->id;
            User::where('id', $userId)->update($inputdata);
            $data['user'] = User::where('id', $userId)->first();

            return response()->json([
                'status' => 'success',
                'message' => 'Language preference updated successfully',
                'message_ar' => 'تم تحديث الملف الشخصي بنجاح',
                'response' => $data
            ], 200);

        } catch (\Exception $e){
            return response()->json([ 'status' => "failed", "response" => "Failed to set driver language preference","error"=>$e->getMessage() ], 400);
        }
    }

       /**
     * get all information related to dealer reagard total earnings, categories,
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show_info($id)
    {
        $list = Delar::where('id', $id)->with('deal')
                ->with(['location' => function ($query) use($id) {
                    $query->where('org_id', $id);
                    $query->where('primary', 1);
                }])->first();

        $adminInfo = User::with('loggedin_devices')->where('org_id', $id)->where('role_id',3)->orderBy('id','ASC')->first();

        $techniciansList = User::where('org_id', $id)->where('role_id',8)->get();

        $addressList = Location::with('city')->where('org_id', $id)->get();       

        if($adminInfo)
            $data['notifications_list']=(new NotificationController)->getUserNotificationsList($adminInfo->id,'N');
        else
            $data['notifications_list']= [];

        // Total Purchased Orders
        $transacationArray = (new TransactionController)->getCustomerTransactionCounts($id, 'dealer');
         
        // Get payouts information of the dealer
         $payouts = Payout::where('payment_to',$id)
            ->orderBy('id', 'desc')
            ->skip(0)->take(10)->get();

        $paid_date = Payout::where('status', 1)->where('payment_to', $id)->orderBy('id', 'desc')->pluck('paid_date')->first();
        $paid_date = $paid_date ? $paid_date : '2021-10-01';
        $todayDate=date("Y-m-d");
        $toDate = date('Y-m-d', strtotime($todayDate .' -1 day'));

        $dealerPayoutLimit = (new PayoutController)->getDealerPayoutLimit($id, $paid_date, $toDate);

        $scanned_count = Transaction::join('item_master', 'item_master.id', 'transactions.item_id')
                    ->where('item_master.delar_id',$id)
                    ->where('transactions.approved_at', '>', $paid_date)
                    ->where('transactions.redeem_quantity', '>', 0)
                    ->count();

      
        $countersArray=$transacationArray;
        $countersArray['scanned_total']=$scanned_count;
        $countersArray['total_share']=$dealerPayoutLimit; 
         
        $amount_paid = Payout::where('status', 1)
                ->where('payment_to', $id)->where('paid_date', $paid_date)
                ->orderBy('id', 'desc')->pluck('amount_paid')->first();

        $amount_paid = $amount_paid ? $amount_paid : 0; 

        $counterArray['total_payouts']=$amount_paid;     

        $data['counters']=$countersArray;
        $data['org_info']=$list;
        $data['technicians_list']=$techniciansList;
        $data['user_info']=$adminInfo;
        $data['address_list']=$addressList;
        $data['payouts_list']=$payouts;
    
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    /**
     * get available active dealers list 
     * 
     * @access admin module
     */
    function active_dealers_list(){
        $list = Delar::where('status', 1)
                ->where('company_type', 'D')
                ->orderBy('org_name','ASC')
                ->with('location', 'deal');

        if(Auth::user()->login_type_id==18){ //If logged in user is dealer 
            $list = $list->where('id',Auth::user()->org_id);
        }
        $list = $list->get();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }
}
