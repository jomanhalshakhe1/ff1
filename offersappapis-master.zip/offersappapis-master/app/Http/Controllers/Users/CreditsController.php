<?php

namespace App\Http\Controllers\Users;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Generals\DealController;
use App\Http\Controllers\Generals\SendPushNotification;
use App\Models\Accounts\ConsumerCredit;
use App\Models\Accounts\Credit;
use App\Models\Accounts\Driver;
use App\Models\Accounts\GroupConsumer;
use App\Models\Accounts\PaymentShare;
use App\Models\Generals\Device;
use App\Models\Generals\Notification;
use App\Models\Accounts\Transaction;
use App\Models\Generals\Lookup;
use App\Models\Generals\NotificationLog;
use App\Models\Generals\Role;
use App\Models\Regulatory\Organization;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Session\Store;
use Illuminate\Support\Facades\Log;
use App\Models\Generals\NotificationsFormats;
use App\Models\Accounts\ConsumerGroup;

/* Events calling */
use App\Events\SendGiftCredits;

/* End events calling */

class CreditsController extends Controller
{
    private $gift = 1;
    private $group = 10;

    /**
     * Get all available gift's list based on the pagination
     * @param $request
     * @access in admin module
     * 
     */
    public function gifts(Request $request)
    {

        $list = Credit::where('credit_on', $this->gift)->withCount('groups', 'individuals')->with('offer');

        if(Auth::user()->role_id == 6)
            $list = $list->where('created_by', Auth::id());

        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $pageno = 0; $pagelength = 0; 
            $totalrecords = $list->count();

             // If pagination got from api request then based on the pagelength need to get records
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)){
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
                $list = $list->orderBy('credits.id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength);
            }
            $list = $list->get();
            $list = $list->toArray();
        }else{
            $list = $list->orderBy('credits.id', 'desc')->get()->toArray();
        }

        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $data['data'] = $list;
            $data['current_page'] = $pageno ? $pageno : '1';
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength ? $pagelength : '200';

            return response()->json(['status11' => 'success', 'data' => $data], 200);
        }else{
            return response()->json(['status' => 'success', 'data' => $list], 200);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function send_gift(Request $request)
    {
        $request['consumers'] = json_decode($request['consumers'], true );
        $rules = [
            'fleet_id' => ['required'],
            'amount' => ['required'],
            'gift_per_user' => ['required'],
            'start_date' => ['required', 'after_or_equal:'.date("Y-m-d") ],
            'end_date' => ['required', 'after_or_equal:start_date'],
            'description' => ['required'],
            'consumers' => ['required'],
        ];

        $validator = Validator::make($request->all(), $rules );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $gift_stat = $this->validateGiftAmounts($request['consumers'], $request['fleet_id'], $request['gift_per_user']);
        if(!$gift_stat['eligible'])
            return response()->json([ 'status' => "failed", "message" => "Invalid Gift Amounts" ], 400);
        else
            $request['amount'] = $gift_stat['amount'];
        // $credits = $this->fleet_credits($request['fleet_id']);
        // if($credits < count($request['consumers']) * $request['amount'])
        //     return response()->json([ 'status' => "failed", "message" => "Credit Limit Exceeded" ], 400);

        try{
            $request['quantity'] = $gift_stat['total_members'];
            $request['credit_on'] = $this->gift;
            $request['created_at'] = date('Y-m-d H:i:s');
            $request['created_by'] = Auth::id();
            
            $notificationFormatList = NotificationsFormats::where('notification_for', 39)->where('status', '1')->orderBy('id', 'asc')->get();

            if(isset($request['is_new_format']) && $request['is_new_format']){
                $credit = Credit::create($request->except('consumers', 'gift_per_user','is_new_format'));
                return $this->giftNewFormateUsers($request, $request['gift_per_user'], $credit['id'], $notificationFormatList);
            } else {
                $credit = Credit::create($request->except('consumers', 'gift_per_user'));
                return $this->giftUsers($request['consumers'], $request['gift_per_user'], $credit['id'], $notificationFormatList);
            }
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Gift creation failed', "error" => $e->getMessage() ], 400);
        }
    }

    /*
     * Prefix: customer, Access: Customer,
     * Referance function by Coupon controller
     * Send coupon credits to the customer
     * This coupon credits are shared by admin credits
     */
    function send_customer_coupon_credits($amount = 0){
        $adminId = Organization::where('company_type', 'A')->pluck('id')->first();

        $credits = array(
            'credit_on' => $this->gift,
            'fleet_id' => $adminId,
            'quantity' => 1,
            'amount' => $amount,
            'start_date' => date('Y-m-d'),
            'end_date' => date('Y-m-d', strtotime('+1 Year')),
            'credit_by' => 'C', // Credits
            'description' => 'Coupon credits are credited', // Credits
            'created_at' => date('Y-m-d H:i:s'),
            'created_by' => Auth::guard('driver')->id(),
        );

        $creditId = Credit::insertGetId($credits);
        ConsumerCredit::insert(array(
            'credit_id' => $creditId,
            'credit_to' => Auth::guard('driver')->id(),
            'credit_for' => 11,
            'created_at' => date('Y-m-d H:i:s'),
        ));

        return $creditId;
    }


    public function validateGiftAmounts($consumers, $fleet_id, $gift_per_user){
        $groups = $individuals = [];
        foreach ($consumers as $consumer)
        {
            if($consumer['credit_for'] == $this->group)
                array_push($groups, $consumer);
            else
                array_push($individuals, $consumer);
        }
        $group_ids = array_column($groups, 'credit_to');
        $individual_filters = [];
        if(count($group_ids) > 0){
            // ignore if individual User was already in Group
            foreach ($individuals as $individual)
            {
                if(GroupConsumer::where('consumer_id', $individual['credit_to'])->whereIn('group_id', $group_ids)->count() == 0)
                    array_push($individual_filters, $individual); // if user not available on the group
            }
        }
        else
            $individual_filters = $individuals;

        $group_user_cnt = GroupConsumer::whereIn('group_id', $group_ids)->count();
        $total_share_cnt = $group_user_cnt + count($individual_filters);

        if(Organization::where('id', $fleet_id)->where('company_type', 'F')->count() > 0) {
            $fleets = DB::select("select a.id, a.org_name,(b.credit_amount - ifnull(d.debit_amount, 0)) as credits,  b.credit_amount, d.debit_amount
            from organizations as a join (select payment_to, sum(amount_paid) as credit_amount from exchanges where status = 1 GROUP BY payment_to) as b
              on a.id = b.payment_to
            left JOIN (select fleet_id, sum(amount) as debit_amount from credits where credit_on = 1 GROUP BY fleet_id) as d
            on a.id = d.fleet_id
            where a.company_type = 'F' and a.status = 1 and a.id = ". $fleet_id);
            $credits=0;
            if(count($fleets)>0)
             $credits = $fleets[0]->credits;
        }
        else {
            $admins = DB::select("select a.id, a.org_name,(ifnull(b.credit_amount,0) - ifnull(d.debit_amount, 0)) as credits,  b.credit_amount, d.debit_amount
            from organizations as a left join (select payment_to, sum(amount_paid) as credit_amount from exchanges where status = 1 GROUP BY payment_to) as b
              on a.id = b.payment_to
            left JOIN (select fleet_id, sum(amount) as debit_amount from credits where credit_on = 1 GROUP BY fleet_id) as d
            on a.id = d.fleet_id
            where a.status = 1 and a.company_type = 'A'");
            $credits=0;
            if(count($admins)>0)
                $credits = $admins[0]->credits;
        }

        $gift_amount = $gift_per_user * $total_share_cnt;
        $data = array('eligible' => ($gift_amount < $credits), "amount" => $gift_amount, "total_members" => $total_share_cnt);

        return $data;
    }

    /**
    *  Send money to selected customers as gift and send notification to customer
    *
    *  @param $consumers, $gift_per_user, $credit_id
    *
    */

    public function giftUsers($consumers, $gift_per_user, $credit_id, $notificationFormatList){
        try{
            $groups = $individuals = [];
            foreach ($consumers as $consumer)
            {
                if($consumer['credit_for'] == $this->group)
                    array_push($groups, $consumer);
                else
                    array_push($individuals, $consumer);
            }


            $group_ids = array_column($groups, 'credit_to');
            $individual_filters = [];
            if(count($group_ids) > 0){
                // ignore if individual User was already in Group
                foreach ($individuals as $individual)
                {
                    if(GroupConsumer::where('consumer_id', $individual['credit_to'])->whereIn('group_id', $group_ids)->count() == 0)
                        array_push($individual_filters, $individual); // if user not available on the group
                }
            }
            else
                $individual_filters = $individuals;

            $consumersList=array();

            $groupsCustomersArray=array();

            if(count($groups)){
                foreach ($groups as $consumer)
                {
                    ConsumerCredit::insert([
                        'credit_id' => $credit_id,
                        'credit_for' => $consumer['credit_for'],
                        'credit_to' => $consumer['credit_to'],
                        'created_at' => date('Y-m-d H:i:s')
                    ]);

                    $groupsCustomersArray[]=$consumer['credit_to'];
                }
            }

            if(count($groupsCustomersArray)){
                $group_users = GroupConsumer::whereIn('group_id',$groupsCustomersArray)->get();
                foreach($group_users as $user){
                    if(!in_array($user['consumer_id'], $consumersList)){
                        $consumersList[]= $user['consumer_id'];
                    }
                }
            }

            if(count($individual_filters)>0){
                foreach ($individual_filters as $consumer)
                {
                    ConsumerCredit::insert([
                        'credit_id' => $credit_id,
                        'credit_for' => $consumer['credit_for'],
                        'credit_to' => $consumer['credit_to'],
                        'created_at' => date('Y-m-d H:i:s')
                    ]);

                    $consumersList[]= $consumer['credit_to'];
                }
            }
            try{
                $isOldFormat=0;
                event(new SendGiftCredits($gift_per_user, $consumersList, $notificationFormatList, $isOldFormat));
            } catch(\Exception $err){
                Log::error("Failed to send gift credits notifications : ". $err->getMessage());
            }

            return response()->json(['status'=> 'success', 'message'=> 'Gift created successfully' ], 200);
        } catch(\Exception $err){
            return response()->json(['status' => 'failed', 'message' => "Customers list not found"], 400);
        }
    }



    /**
    *  Send money to selected customers as gift and send notification to customer
    *
    *  @param $consumers, $gift_per_user, $credit_id
    *
    */

    public function giftNewFormateUsers($request, $gift_per_user, $credit_id, $notificationFormatList){
         $consumersCount=0;$consumersData=array();

         if(!isset($request['consumers'])){
            $consumersCount++;echo "yes";
         } else {
            if($request['consumers']!=''){
                $count=count($request['consumers']);
                if($count>0 ){
                    $consumersData=$request['consumers']['0'];
                    if(array_key_exists('credit_to', $consumersData)){
                        if($consumersData['credit_for']==10 && $consumersData['credit_to']=='')
                            $consumersCount++;
                        else if($consumersData['credit_for']==11 && $consumersData['credit_to']=='')
                            $consumersCount++;
                    }
                } else {
                     $consumersCount++;
                }
            } else {
                $consumersCount++; 
            }
        }

        if($consumersCount>0){
            return response()->json(['status' => 'failed', 'message' => "Customers list or groups list required"], 400);
        } 

        if($consumersData['credit_for']=='11'){//individual customers
            return $this->individualConsumersGifts($gift_per_user, $credit_id, $request, $notificationFormatList);
        } else if($consumersData['credit_for']=='10'){ //groups
            return $this->groupConsumersGifts($gift_per_user, $credit_id, $request, $notificationFormatList);
        }
    }

    /**
     * Send gift credits to group's customers
     * @param 
    */
    public function groupConsumersGifts($gift_per_user, $credit_id, $request, $notificationFormatList)
    {   
        $consumersData=$request['consumers']['0'];
        $list = ConsumerGroup::with('company','consumers','consumers.driver', 'consumers.loggedin_devices')
                ->withCount( ['consumers' => function($q){ $q->where('status', 1); }])
                ->Has( 'consumers', '>' , 0)
                ->where('status', 1);
        if(array_key_exists('credit_to', $consumersData)){
            $arr=array();
            $arr=explode(',',$consumersData['credit_to']);
            $list=$list->whereIn('id', $arr);
        } else if(array_key_exists('deleted_to', $consumersData)){
            $arr=array();
            $arr=explode(',',$consumersData['deleted_to']);
            $list=$list->whereNotIn('id',$arr);
        }

        $org_id=$request->fleet_id;
        
        if($request->user_type == 'P'){ // Fleet Company
            $list = $list->where('company', $org_id);
        } 
        $list=$list->orderBy('id','DESC')->get();

        if($list){
            $groupsArray=array();
            foreach($list as $groupData){
                //Insert into consumer credits
                if(!in_array($groupData->id, $groupsArray)){
                    ConsumerCredit::insert([
                        'credit_id' => $credit_id,
                        'credit_for' => $consumersData['credit_for'],
                        'credit_to' => $groupData->id,
                        'created_at' => date('Y-m-d H:i:s')
                    ]);

                    $groupsArray[]=$groupData->id;
                }
                try{
                    $customerList=$groupData->consumers;
                    //gift per user, user data, notificationFormatList and is new format=1

                    foreach($customerList as $singleUser){
                        event(new SendGiftCredits($gift_per_user, $singleUser, $notificationFormatList, 1));
                    }
                } catch(\Exception $err){
                    Log::error("Failed to send gift credits notifications : ". $err->getMessage());
                }
            }
            return response()->json(['status'=> 'success', 'message'=> 'Gift created successfully','data'=>$list ], 200);
        } else {
            return response()->json(['status' => 'failed', 'message' => "Customers list not found"], 400);
        }
    }



    /**
     * Send gift credits to individual customers
     * @param 
    */
    public function individualConsumersGifts($gift_per_user, $credit_id, $request, $notificationFormatList)
    {
        $consumersData=$request['consumers']['0'];
        $org_id=$request->fleet_id;

        if($request->user_type=='P') // Fleet Company
        {
            $customersList = Driver::join('fleet_drivers', 'drivers.id', 'fleet_drivers.driver_id')
                ->select('drivers.*', 'fleet_drivers.employee_id')
                ->where('fleet_drivers.status', 1)
                ->where('drivers.status', 1)
                ->where('drivers.is_verified', 1);

            $customersList = $customersList->where('fleet_drivers.fleet_id', $org_id);
        }  else { // All users for admin    
            $customersList = Driver::select('drivers.*', DB::raw(" '' as employee_id"))
                        ->where('is_verified', 1)->where('drivers.status', 1);
        }

        if(array_key_exists('credit_to', $consumersData)){
            $arr=array();
            $arr=explode(',',$consumersData['credit_to']);
            $customersList=$customersList->whereIn('drivers.id',$arr);
        } else if(array_key_exists('deleted_to', $consumersData)){
            $arr=array();
            $arr=explode(',',$consumersData['deleted_to']);
            $customersList=$customersList->whereNotIn('drivers.id',$arr);
        }

        $customersList=$customersList->with('loggedin_devices')->orderBy('drivers.id','DESC')->get();

        if($customersList){
            foreach($customersList as $userData){
                //Insert into consumer credits
                ConsumerCredit::insert([
                    'credit_id' => $credit_id,
                    'credit_for' =>$consumersData['credit_for'],
                    'credit_to' => $userData->id,
                    'created_at' => date('Y-m-d H:i:s')
                ]);

                try {
                    // Gift per user, $userData, $notification_for and $isNewFormate
                    event(new SendGiftCredits($gift_per_user, $userData, $notificationFormatList, 1));
                } catch(\Exception $err){
                    Log::error("Failed to send gift credits notifications : ". $err->getMessage());
                }
            }
            return response()->json(['status'=> 'success', 'message'=> 'Gift created successfully' ], 200);
        } else {
            return response()->json(['status' => 'failed', 'message' => "Customers list not found"], 400);
        }
    }

    public function fleet_credits($fleet_id)
    {
        $qry = "select (select ifnull(sum(amount_paid),0) as ex_credits from exchanges where payment_to = ".$fleet_id.")
                   - ifnull(sum(amount),0) as fleet_credits
            from (
            select consumer_credits.credit_id, sum(amount) as amount from credits
              JOIN consumer_credits on credits.id = consumer_credits.credit_id
              where credits.fleet_id = ".$fleet_id."
            GROUP BY consumer_credits.credit_id) as a ";
        $data = DB::select($qry);
        return $data['fleet_credits'];
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function gift_info($id)
    {
        $list = Credit::where('id', $id)->with('consumer')->first();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // No update to the credits, only in-Active
    /*
    public function update_gift(Request $request, $id)
    {
        $request['consumers'] = json_decode($request['consumers'], true );
        $rules = [
            'amount' => ['required'],
            'start_date' => ['required'],
            'end_date' => ['required'],
            'description' => ['required'],
            'status' => ['required'],
            'consumers' => ['required'],
        ];


        $validator = Validator::make($request->all(), $rules );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try{

            $request['updated_at'] = date('Y-m-d H:i:s');
            $credit = Credit::where('id', $id )->update($request->except('consumers'));

            ConsumerCredit::where('credit_id', $id)->delete();
            $consumers = $request['consumers'];
            foreach ($consumers as $consumer)
            {
                ConsumerCredit::insert([
                    'credit_id' => $id,
                    'credit_for' => $consumer['credit_for'],
                    'credit_to' => $consumer['credit_to'],
                    'created_at' => date('Y-m-d H:i:s')
                ]);
            }

            return response()->json(['status'=> 'success', 'message'=> 'Gift updated successfully' ], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Gift update failed', "error" => $e ], 400);
        }
    }
    */

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function admin_credits()
    {
        $paymentShares = PaymentShare::where('status', 1)->orderBy('id', 'desc')->limit(1);

        $admin_share = Transaction::joinSub($paymentShares, 'payment_share', function ($qry){})
            ->leftJoin('fleet_drivers', 'transactions.created_by', 'fleet_drivers.driver_id')
            ->leftJoin('organizations', 'fleet_drivers.fleet_id', 'organizations.id')
            ->where('transactions.payment_status', 'Successful')
            ->where('transactions.status', 1)
            ->selectRaw('ROUND(((transactions.price * transactions.discount/100) * payment_share.admin_share / 100) 
            - ((transactions.price * transactions.discount/100) * payment_share.admin_share / 100) * ifnull(organizations.payment_share,0) / 100, 2) as admin_share')
            ->pluck('admin_share')
            ->first();

        $admin_share = $admin_share ? $admin_share : 0;
        return $admin_share;
    }

    public function delar_credits($delar_id = 1){
        $res = DB::select("select 
      ROUND(sum(
                ((((a.price - a.price * a.discount/100) - ((a.price * a.discount/100) * payment_share.admin_share / 100)) -
                  (
                    ((a.price - a.price * a.discount/100) - ((a.price * a.discount/100) * payment_share.admin_share / 100)) -
                    ((a.price - a.price * a.discount/100) - ((a.price * a.discount/100) * payment_share.admin_share / 100)) /
                    (1 + payment_share.vat/100)
                  )) -
                 (
                   1 + (((a.price - a.price * a.discount/100) - ((a.price * a.discount/100) * payment_share.admin_share / 100)) -
                        (
                          ((a.price - a.price * a.discount/100) - ((a.price * a.discount/100) * payment_share.admin_share / 100)) -
                          ((a.price - a.price * a.discount/100) - ((a.price * a.discount/100) * payment_share.admin_share / 100)) /
                          (1 + payment_share.vat /100)
                        )) * payment_share.pg_share / 100
                 )) * redeems.redeem_quantity + c.service_cost
            ),2) as delar_credits
    from transactions as a join item_master as b on a.item_id = b.id
      inner join item_offers as c on b.id = c.item_id
      inner join (select * from `payment_shares` where `status` = 1 order by `id` desc limit 1) as `payment_share`
      inner join (
                   select a.transaction_no, c.delar_id, ifnull(d.paid_date, '2021-10-01') as paid_date, sum(a.quantity) as redeem_quantity
                   from redeem_log as a join transactions as b on a.transaction_no = b.transaction_no
                     join item_master as c on b.item_id = c.id
                     left join (select payment_to, max(payouts.paid_date) as paid_date from payouts group by payment_to) as d on c.delar_id = d.payment_to
                   group by a.transaction_no, c.delar_id, d.paid_date
                 ) as redeems on a.transaction_no = redeems.transaction_no
    where a.payment_status = 'Successful' and a.redeem_quantity > 0 and a.status = 1 and b.delar_id = ". $delar_id);

        $credits = 0;
        if((count($res) > 0))
        $credits =  $res[0]->delar_credits ? $res[0]->delar_credits : 0;
        return $credits;
    }

    public function fleet_shares($fleet_id = 1){
        $res = DB::select("select 
          ROUND(sum(
                    (((price * discount/100) * payment_share.admin_share/ 100) * ifnull(c.payment_share,0) / 100) *
                    (select ifnull(sum(redeem_log.quantity),0) as quantity from redeem_log where redeem_log.transaction_no = transaction_no
                     and cast(redeem_at as date) BETWEEN
                     (select ifnull(max(paid_date), '2021-10-01') as paid_date from payouts where payment_to = b.fleet_id)
                     AND CAST(current_date - 1 AS DATE) )
                ), 2) as fleet_share
        from transactions as a JOIN fleet_drivers as b on a.created_by = b.driver_id
          JOIN organizations as c on b.fleet_id = c.id
          join (select * from payment_shares ORDER BY id DESC limit 1) as payment_share
        where a.payment_status = 'Successful' and a.redeem_quantity > 0 and a.status = 1 and b.fleet_id = ". $fleet_id);

        $credits = 0;
        if((count($res) > 0))
            $credits =  $res[0]->fleet_share ? $res[0]->fleet_share : 0;
        return $credits;
    }

    public function consumer_accounts(Request $request)
    {
        $login_type_id = Role::where('id',Auth::user()->role_id)->pluck('login_type_id')->first();
         $pageno = 0; $pagelength = 0; 
        if($login_type_id == 19) // Fleet Company
        {
            $org_id = Auth::user()->org_id;
            $consumers = Driver::join('fleet_drivers', 'drivers.id', 'fleet_drivers.driver_id')
                ->select('drivers.*', 'fleet_drivers.employee_id')
                ->where('fleet_drivers.fleet_id', $org_id);
        }
        else
            //$consumers = Driver::all();
            $consumers = Driver::leftjoin('fleet_drivers', 'drivers.id', 'fleet_drivers.driver_id')
                ->select('drivers.*','fleet_drivers.employee_id');


        // Apply pagination if pagelength and page no got as a request    
        $totalrecords=$consumers->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
            $consumers = $consumers->skip( ($pageno-1)*$pagelength )->take($pagelength);
        } 
        $consumers=$consumers->get();
        


        $accounts = array();

        foreach ($consumers as $consumer)
        {
            $user_id = $consumer->id;
           

            $addedCredits = "select ifnull(sum(credits),0) as credits from (
        SELECT a.id, a.start_date, a.end_date, if(a.credit_on = 2, a.amount, (a.amount / a.quantity)) as credits
        from credits as a JOIN consumer_credits as b on a.id = b.credit_id and b.credit_for = 10
            join group_consumers as c on b.credit_to = c.group_id and c.consumer_id = ".$user_id."
        where (a.credit_on = 1 or (a.credit_on = 2 and a.credit_by = 'C') or (a.credit_on = 3 and a.credit_by = 'C'))
        UNION
        SELECT a.id, a.start_date, a.end_date, if(a.credit_on = 2, a.amount, (a.amount / a.quantity)) as credits
        from credits as a JOIN consumer_credits as b on a.id = b.credit_id and b.credit_for = 11 and b.credit_to = ".$user_id."
        where (a.credit_on = 1 or (a.credit_on = 2 and a.credit_by = 'C') or (a.credit_on = 3 and a.credit_by = 'C'))) as x";

        $addedCredits = DB::select($addedCredits);
        $credits = $addedCredits[0]->credits;

        $consumedCredits = "select ifnull(sum(b.amount_by_credits),0) as consumed
        from transactions as a join payments as b on a.transaction_no = b.transaction_no
        where b.amount_by_credits > 0 and (a.payment_status = 'Successful' or a.payment_status = 'Requests'
           or a.payment_status = 'Available') and a.status = 1 and a.created_by = ".$user_id;
        $consumedCredits = DB::select($consumedCredits);
        $consumed = $consumedCredits[0]->consumed;

        $accounts = array(
            "credits" => number_format((float)($credits-$consumed), 2, '.', ''),
            "expired" => 0,
            "consumed" => number_format((float)$consumed, 2, '.', '')
        );

           $consumer->credits = $accounts['credits'];
           $consumer->expired = $accounts['expired'];
           $consumer->consumed = $accounts['consumed'];
        }

        $data['data'] = $consumers;
        $data['current_page'] = $pageno ? $pageno : '1';
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength ? $pagelength : '200';

        return response()->json(['status'=> 'success', 'data'=> $data ], 200);

    }

    public function delar_accounts()
    {


        $sql = "select a.id, a.org_name,round(ifnull(payment_share.dealer_share,0),2) as delar_credits, a.status, 
                sum(ifnull(payout.paid_amount, 0)) as paid_amount from organizations as a ";



        $dealShare="round(((bill.price - (bill.price * bill.discount / 100) - 
        (bill.pg_fee + ((100-bill.discount)* 
        (((((bill.price - ( bill.price * bill.discount / 100))+ ((bill.price * bill.discount / 100)-(bill.price * bill.discount / 100)
        * (100 - bill.joy_share) / 100)-(((bill.price * bill.discount / 100)-((bill.price * bill.discount / 100) 
        * (100 - bill.joy_share) / 100))* bill.partner_discount / 100))+ bill.service_cost + bill.filter_cost)* bill.pg_share / 100)) / 100)))
         + bill.service_cost + bill.filter_cost)-(((bill.price - (bill.price * bill.discount / 100) - (bill.pg_fee + ((100-bill.discount)
         * (((((bill.price - ( bill.price * bill.discount / 100))+ ((bill.price * bill.discount / 100)-(bill.price * bill.discount / 100)
         * (100 - bill.joy_share) / 100)-(((bill.price * bill.discount / 100)-((bill.price * bill.discount / 100) * (100 - bill.joy_share) / 100))
         * bill.partner_discount / 100))+ bill.service_cost + bill.filter_cost)* bill.pg_share / 100)) / 100))) + bill.service_cost + bill.filter_cost)
         - ((bill.price - (bill.price * bill.discount / 100) - (bill.pg_fee + ((100-bill.discount)* (((((bill.price - ( bill.price * bill.discount / 100))
         + ((bill.price * bill.discount / 100)-(bill.price * bill.discount / 100)* (100 - bill.joy_share) / 100)-(((bill.price * bill.discount / 100)
         -((bill.price * bill.discount / 100) * (100 - bill.joy_share) / 100))* bill.partner_discount / 100))+ bill.service_cost + bill.filter_cost)
         * bill.pg_share / 100)) / 100))) + bill.service_cost + bill.filter_cost)/ (1 + bill.vat/100)),2)";


        $sql=$sql." LEFT JOIN 
            (
            select  b.delar_id,SUM((redeem_log.quantity*".$dealShare."))  as dealer_share
              from transactions as a 
                JOIN item_master as b on a.item_id = b.id
                JOIN redeem_log ON redeem_log.transaction_no=a.transaction_no
                JOIN organizations as c on b.delar_id = c.id
                JOIN transaction_details as bill on bill.transaction_no = a.transaction_no
              where   a.payment_status = 'Successful' and a.redeem_quantity > 0 and a.status = 1 and 
              cast(redeem_log.redeem_at as date) BETWEEN (select ifnull(max(paid_date), '2021-10-01') as paid_date 
              from payouts where payment_to = b.delar_id) AND CAST(current_date - 1 AS DATE)  group by  b.delar_id
              ) as payment_share on a.id = payment_share.delar_id";


         $sql=$sql." LEFT JOIN
        (select a.payment_to, sum(a.amount_paid) as paid_amount from payouts as a join organizations as b
        on a.payment_to = b.id and b.company_type = 'D' where a.paid_date = current_date GROUP BY a.payment_to) as payout 
        on a.id= payout.payment_to
        where a.company_type = 'D' ";

        if(Auth::user()->login_type_id==18){
            $sql=$sql." and a.id=".Auth::user()->org_id;
        } 
        $sql=$sql." group by a.id, a.org_name, a.status, delar_credits ORDER BY delar_credits desc";

        $pageno = 0; $pagelength = 0; 

        $totalrecords=count(DB::select($sql));
        
        //If pagination applies as pagelength and page no came from request
        if (isset(request()->pagelength, request()->pageno) && !empty(request()->pagelength)) {
            $pagelength = request()->pagelength;
            $pageno = request()->pageno;
            $page_no=($pageno-1)*$pagelength;
            $sql = $sql." LIMIT ".$page_no.",".$pagelength;
        }  

        $list = DB::select($sql);

        $data['data'] = $list;
        $data['current_page'] =$pageno ? $pageno : '1';
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength ? $pagelength : '20';

        return response()->json(['status'=> 'success', 'data'=> $data ], 200);
    }

    /**
     * Get all partner's account details
     * @param $request
     * @access admin module
     * 
     */
    public function fleet_accounts(Request $request){

        $sql="select a.id, a.org_name, ifnull(credtis.exchange, 0) credits,
                                 ifnull(payment_share.fleet_share,0) as fleet_share,
                                 ifnull(payout.paid_amount,0) payout,  a.status
        from organizations as a";

        $sql=$sql." LEFT JOIN (select a.fleet_id, 
        SUM((((bill.price * bill.discount / 100)-((bill.price * bill.discount / 100)*(100-bill.joy_share)/100))*bill.partner_share/100)*redeem_log.quantity) as fleet_share
                      from transactions as a 
                        JOIN redeem_log ON redeem_log.transaction_no=a.transaction_no
                        JOIN organizations as c on a.fleet_id = c.id
                        JOIN transaction_details as bill on bill.transaction_no = a.transaction_no
                      where  bill.partner_share>0 and a.payment_status = 'Successful' and a.redeem_quantity > 0 and a.status = 1 and 
                      cast(redeem_log.redeem_at as date) BETWEEN (select ifnull(max(paid_date), '2021-10-01') as paid_date from payouts where payment_to = a.fleet_id) AND CAST(current_date - 1 AS DATE) group by a.fleet_id ) as payment_share on a.id = payment_share.fleet_id";

        $sql=$sql." LEFT JOIN
          (select a.payment_to, sum(amount_paid) as paid_amount from payouts as a join organizations as b
              on a.payment_to = b.id and b.company_type = 'F' where paid_date = current_date GROUP BY a.payment_to) as payout on a.id = payout.payment_to
          LEFT JOIN
          (select a.payment_to, sum(amount_paid) as exchange from exchanges as a join organizations as b
              on a.payment_to = b.id and b.company_type = 'F' GROUP BY  a.payment_to) as credtis on a.id = credtis.payment_to
        where a.company_type = 'F' and a.status = 1 ";


        if(Auth::user()->login_type_id==19){
            $sql=$sql." and a.id=".Auth::user()->org_id;
        } 

        $sql=$sql." ORDER BY a.org_name asc, 3 desc,4 desc,5 desc";
         
        $pageno = 0; $pagelength = 0; 

        $totalrecords=count(DB::select($sql));

        //If pagination applies as pagelength and page no came from request
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
            $page_no=($pageno-1)*$pagelength;
            $sql = $sql." LIMIT ".$page_no.",".$pagelength;
        }  

        $list = DB::select($sql);

        $data['data'] = $list;
        $data['current_page'] =$pageno ? $pageno : '1';
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength ? $pagelength : '20';

        return response()->json(['status'=> 'success', 'data'=> $data ], 200);
    }

    /*
    public function consumer_creditsold()// Not using right now 25/02/2022
    {
        if(!Auth::guard('driver')->id())
            return response()->json(['status'=>'failed', 'message'=> 'Authentication failed' ], 400);

        $user_id = Auth::guard('driver')->id();
        //$user_id = 5;
        $addedCredits = "SELECT  a.start_date, '' end_date, sum(a.amount/a.quantity) as credit_amount, 0 expired_amount from credits as a join (
          -- consumer from group
          SELECT a.credit_id, b.consumer_id from consumer_credits as a 
          join group_consumers as b on a.credit_for = 0 and a.credit_to = b.group_id and b.consumer_id = ".$user_id."
          UNION all
          -- consumer from individual on Gift and Refunds, Adjustments
          SELECT credit_id, credit_to as consumer_id from consumer_credits where credit_for = 11 and credit_to = ".$user_id.") as b
          on a.id = b.credit_id and (a.credit_on = 1 or (a.credit_on = 2 and a.credit_by = 'C') or (a.credit_on = 3 and a.credit_by = 'C')) GROUP BY a.start_date ";

        $addedCredits = DB::select($addedCredits);


        $expiredCredits = "SELECT  '' start_date, a.end_date, 0 credit_amount, sum(a.amount/a.quantity) as expired_amount from credits as a join (
-- consumer from group
SELECT a.credit_id, b.consumer_id from consumer_credits as a 
join group_consumers as b on a.credit_for = 0 and a.credit_to = b.group_id and b.consumer_id = ".$user_id."
UNION
-- consumer from individual on Gift and Refunds, Adjustments
SELECT credit_id, credit_to as consumer_id from consumer_credits where credit_for = 11 and credit_to = ".$user_id.") as b
    on a.id = b.credit_id and (a.credit_on = 1 or (a.credit_on = 2 and a.credit_by = 'C') or (a.credit_on = 3 and a.credit_by = 'C')) GROUP BY a.end_date" ;
        $expiredCredits = DB::select($expiredCredits);

        $consumedCredits = "select cast(a.created_at as date) as consumed_at, sum(a.amount_by_credits) as consumed_amount
                from payments as a join transactions as b
                    on a.transaction_no = b.transaction_no and a.payment_status = b.payment_status 
                    and a.amount_by_credits is not null and b.created_by = ".$user_id."
                    where b.payment_status = 'Successful' and b.status = 1
                GROUP BY cast(a.created_at as date) ";
        $consumedCredits = DB::select($consumedCredits);

       if(count($addedCredits) > 0) {
                // if credits are added to consumer
                $start_date = $addedCredits[0]->start_date;
                $credits = $consumed = $expired = 0;
               $unExpired=array();$expiredDate='';$consumedOn=array();$expiredArray=array();
            $dayWiseCredits = array();
            $i = 0;
            while (strtotime($start_date) <= strtotime(date('Y-m-d'))) {

                // Test day by day

                foreach ($addedCredits as $added) {
                    if ($added->start_date == $start_date)
                        $credits += $added->credit_amount;
                }

                foreach ($expiredCredits as $expiredC) {

                    if ($expiredC->end_date == $start_date && $start_date<date('Y-m-d')){
                        $expired += $expiredC->expired_amount;
                        $expiredDate=$expiredC->end_date;
                        $expiredArray[$expiredC->end_date]=$expiredC->expired_amount;
                    }  else {
                        $unExpired[$expiredC->end_date]=$expiredC->expired_amount;
                    }
                }


                foreach ($consumedCredits as $consumedC) {
                    if ($consumedC->consumed_at == $start_date){
                        $consumedOn[$consumedC->consumed_at]= $consumedC->consumed_amount;
                        $consumed += $consumedC->consumed_amount;
                    }
                }

                $dayWiseCredits[$i] = array(
                    "credit_date" => $start_date,
                    "credits" => $credits,
                    "expired" => $expired,
                    "consumed" => $consumed
                );
                $credits = $consumed = $expired = 0;
                $i++;

                $start_date = date("Y-m-d", strtotime("+1 days", strtotime($start_date)));
            }

            $credits = $consumed = $expired = 0;

           
            foreach ($dayWiseCredits as $day) {
                $credits += $day['credits'];
                $expired += $day['expired'];
                $consumed += $day['consumed'];
            }

            //echo $credits." ".$expired." ".$consumed;

            $remainingAmount=array_sum($unExpired)-array_sum($expiredArray);

            $totalCredits=$credits;
            if($expired==0){
                $credits=$credits-$consumed;
            } else if($credits==$expired && $consumed==0){
                $credits=$credits-$expired;
            }  else if($credits==$expired && $consumed>0){
                $credits=$credits-$expired;
                $expired=$expired-$consumed;
            } else if($credits>$expired){ 
                //Consumed Amount from expired date
                $consumedBeforeExpiredSql="select ifNULL(sum(a.amount_by_credits),0) as consumed_amount from payments as a join transactions as b on a.transaction_no = b.transaction_no and a.payment_status = b.payment_status and a.amount_by_credits is not null and b.created_by = ".$user_id." and a.created_at<='".$expiredDate." 23:59:59' where b.payment_status = 'Successful' and b.status = 1";

                $expiredConsumedData = DB::select($consumedBeforeExpiredSql);
                $expiredConsumed=$expiredConsumedData['0']->consumed_amount;

               // Consumed Amount from unexpired dates
                $consumedAfterExpiredSql="select ifNULL(sum(a.amount_by_credits),0) as consumed_amount from payments as a join transactions as b on a.transaction_no = b.transaction_no and a.payment_status = b.payment_status and a.amount_by_credits is not null and b.created_by = ".$user_id." and a.created_at>'".$expiredDate." 23:59:59' and a.created_at<='".date('Y-m-d H:i:s')."' where b.payment_status = 'Successful' and b.status = 1";

                $unexpiredCunsumedData = DB::select($consumedAfterExpiredSql);
                $unexpiredConsumed=$unexpiredCunsumedData['0']->consumed_amount;
                if($unexpiredConsumed==$remainingAmount){
                    $credits=0;
                    $expired=$expired-$expiredConsumed;
                } else if($expired>$consumed){
                     $credits=$remainingAmount-$unexpiredConsumed;
                     $expired=$expired-$expiredConsumed;
                 } else {
                     $credits=$remainingAmount-$unexpiredConsumed;
                 }     
            }


            $accounts = array(
                "total_credits"=> number_format((float)($totalCredits), 2, '.', ''),
                "credits" => number_format((float)($credits), 2, '.', ''),
                "expired" => number_format((float)$expired, 2, '.', ''),
                "consumed" => number_format((float)$consumed, 2, '.', '')
            );

        } else {
            $accounts = array(
                "total_credits"=>0,
                "credits" => 0,
                "expired" => 0,
                "consumed" => 0
            );
        }

        $cnt = NotificationLog::where('notification_to', $user_id)->where('notification_for', 'C')->whereNull('read_at')->count();

        return response()->json(['status'=> 'success', 'accounts'=> $accounts, "is_read" => ($cnt > 0 ? 1 : 0) ], 200);
    }
    */

    /*
     * API: Customer only
     * Api used for customer app. In the home screen we displaying the credits and checking for the popup notifications
     */

    public function consumer_credits()
    {
        try{
            if(!Auth::guard('driver')->id())
                return response()->json(['status'=>'failed', 'message'=> 'Authentication failed' ], 400);
            $user_id = Auth::guard('driver')->id();
            $accounts=$this->getCreditsInfo($user_id);

            $type='C'; // Customer  
       
            $notifications = $this->popupNotificationsList($user_id, $type);

            return response()->json([
                'status'=> 'success',
                'accounts'=> $accounts,
                "is_read" => $notifications['is_read'], // this will show unread notification available in app jome screen
                'popup_notifications' => $notifications['list'],
                'available_popup_count' => $notifications['count'], // count for unread popup notifications count
            ], 200);
        } catch(\Exception $e) {
             return response()->json([
                'status'=> 'failed',
                'message'=>'Failed to get credit information',
                'message_ar'=>'فشل في الحصول على معلومات الائتمان'
               
            ], 400);
        }
    }


    /*
     * API: Guest only
     * Api used for customer app. In the home screen we displaying the credits and checking for the popup notifications
     */

    public function guest_consumer_credits(Request $request)
    {
        try{
            $accounts = array(
                "credits" => 0,
                "expired" => 0,
                "consumed" => 0
            );
       
            if(isset($request->device_id) && $request->device_id!=''){
              $user_id = $request->device_id;
            }

            if(isset($request->user_type) && $request->user_type!=''){
              $type=$request->user_type;
            }
     
            $cnt = NotificationLog::where('notification_to', $user_id)->with('notification_list')
                ->withCount( ['notification_list' => function($q){ $q->where('is_set', 1); }])
                ->Has( 'notification_list', '>' , 0)
                ->where('notification_for', $type)
                ->whereNull('read_at')
                ->count();


            $popUpnotifications = Notification::select('notifications.*')
                ->join('notifications_log', 'notifications.id', 'notifications_log.notification_id')
                ->where('notifications_log.notification_to', $user_id)
                ->where('notifications_log.notification_for', $type)
                ->where('notifications.is_popup', '1')
                ->where('notifications.is_sent','1')
                ->whereNull('notifications_log.deleted_at')
                ->whereNull('notifications_log.read_popup_at')
                ->with('deal', 'offer','location_info', 'deal.deal', 'transaction', 'transaction.payment_details')
                ->where('notifications.expired_on','>',date("Y-m-d H:i:s"))
                ->orderBy('notifications.id', 'asc');


            $popupCount = $popUpnotifications->count();


            return response()->json([
                'status'=> 'success',
                'accounts'=> $accounts,
                'is_read' => ($cnt > 0 ? 1 : 0), // this will show unread notification available in app jome screen
                'popup_notifications' => null,
                'available_popup_count' => $popupCount, // count for unread popup notifications count
            ], 200);
        } catch(\Exception $e) {
             return response()->json([
                'status'=> 'failed',
                'message'=>'Failed to get credit information',
                'message_ar'=>'فشل في الحصول على معلومات الائتمان'
               
            ], 400);
        }
    }


    function popupNotificationsList($user_id, $type){

        // Send information about notifications are read or not
        // send popup notification if available

        $cnt = NotificationLog::where('notification_to', $user_id)->with('notification_list')
                ->withCount( ['notification_list' => function($q){ $q->where('is_set', 1); }])
                ->Has( 'notification_list', '>' , 0)
                ->where('notification_for', $type)
                ->whereNull('read_at')
                ->count();


        $popUpnotifications = Notification::select('notifications.*')
            ->join('notifications_log', 'notifications.id', 'notifications_log.notification_id')
            ->where('notifications_log.notification_to', $user_id)
            ->where('notifications_log.notification_for', $type)
            ->where('notifications.is_popup', '1')
            ->where('notifications.is_sent','1')
            ->whereNull('notifications_log.deleted_at')
            ->whereNull('notifications_log.read_popup_at')
            ->with('deal', 'offer', 'deal.deal','location_info', 'transaction', 'transaction.payment_details')
            ->where('notifications.expired_on','>',date("Y-m-d H:i:s"))
            ->orderBy('notifications.id', 'asc');


        $popupCount = $popUpnotifications->count();

        $popUpnotifications = $popUpnotifications->first();
        if($popUpnotifications){
            if($this->validForVersion($user_id)) {
                // Need to remove popup notification list from here, need to call other api to fetch popup notification data for old version,
                // then only it will be consider as read

                // read popup notification as default
               
                $update = array('read_popup_at' => date('Y-m-d H:i:s'));
                if(!$popUpnotifications->is_inapp)
                {
                    // if notification doesn't has in-app notification then read this
                    $update['read_at'] = date('Y-m-d H:i:s');
                }
                NotificationLog::where('notification_to', $user_id)
                    ->where('notification_for', 'C')
                    ->where('notification_id', $popUpnotifications->id)
                    ->whereNull('read_popup_at')
                    ->update($update);

            }
            else{
                $popUpnotifications = null;
            }
        }

        return array(
            'count' => $popupCount,
            "is_read" => ($cnt > 0 ? 1 : 0), // 1 - Yet to read,  0 - read
            'list' => $popUpnotifications
        );
    }

    function validForVersion($user_id){
        $device_type = 'android';
        if(isset(Auth::guard('driver')->user()->device_type)){
            $device_type = Auth::guard('driver')->user()->device_type;
        }

        $app_version = Device::where('user_type', 'driver')
                            ->where('device_type', $device_type)
                            ->where('user_id', $user_id)
                            ->orderBy('id', 'desc')
                            ->pluck('app_version')->first();

        $app_version = (substr($app_version, 0,1) == 'v') ? ltrim($app_version, 'v') : $app_version;

       // if($_SERVER['SERVER_NAME'] == 'joyapp.io')
            $request_version = '0.1.40';
        // else
        //     $request_version = '0.0.17';


        if(version_compare($app_version, $request_version) <= 0)
        {
            /*
                By default, version_compare() returns
                -1 if the first version is lower than the second,
                0 if they are equal, and
                1 if the second is lower.
            */
            // Lower Version need to update
            $data = array(
                'status' => 'success',
                'message' => "Allow user to update",
            );

            return true;
        }
        else{
            // Higher Version no need to update
            $data = array(
                'status' => 'success',
                'message' => "Don't Allow user to update",
            );

            return false;
        }
    }


    /* Get credits information of the customer
    
    @param $user_id
    return $accounts
    */
    function getCreditsInfo($user_id){

        $addedCredits = "select ifnull(sum(credits),0) as credits from (
        SELECT a.id, a.start_date, a.end_date, if(a.credit_on = 2, a.amount, (a.amount / a.quantity)) as credits
        from credits as a JOIN consumer_credits as b on a.id = b.credit_id and b.credit_for = 10
            join group_consumers as c on b.credit_to = c.group_id and c.consumer_id = ".$user_id."
        where (a.credit_on = 1 or (a.credit_on = 2 and a.credit_by = 'C') or (a.credit_on = 3 and a.credit_by = 'C'))
        UNION
        SELECT a.id, a.start_date, a.end_date, if(a.credit_on = 2, a.amount, (a.amount / a.quantity)) as credits
        from credits as a JOIN consumer_credits as b on a.id = b.credit_id and b.credit_for = 11 and b.credit_to = ".$user_id."
        where (a.credit_on = 1 or (a.credit_on = 2 and a.credit_by = 'C') or (a.credit_on = 3 and a.credit_by = 'C'))) as x";

        $addedCredits = DB::select($addedCredits);
        $credits = $addedCredits[0]->credits;

        // $consumedCredits = "select ifnull(sum(b.amount_by_credits),0) as consumed
        // from transactions as a join payments as b on a.transaction_no = b.transaction_no
        // where b.amount_by_credits > 0 and (a.payment_status = 'Successful' or a.payment_status = 'Requests'
        //    or a.payment_status = 'Available') and a.status = 1 and a.created_by = ".$user_id." and b.action_code IN ('1','4','5')";


        $consumedCredits = "select ifnull(sum(b.amount_by_credits),0) as consumed
        from transactions as a join payments as b on a.transaction_no = b.transaction_no
        where b.amount_by_credits > 0 and (a.payment_status = 'Successful' or a.payment_status = 'Requests'
           or a.payment_status = 'Available' or a.payment_status = 'Cancelled') and b.payment_status='Successful' and a.status = 1 and a.created_by = ".$user_id." and b.action_code IN ('1','4','5')";



        $consumedCredits = DB::select($consumedCredits);
        $consumed = $consumedCredits[0]->consumed;

        $accounts = array(
            "credits" => number_format((float)($credits-$consumed), 2, '.', ''),
            "expired" => 0,
            "consumed" => number_format((float)$consumed, 2, '.', '')
        );
        return $accounts;
    }

    /*
     * Access: admin, Prefix: api
     * Referance: Send Gifts, Apply coupon credits
     */
    public function eligible_gift_accounts(){

        // Note: Gift Amounts should be send on amounts by exchanges, Transaction share will not added

        $fleets = DB::select("select a.id, a.org_name,(b.credit_amount - ifnull(d.debit_amount, 0)) as credits,  b.credit_amount, d.debit_amount
            from organizations as a join (select payment_to, sum(amount_paid) as credit_amount from exchanges where status = 1 GROUP BY payment_to) as b
              on a.id = b.payment_to
            left JOIN (select fleet_id, sum(amount) as debit_amount from credits where credit_on = 1 GROUP BY fleet_id) as d
            on a.id = d.fleet_id
            where a.company_type = 'F' and a.status = 1");

        $admins = DB::select("select a.id, a.org_name,(b.credit_amount - ifnull(d.debit_amount, 0)) as credits,  b.credit_amount, d.debit_amount
            from organizations as a join (select payment_to, sum(amount_paid) as credit_amount from exchanges where status = 1 GROUP BY payment_to) as b
              on a.id = b.payment_to
            left JOIN (select fleet_id, sum(amount) as debit_amount from credits where credit_on = 1 GROUP BY fleet_id) as d
            on a.id = d.fleet_id
            where a.status = 1 and a.company_type = 'A'");

        $data = array('fleets' => $fleets, 'admins' => $admins);
        return response()->json(['status'=> 'success', 'data'=> $data ], 200);
    }

    public function send_cancelledorder_refund ($transactionNo, $amount) {
        $trans = Transaction::where('transaction_no',$transactionNo)->first();
        $request['quantity']=$trans['quantity'];

        if($trans['deal_id'] == 6 || $trans['deal_id'] == 2) // tires & battaries
            ItemMaster::where('id', $trans['item_id'])
                ->update(['quantity' => DB::raw('quantity + '.$request['quantity'])]);

        ItemOffer::where('id', $trans['offer_id'])->where('item_id', $trans['item_id'])
            ->update(['quantity' => DB::raw('quantity + '.$request['quantity'])]);

        Transaction::where('transaction_no', $transactionNo)
                    ->update(['revised_quantity' => $request['quantity']]);

        $refundArray['transaction_no'] = $transactionNo;
        $refundArray['credit_on'] = 2;
        $refundArray['amount'] = $amount;
        $refundArray['quantity'] = $request['quantity'];       
        $refundArray['start_date'] = date('Y-m-d');      
        $refundArray['end_date'] = date('Y-m-d', strtotime('+1 year'));
        $refundArray['credit_by'] = 'C';
        $refundArray['created_at'] = date('Y-m-d H:i:s');
        $refundArray['created_by'] = 1;
        $refundArray['status'] = 1;
        $refundArray['description'] = 'Partner cancelled purchased deal';
        $credit = Credit::create($refundArray);

        ConsumerCredit::insert([
            'credit_id' => $credit['id'],
            'credit_for' => 11, // INDIVIDUAL
            'credit_to' => $trans['created_by'],
            'created_at' => date('Y-m-d H:i:s')
        ]);

        (new SendPushNotification())->refund_notification($transactionNo, 36);
    }

    public function payment_types(Request $request)
    {
        try{
            $payment_types = Lookup::where('group_id', 7)->where('status', 1)->get();

            $creds = $this->consumer_credits();
            $data = (array)$creds->getData();
            if($data['is_read'])
                unset($data['is_read']);
            if($data['status'])
                unset($data['status']);

            $data["payment_types"] = $payment_types;

            return response()->json(['status' => 'success', 'data' => $data], 200);
        } catch (\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Payment Types not found'], 400);
        }
    }



   /*
    *Get gift data based on the id
    *@param $giftId
    */
     public function getCustomerGiftsData($giftId) {
        try{

         $list = Credit::where('id', $giftId)->first();
         $individuals=ConsumerCredit::where('credit_for',11)->where('credit_id', $giftId)->count();

         $groupsList=ConsumerCredit::where('credit_for',10)->withCount('group_consumers')->with('company_info')->where('credit_id', $giftId)->get();

          return response()->json(['status'=>'success', 'data' => $list, 'individuals'=>$individuals, 'groupsList'=>$groupsList], 200);

        } catch (\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Notifications failed', "error" => $e->getMessage()], 400);
        }
    }

     /*
      * Get all users list based on the gift id and either individual or group users
     */   
     public function gifts_users_list(Request $request) {
        try{
            $list = Credit::where('id', $request->gift_id)->first();
            $data=array();
            if($request->group_id>0){
                $data=$this->getGroupUsersList($request);
            } else {
                $data=$this->getIndividualUsersList($request);
            }
            return response()->json(['status'=>'success', 'gift_data' => $list, 'users_list' => $data], 200);

        } catch (\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Failed to get gift received users', "error" => $e->getMessage()], 400);
        }
    }

    function getGroupUsersList($request){
        $pageno = 1; $pagelength = 10;
        $list =  GroupConsumer::select('c.id','c.first_name', 'c.contact_no', 'c.email', 'c.is_verified')->where('group_consumers.group_id', $request['group_id'])
                ->join('drivers as c', 'group_consumers.consumer_id', 'c.id');

        $totalrecords = $list->orderBy('id', 'desc')->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }
        $list = $list->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;

        return $data;
    }
  
    function getIndividualUsersList($request){
        $pageno = 1; $pagelength = 10;
        $list = ConsumerCredit::select('c.id','c.first_name', 'c.contact_no', 'c.email','c.status', 'c.is_verified')->where('consumer_credits.credit_id',$request['gift_id'])
            ->where('consumer_credits.credit_for',11)
            ->join('drivers as c', 'consumer_credits.credit_to', 'c.id');

        $totalrecords = $list->orderBy('id', 'desc')->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }
        $list = $list->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;

        return $data;
    }
}
