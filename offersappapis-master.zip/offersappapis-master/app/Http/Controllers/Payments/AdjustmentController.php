<?php

namespace App\Http\Controllers\Payments;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Generals\DealController;
use App\Http\Controllers\TransactionController;
use App\Models\Accounts\ConsumerCredit;
use App\Models\Accounts\Credit;
use App\Models\Accounts\PaymentShare;
use App\Models\Accounts\Transaction;
use App\Models\Generals\Lookup;
use Illuminate\Http\Request;
use App\Models\Accounts\Payment;
/* Events calling */
use App\Events\OrderAdjustment;
use App\Events\Emails\AdjustmentCreatedEmail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class AdjustmentController extends Controller
{
    private $adjustment = 3;
    private $individual = 11;

    /**
     * Get all available adjustment's list based on the pagination
     * @param $request
     * @access in admin module
     *
     */
    public function index(Request $request)
    {
        $list = Credit::select('credits.*', 'c.first_name', 'c.last_name', 'c.contact_no' ,'d.title as item_name',
            'b.price', 'b.discount', 'b.quantity' , 'e.org_name', 'f.title as category' )
            ->join('transactions as b', 'credits.transaction_no', 'b.transaction_no')
            ->join('drivers as c', 'b.created_by', 'c.id')
            ->join('item_master as d', 'b.item_id', 'd.id')
            ->join('organizations as e', 'd.delar_id', 'e.id')
            ->join('deals as f', 'd.deal_id', 'f.id')
            ->where('credits.credit_on', $this->adjustment);
        
        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $pageno = 0; $pagelength = 0;

            //If logged in user is dealer
            if(Auth::user()->login_type_id == 18) // Delar
                $list = $list->where('d.delar_id' , Auth::user()->org_id);
          

            $totalrecords = $list->count();
            // If pagination applied then based on the pagelength need to get records
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)){
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
                $list = $list->orderBy('credits.id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength);
            }
            $list = $list->get();
        }else{
            $list = $list->orderBy('credits.id', 'desc')->get();
        }

        $dealShare = new DealController();
        foreach ($list as $row) {
            $pricing = $dealShare->price_logic($row['price'], $row['discount'], $row['deal_id']);
            $row['final_price'] = $row['quantity'] * $pricing['final_price'];
        }

        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $data['data'] = $list;
            $data['current_page'] = $pageno ? $pageno : '1';
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength ? $pagelength : '200';

            return response()->json(['status' => 'success', 'data' => $data], 200);
        }else{
            return response()->json(['status' => 'success', 'data' => $list], 200);
        }
    }

    public function send_adjustment()
    {
        $request=request();
        $rules = [
            'transaction_no' => ['required'],
            'amount' => ['required'],
            'credit_by' => ['required'],
            'description' => ['required'],
            'status' => ['required'],
        ];

        $validator = Validator::make($request->all(), $rules );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $pricing = (new DealController())->bill_price_logic($request['transaction_no']);
        $price_limit = $pricing['sharings']['adjustment_limit'];

        if($request['amount'] > $price_limit)
            return response()->json([ 'status' => "failed", "message" => "Adjustment amount limit was exceeded" ], 400);

        try{
            $refund_for = Transaction::where('transaction_no', $request['transaction_no'])->pluck('created_by')->first();

            $paymentData=Payment::where('transaction_no', $request['transaction_no'])->orderBy('id','ASC')->first();
            if(empty($paymentData)){
                return response()->json(['status'=>'failed', 'message'=> 'Payment not yet done'], 400);
            }

            if($paymentData->payment_on==50){
                 return response()->json(['status'=>'failed', 'message'=> 'Adjustment not applicable for tabby related transactions'], 400);
            }

            $credit_id = Credit::where('credit_on', $this->adjustment)->where('transaction_no', $request['transaction_no'])->pluck('id')->first();

            if(!$credit_id) {
                $request['start_date'] = date('Y-m-d');
                $request['end_date'] = date('Y-m-d', strtotime('+1 year'));
                $request['credit_on'] = $this->adjustment;
                $request['created_at'] = date('Y-m-d H:i:s');
                $request['created_by'] = Auth::id();
                $credit = Credit::create($request->all());

                ConsumerCredit::insert([
                    'credit_id' => $credit['id'],
                    'credit_for' => $this->individual, // INDIVIDUAL
                    'credit_to' => $refund_for,
                    'created_at' => date('Y-m-d H:i:s')
                ]);

                Transaction::where('transaction_no', $request['transaction_no'])
                    ->update(['remarks'=>$request->description]);


                try {
                    // Send notification to consumer , deal admin
                    event(new OrderAdjustment($request['transaction_no'], 37, $request['amount']));

                    // Send email notification to consumer along with invoice
                    event(new AdjustmentCreatedEmail($request['transaction_no'], $request['amount']));
                }
                catch (\Exception $e){
                    Log::error("Adjustment events has error");
                }
            }
            else{
                $request['updated_at'] = date('Y-m-d H:i:s');
                Credit::where('credit_on', $this->adjustment)
                    ->where('transaction_no', $request['transaction_no'])
                    ->update($request->all());
            }

            return response()->json(['status'=> 'success', 'message'=> 'Adjustment created successfully' ], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Adjustment creation failed', "error" => $e->getMessage() ], 400);
        }
    }

    public function adjustment_info($id = null)
    {
        $list = Transaction::select('transactions.transaction_no', 'c.first_name', 'c.last_name', 'c.contact_no',  'c.email', 'd.title as item_name',
            'transactions.price', 'transactions.discount', 'transactions.quantity' ,'transactions.revised_quantity' , 'transactions.created_at', 'e.org_name', 'f.title as category',
            'g.amount', 'g.description', 'g.id as credit_id', 'g.credit_by', 'g.transaction_id', 'g.status' )
            ->join('drivers as c', 'transactions.created_by', 'c.id')
            ->join('item_master as d', 'transactions.item_id', 'd.id')
            ->join('organizations as e', 'd.delar_id', 'e.id')
            ->join('deals as f', 'd.deal_id', 'f.id')
            ->leftJoin('credits as g', function ($qry){
                $qry->on('transactions.transaction_no', 'g.transaction_no')
                    ->where('g.credit_on', $this->adjustment)
                    ->where('g.status', 1);
            })
            ->where('transactions.transaction_no', $id )
            ->first();

        $dealShare = new DealController();
        $pricing = $dealShare->bill_price_logic($id);
        $list['final_price'] = $pricing['final_price'];
        $list['price_limit'] = $pricing['sharings']['adjustment_limit'];

        $statusArray =  (new TransactionController())->transaction_row_status($list);
        $list['transaction_status'] = $statusArray['transaction_status'];
        $list['payment_method'] = $this->findPaymentMethod($list['payment_with'], $list['payment_on']);

        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    public function findPaymentMethod($payment_with, $payment_on){
        $payment_method = '-';
        if($payment_with == 7)
            $payment_method = 'Joy Credits';
        else if($payment_with == 8 || $payment_with == 9) {
            if($payment_on == '')
                $payment_method = '-';
            else{
                $payment_method = ($payment_with == 9 ? 'Joy Credits & ' : '').
                    Lookup::where('id', $payment_on)->pluck('entity_name')->first();
            }
        }

        return $payment_method;
    }

}
