<?php

namespace App\Http\Controllers\Payments;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Generals\DealController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\TabbyTransactionController;
use App\Http\Controllers\TransactionController;
use App\Models\Accounts\ConsumerCredit;
use App\Models\Accounts\Credit;
use App\Models\Accounts\Payment;
use App\Models\Accounts\Transaction;
use App\Models\Generals\Lookup;
use App\Models\Generals\Role;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use Illuminate\Http\Request;

/* Events calling */
use App\Events\OrderRefunded;
use App\Events\Emails\RefundCreatedEmail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Events\cancelTranaction;

class RefundController extends Controller
{
    private $refund = 2;
    private $adjustment = 3;
    private $group = 10;
    private $individual = 11;

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $list = Credit::select('credits.*', 'c.first_name', 'c.last_name', 'c.contact_no' ,'d.title as item_name',
            'b.price', 'b.discount', 'b.quantity', 'e.org_name', 'f.title as category' )
            ->join('transactions as b', 'credits.transaction_no', 'b.transaction_no')
            ->join('drivers as c', 'b.created_by', 'c.id')
            ->join('item_master as d', 'b.item_id', 'd.id')
            ->join('organizations as e', 'd.delar_id', 'e.id')
            ->join('deals as f', 'd.deal_id', 'f.id')
            ->where('credits.credit_on', $this->refund);

        $portal_user = Auth::id();
        if($portal_user){
            // check for delar
            $login_type_id = Role::where('id', Auth::user()->role_id)->pluck('login_type_id')->first();
            if($login_type_id == 18) // Delar
                $list = $list->where('d.delar_id' , Auth::user()->org_id);
        }

        // $list = $list->orderBy('credits.id', 'desc')->get()->toArray();
        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $pageno = 0; $pagelength = 0;
            $totalrecords = $list->count();

            // If pagination applicable then get data based on the pagelength
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
                $list = $list->orderBy('credits.id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength);
            }

            $list = $list->get();
        }else{
            $list = $list->orderBy('credits.id', 'desc')->get();
        }

        $dealShare = new DealController();
        foreach ($list as $row) {
            $pricing = $dealShare->price_logic($row['price'], $row['discount'], $row['deal_id']);
            $row['final_price'] = $row['quantity'] * $pricing['final_price'];
        }

        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $data['data'] = $list;
            $data['current_page'] = $pageno ? $pageno : '1';
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength ? $pagelength : '200';
            return response()->json(['status' => 'success', 'data' => $data], 200);
        }else{
            return response()->json(['status' => 'success', 'data' => $list], 200);
        }
    }

    public function refund_info($id = null)
    {
        $list = Transaction::select('p.amount_by_banking','p.amount_by_credits','transactions.transaction_no', 'c.first_name',
            'c.last_name', 'c.contact_no', 'c.email' ,'d.title as item_name', 'transactions.price', 'transactions.discount',
            'transactions.quantity', 'transactions.revised_quantity', 'transactions.redeem_quantity', 'transactions.payment_status',
            'transactions.created_at', 'transactions.payment_with', 'p.payment_on', 'e.org_name', 'f.title as category','f.id as deal_id',
            'g.amount', 'g.description', 'g.id as credit_id', 'g.credit_by', 'g.transaction_id', 'g.status', 'p.response_result','p.action_code')
            ->join('drivers as c', 'transactions.created_by', 'c.id')
            ->join('item_master as d', 'transactions.item_id', 'd.id')
            ->join('organizations as e', 'd.delar_id', 'e.id')
            ->join('payments as p', function ($qry){
                $qry->on('transactions.transaction_no', 'p.transaction_no')
                    ->where('p.payment_status', 'Successful')
                    ->orderBy('p.id', 'DESC');
            })
            ->join('deals as f', 'd.deal_id', 'f.id')
            ->leftJoin('credits as g', function ($qry){
                $qry->on('transactions.transaction_no', 'g.transaction_no')
                    ->where('g.credit_on', $this->refund)
                    ->where('g.status', 1);
            })
            ->where('transactions.transaction_no', $id )
            ->first();

        $dealShare = new DealController();
        $pricing = $dealShare->bill_price_logic($id);
        $list['final_price'] = $pricing['final_price'];
        $list['service_cost'] = $pricing['service_cost'];
        $list['filter_cost'] = $pricing['filter_cost'];
        $list['price_after_discount'] = $pricing['price_after_discount'];

        $statusArray =  (new TransactionController())->transaction_row_status($list);
        $list['transaction_status'] = $statusArray['transaction_status'];
        $list['payment_method'] = $this->findPaymentMethod($list['payment_with'], $list['payment_on']);

        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    public function send_refund()
    {
        $request=request();
        $rules = [
            'transaction_no' => ['required'],
            // 'amount' => ['required'],
            'quantity' => ['required'],
            // 'credit_by' => ['required'],
            'description' => ['required'],
            'status' => ['required'],
        ];

        $validator = Validator::make($request->all(), $rules );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $refund_for = Transaction::where('transaction_no', $request['transaction_no'])->first();

        $totalAvailableQuanity = $refund_for['quantity']-$refund_for['redeem_quantity'];


        if($totalAvailableQuanity <= 0){
            return response()->json(['status'=>'failed', 'message'=> 'Transaction already redeemed, Refund not allowed' ], 400);
        } else if($refund_for['revised_quantity'] > 0){
            return response()->json(['status'=>'failed', 'message'=> 'Transaction already refunded, Refund not allowed' ], 400);
        }

        if($request['quantity'] > $totalAvailableQuanity ){
            return response()->json(['status'=>'failed', 'message'=> 'Refund quantity exceeded than Available quantity' ], 400);
        }



        $paymentData = Payment::where('transaction_no', $request['transaction_no'])
                        ->where('payment_status', 'Successful')->where('payment_type', 1)->first();
        if($paymentData){
            if(!($paymentData->action_code == 5 || $paymentData->action_code == 1)){
                return response()->json(['status'=>'failed', 'message'=> "Payment not yet done, Can't able to refund this transaction"   ], 400);
            }
        }else{
            return response()->json(['status'=>'failed', 'message'=> "Payment not yet done, Can't able to refund this transaction"   ], 400);
        }

        if(($request['quantity']<$refund_for['quantity']) && $paymentData->payment_on==50 ){
            return response()->json(['status'=>'failed', 'message'=> 'Partial Refund is not possible for transaction done with tabby' ], 400);
        }

        // Refund can be done by bank for 14 days of purchase item
        $refund_for_14days = date('Y-m-d ', strtotime($refund_for['created_at'].'+14 days'));
        if(strtotime(date('Y-m-d')) >  strtotime($refund_for_14days) ){
            // Send whole refund amount as credits
            // return response()->json(['status'=>'failed', 'message'=> 'Refund time expired' ], 400);
        }

        $refundTotalAmount = $this->requestForTotalRefundAmount($request['transaction_no'], $request['quantity'], $refund_for);

        $request['amount'] = $refundTotalAmount;
        if($refundTotalAmount <= 0){
            return response()->json(['status'=>'failed', 'message'=> 'Invalid Refund Amount' ], 400);
        }

        try{
            $amountTypes = $this->requestForRefundAmountTypes($request['transaction_no'], $refundTotalAmount );

            $this->requestToCreateRefundPayments($request['transaction_no'], $amountTypes, $refund_for['created_by']);

            //update quantity
            Transaction::where('transaction_no', $request['transaction_no'])
                ->update(['revised_quantity' => $request['quantity'],'remarks'=>$request->description]);

            $this->update_refund_invoice_no($request['transaction_no']);

            if($request['quantity']>0){
                $trans = Transaction::where('transaction_no',$request['transaction_no'])->first();
                // update available quantity
                if($trans['deal_id'] == 6 || $trans['deal_id'] == 2) // tires & battaries
                    ItemMaster::where('id', $trans['item_id'])
                        ->update(['quantity' => DB::raw('quantity + '.$request['quantity'])]);

                ItemOffer::where('id', $trans['offer_id'])->where('item_id', $trans['item_id'])
                    ->update(['quantity' => DB::raw('quantity + '.$request['quantity'])]);
            }

            try{
                // Send email notification to consumer along with invoice
                event(new RefundCreatedEmail($request['transaction_no'], $request['quantity'], $refundTotalAmount));
                // Send notification to consumer , deal admin
                event(new OrderRefunded($request['transaction_no'], 36, $refundTotalAmount));
            } catch(\Exception $e){
                Log::error("Failed to send notification on refunds: ". $request['transaction_no']);
            }

            return response()->json(['status'=> 'success', 'message'=> 'Refund created successfully' ], 200);
        }
        catch (\Exception $e) {
            return response()->json(['status'=>'failed', 'message'=> 'Refund creation failed', "error" =>$e->getMessage()], 400);
        }
    }

    private function requestForTotalRefundAmount($transaction_no, $requestQuantity, $refund_for){

        $dealShare = new DealController();
        $pricing = $dealShare->bill_price_logic($transaction_no);
        $finalPrice = $pricing['final_price'];

        $refundQuanity = $requestQuantity;
        $refundTotalAmount = 0;
        if($refund_for['quantity'] > $refundQuanity || $refund_for['redeem_quantity '] > 0)
        {
            // Partial Refund
            // Refund allows after redeem also
            $paymentData = Payment::where('transaction_no', $transaction_no)
                ->where('payment_status','Successful')->orderBy('id','asc')->first();

            if($paymentData['payment_on'] == '50'){
                // Payment by tabby
                return response()->json(['status'=>'failed', 'message'=> 'Partial Refund not allowed on Tabby payment Transaction' ], 400);
            }

            $item_price = ($pricing['price_after_discount'] / $refund_for['quantity']) * $refundQuanity;

            $service_cost = 0;
            if($refund_for['deal_id']== "4" || $refund_for['deal_id']== "5"){ // 4 - Cleaning, 5 - Deatiling
                $service_cost = ($pricing['service_cost'] / $refund_for['quantity']) * $refundQuanity;
            }
            $refundTotalAmount = round($item_price + $service_cost, 2);
        }
        else if($refund_for['quantity'] == $refundQuanity)
        {
            // Full Refund
            // Need to give total price
            $refundTotalAmount = $finalPrice;
        }
        return round($refundTotalAmount, 2);
    }

    private function requestForRefundAmountTypes($transaction_no, $refundTotalAmount){

        $amountTypes = array(
            'credit_by' => 'C', // C- Credits, B- Banking, CB - Both
            'bank_amount' => 0,
            'credit_amount' => 0,
        );

        $paymentData = Payment::where('transaction_no', $transaction_no)
            ->where('payment_status','Successful')->orderBy('id','asc')->first();

        $refund_for_14days = date('Y-m-d', strtotime($paymentData->created_at.'+14 days'));
        if(strtotime(date('Y-m-d')) >  strtotime($refund_for_14days) ){
            // Send whole amount as credits only after 14 days of first payment
            $amountTypes['credit_amount'] = round($refundTotalAmount, 2);
            return $amountTypes;
        }

        // check is the transaction already refunded
        $refund_quantity = Transaction::where('transaction_no', $transaction_no)->pluck('revised_quantity')->first();

        $enableRefund = false;
        $bankingAmount = $paymentData->amount_by_banking;
        $creditsAmount = $paymentData->amount_by_credits;
        if($refund_quantity > 0){
            // already given some refund
            $refundsBank = $refundsCredits = 0;
            $refunds = Credit::where('transaction_no', $transaction_no)
                        ->select('credit_by')->selectRaw('sum(amount) as amount')
                        ->groupBy('credit_by')->get();

            foreach($refunds as $refund){
                if($refund['credit_by'] == 'C')
                    $refundsCredits = $refund['amount'];
                else if($refund['credit_by'] == 'B')
                    $refundsBank = $refund['amount'];
            }

            $creditsAmount = $creditsAmount - $refundsCredits;
            $bankingAmount = $bankingAmount - $refundsBank;
        }

        if ($bankingAmount == '0' && $creditsAmount > 0) {
            // Only by credits
            $amountTypes['credit_by'] = 'C';
            $enableRefund = true;
        } else if ($bankingAmount > 0 && $creditsAmount == 0) {
            // Only by banking
            $amountTypes['credit_by'] = 'B';
            $enableRefund = true;
            // 34 - Google Pay
            // 33 - Apple Pay, 35 - Credit Cards - Payment by Urway, 50 -Payment by Tabby

        } else if ($bankingAmount > 0 && $creditsAmount > 0) {
            // Payment by Credits and Banking
            if ($creditsAmount >= $refundTotalAmount && $creditsAmount > 0) {
                // Refund amount sent as credits only, when refund amount less than or equal credits spent on payment
                $amountTypes['credit_by'] = 'C';
                $enableRefund = true;
            } else {
                // Refund amount sent as credits and banking also
                // Send credits spent on payment as refund amount first, then send remaining amount as banking

                // 34 - Google Pay
                // 33 - Apple Pay, 35 - Credit Cards - Payment by Urway
                // 50 - Refund Payment by Tabby

                $enableRefund = true;

                if ($enableRefund) {
                    // Two records fpr refund credits, one for Credits and second for banking
                    $amountTypes = array(
                        'credit_by' => 'CB', // C- Credits, B- Banking, CB - Both
                        'bank_amount' => round($refundTotalAmount - $creditsAmount, 2),
                        'credit_amount' => round($creditsAmount, 2),
                    );

                    $enableRefund = false; // Doesn't allow refund again
                }
            }
        }


        if($enableRefund)
        { 
            // Single record for refund credits here
            $amountTypes['bank_amount'] = $amountTypes['credit_by'] == 'B' ? $refundTotalAmount : 0;
            $amountTypes['credit_amount'] = $amountTypes['credit_by'] == 'C' ? $refundTotalAmount : 0;
        }

        if($amountTypes['bank_amount'] < 3)
        {
            // if bank amount lessthan 3 SAR send those amount also as credits
            $amountTypes['credit_amount'] += $amountTypes['bank_amount'];
            $amountTypes['bank_amount'] = 0;
            $amountTypes['credit_by'] = 'C';
        }

        return $amountTypes;
    }

    private function requestToCreateRefundPayments($transaction_no, $amountTypes, $created_by){

        $totalRefundAmount = $amountTypes['bank_amount'] + $amountTypes['credit_amount'];
        $data = array(
            'transaction_no' => $transaction_no,
            'quantity' => request()->quantity,
            'amount' => $totalRefundAmount,
            'credit_by' => $amountTypes['credit_by'],
            'description' => request()->description ?? '',
        );

        if($amountTypes['credit_by'] == 'B' || $amountTypes['credit_by'] == 'C')
        {
            // Refund by credits or banking
            $this->refund_payment_records(
                $transaction_no,
                $amountTypes['bank_amount'],
                $amountTypes['credit_amount'],
                $amountTypes['credit_by']
            );
            $this->sendRefundAmount($data, $created_by);
        }
        else if($amountTypes['credit_by'] == 'CB'){
            // Refund by credits and banking
            $data['amount'] = $amountTypes['credit_amount'];
            $data['credit_by'] = 'C';
            $this->sendRefundAmount($data, $created_by);
            $data['amount'] = $amountTypes['bank_amount'];
            $data['credit_by'] = 'B';
            $this->sendRefundAmount($data, $created_by);

            $this->refund_payment_records(
                $transaction_no,
                $amountTypes['bank_amount'],
                $amountTypes['credit_amount'],
                $amountTypes['credit_by']
            );
        }

        $refundAmountOnBank = $amountTypes['bank_amount'];
        if($refundAmountOnBank > 0) {
            // 33 - Apple Pay, 35 - Credit Cards - Payment by Urway, 50 - Refund Payment by Tabby
            $responseArray = $this->bank_refund($transaction_no, $refundAmountOnBank, request()->ip());

            if (!isset($responseArray['payment_status'])) {
                Log::error('Refund Payment by bank gateway failed');
            }
        }
    }

    private function refund_payment_records($transaction_no, $bank_amount = 0, $credit_amount = 0, $credit_by = 'C'){

        $trans_details = Transaction::where('transaction_no', $transaction_no)->first();
        $paymentData = Payment::where('transaction_no', $transaction_no)
                            ->where('payment_status','Successful')
                            ->where('payment_type', 1) // 1 - Main Payment
                            ->orderBy('id','asc')->first(); // Fetch first payment record only

        $payment_no = date('Ymd').sprintf('%02d',$trans_details->deal_id)
            .sprintf('%04d',$trans_details->item_id).mt_rand(1000, 9999);

        $payments = array(
            "payment_no" => $payment_no,
            "transaction_no" => $transaction_no,
            "payment_type" => 2, // Refund Payment
            "payment_on" => $paymentData->payment_on,
            "amount_by_banking" => $bank_amount,
            "amount_by_credits" => $credit_amount,
            "action_code" => 2, // 2 - Refund payment
            "created_at" => date('Y-m-d H:i:s'),
        );

        if($paymentData->payment_on == 34 || $credit_by == 'C')
        {
            // 34- Google Pay, C - Refund by Credits
            $payments['payment_status'] = 'Successful';
        }

        Payment::insert($payments);
    }

    private function bank_refund($transaction_no, $refundAmount = 0, $ip){

        // This Refund functionlaity for 34 - Apple Pay, 35 - Credit Cards by Urway Payment Gateway
        // 50 - Tabby refunds

        $paymentData = Payment::where('transaction_no', $transaction_no)
                            ->where('payment_status','Successful')
                            ->where('payment_type', 1) // 1 - Main Payment
                            ->orderBy('id','asc')->first(); // Fetch first payment record only

        try {
            if ($paymentData->payment_on == 50) {
                $result = (new TabbyTransactionController())->refundTabbypayment($paymentData->payid, $refundAmount);
 
                return $result;
            } else
                $result = (new PaymentController())->refund_payments($paymentData->payid, $refundAmount, $ip);

            $resultData = '';
            if (isset($result['data']))
                $resultData = $result['data'];

            if (!empty($resultData)) {
                $updatePayment = array(
                    "payment_status" => $result['payment_status'],
                    "payid" => $result['tranid'],
                    "response_code" => $resultData->responseCode ?? '000',
                    "response_amount" => $resultData->amount,
                    "response_result" => $result['Response'],
                    "updated_at" => date('Y-m-d H:i:s'),
                );

                $payment_no = Payment::where('transaction_no', $transaction_no)
                    ->where('payment_type', 2)// 2 - Refund Payment
                    ->pluck('payment_no')->first();

                Payment::where('payment_no', $payment_no)->update($updatePayment);
            }

            return $result;
        }
        catch (\Exception $e) {
            Log::error("Refund Bank payment failed. ". $e->getMessage());
        }
    }

    public function sendRefundAmount($request, $created_by){
        $request['start_date'] = date('Y-m-d');
        $request['end_date'] = date('Y-m-d', strtotime('+1 year'));
        $request['credit_on'] = $this->refund;
        $request['created_at'] = date('Y-m-d H:i:s');
        $request['created_by'] = Auth::id();

        $creditId = Credit::insertGetId($request);
        ConsumerCredit::insert([
            'credit_id' => $creditId,
            'credit_for' => $this->individual, // INDIVIDUAL
            'credit_to' => $created_by,
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }

    public function findPaymentMethod($payment_with, $payment_on){
        $payment_method = '-';
        if($payment_with == 7)
            $payment_method = 'Joy Credits';
        else if($payment_with == 8 || $payment_with == 9) {
            if($payment_on == '')
                $payment_method = '-';
            else{
                $payment_method = ($payment_with == 9 ? 'Joy Credits & ' : '').
                    Lookup::where('id', $payment_on)->pluck('entity_name')->first();
            }
        }

        return $payment_method;
    }

    private function update_refund_invoice_no($transaction_id){

        $successCount = Transaction::join('payments', 'payments.transaction_no', 'transactions.transaction_no')
            ->where('transactions.transaction_no', $transaction_id)
            ->where('transactions.payment_status', 'Successful')
            ->where('payments.payment_status', 'Successful')
            ->where('payments.payment_type', '=', 2) // 2 - Refund Payment
            ->whereNull('payments.invoice_no')
            ->count();

        if(!$successCount) // Not Eligible for invoice - For Successful payment ony eligible
            return false;

        $successCount = Payment::where('payment_type', 2)->whereNotNull('invoice_no')->count();

        $paymentData = Payment::where('transaction_no', $transaction_id)
            ->where('payment_status','Successful')
            ->where('payment_type', 2) // 1 - Main Paymentg
            ->orderBy('id','desc') // Fetch latest payment record only
            ->first();

        if(!isset($paymentData->payment_no))
            return false;

        $invoiceNo = 'R-'. (100000000 + $successCount + 1);
        Payment::where('transaction_no', $transaction_id)
            ->where('payment_no', $paymentData->payment_no)
            ->where('payment_type', 2) // 2 - Refund Payment
            ->update(['invoice_no' => $invoiceNo]);
    }


    public function cancel_transaction_refund($request, $refund_for)
    {
        
        $totalAvailableQuanity = $refund_for['quantity'];

        if($request['quantity'] > $totalAvailableQuanity ){
            return ['status'=>'failed', 'message'=> 'Refund quantity exceeded than Available quantity' ];
        }

        $paymentData = Payment::where('transaction_no', $request['transaction_no'])
                        ->where('payment_status', 'Successful')->where('payment_type', 1)->first();

        $refundTotalAmount = $this->requestForTotalRefundAmount($request['transaction_no'], $request['quantity'], $refund_for);

        $request['amount'] = $refundTotalAmount;
        if($refundTotalAmount <= 0){
            return ['status'=>'failed', 'message'=> 'Invalid Refund Amount' ];
        }

        try{
            $amountTypes = $this->requestForRefundAmountTypes($request['transaction_no'], $refundTotalAmount );

            $this->requestToCreateRefundPayments($request['transaction_no'], $amountTypes, $refund_for['created_by']);

            //update quantity
            Transaction::where('transaction_no', $request['transaction_no'])
                ->update(['revised_quantity' => $request['quantity'],'payment_status' => 'Cancelled','remarks'=>$request->description]);


            $this->update_refund_invoice_no($request['transaction_no']);

            if($request['quantity']>0){
                $trans = Transaction::where('transaction_no',$request['transaction_no'])->first();
                // update available quantity
                if($trans['deal_id'] == 6 || $trans['deal_id'] == 2) // tires & battaries
                    ItemMaster::where('id', $trans['item_id'])
                        ->update(['quantity' => DB::raw('quantity + '.$request['quantity'])]);

                ItemOffer::where('id', $trans['offer_id'])->where('item_id', $trans['item_id'])
                    ->update(['quantity' => DB::raw('quantity + '.$request['quantity'])]);
            }

            return ['status'=> 'success', 'message'=> 'Cancellation created successfully' ];
        }
        catch (\Exception $e) {
            return ['status'=>'failed', 'message'=> 'Failed to create cancellation', "error" =>$e->getMessage()];
        }
    }
}
