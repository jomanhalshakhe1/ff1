<?php

namespace App\Http\Controllers\Payments;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Inventory\GiftCredit;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class GiftsCreditsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $pageno = 1; $pagelength = 10;
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $totalrecords = GiftCredit::count();
        $list = GiftCredit::orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();
        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'amount' => 'required|max:10',
                'user_group' => ['required'],
                'no_of_users' => ['required', 'max:100' , 'min:1' ],
                'apply_for' => ['required'],
                'credits_expiry' => ['required'],
                'notification_title' => ['required'],
                'notification_title_ar' => ['required'],
                'notification_message' => ['required'],
                'notification_message_ar' => ['required'],
                'start_date' => ['required'],
                'end_date' => ['required'],
                'status' => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $request['created_at']=date("Y-m-d H:i:s");
        

            $insertArray=$request->all();
            GiftCredit::insert($insertArray);
            return response()->json(['status'=>'success', 'message'=> 'Gift credit details created successfully'], 200);
        }
        catch (\Exception $e)
        {
             return response()->json(['status'=>'failed', 'message'=> 'Failed to create new gift credit details','error'=>$e->getMessage()], 400);
        } 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $list=GiftCredit::where('id', $id)->first();
        if($list)
            return response()->json(['status'=>'success', 'data'=> $list], 200);
        } else {
             return response()->json(['status'=>'failed', 'message'=> 'Failed to get gift credit details'], 400);
        } 
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(),
            [
                'amount' => 'required|max:10',
                'user_group' => ['required'],
                'no_of_users' => ['required', 'max:100' , 'min:1' ],
                'apply_for' => ['required'],
                'credits_expiry' => ['required'],
                'notification_title' => ['required'],
                'notification_title_ar' => ['required'],
                'notification_message' => ['required'],
                'notification_message_ar' => ['required'],
                'start_date' => ['required'],
                'end_date' => ['required'],
                'status' => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            
            $request['updated_at']=date("Y-m-d H:i:s");
            $updateArray=$request->all();
            GiftCredit::where('id', $id)->update($updateArray);
            return response()->json(['status'=>'success', 'message'=> 'gift credit details modified successfully'], 200);
        }
        catch (\Exception $e)
        {
             return response()->json(['status'=>'failed', 'message'=> 'Failed to modify gift credit details','error'=>$e->getMessage()], 400);
        } 
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
