<?php

namespace App\Http\Controllers;

use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

use Maatwebsite\Excel\Facades\Excel;
use App\Imports\DealsBulkUpload;
use App\Models\Inventory\OfferLocation;
use App\Models\Generals\Slider;

class ItemController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $list = ItemMaster::where('status', 1)->with('delar', 'offer', 'deal')->get();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request['offer'] = json_decode($request['offer'], true);
        $validator = Validator::make($request->all(),
            [
                'title' => ['required', 'string', 'max:100' ],
                'code' => ['required', 'string', 'max:20' ],
                'price' => ['string', 'max:15' ],
                'company' => ['string', 'max:60' ],
                'quantity' => ['required'],
                'dimensions' => ['required'],
                'deal_id' => ['required'],
                'delar_id' => ['required'],
                'description' => ['required' ],
                'thumbnail' => ['required', 'mimes:jpeg,jpg,png', 'max:500' ],
                'offer.discount' => ['required' ],
                'offer.start_date' => ['required' ],
                'offer.end_date' => ['required' ],
                'offer.description' => ['required' ],
                'offer.terms' => ['required' ],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/deals/battery/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/deals/battery/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('deals/battery/', $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $insert = array(
                'title' => $request['title'],
                'code' => $request['code'],
                'price' => $request['price'],
                'company' => $request['company'],
                'quantity' => $request['quantity'],
                'dimensions' => $request['dimensions'],
                'deal_id' => $request['deal_id'],
                'delar_id' => $request['delar_id'],
                'description' => $request['description'],
                'thumbnail_url' => $request['thumbnail_url'],
                'created_at' => date('Y-m-d H:i:s')
            );

            $item_id = ItemMaster::insertGetId($insert);

            $insert = array(
                'item_id' => $item_id,
                'deal_id' => $request['deal_id'],
                'discount' => $request['offer']['discount'],
                'start_date' => $request['offer']['start_date'],
                'end_date' => $request['offer']['end_date'],
                'description' => $request['offer']['description'],
                'terms' => $request['offer']['terms'],
                'created_at' => date('Y-m-d H:i:s')
            );

            ItemOffer::insert($insert);
            return response()->json(['status'=>'success', 'message'=> 'ItemMaster created successfully'], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'ItemMaster creation failed'], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $list = ItemMaster::where('id', $id)->first();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request['offer'] = json_decode($request['offer'], true);
        $validator = Validator::make($request->all(),
            [
                'title' => ['required', 'string', 'max:100' ],
                'code' => ['required', 'string', 'max:20' ],
                'price' => ['string', 'max:15' ],
                'company' => ['string', 'max:60' ],
                'quantity' => ['required'],
                'dimensions' => ['required'],
                'deal_id' => ['required'],
                'delar_id' => ['required'],
                'description' => ['required' ],
                'thumbnail' => ['required', 'mimes:jpeg,jpg,png', 'max:500' ],
                'offer.discount' => ['required' ],
                'offer.start_date' => ['required' ],
                'offer.end_date' => ['required' ],
                'offer.description' => ['required' ],
                'offer.terms' => ['required' ],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/deals/battery/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/deals/battery/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('deals/battery/', $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $insert = array(
                'title' => $request['title'],
                'code' => $request['code'],
                'price' => $request['price'],
                'company' => $request['company'],
                'quantity' => $request['quantity'],
                'dimensions' => $request['dimensions'],
                'deal_id' => $request['deal_id'],
                'delar_id' => $request['delar_id'],
                'description' => $request['description'],
                'thumbnail_url' => $request['thumbnail_url'],
                'updated_at' => date('Y-m-d H:i:s')
            );

            ItemMaster::where('id', $id)->update($insert);

            $insert = array(
                'discount' => $request->offer->discount,
                'start_date' => $request->offer->start_date,
                'end_date' => $request->offer->end_date,
                'description' => $request->offer->description,
                'terms' => $request->offer->terms,
                'updated_at' => date('Y-m-d H:i:s')
            );

            ItemOffer::where('item_id', $id)->update($insert);

            return response()->json(['status'=>'success', 'message'=> 'ItemMaster updated successfully'], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'ItemMaster updation failed'], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    public function upload_excel(){
        return view('uploads');
    }

    public function upload_excel_file(Request $request){

        $validator = Validator::make($request->all(),[
            'deals_list'  => 'required|mimes:xls,xlsx',
            'locationId'  => 'required',
            'dealerId'  => 'required'
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }




         $path = $request->file('deals_list')->getRealPath();
         $data = Excel::toArray(new DealsBulkUpload, $request->file('deals_list'));
         $i=1;
         if(count($data) > 0)
        {
            foreach($data as $key => $value)
            {
                foreach($value as $row)
                {
                     $tireData=ItemMaster::where('code', trim($row['parts']))->first();

                     echo $tireData->id." ".$tireData->code;
                     if(!empty($tireData)){

                                     $content = file_get_contents($row['images']);
                        //Store in the filesystem.

                        $headers = get_headers($row['images'], 1);
                        $type = $headers["Content-Type"];
                        $extension='jpg';
                        if($headers["Content-Type"]=='image/webp'){
                            $extension='jpg';
                        } else  if($headers["Content-Type"]=='image/png'){
                            $extension='png';
                        } 
                    
                        $destinationPath = public_path() . '/uploads/deals/tires/';
                        $safeName = "thumb".Str::random(10) . '.'.$extension ;
                        $sliderName = "slider".Str::random(10) . '.'.$extension;
                        $thumbURL=$destinationPath.$safeName;
                        $sliderImg=$destinationPath.'sliders/'.$sliderName;
                        $fp = fopen($thumbURL, "w");
                        fwrite($fp, $content);
                        $fp1 = fopen($sliderImg, "w");
                        fwrite($fp1, $content);
                        fclose($fp);


                        $masterArray=array('thumbnail_url'=>'/uploads/deals/tires/'.$safeName);

                        $id=$tireData->id;
                        ItemMaster::where('id', $id)->update($masterArray);

                      
                        $sDataArray=array('thumbnail_url'=>'/uploads/deals/tires/sliders/'.$sliderName);
                        Slider::where('item_id', $id)->update($sDataArray);

                     }
                    
                }
            }
            
        }

    }

    public function upload_tire_images()
    {
        $tires = ItemMaster::where('deal_id', 2)->where('status', 3)->limit(100)->get();

        foreach ($tires as $row) {
            $content = file_get_contents($row['thumbnail_url']);
            //Store in the filesystem.

            $headers = get_headers($row['thumbnail_url'], 1);
            $type = $headers["Content-Type"];
            $extension = 'jpg';
            if ($headers["Content-Type"] == 'image/webp') {
                $extension = 'jpg';
            } else if ($headers["Content-Type"] == 'image/png') {
                $extension = 'png';
            }

            $destinationPath = public_path() . '/uploads/deals/tires/';
            $safeName = "thumb" . Str::random(10) . '.' . $extension;
            $sliderName = "slider" . Str::random(10) . '.' . $extension;
            $thumbURL = $destinationPath . $safeName;
            $sliderImg = $destinationPath . 'sliders/' . $sliderName;
            $fp = fopen($thumbURL, "w");
            fwrite($fp, $content);
            $fp1 = fopen($sliderImg, "w");
            fwrite($fp1, $content);
            fclose($fp);

            $masterArray = array('thumbnail_url' => '/uploads/deals/tires/' . $safeName, 'status' => 1);

            $id = $row['id'];
            ItemMaster::where('id', $id)->update($masterArray);
            ItemOffer::where('item_id', $id)->update(['status' => 1]);

            $sDataArray = array('thumbnail_url' => '/uploads/deals/tires/sliders/' . $sliderName);
            Slider::where('item_id', $id)->update($sDataArray);
        }
    }

    public function upload_excel_fileold(Request $request){

        $validator = Validator::make($request->all(),[
            'deals_list'  => 'required|mimes:xls,xlsx',
            'locationId'  => 'required',
            'dealerId'  => 'required'
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }




         $path = $request->file('deals_list')->getRealPath();
         $data = Excel::toArray(new DealsBulkUpload, $request->file('deals_list'));
         $i=1;
         if(count($data) > 0)
        {
            foreach($data as $key => $value)
            {
                foreach($value as $row)
                {


                     $tireCount=ItemMaster::where('code', trim($row['parts']))->count();
                    //echo $row['parts']."---".$tireCount."---".$i."<br>";
                    $i++;
                    if($tireCount==0){

                    $dealPrice=$row['retail_price_without_vat']+($row['retail_price_without_vat']*15/100);
                    $dealPrice=round($dealPrice,2);

                     $desc=trim($row['parts']).' '.trim($row['brandname']).' '.trim($row['tiresize']).' '.trim($row['yearofproduction']);

                    if(trim($row['patternname'])!='**'){
                        $desc=trim($row['parts']).' '.trim($row['brandname']).' '.trim($row['tiresize']).' '.trim($row['patternname']).' '.trim($row['yearofproduction']);
                    }
                    

                    $title=trim($row['brandname']).' '.trim($row['tiresize']);
                     $sizes=explode(" ",trim($row['tiresize']));


                   //   print_r($sizes);
                   // echo $row['parts']." ",$row['tiresize'], "<br>";
                    $sizeWidth=trim($sizes['0']);
                    $size=trim($sizes['1']);

                    $sizeArray=explode("/",$sizeWidth);

                    $width=$sizeArray['0']; $height=0;
                    if(count($sizeArray)>1){
                        $height=$sizeArray['1'];
                    } else {
                       echo $row['parts']."<br>" ;
                    }
                    
                    $content = file_get_contents($row['images']);
                    //Store in the filesystem.

                    $headers = get_headers($row['images'], 1);
                    $type = $headers["Content-Type"];
                    $extension='jpg';
                    if($headers["Content-Type"]=='image/webp'){
                        $extension='jpg';
                    } else  if($headers["Content-Type"]=='image/png'){
                        $extension='png';
                    } 

// $extensionArray=explode('/', $type);

                     // $extension = $row['images']->extension()?: 'png';
                    $destinationPath = public_path() . '/uploads/deals/tires/';
                    $safeName = "thumb".Str::random(10) . '.'.$extension ;

                    $sliderName = "slider".Str::random(10) . '.'.$extension;

                    $thumbURL=$destinationPath.$safeName;
                    $sliderImg=$destinationPath.'sliders/'.$sliderName;

                    $fp = fopen($thumbURL, "w");
                    fwrite($fp, $content);

                    $fp1 = fopen($sliderImg, "w");
                    fwrite($fp1, $content);



                    fclose($fp);



                    $insert_data = array(
                        'title'  => $title,
                        'title_ar'   =>$title,
                        'code'   => trim($row['parts']),
                        'price'   => $dealPrice,
                        'company'   => trim($row['brandname']),
                        'quantity'   => '10000',
                        'deal_id'    => '2',
                        'delar_id'    => $request['dealerId'],
                        'description'=>$desc,
                        'description_ar'=>$desc,
                        'size'=>$size,
                        'height'=>$height,
                        'width'=>$width,
                        'created_by'=>'1',
                        'created_at' => date('Y-m-d H:i:s'),
                        'status'=>'1',
                        'thumbnail_url'=>'/uploads/deals/tires/'.$safeName
                    );

                   
                     $tire_id = ItemMaster::insertGetId($insert_data);
                     $dt= date('Y-m-d');
                    
                     $expiryDate=date('Y-m-d', strtotime('+1 year', strtotime($dt)));

                    $insert = array(
                        'item_id' => $tire_id,
                        'deal_id' => '2',
                        'price' =>$dealPrice,
                        'quantity' => '10000',
                        'discount' => '15',
                        'start_date' =>$dt,
                        'end_date' =>$expiryDate,
                        'description' => $desc,
                        'description_ar' => $desc,
                        'terms' => 'terms and conditions for '.$desc,
                        'terms_ar' =>'terms and conditions for '.$desc,
                        'vn_access' => '0',
                        'pn_access' => '0',
                        'on_site' => '0',
                        'is_notify' =>'0',
                        'created_at' => date('Y-m-d H:i:s'),
                        'created_by' => '1',
                    );

                    $offer_id = ItemOffer::insertGetId($insert);

                    $insert_offer_location = array(
                        'location_id' => $request['locationId'],
                        'offer_id' => $offer_id,
                        'created_at' => date('Y-m-d H:i:s'),
                        'created_by' => 1,
                    );

                    OfferLocation::insert($insert_offer_location);

                    $sliderInsert = array(
                        'deal_id' => '2',
                        'item_id' => $tire_id,
                        'thumbnail_url' =>'/uploads/deals/tires/sliders/'.$sliderName,
                        'created_at' => date('Y-m-d H:i:s')
                    );
                     Slider::insert($sliderInsert);
                   

                    }
                }
            }

            
        }

    }

    public function upload_aws_bucket(){
        return view('upload_aws_bucket');
    }

    public function upload_s3_file(Request $request){

        $request->validate([
            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        if ($file=$request->file('image')) {
            $destinationPath = public_path() . '/uploads/images/';
            $safeName = time().'.'.$request->image->extension();
            $file->move($destinationPath, $safeName);
            $request['app_file'] = '/uploads/images/'.$safeName;
        }

        $path = url('/').$request['app_file'];
        $path = Storage::disk('s3')->put('images', $path);
        $path = Storage::disk('s3')->url($path);

        /* Store $imageName name in DATABASE from HERE */

        return back()
            ->with('success','You have successfully upload image.')
            ->with('image', $path);

    }
}
