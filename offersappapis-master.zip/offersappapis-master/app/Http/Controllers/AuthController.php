<?php

namespace App\Http\Controllers;

use App\Models\Generals\Role;
use App\Models\Regulatory\Delar;
use App\Models\Regulatory\Location;
use App\Models\Regulatory\Maker;
use App\Models\Accounts\Reset;
use App\Models\Accounts\User;
use App\Models\Regulatory\Organization;
use App\Models\Regulatory\OrgDeal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Http\Controllers\Generals\EmailController;
use Illuminate\Support\Facades\Log;
use App\Events\Emails\EmailActivation;


class AuthController extends Controller
{
    public function signup(Request $request)
    {
        $data=[];
        $validator = Validator::make($request->all(),
            [
                'first_name'    => ['required', 'string', 'max:30' ],
                'last_name'    => ['max:30' ],
                'email'    => ['required', 'string', 'email', 'max:60', 'unique:users'],
                'contact_no'    => ['required', 'string', 'max:15', 'unique:users' ],
                'password' => ['required', 'string', 'min:6'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $inputdata = array(
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'contact_no' => $request->contact_no,
            'role_id' => 1,
            'created_at' => date('Y-m-d H:i:s')
        );

        try {
            $user = User::insertGetId($inputdata);
            $user = User::find($user);
            $token = JWTAuth::fromUser($user);
            $data['user'] = $user;
            $data["token"] = $token;

            return response()->json(['status' => 'success', 'message' => 'Signup Successfully', 'response' => $data], 200);
        }
        catch (\Exception $e){
            return response()->json(['status' => 'failed', 'message' => 'Signup Failed'], 200);
        }
    }


    function member_signup(Request $request){
        $data=[];
        $request['contact_no'] = $request['country_code'].$request['phone'];
        $validator = Validator::make($request->all(),
            [
                'first_name'    => ['required', 'string', 'max:30' ],
                'email'    => ['required', 'string', 'email', 'max:60', 'unique:users,email,NULL,id,deleted_at,NULL'],
                'contact_no'    => ['required', 'string', 'max:15', 'unique:users,contact_no,NULL,id,deleted_at,NULL' ],
                'password' => ['required', 'string', 'min:6'],
                'usertype'=>['required'],
                'company_name'=>['required'],
                'city'=>['required']

            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }


         try{

          // Create organizations
            $insert = array(
                'org_name' => $request['company_name'],
                'org_name_ar' => $request['company_name'],
                'code' => '',
                'country_code' => $request['country_code'],
                'phone' => $request['contact_no'],
                'email' => $request['email'],
                'company_type' => $request['usertype'], // Delar Type
                'thumbnail_url' =>'',
                'created_by' => '1',
                'created_at' => date('Y-m-d H:i:s')
            );

 
            $delar_id = Delar::insertGetId($insert);
            // Create organizations

            // Dealer location
            $location['city'] = $request['city'];
            $location['latitude'] =  $request['latitude'];
            $location['longitude'] =  $request['longitude'];
            $location['org_id'] = $delar_id;
            $location['primary'] = 1;
            $location['created_at'] = date('Y-m-d H:i:s');
            Location::insert($location);
            // End Dealer location


            if( $request['usertype']=='D'){ // Category type
                $request['category'] = json_decode($request['category'], true);
                if(count($request->category) > 0){
                    foreach ($request->category as $key => $dealidrow) {
                        if(OrgDeal::where('org_id', $delar_id)->where('deal_id', $dealidrow)->count() == 0){
                            $insert = array(
                                'org_id' => $delar_id,
                                'deal_id' => $dealidrow,
                                'status' => 1, //$request['status'],
                                'created_at' => date('Y-m-d H:i:s')
                            );
                            OrgDeal::insertGetId($insert);
                        }
                    }
                }
            }

            $roleId=3;

            if($request['usertype']=='F'){
                 $roleId=6;
            } else if($request['usertype']=='M'){
                $roleId=2; 
            }

            // Create Admin details
            $insert = array(
                "first_name" => $request['first_name'],
                "email" => $request['email'],
                "password" => Hash::make($request['password']),
                "role_id" => $roleId, 
                "org_id" => $delar_id, // Delar Organization
                "profile_pic" => '',
                'created_at' => date('Y-m-d H:i:s'),
                'country_code' => $request['country_code'],
                'contact_no' => $request['contact_no'],
                'is_verified' => 0,
                'status' => 0,
            );

            User::insert($insert);

           //(new EmailController)->send_activation_mail($request['email'],$request['first_name']);

             $otp = mt_rand(1000, 9999);

             $userData=Reset::where('email', $request['email'])->where('user_type', 'User')->first();
             if(empty($userData))
                Reset::insert(array('email' =>$request['email'], 'token' => $otp, 'user_type' => 'User', 'created_at' => date('Y-m-d H:i:s')));
            else
                Reset::where('email' , $request['email'])->where('user_type' ,'User')->update(array('token' => $otp, 'created_at' => date('Y-m-d H:i:s')));
            try{
                // Send notification to user
                event(new EmailActivation($request['email'], $request['first_name'], $otp, 'User', '6'));
            } catch(\Exception $e){
                   Log::error('Failed to send mail. Please try again later: '. $e->getMessage());
            }
          

           return response()->json(['status'=>'success', 'message'=> 'You have successfully created your account with us. Please check your mail to activate your account.'.$request['contact_no']], 200);

        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Failed to create your account.', "error" => $e ], 400);
        }
    }

   

    public function signin(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'email' => ['required', 'string', 'email',],
                'password' => ['required', 'string'],
            ]
        );

        if ($validator->fails()) {
            return response()->json([ 'status' => "failed", "response" => $validator->messages()], 400);
        }

        $userData=User::where('email', $request->email)->first();
        
        if(empty($userData))
             return response()->json(['status' => 'failed', 'response' => "Email id is not available"], 400);

        if($userData->role_id==7 || $userData->role_id==8)
            return response()->json(['status' => 'failed', 'response' => "Technicians not allowed to access web portal"], 400);
        

        if($userData->status==0 && $userData->is_verified==0){

            $otp = mt_rand(1000, 9999);
            $userData=Reset::where('email', $request['email'])->where('user_type', 'User')->first();
            if(empty($userData))
                Reset::insert(array('email' =>$request['email'], 'token' => $otp, 'user_type' => 'User', 'created_at' => date('Y-m-d H:i:s')));
            else
                Reset::where('email' , $request['email'])->where('user_type' ,'User')->update(array('token' => $otp, 'created_at' => date('Y-m-d H:i:s')));

            try{
                // Send notification to user
                event(new EmailActivation($request['email'],$userData->first_name, $otp, 'User', '6'));
            } catch(\Exception $e){
                Log::error('Failed to send mail. Please try again later: '. $e->getMessage());
            }

            return response()->json(['status'=>'failed','response' => "Account not yet activated"], 400);
        } else if($userData->is_verified == 0) {
            return response()->json(['status'=>'failed','response' => "Account not yet approved"], 400);
        } else if($userData->is_verified == 2) {
            return response()->json(['status'=>'failed','response' => "Account was blocked"], 400);
        } else {

            $request['status'] = 1;
            $credentials = $request->only('email', 'password', 'status');

            try {
                if (! $token = JWTAuth::attempt($credentials)) {
                    return response()->json(['status' => 'failed', 'response' => "Invalid Credentials"], 400);
                }
            } catch (JWTException $e) {
                return response()->json(['status' => 'failed','response' => 'could_not_create_token'], 500);
            }

            $user = Auth::user();
            if($user->login_type_id == 18) // Delar
                $user->deals = OrgDeal::where('org_id', $user->org_id)->pluck('deal_id');
            if($user->login_type_id == 19) // fleet
                $user->personal_info = Organization::where('id', $user->org_id)->where('company_type', 'F')->pluck('personal_info')->first();

            $user->Token = $token;
            return response()->json(['status'=>'success','response' => "Success",'data' => $user], 200);
        }
    }

    public function send_otp($mail = null)
    {
        if(env('APP_OTP')=='production') {
            $otp = mt_rand(100000, 999999);
            //$mail = 'admin@glovision.co';

            $data = User::where('EmailId', $mail)->get()->toArray();
            $data = $data[0];
            $data['OTP'] = $otp;

            //if(!Reset::find($mail))
             $userData=Reset::where('email', $mail)->where('user_type', 'User')->first();
             if(empty($userData))
                Reset::insert(array('email' => $mail, 'token' => $otp, 'user_type' => 'User', 'created_at' => date('Y-m-d H:i:s')));
            else
                Reset::where('email' , $mail)->where('user_type' ,'User')->update(array('token' => $otp, 'created_at' => date('Y-m-d H:i:s')));

            // $mail = 'renownuday@gmail.com';
            $data['OTP'] = str_split($otp, 1);

            try {
                Mail::send('emails.sendotp', $data, function ($message) use ($mail, $data) {
                    $message->to($mail, $data['FirstName'])->subject
                    ('Verify Mail From Express fit');
                    $message->from('udaykumar.borra@renownanalytics.com', 'Express Fit');
                });
                return array('status'=>'success', 'message'=> 'Mail Sent Successfully');
            }
            catch (Exception $e) {
                return array('status' => 'failed', 'message' => 'Mail Sent Failed');
            }
        }
    }

    public function Resend_otp(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'EmailId' => ['required', 'string', 'email',]
            ]
        );
        if ($validator->fails()) {
            return response()->json(['status'=>'failed', 'response' => [], 'message'=> 'Validation Error'], 400);
        }

        $this->send_otp($request->EmailId);

        return response()->json(['status'=>'success', 'response' => [], 'message'=> 'OTP Sent'], 200);
    }

    public function verify_otp(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'EmailId' => ['required', 'string', 'email'],
                'OTP' => ['required', 'string', 'min:6']
            ]
        );
        if ($validator->fails()) {
            return response()->json([ 'status' => "failed", "response" => $validator->messages()], 400);
        }

        if(User::where('email', $request->EmailId)->get())
        {
            if(Reset::where([['email', $request->EmailId ],['user_type', 'User' ],[ 'token' , $request->OTP ]] )->get())
            {
                User::where('email', $request->EmailId)->update(['is_verified' => 1]);
                Reset::where('email', $request->EmailId)->where('user_type', 'User')->delete();

                $user = User::where('email', $request->EmailId)->first()->toArray();
                unset($user['Password']);

                $this->sendRegistryMail($user);

                return response()->json(['status'=>'success', 'message'=> 'Email Verified'], 200);
            }

            return response()->json(['status'=>'failed', 'message'=> 'Invalid OTP'], 400);
        }

        return response()->json(['status'=>'failed', 'message'=> 'Invalid User'], 400);
    }

    public function change_password(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'old_password'    => ['required', 'string', 'max:60'],
                'new_password'    => ['required', 'string', 'min:6'],
            ]
        );

        if ($validator->fails()) {
            return response()->json([ 'status' => "failed", "response" => $validator->messages()], 400);
        }

        $user = User::where('id', Auth::id() )->first();

        if(Hash::check($request['old_password'], $user->Password )) {

            $update['Password'] = Hash::make($request['new_password']);

            if($request['old_password'] != $request['new_password']){
                $res = User::where('id', Auth::id())->update($update);

                if ($res){
                    Log::info("UserController::changePassword ".Auth::user()->FirstName."".Auth::user()->LastName." Password Updated");
                    return response()->json(['status' => 'success', 'message' => 'Password Updation Successfully']);
                }
                else
                    return response()->json(['status' => 'failed', 'message' => 'Password Updation Failed'], 400);
            }else{
                return response()->json(['status'=>'failed','message'=>'Your Old And New Password Is Same'], 400);
            }
        }else{
            return response()->json(['status'=>'failed','message'=>'Your Old Password Is Wrong'], 400);
        }
    }

    public function forgotpswd1(Request $request)
    {
        if($request->isMethod('post'))
        {
            $validator = Validator::make($request->all(),
                [
                    'EmailId'    => ['required', 'string', 'email', 'max:60'],
                ]
            );

            if ($validator->fails()) {
                return redirect()->back()
                    ->withErrors($validator)
                    ->withInput();
            }

            $where['EmailId'] = $request['EmailId'];
            $usercnt = User::where('email' , $request['EmailId'] )->count();

            if($usercnt > 0) {
                // $this->send_reset_link($request['EmailId'])
                return back()->with('success','Please check your mail to reset password');
            }else{
                return back()->with('failed','Invalid User ID');
            }
        }

        return view('auth.forgotpswd');
    }

    public function forgotpwd(Request $request)
    {
        try{
            if($request->isMethod('post'))
            {
                $validator = Validator::make($request->all(),
                    [
                       'EmailId'    => ['required', 'string', 'email', 'max:60'],
                    ]
                );

                if ($validator->fails()) {
                    return response()->json([ 'status' => "failed", "response" => $validator->messages()], 400);
                }

                $user = User::where('email' , $request->EmailId )->first();

                if(!empty($user)) {
                    try{
                        if($user->role_id==7 || $user->role_id==8){
                            return response()->json(['status' => 'failed', 'response' => "Technician not allowed to access web portal and can't reset your password."], 400);
                        } else if($user->is_email_verified){
                            return response()->json(['status'=>'failed', 'response'=> 'Email id not yet verified'], 400);
                        }

                        (new EmailController)->send_reset_link($request['EmailId'], $user);

                    } catch(\Exception $e){
                         return response()->json(['status'=>'failed', 'response'=> 'Failed to send notification'], 400);
                    }
                    return response()->json(['status'=>'success', 'message'=> 'Please check your mail to reset password', 'userData'=>$user], 200); 
                } else {
                    return response()->json(['status'=>'failed', 'response'=> 'Invalid Email ID'], 400);
                }
            } 
        } catch(\Exception $e){
             return response()->json(['status'=>'failed', 'response'=> 'Failed to send notification'], 400);
        }
    }



    public function forgot_resetpassword(Request $request)
    {
        if($request->isMethod('post'))
        {
            $validator = Validator::make($request->all(),
                [
                    'email'    => ['required', 'string', 'email', 'max:60'],
                    'password'    => ['required', 'string', 'max:60'],
                    'emailToken'    => ['required', 'string', 'max:60'],
                ]
            );

            if ($validator->fails()) {
                return response()->json([ 'status' => "failed", "response" => $validator->messages()], 400);
            }

            $user = User::where('email' , $request->email )->first();

            if(!empty($user)) {
                if(Reset::where([['email', $request->email ],['user_type', 'User' ],[ 'token' , $request->emailToken ]] )->get())
                {
                    $password = Hash::make($request->password);
                    User::where('email', $request->email)->update(['password' => $password ]);
                    Reset::where('email', $request->email)->where('user_type', 'User')->delete();

                    return response()->json(['status'=>'success', 'message'=> 'Password Reset Succuessfull. Now you can login with new password'], 200);
                } else {
                    return response()->json(['status'=>'failed', 'message'=> 'Invalid token'], 400);
                }
            }else{
                return response()->json(['status'=>'failed', 'message'=> 'Invalid User ID'], 400);
            }
        }
    }

    public function partners_resetpassword(Request $request, $id)
    {
        if($request->isMethod('post'))
        {
            $validator = Validator::make($request->all(),
                [
                    'email'    => ['required', 'string', 'email', 'max:60'],
                    'password'    => ['required', 'string', 'max:60'],
                    'roleId'=>['required']
                ]
            );

            if ($validator->fails()) {
                return response()->json([ 'status' => "failed", "response" => $validator->messages()], 400);
            }

            $user = User::where('email' , $request->email )->where('role_id' , $request->roleId )->first();

            if(!empty($user)) {
                
                $password = Hash::make($request->password);
                User::where('email', $request->email)->update(['password' => $password ]);
                return response()->json(['status'=>'success', 'message'=> 'Password Reset Succuessfull'], 200);
               
            } else {
                return response()->json(['status'=>'failed', 'message'=> 'Invalid admin details'], 400);
            }
        }
    }

    public function reset_password(Request $request)
    {
        if($request->isMethod('post'))
        {
            $validator = Validator::make($request->all(),
                [
                    'email'    => ['required', 'string', 'email', 'max:60'],
                    'password'    => ['required', 'string', 'max:60'],
                    'oldPassword'    => ['required', 'string', 'max:60'],
                ]
            );

            if ($validator->fails()) {
                return response()->json([ 'status' => "failed", "response" => $validator->messages()], 400);
            }

            $user = User::where('email' , $request->email )->first();

            if(!empty($user)) {
                 $oldPwd = Hash::make($request->oldPassword);
                
                 if(Hash::check($request->oldPassword, $user->password)){
                    $password = Hash::make($request->password);
                    User::where('email', $request->email)->update(['password' => $password ]);
                    return response()->json(['status'=>'success', 'message'=> 'Password Reset Succuessfull'], 200);
                 } else {
                     return response()->json(['status'=>'failed', 'message'=> 'Invalid Old Password'], 400);
                 }

            } else {
                return response()->json(['status'=>'failed', 'message'=> 'Invalid User ID'], 400);
            }
        }
    }

    public function sendRegistryMail($data)
    {
        if(env('APP_EMAIL')=='production') {
            try {
                Mail::send('emails.registry', $data, function ($message) use ( $data) {
                    $message->to($data['EmailId'], $data['FirstName'])->subject
                    ('Registration From Express fit');
                    $message->from('udaykumar.borra@renownanalytics.com', 'Express Fit');
                });
                return true;
            } catch (\Exception $e) {
                return false;
            }
        }
    }

    public function register(Request $request)
    {
        $request['location'] = json_decode($request['location'], true);
        $request['phone'] = $request['country_code'].$request['contact_no'];
        $validator = Validator::make($request->all(),
            [
                'org_name' => ['required', 'string', 'max:100' ],
                'org_name_ar' => ['required', 'string', 'max:100' ],
                'code' => ['required', 'string', 'max:20', 'unique:organizations'  ],
                'email' => ['required', 'string', 'email', 'max:60', 'unique:users' ],
                'country_code' => 'required|max:5',
                'phone' => ['required', 'max:15', 'unique:users,contact_no'],
                'category.*' => ['required'],
                'location.street' => ['string', 'max:60' ],
                'location.city' => ['required', 'max:60' ],
                'location.district' => ['string', 'max:60' ],
                'location.zipcode' => ['string', 'max:20' ],
                'location.latitude' => ['required', 'numeric', 'between:0,180'],
                'location.longitude' => ['required', 'numeric', 'between:0,180'],
                'thumbnail' => ['required', 'mimes:jpeg,jpg,png', 'max:500' ],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $request['category'] = json_decode($request['category'], true);

        $uType = in_array(9, $request['category']) ? 'maker/' : 'delar/';
        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/'.$uType;
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/'.$uType.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put($uType , $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        $uType = in_array(9, $request['category']) ? 'Maker' : 'Delar';
        try{
            /*
             * M - Maker, D - Delar
             * 2 - Maker Admin, 3 - Delar Admin
             */

            $request['company_type'] = in_array(9, $request['category']) ? 'M' : 'D';
            $request['password'] = in_array(9, $request['category']) ? 'maker@123' : 'delar@123';

            $insert['role_id'] = in_array(9, $request['category']) ? 2 : 3;
            $request['created_at'] = date('Y-m-d H:i:s');
            $request['created_by'] = 1;

            $org = Maker::create($request->except('location', 'contact_no', 'password', 'thumbnail'));

            if(count($request->category) > 0){
                foreach ($request->category as $key => $dealidrow) {
                    if(OrgDeal::where('org_id', $org['id'])->where('deal_id', $dealidrow)->count() == 0){
                        $insert = array(
                            'org_id' => $org['id'],
                            'deal_id' => $dealidrow,
                            'status' => 1, //$request['status'],
                            'created_at' => date('Y-m-d H:i:s')
                        );
                        OrgDeal::insertGetId($insert);
                    }
                }
            }

            $location = $request['location'];
            $location['org_id'] = $org['id'];
            $location['primary'] = 1;
            $location['created_at'] = date('Y-m-d H:i:s');
            Location::insert($location);

            $insert['first_name'] = $request['org_name'];
            $insert['email'] = $request['email'];
            $insert['org_id'] = $org['id'];
            $insert['password'] = Hash::make($request['password']);
            $insert['country_code'] = $request['country_code'];
            $insert['contact_no'] = $request['country_code'].$request['contact_no'];
            $insert['profile_pic'] = $request['thumbnail_url'];
            $insert['created_at'] = date('Y-m-d H:i:s');

            User::insert($insert);

            return response()->json(['status'=>'success', 'message'=> $uType.' created successfully'], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> $uType.' creation failed', "error" => $e ], 400);
        }
    }

  
    public function verify_userotp(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'EmailId' => ['required', 'string', 'email'],
                'OTP' => ['required', 'string'],
                "type"=>['required']
            ]
        );
        if ($validator->fails()) {
            return response()->json([ 'status' => "failed", "response" => $validator->messages()], 400);
        }

        if(User::where('email', $request->EmailId)->get())
        {
            if($request->OTP == '0000' && env('APP_ENV') != 'production') {
                Reset::where('email' , $request->EmailId)->where('user_type' , 'User')->update(array('token' => '0000'));
            }

            if(Reset::where([['email', $request->EmailId ],[ 'token' , $request->OTP ],[ 'user_type' , 'User' ]] )->count()>0)
            {    
                if($request['type']=='Account') {// Verify registered user

                    $userArray['is_verified']=1;
                    $userArray['status']=1;
                    if($request->OTP!='0000'){
                        $userArray['is_email_verified']=1;
                    }
                    
                    Reset::where('email', $request->EmailId)->where('user_type', 'User')->delete();
                    User::where('email' , $request->EmailId)->update($userArray);
                }

                return response()->json(['status'=>'success', 'message'=> 'Email Verified'], 200);
            } else{
                return response()->json(['status'=>'failed', 'message'=> 'Invalid OTP'], 400);
            }
        }

        return response()->json(['status'=>'failed', 'message'=> 'Invalid User'], 400);
    }

}
