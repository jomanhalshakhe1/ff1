<?php

namespace App\Http\Controllers\tabby;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Generals\SendPushNotification;
use App\Models\Generals\Lookup;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\Accounts\Transaction;
use App\Models\Accounts\Payment;
use App\Models\Accounts\Driver;
use App\Http\Controllers\Generals\DealController;
use App\Http\Controllers\GeneralController;
use App\Models\Regulatory\Organization;
use Salla\ZATCA\GenerateQrCode;
use Salla\ZATCA\Tags\InvoiceDate;
use Salla\ZATCA\Tags\InvoiceTaxAmount;
use Salla\ZATCA\Tags\InvoiceTotalAmount;
use Salla\ZATCA\Tags\Seller;
use Salla\ZATCA\Tags\TaxNumber;
//use App\Http\Controllers\Users\CreditsController;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use App\Events\Emails\RefundCreatedEmail;
use App\Events\OrderRefunded;
use App\Models\Accounts\ConsumerCredit;
use App\Models\Accounts\ConsumerGroup;
use App\Models\Accounts\Credit;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Events\cancelTranaction;
use App\Http\Controllers\Payments\RefundController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\Users\PetrominController;

class TabbyController extends Controller
{
    private $refund = 2;
    private $adjustment = 3;
    private $secretKey='sk_test_fadfa734-8936-4d96-ab33-9385e164007c';
    private $publicKey='pk_test_6bdaf89c-c267-4647-b0c9-881d776ed1e5';
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     * Get transactions list using tabby
     * @param $pagelength, $pageno
     * @return \Illuminate\Http\Response
     */

    public function getAllTabbyTransactionsList(Request $request){
      try{
        $pageno = 1;
        $pagelength = 10;
        $login_type_id = Auth::user()->login_type_id;
        $list = Transaction::with('item', 'offer', 'driver', 'item.delar', 'item.deal', 'refund', 'adjustment', 'location', 'driver.fleet_consumer', 'approver','payment')
        ->select('transactions.*')
        ->where('transactions.payment_status','!=','pending');
        
        if (isset($request->deal_category) && $request->deal_category != 'All') {
            $list = $list->where('transactions.deal_id', $request->deal_category);
        }

        $list = $list->whereHas('payment', function ($paymentInfo){
            $paymentInfo->where('payment_on', 50);
        });

        //Start search filters
        if (isset($request->status) && $request->status != 'All') {
             if ($request->status == 'Redeemed') {
                $list = $list->where('payment_status', 'Successful')
                  ->where('redeem_quantity','>',0)
                  ->whereRaw("((quantity-revised_quantity)-redeem_quantity)=0");
            } else if ($request->status == 'Refunded') {
                $list = $list->whereRaw("(payment_status='Successful' or payment_status='Available')")
                    ->whereColumn('revised_quantity', '=', 'quantity');
            } else if ($request->status == 'Partial Refund') {
                
                $list = $list->whereRaw("(payment_status='Successful' or payment_status='Available')")
                  ->where('revised_quantity','>',0)
                  ->whereRaw("((quantity-redeem_quantity)-revised_quantity)>0");
            } else if ($request->status == 'Paid') {
                $list = $list->where('payment_status', 'Successful')
                    ->where('redeem_quantity', '>', '0')
                    ->where('revised_quantity', '>', '0');
            } else if ($request->status == 'Successful') {
                $list = $list->where('payment_status', 'Successful')
                    ->where('redeem_quantity', '0')
                    ->where('revised_quantity', '0');
            } else  if (in_array($request->status, array('Failed', 'Cancelled', 'Requests', 'Rejected', 'pending'))) {
                $list = $list->where('payment_status', $request->status);
            } else if ($request->status == 'Available') {
                $list = $list->where('payment_status', 'Available')
                    ->where('redeem_quantity', '0')
                    ->where('revised_quantity', '0');
            } 
        }

        if (isset($request->deal_category) && $request->deal_category != 'All') {
            $list = $list->where('deal_id', $request->deal_category);
        }

        $fromDate=$request->from_date;
        $toDate=$request->to_date;

        if($fromDate!='' && $toDate==''){
            $list = $list->where('created_at','>=',$fromDate." 00:00:00");
        } else if($fromDate=='' && $toDate!=''){
            $list = $list->where('created_at','<=',$toDate." 23:59:59");
        } else if($fromDate!='' && $toDate!=''){
            $list = $list->where('created_at','>=',$fromDate." 00:00:00");
            $list = $list->where('created_at','<=',$toDate." 23:59:59");
        }

        if ($login_type_id == 17) {
            if (isset($request->deal_providers) && $request->deal_providers != 'All') {
                $list = $list->whereHas('item', function ($item) use ($request) {
                    $item->where('delar_id', $request->deal_providers);
                });
            }
        }

        $search=$request->searchby_keyword;

        // If search keyword by customer information(CI)
        if($request->searchby_type=='CI'){
            $list = $list->whereHas('driver', function ($item) use ($search) {
                $item->where('first_name','LIKE',"%{$search}%");
                $item->orWhere('last_name','LIKE',"%{$search}%");
                $item->orWhere('contact_no','LIKE',"%{$search}%");
                $item->orWhere('email','LIKE',"%{$search}%");
            });
        }

        // If search keyword by company name (CA)
        if($request->searchby_type=='CA'){
            $list = $list->whereHas('item.delar', function ($item) use ($search) {
               $item->where('org_name','LIKE',"%{$search}%");
            });
        }

        // If search keyword by Item Name(IN)
        if($request->searchby_type=='IN'){
            $list = $list->whereHas('item', function ($item) use ($search) {
               $item->where('title','LIKE',"%{$search}%");
               $item->orWhere('title_ar','LIKE',"%{$search}%");
               $item->orWhere('description','LIKE',"%{$search}%");
               $item->orWhere('description_ar','LIKE',"%{$search}%");
            });
        }


         // If search keyword by response code(RC)
        if($request->searchby_type=='RC'){
            $list = $list->whereHas('payment', function ($item) use ($search) {
               $item->where('response_code','LIKE',"%{$search}%");
            });
        }

        if ($login_type_id == 18 || $login_type_id == 22){ // Delar admin or delar technician login
            $list = $list->whereHas('item', function ($item) {
                $item->where('delar_id', Auth::user()->org_id);
            });
        } else if ($login_type_id == 19) { // partner account
            $list = $list->whereHas('driver.fleet_consumer', function ($item) {
                $item->where('fleet_drivers.fleet_id', Auth::user()->org_id);
            });
        }
        //End search filter


        $list = $list->orderBy('transactions.id', 'desc');
        $totalrecords = $list->count();

        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = $list->skip(($pageno - 1) * $pagelength)->take($pagelength)->get()
            ->map(function ($row) {
                return $this->format($row);
            });

        if (explode('/', $request->route()->getPrefix())[0] == 'api') {
            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status' => 'success', 'data' => $data], 200);
        } else {
            return response()->json(['status' => 'success', 'data' => $list], 200);
        }

        } catch (\Exception $exception) {
            return response()->json([
                'status' => 'failed',
                'error'=>$exception->getMessage(),
                'status_code'=>400
            ]);
        } 
    }
    /**
     * Get transactions list using tabby
     * @param $pagelength, $pageno
     * @return \Illuminate\Http\Response
     */

    function getAllTabbyTransactionsListOld(){
      try{
            $pageno = 1; $pagelength = 10;
            if (isset(request()->pagelength, request()->pageno) && !empty(request()->pagelength)) {
                $pagelength = request()->pagelength;
                $pageno = request()->pageno;
            }

            $limit=$pagelength;$offset=($pageno-1)*$pagelength;
            $startDate="2023-02-07T9:50:08Z";
            $endDate=date("Y-m-d")."T23:59:59Z";
            $paymentURL="payments?limit=".$limit."&offset=".$offset."&created_at__gte=".$startDate."&created_at__lte=".$endDate;

            //$paymentURL="payments?limit=".$limit."&offset=".$offset;

            $result=$this->getDataUsingCurl($paymentURL);
            $data=json_decode($result);

            if($data){

                if(!empty($data->status) && $data->status=='error'){
                    return response()->json([
                        'status'=>'failed',
                        'message'=> $data->error,
                    ], 400);

                } else {
                    $pagination=$data->pagination;
                    $resultsArray['total'] = $pagination->total_count;
                    $resultsArray['current_page'] = $pageno;
                    $resultsArray['per_page'] = $pagelength;
                    //Payment Details
                    $paymentDetails=$data->payments;
                    $resultsInfo=$this->formate_data($paymentDetails, $resultsArray['total']);
                    $resultsArray['data']=$resultsInfo['transactioninfo'];
                    $resultsArray['total']=$resultsInfo['total_records'];
                    return response()->json([
                            'status'=>'success',
                            'data'=> $resultsArray,
                        ], 200);
                }
            } else{
               return response()->json([
                    'status' => 'failed',
                    'message'=> 'No data found',
                    'status_code'=>400
                ]);
            }

        } catch (\Exception $exception) {
            return response()->json([
                'status' => 'failed',
                'error'=>$exception->getMessage(),
                'status_code'=>400
            ]);
        } 
    }


    /**
     * Get required formatted data from payment details
     * @param $data
     * 
     */
    function formate_olddata($data){
        $newData=array();$i=0;
        foreach($data as $singleData){

            $itemsList=$singleData->order->items;
            $orderInfo=$singleData->order_history;
            $itemsDetails=array();
            if($itemsList){
                 foreach($itemsList as $singleItem){
                    $itemsDetails=array(
                       'created_at'=>$singleItem->order->created_at ?? NULL,
                       'item_name'=>$singleItem->title,
                       'deal_name'=>$singleItem->deal_name ?? NULL,
                       'company_name'=>$singleItem->company_name ?? NULL, 
                       'quantity'=>$singleItem->quantity ?? NULL, 
                       'unit_price'=>$singleItem->unit_price ?? NULL, 
                       'discount'=>$singleItem->discount_amount ?? NULL, 
                    );
                  } 
            }
            $paymentMethod='';
            foreach($orderInfo as $singleInfo){
                $paymentMethod=$singleInfo->payment_method;
            }
            
            $newData[]=array(
                'id'=>$singleData->id,
                'status'=>$singleData->status,
                'total_amount'=>$singleData->amount,
                'customer_info'=>array(
                    'name'=>$singleData->buyer->name,
                    'email'=>$singleData->buyer->email,
                    'phone'=>$singleData->buyer->phone
                ),
                'payment_method'=>$paymentMethod,
                'items_info'=>$itemsDetails,
            ); 
        }
        return $newData;
    }

    /**
     * Get required formatted data from payment details
     * @param $data
     * 
     */
    function formate_data($data, $totalrecords){
        $newData=array();$i=0;
        $transactionArray=array();
        foreach($data as $singleData){
            $newData=$this->getTransactionInfo($singleData);

            if(count($newData)==0){
                $totalrecords--;
            } else {
                $transactionArray[]=$newData;
            }
        }
        $resultsArray['total_records']=$totalrecords;
        $resultsArray['transactioninfo']=$transactionArray;
        return $resultsArray;
    }

    function getTransactionInfo($singleData){
        $newData=array();
        if($singleData) {
            $itemsDetails=array();
            
            $paymentMethod='';
            if($singleData->order_history){
                foreach($singleData->order_history as $singleInfo){
                    $paymentMethod=$singleInfo->payment_method;
                }
            }
            
            $transactionNo=isset($singleData->meta->transaction_no) ? $singleData->meta->transaction_no : '';

            if($transactionNo){

                $list=$this->getTransactionDetails($transactionNo);

                $newData=array(
                    'payment_id'=>$singleData->id,
                    'tabby_status'=>$singleData->status,
                     'tabby_created_at'=>$singleData->created_at,
                    'payment_method'=>$paymentMethod,
                    'total_amount'=>$singleData->amount,
                    'transaction_info'=>$list, 
                ); 
            } 
            // else {
            //      $newData=array(
            //         'payment_id'=>$singleData->id,
            //         'tabby_status'=>$singleData->status,
            //         'payment_method'=>$paymentMethod,
            //         'total_amount'=>$singleData->amount,
            //         'transaction_info'=>NULL
            //     ); 
            // }
        }
        return $newData;
    }

    public function getTransactionDetails($id){

        $list = Transaction::where('transaction_no', $id)
            ->with('item', 'item.offer', 'item.delar', 'item.slider', 'item.delar.location',
                'driver', 'feedback', 'payment_details', 'vehicle_owners', 'driver_address', 'adjustment')
            ->get()
            ->map(function ($row) {
                return $this->format($row);
            })->first();

        if (!$list)
            return response()->json(['status' => 'failed', 'message' => "Invalid Transaction Id"], 400);

        $list['item']['offer']['vehicle'] = null;

        $admin_vat_no = Organization::where('company_type', 'A')->pluck('vat_no')->first();
        $list['vat_no'] = $admin_vat_no; //'311080860200003';

        // data:image/png;base64, .........
        $displayQRCodeAsBase64 = GenerateQrCode::fromArray([
            new Seller('Innvohub'), // seller name
            new TaxNumber($admin_vat_no), // seller tax number
            new InvoiceDate($list['created_at']), // invoice date as Zulu ISO8601 @see https://en.wikipedia.org/wiki/ISO_8601
            new InvoiceTotalAmount($list['final_price']), // invoice total amount
            new InvoiceTaxAmount(round($list['vat_amount'], 2)) // invoice tax amount
            // TODO :: Support others tags
        ])->render();

        $list['qr_image'] = $displayQRCodeAsBase64;

        $list['refund_credits'] = 0;
        if ($list['revised_quantity'] > 0) {
            $list['refund_credits'] = $list['refund_payment']['final_price'];
            $list['refund_no'] = 'R-' . $list['invoice_no'];

            $createdDate = Credit::where('transaction_no', $id)->orderBy('created_at', 'DESC')->pluck('created_at')->first();
            $displayQRCodeAsBase64 = GenerateQrCode::fromArray([
                new Seller('Innvohub'), // seller name
                new TaxNumber($admin_vat_no), // seller tax number
                new InvoiceDate($createdDate), // invoice date as Zulu ISO8601 @see https://en.wikipedia.org/wiki/ISO_8601
                new InvoiceTotalAmount($list['refund_payment']['final_price']), // invoice total amount
                new InvoiceTaxAmount($list['refund_payment']['vat_amount']) // invoice tax amount
                // TODO :: Support others tags
            ])->render();

            $list['qr_image_refund'] = $displayQRCodeAsBase64;
        }

        if ($list['payment_status'] == 'canceled') {
            $list['refund'] = $list['final_price'];
            $list['item']['offer']['refund'] = $list['final_price'];
        } else {
            $list['refund'] = 0;
            $list['item']['offer']['refund'] = 0;
        }

        return $list;
    }

    /**
     * Get transactions details based on the pamentId
     * @param $paymentId
     * @return \Illuminate\Http\Response
     */

    function getPaymentDataByPaymentId($paymentId){     
        try{  
            $paymentURL="payments/".$paymentId;
            $result=$this->getDataUsingCurl($paymentURL);
            $data=json_decode($result);

            if(!empty($data->status) && $data->status=='error'){
                return response()->json([
                    'status'=>'failed',
                    'message'=> $data->error,
                ], 400);

            } else {

                $newData=$this->getTransactionInfo($data);
                return response()->json([
                        'status'=>'success',
                        'data'=> $newData,
                    ], 200);
            }

        } catch (\Exception $exception) {
            return response()->json([
                'status' => 'failed',
                'error'=>$exception->getMessage(),
                'status_code'=>400
            ]);
        } 
    }

    /**
     * Access: admin, dealer Prefix: api
     *
     * Cancelled the transactions details based on the pamentId
     * @param $paymentId
     * @return \Illuminate\Http\Response
     */
    public function cancelTransaction(){
        $request=request();
        $rules = [
            'transaction_no' => ['required'],
            'description' => ['required'],
            'status' => ['required'],
            'quantity'=>['required']
        ];

        $validator = Validator::make($request->all(), $rules );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $transactionNo=$request->transaction_no;

            $refund_for = Transaction::where('transaction_no', $transactionNo)->get()->map(function ($row) {
                    return $this->format_price($row);
                })->first();

            $paymentData=Payment::where('transaction_no', $transactionNo)->orderBy('id','Desc')->first();

            $totalAvailableQuanity = $refund_for['quantity']-$refund_for['revised_quantity'];
            if($totalAvailableQuanity == 0){
                return response()->json(['status'=>'failed', 'message'=> 'Transaction already refunded, cancellation not allowed' ], 400);
            }

            if($request['quantity'] > $totalAvailableQuanity ){
                return response()->json(['status'=>'failed', 'message'=> 'Quantity exceeded than available quantity' ], 400);
            }

            // Refund can be done for 14 days of purchase item
            $refund_for_14days = date('Y-m-d H:i:s', strtotime($refund_for['created_at'].'+14 days'));
             
            if(strtotime(date('Y-m-d H:i:s') >  strtotime($refund_for_14days) )){
                return response()->json(['status'=>'failed', 'message'=> 'Cancelled time expired' ], 400);
            } else if($refund_for['quantity']==$refund_for['revised_quantity']){
               return response()->json(['status'=>'failed', 'message'=> "This transaction already fully refunded" ], 400); 
            } else {
                if($refund_for['payment_status']=='Requests'){
                    $results=$this->cancelInprocessRequests($refund_for, $request);
                     if($results['status']=='success'){
                        // Cancel petromin service booking
                        $this->delete_servicebooking($request['transaction_no']);

                        //Send cancel notification to customer
                        $this->sendCancelNotification($request);
                        return response()->json($results, 200); 

                     } else {
                        return response()->json($results, 400); 
                     } 
                } else if($refund_for['payment_status']=='Successful' || $refund_for['payment_status']=='Available'){
                    $results=(new RefundController())->cancel_transaction_refund($request, $refund_for);
                    if($results['status']=='success'){
                        // Cancel petromin service booking
                        $this->delete_servicebooking($request['transaction_no']);

                        //Send cancel notification to customer
                        $this->sendCancelNotification($request);
                        return response()->json($results, 200); 

                     } else {
                        return response()->json($results, 400); 
                     } 
                } else {
                    $tranArray['payment_status']='Cancelled';
                    $tranArray['updated_at']=date("Y-m-d H:i:s");
                    $tranArray['remarks']=$request->description;
                    Transaction::where('transaction_no', $transactionNo)->update($tranArray); 
                    $this->updatePaymentStatus($transactionNo, $paymentData->id);

                    // Cancel petromin service booking
                    $this->delete_servicebooking($request['transaction_no']);

                    //Send cancel notification to customer
                    $this->sendCancelNotification($request);

                    return response()->json(['status'=>'success', 'message'=> "This transaction was cancelled" ], 200); 
                }
            }
        } catch(\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> "Failed to cancelled purchased deal",'error'=>$e->getMessage() ], 400);
        }
    }

    /**
     * send cancel trnasaction notifications to customer
     * @param $request
     */
    function sendCancelNotification($request){
         try{
                // Send email notification to consumer along with invoice
               event(new cancelTranaction($request['transaction_no'], '31', 'Transaction'));
                
            } catch(\Exception $e){
                Log::error("Failed to send notification on cancellation: ". $request['transaction_no']);
            }

    }

    /*
     * Cancel petromin service booking on offer not availability or technician rejection
     */
    public function delete_servicebooking($transaction_no){
        $trans = Transaction::where('transaction_no', $transaction_no)->first();
        $item = ItemOffer::where('id', $trans['offer_id'])->first();
 
        if($item['provider_reference_subid'] && $trans['service_id']){
            // Create Booking
            try {
                (new PetrominController())->destroy($trans['service_id']);
            }catch (\Exception $e){
                Log::error("Petromin cancel service booking failed: Transaction No.:". $transaction_no);
            }
        }

        return true;
    }



    /**
     * Cancel inprocess requests for all methods
     * @param $refund_for, $request
     */
    function cancelInprocessRequests($refund_for, $request){
         $paymentData=Payment::where('transaction_no', $request->transaction_no)->orderBy('id','asc')->first();
         if(empty($paymentData)){
             return ['status'=>'failed','message'=>"Payment not yet authorized"];
         }

        if($paymentData->payment_on=='50'){
           $result=$this->unlock_tabbypayment($paymentData->payid, $paymentData->amount_by_banking);

           if($result['status']=='failed'){
             return $result; 
           }
           $paymentArray=array();
           $paymentArray['action_code']= 9;
           $paymentArray['updated_at'] = date('Y-m-d H:i:s');
           Payment::where('transaction_no', $request['transaction_no'])->where('id', $paymentData->id)->update($paymentArray);

        } else if($paymentData->payment_on=='35'){
            $result = (new PaymentController())->unlock_payments($paymentData->payid, $paymentData->amount_by_banking, $request->ip(), '9');
            
            if(!$result['status']){
                return ['status'=>'failed','message'=> $result['Response'],'data'=>$result['data']];
            }

            $resultData = $result['data'];
            $paymentArray=array();
            $paymentArray['payment_status'] = $result['payment_status'];
            $paymentArray['response_result'] = $result['Response'];

            if (!empty($resultData)) {
                $paymentArray['response_code'] = $resultData->responseCode;
                $paymentArray['response_amount'] = $resultData->amount;
            }
            Payment::where('transaction_no', $request['transaction_no'])->where('id', $paymentData->id)->update($paymentArray);
        } 

        $tranArray=array();
        $tranArray['payment_status']='Cancelled';
        $tranArray['updated_at']=date("Y-m-d H:i:s");
        $tranArray['remarks']=$request->description;

        Transaction::where('transaction_no', $request->transaction_no)->update($tranArray); 
        $this->updatePaymentStatus($request->transaction_no, $paymentData->id);
        return ['status'=>'success', 'message'=> "This transaction was cancelled"]; 
    }


    private function updatePaymentStatus($transactionNo, $paymentId){
        $paymentArray=array();

        $tranInfo=Transaction::where("transaction_no", $transactionNo)->with('payment')->first();
        $paymentArray['action_code']= 9;
        $paymentArray['updated_at'] = date('Y-m-d H:i:s');
        Payment::where('transaction_no', $transactionNo)->where('id', $tranInfo->payment->id)->update($paymentArray);
    }


    /**
     * Cancelled transaction where item is not available
     * @param $paymentId
     * @return $arr
     */
    function unlock_tabbypayment($paymentId, $amount){
        try{         
            $paymentURL="payments/".$paymentId."/close";
            $postData='';
            $result=$this->postDataUsingCurl($paymentURL, $postData);
            $data=json_decode($result);

            if(!empty($data->status) && $data->status=='error'){
                return  [
                    'status'=>'failed',
                    'message'=> $data->error,
                ];

            } else {
                return ['status'=>'success','data'=>$data];
            }

        } catch (\Exception $exception) {
            return [
                'status' => 'failed',
                'message'=>'Failed to cancelled transactions',
                'error'=>$exception->getMessage(),
                'status_code'=>400
            ];
        } 
    } 

    /**
     * Cancelled transaction where item is not available
     * @param $paymentId
     * @return $arr
     */
    function cancel_tabby_transaction($paymentId){
        try{

            //Update payment status 
             $paymentData=Payment::where('payid', $paymentId)->orderBy('id','asc')->first();
             if(empty($paymentData)){
                 return ['status'=>'failed','message'=>"Failed to cancel"];
             }

            $paymentURL="payments/".$paymentId."/close";

            $postData='';
            $result=$this->postDataUsingCurl($paymentURL, $postData);
            $data=json_decode($result);

            if(!empty($data->status) && $data->status=='error'){
                return  [
                    'status'=>'failed',
                    'message'=> $data->error,
                ];
            } else {

                $arr=array('payment_status'=>'Cancelled', 'updated_at'=>date('Y-m-d H:i:s'));

                Transaction::where('transaction_no', $paymentData->transaction_no)->update($arr);
              
                $arr=array('response_result'=>'Cancelled','action_code'=>'9', 'updated_at'=>date('Y-m-d H:i:s'));
                Payment::where('id', $paymentData->id)->update($arr);

                return [
                        'status'=>'success',
                        'data'=> $data,
                    ];
            }

        } catch (\Exception $exception) {
            return [
                'status' => 'failed',
                'error'=>$exception->getMessage(),
                'status_code'=>400
            ];
        } 
    }

    /**
     * Refund the transactions details based on the pamentId
     * @param $payment_id, $amount
     * @return \Illuminate\Http\Response
     */

    function refundTabbypayment($payment_id, $amount){
        
        try{
             $paymentURL="payments/".$payment_id."/refunds";

            $fields=array(
                "amount"=>$amount
            );

            $postData=json_encode($fields);
            $result=$this->postDataUsingCurl($paymentURL,$postData);
            $data=json_decode($result);
 
            if($data){
                if(!empty($data->status) && $data->status=='error'){
                    return [
                        'payment_status'=>'failed',
                        'message'=> $data->error,
                    ];
                } else {
                    return  [
                        'payment_status'=>'success',
                        'data'=> $data,
                    ];
                }
            } else {
                return [
                        'payment_status'=>'failed',
                        'message'=> "Refund not yet done"
                ];
            }
        } catch (\Exception $exception) {
            return [
                'payment_status' => 'failed',
                'message'=>$exception->getMessage(),
                'status_code'=>400
            ];
        }     
    }

    /**
     * Send refund amount to customer when user cancelled order
     * @param 
     */
    public function send_refund(Request $request)
    {
        $rules = [
            'transaction_no' => ['required'],
            'quantity' => ['required'],
            'description' => ['required'],
            'status' => ['required'],
        ];

        $validator = Validator::make($request->all(), $rules );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $paymentData = Payment::where('transaction_no', $request['transaction_no'])
                        ->where('payment_status', 'Successful')->where('payment_type', 1)->first();

        if(empty($paymentData)){
              return response()->json(['status'=>'failed', 'message'=> 'Transaction already redeemed, Refund not allowed' ], 400);
        }

        //Get payment details to check
        $paymentURL="payments/".$paymentData->payid;
        $result= $this->getDataUsingCurl($paymentURL);
        $data=json_decode($result);

        if($data){
            if(!empty($data->status) && $data->status=='error'){
                return response()->json([
                    'status'=>'failed',
                    'message'=> $data->error,
                ], 400);

            } else {

                if($data->status=='CLOSED'){
                    if(!count($data->captures)){
                        return response()->json([
                            'status'=>'failed',
                            'message'=> 'Payment not yet done',
                        ], 400);
                    } else if(count($data->refunds)>0){
                        return response()->json([
                            'status'=>'failed',
                            'message'=> 'Refund already done',
                        ], 400);
                    } 
                } else if($data->status=='AUTHORIZED'){
                    return response()->json([
                        'status'=>'failed',
                        'message'=> 'Payment authorized, but payment not yet captured',
                    ], 400);
                } 

                // Send refund to customer based on the payment method of tabby
                return (new RefundController)->send_refund($request);
            }
        } else{
           return response()->json([
                'status' => 'failed',
                'message'=> 'No data found',
                'status_code'=>400
            ]);
        }  
    } 


    // Refund amount using URWAY
    function refundBankUsingURWAY($request, $refund_for, $paymentData, $refundAmount){
        $creditController=new RefundController();
        $responseArray=$creditController->bank_refund($request, $refund_for, $request->ip()); 
         if($responseArray['payment_status']=='Successful'){
          
            $this->updateTransaction($request, $refund_for, $paymentData,$refundAmount);

            return ['status'=>'success'];
       } else {
          return ['status'=>'failed', 'message'=> $responseArray['Response']];
       }  
    }

    // Refund amount using tabby
    function refundBankUsingTabby($request, $refund_for, $paymentData, $refundAmount){
        $responseArray=$this->refundTabbypayment($paymentData->payid, $refundAmount); 

        if($responseArray['payment_status']=='success'){
            $paymentArray['action_code']=2;
            $paymentArray['updated_at']=date("Y-m-d H:i:s");
            Payment::where('id', $paymentData->id)->update($paymentArray);

            $this->updateTransaction($request, $refund_for, $paymentData,$refundAmount);
          
            return ['status'=>'success'];
        } else {
            return ['status'=>'failed', 'message'=> $responseArray['message']];
        }
    }

    //Update Transaction details
    function updateTransaction($request, $refund_for, $paymentData, $refundAmount){
   
      $creditController=new RefundController();
      if($paymentData->amount_by_credits>0){ 
        $request['credit_by']='C';
        $request['amount']=$paymentData->amount_by_credits;
        $creditController->sendRefundAmount($request,$refund_for);
      }

      $requestArray=$request;
      $requestArray['credit_by']='B';
      $requestArray['amount']=$refundAmount;
      $creditController->sendRefundAmount($requestArray, $refund_for);
    }


    /**
     * Call API using get Method
     * 
     */
    function getDataUsingCurl($url){
       
        $url="https://api.tabby.ai/api/v2/".$url;
        $token=$this->secretKey;
        $ch = curl_init($url); // Will be provided by Tabby
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $headers=array(
            'Content-Type: application/json',
            'Authorization: Bearer '.$token
        );
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }

    /**
     * Call API using post Method
     * 
     */
    function postDataUsingCurl($url, $postData){
        $url="https://api.tabby.ai/api/v2/".$url;
        $token=$this->secretKey;
        $ch = curl_init($url); // Will be provided by Tabby
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $headers=array(
            'Content-Type: application/json',
            'Authorization: Bearer '.$token
        );

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);

        curl_close($ch);
        return $response;
     }



    /** 
     * Formate redeem price
     */

    public function format_price($row)
    {
        $dealShare = new DealController();

        $pricing = $dealShare->bill_price_logic($row['transaction_no'], $row->quantity); // Sends info for single quantity
        $row['final_price'] = $pricing['final_price'];
        $row['discount'] = $pricing['price_after_discount'];
        $row['vat_amount'] = $pricing['vat_amount'];
        $row['item_price'] = $pricing['item_price'];
        $row['discount_amount'] = $pricing['discount_amount'];

        $row['vat'] = $pricing['vat'];
        $row['payment_with'] = $row['payment']['payment_on'] ?? '';
        $row['filter_cost'] = $pricing['filter_cost'];
        $row['service_cost'] = $pricing['service_cost'];
        $row['service_cost_without_vat'] = $pricing['service_cost_without_vat'];
        $row['coupon_savings'] = $pricing['coupon_savings'];
        $row['price_after_discount'] = $pricing['price_after_discount'];

        return $row;   
    }

    //Format transaction details

    public function format($row)
    {

        $dealShare = new DealController();
        $pricing = $dealShare->bill_price_logic($row['transaction_no']); // Sends info for single quantity
        $row['final_price'] = $pricing['final_price'];
        $row['discount'] = $pricing['price_after_discount'];
        $row['vat_amount'] = $pricing['vat_amount'];
        $row['item_price'] = $pricing['item_price'];
        $row['discount_amount'] = $pricing['discount_amount'];

        $row['vat'] = $pricing['vat'];

        $row['payment_method'] = '-';
        $payment_on = $row['payment']['payment_on'] ?? '';

        if($row['payment_with'] == 7)
            $row['payment_method'] = 'Joy Credits';
        else if($row['payment_with'] == 8 || $row['payment_with'] == 9) {
            if($payment_on == '')
                $row['payment_method'] = '-';
            else{
                $row['payment_method'] = ($row['payment_with'] == 9 ? 'Joy Credits & ' : '').
                    Lookup::where('id', $payment_on)->pluck('entity_name')->first();
            }
        }

        $row['filter_cost'] = $pricing['filter_cost'];
        $row['service_cost'] = $pricing['service_cost'];
        $row['coupon_savings'] = $pricing['coupon_savings'];

        $status = $this->transaction_row_status($row);
        $row['transaction_status'] = $status['transaction_status'];
        $row['transaction_status_ar'] = $status['transaction_status_ar'];

        if ($row['item']) {
            $row['item']['title'] = $row['paymentinfo']['item_name'];
            $row['item']['title_ar'] = $row['paymentinfo']['item_name_ar'];
            $row['item']['dimensions'] = $row['paymentinfo']['dimensions'];
            $row['item']['volt'] = $row['paymentinfo']['volt'];
            $row['item']['ah'] = $row['paymentinfo']['ah'];
            $row['item']['size'] = $row['paymentinfo']['size'];
            $row['item']['height'] = $row['paymentinfo']['height'];
            $row['item']['width'] = $row['paymentinfo']['width'];
            $row['item']['description'] = $row['paymentinfo']['item_description'];
            $row['item']['description_ar'] = $row['paymentinfo']['item_description_ar'];
            $row['item']['thumbnail_url'] = $row['paymentinfo']['thumbnail_url'];
        }

        if ($row['offer']) {
            $row['offer']['title'] = $row['paymentinfo']['offer_name'];
            $row['offer']['title_ar'] = $row['paymentinfo']['offer_name_ar'];
            $row['offer']['description'] = $row['paymentinfo']['offer_description'];
            $row['offer']['description_ar'] = $row['paymentinfo']['offer_description_ar'];
            $row['offer']['terms'] = $row['paymentinfo']['terms'];
            $row['offer']['terms_ar'] = $row['paymentinfo']['terms_ar'];
            $row['offer']['end_date'] = $row['paymentinfo']['end_date'];
            $row['offer']['is_notify'] = $row['paymentinfo']['is_notify'];
            $row['offer']['on_site'] = $row['paymentinfo']['on_site'];
            $row['offer']['service_cost'] = $row['paymentinfo']['service_cost'];
        }

        if ($row['item']['delar']) {
            $row['item']['delar']['org_name'] = $row['paymentinfo']['delar_name'];
            $row['item']['delar']['org_name_ar'] = $row['paymentinfo']['delar_name_ar'];
            $row['item']['delar']['address'] = $row['paymentinfo']['delar_address'];
        }

        $row['customer_contactnumber'] = "";
        if ($row['offer']['on_site'] == '1') {
            $row['customer_contactnumber'] = Driver::where('id', $row['created_by'])->pluck('contact_no')->first();
        }

        $row['scan_url'] = url('/download_public_invoice/' . $row['transaction_no']);

        unset($row['paymentinfo']);
        return $row;
    }

       //Get joy purchase status
    public function transaction_row_status($row)
    {

        if (($row['redeem_quantity'] > 0 && $row['revised_quantity'] > 0) && $row['payment_status'] == 'Successful') {
            $transaction_status = 'Paid';
            $transaction_status_ar = 'مستخدمة';
        } else if ($row['quantity'] == $row['revised_quantity'] && ($row['payment_status'] == 'Successful' || $row['payment_status'] == 'Available')) {
            $transaction_status = 'Refunded';
            $transaction_status_ar = 'مستردة';
        } else if (($row['quantity']-$row['redeem_quantity'])-$row['revised_quantity']>0 && $row['revised_quantity']>0 && ($row['payment_status'] == 'Successful' || $row['payment_status'] == 'Available')) {
            $transaction_status = 'Partial Refund';
            $transaction_status_ar = 'مستردة';
        }  else if (($row['quantity']-$row['revised_quantity'])==$row['redeem_quantity'] && $row['redeem_quantity']>0 && ($row['payment_status'] == 'Successful' || $row['payment_status'] == 'Successful')) {
            $transaction_status = 'Redeemed';
            $transaction_status_ar = 'مستخدمة';
        } else if ($row['payment_status'] == 'Successful' && ($row['revised_quantity'] == '0' && $row['redeem_quantity'] == '0')) {
            $transaction_status = 'Successful';
            $transaction_status_ar = 'مدفوعة';
        } else if ($row['payment_status'] == 'pending') {
            $transaction_status = 'In Complete';
            $transaction_status_ar = 'في اكتمال';
        } else if ($row['payment_status'] == 'Rejected') {
            $transaction_status = 'Rejected';
            $transaction_status_ar = 'فشل';
        } else if ($row['payment_status'] == 'Requests') {
            $transaction_status = 'In-process';
            $transaction_status_ar = 'تحت المعالجة';
        } else if ($row['payment_status'] == 'Cancelled') {
            $transaction_status = 'Cancelled';
            $transaction_status_ar = 'ملغية';
        } else if ($row['payment_status'] == 'Failed') {
            $transaction_status = 'Failed';
            $transaction_status_ar = 'فشل';
        } else if ($row['payment_status'] == 'Available') {
            $transaction_status = 'Available';
            $transaction_status_ar = 'متاح';
        }  else {
            $transaction_status = $row['payment_status'];
            $transaction_status_ar = $row['payment_status'];
        }

        return array(
            'transaction_status' => $transaction_status,
            'transaction_status_ar' => $transaction_status_ar
        );
    }

    public function capture_amount(Request $request)
    {
        return $this->captureAmount($request);
    }

    function captureAmount($request){
        try{ 

            $item_id = Transaction::where('transaction_no', $request->transaction_no)->pluck('item_id')->first();

            $is_notify = ItemOffer::where('item_id', $item_id)->pluck('is_notify')->first();

            $trans_status = $request->payment_status;
            if ($request->payment_status == 'Successful' && $is_notify)
                $trans_status = 'Requests';


            $remarks = 'Payment processing was ' . $request->payment_status;
            if ($request->payment_status == 'Failure') {
                $remarks = 'Payment processing was failed';
                $trans_status = 'Failed';
                $request['payment_status'] = 'Failed';
            }

            $tranArray['payment_status']=$trans_status;
            $tranArray['remarks']=$remarks;

            Transaction::where('transaction_no', $request->transaction_no)
                ->update(['payment_status' => $trans_status, 'remarks' => $remarks]);

            $paymentData=Payment::where('transaction_no', $request->transaction_no)->orderBy('id','ASC')->first();

            $paymentArray['payid'] = $request->payment_id;
            $paymentArray['payment_status'] = $request['payment_status'];
            $paymentArray['response_result'] = strtolower($request->tabby_status);
            $paymentArray['payment_on'] = 50;
            $paymentArray['updated_at'] = Date('Y-m-d H:i:s');
            $paymentArray['transaction_no'] = $request->transaction_no;

            Payment::where('payment_no', $paymentData->payment_no)
                    ->update($paymentArray);

             $transactionArray['payment_status']=$request->payment_status;
             $transactionArray['updated_at'] = Date('Y-m-d H:i:s');
             Payment::where('transaction_no', $request->transaction_no)
                    ->update($transactionArray);

            if($trans_status=='Successful'){
                $captureAmount=$paymentData->amount_by_banking;

                // return response()->json(['status'=>'success', 'message'=>'Authorization done. Once deal available payment will be capture'], 200);

                $result=$this->captureAmountUsingPaymentId($request, $captureAmount);

                if($result['status']=='failed'){
                   return response()->json($result, 400);
                } else {

                    $paymentNewArray['updated_at'] = Date('Y-m-d H:i:s');
                    $paymentNewArray['response_result'] = $result['payment_status'];
                    $paymentNewArray['action_code'] = 5;
                    Payment::where('payment_no', $paymentData->payment_no)
                        ->update($paymentNewArray);

                    $trans = Transaction::where('transaction_no', $request->transaction_no)->first();
                        

                        // update available quantity
                    if ($trans['deal_id'] == 6 || $trans['deal_id'] == 2) // tires & battaries
                        ItemMaster::where('id', $trans['item_id'])
                            ->update(['quantity' => DB::raw('quantity - ' . $trans['quantity'])]);

                    ItemOffer::where('id', $trans['offer_id'])->where('item_id', $trans['item_id'])
                        ->update(['quantity' => DB::raw('quantity - ' . $trans['quantity'])]);

                   $this->update_transaction_invoice_no($request->transaction_no);

                   //Send Notifications

                   return response()->json($result, 200);
                }
            } else {
                return response()->json(['status'=>'success', 'message'=>'Authorization done. Once deal available payment will be capture'], 200);
            }
        }catch(\Exception $e){
            return response()->json(['status'=>'failed', 'message'=>'Failed to capture', 'error'=>$e->getMessage()], 400);
        }
    }

    private function update_transaction_invoice_no($transaction_id){

        $successCount = Transaction::join('payments', 'payments.transaction_no', 'transactions.transaction_no')
            ->where('transactions.transaction_no', $transaction_id)
            ->whereIn('transactions.payment_status', ['Successful', 'Available'])
            ->where('payments.payment_status', 'Successful')
            ->where('payments.payment_type', '=', 1) // 1 - Main Payment
            ->whereNull('transactions.invoice_no')
            ->count();

        if(!$successCount) // Not Eligible for invoice
            return false;

        $successCount = Transaction::whereNotNull('invoice_no')->count();

        $invoiceNo = 100000000 + $successCount + 1;
        Transaction::where('transaction_no', $transaction_id)->update(['invoice_no' => $invoiceNo]);
        Payment::where('transaction_no', $transaction_id)
            ->where('payment_type', 1) // 1 - Main Payment
            ->update(['invoice_no' => $invoiceNo]);

        // Send Payment success alert
        (new SendPushNotification())->send_success_tran_alert($transaction_id);
    }


    function captureAmountUsingPaymentId($request, $amount){
         try{  
            $paymentURL="payments/".$request->payment_id."/captures";

             $fields=array(
                "amount"=>$amount
            );
 
            $postData=json_encode($fields);

            $result=$this->postDataUsingCurl($paymentURL, $postData);

            $data=json_decode($result);
           
            if($data){
                if(!empty($data->status) && $data->status=='error'){
                   return [
                        'status'=>'failed',
                        'message'=> $data->error,
                    ];

                } else {
                    $newData=$this->getTransactionInfo($data);
                    return [
                        'status'=>'success',
                        'data'=> $newData,
                        'payment_status'=>$data->status
                    ];
                }
            } else {
                return [
                    'status'=>'failed',
                    'message'=> 'Not yet captured',
                ];
            }

        } catch (\Exception $exception) {
            return [
                'status' => 'failed',
                'error'=>$exception->getMessage(),
                'status_code'=>400
            ];
        } 
    }


    /**
     * get all pending transactions
     * @param Request $request
     * @return \Illuminate\Http\Response
     */

    function getAllPendingTransactions(Request $request){

        $pageno = 1;
        $pagelength = 10;
        $login_type_id = Auth::user()->login_type_id;
        $list = Transaction::with('item', 'offer', 'driver', 'item.delar', 'item.deal',
            'refund', 'adjustment', 'location', 'driver.fleet_consumer', 'approver')
            ->where('payment_status','pending');

        
        if (isset($request->deal_category) && $request->deal_category != 'All') {
            $list = $list->where('deal_id', $request->deal_category);
        }

        $totalrecords = $list->orderBy('id', 'desc')->count();

        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = $list->orderBy('id', 'desc')->skip(($pageno - 1) * $pagelength)->take($pagelength)->get()
            ->map(function ($row) {
                return $this->format($row);
            });

        if (explode('/', $request->route()->getPrefix())[0] == 'api') {
            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status' => 'success', 'data' => $data], 200);
        } else {
            return response()->json(['status' => 'success', 'data' => $list], 200);
        }
    }

    /**
     * get all refunded transactions
     * @param Request $request
     * @return \Illuminate\Http\Response
     */

    function getAllRefundedTransactions(Request $request){
        $pageno = 1;
        $pagelength = 10;
        $login_type_id = Auth::user()->login_type_id;
        $list = Transaction::with('item', 'offer', 'driver', 'item.delar', 'item.deal', 'refund', 'adjustment', 'location', 'driver.fleet_consumer', 'approver')
        ->select('transactions.*','payments.response_result')
        ->where('transactions.payment_status','Successful')
        ->where('transactions.revised_quantity','>','0')
        ->where('payments.payment_on',50)
        ->join('payments', 'payments.transaction_no', 'transactions.transaction_no');

        
        if (isset($request->deal_category) && $request->deal_category != 'All') {
            $list = $list->where('transactions.deal_id', $request->deal_category);
        }

        $list = $list->orderBy('transactions.id', 'desc');
        $totalrecords = $list->count();

        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = $list->skip(($pageno - 1) * $pagelength)->take($pagelength)->get()
            ->map(function ($row) {
                return $this->format($row);
            });

        if (explode('/', $request->route()->getPrefix())[0] == 'api') {
            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status' => 'success', 'data' => $data], 200);
        } else {
            return response()->json(['status' => 'success', 'data' => $list], 200);
        }
    }


    /**
     * get all cancelled transactions
     * @param Request $request
     * @return \Illuminate\Http\Response
     */

    function getAllCancelledTransactions(Request $request){

        $pageno = 1;
        $pagelength = 10;
        $login_type_id = Auth::user()->login_type_id;
        $list = Transaction::with('item', 'offer', 'driver', 'item.delar', 'item.deal', 'refund', 'adjustment', 'location', 'driver.fleet_consumer', 'approver')
        ->select('transactions.*','payments.response_result')
        ->where('transactions.payment_status','Cancelled')
        ->where('payments.payment_on',50)
        ->join('payments', 'payments.transaction_no', 'transactions.transaction_no');

        if (isset($request->deal_category) && $request->deal_category != 'All') {
            $list = $list->where('transactions.deal_id', $request->deal_category);
        }

        $list = $list->orderBy('transactions.id', 'desc');
        $totalrecords = $list->count();

        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = $list->skip(($pageno - 1) * $pagelength)->take($pagelength)->get()
            ->map(function ($row) {
                return $this->format($row);
            });

        if (explode('/', $request->route()->getPrefix())[0] == 'api') {
            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status' => 'success', 'data' => $data], 200);
        } else {
            return response()->json(['status' => 'success', 'data' => $list], 200);
        }
    }
}
