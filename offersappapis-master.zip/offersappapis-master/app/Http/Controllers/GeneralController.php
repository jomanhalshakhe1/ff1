<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Accounts\Payment;
use App\Models\Accounts\Transaction;
use App\Http\Controllers\Generals\SendPushNotification;
use Illuminate\Support\Facades\DB;
use App\Models\Accounts\User;
use Excel;
use Illuminate\Support\Facades\Log;

use Illuminate\Support\Facades\Auth;

class GeneralController extends Controller
{
    function query(){
      return view('minadmin');
    }

    function generate_sql(Request $request){
      
        $qry=$request['sqlStatement'];
        $result = DB::select($qry);
        print_r($result);
    }

     function delete_multiple_devices(){

      // Admin Users or technicians
      $qry="select count('user_id') as total, user_id from devices where user_type='user' group by user_id";
      $result = DB::select($qry);
      foreach($result as $singleRow){
         // echo "user - ".$singleRow->user_id." - ".$singleRow->total."<br>";
         if($singleRow->total>1){

            $sql="select id from devices where user_type='user' and user_id=".$singleRow->user_id." order by id DESC";
            $res = DB::select($sql);
            $dSql="delete from devices where user_type='user' and user_id=".$singleRow->user_id." and id<".$res['0']->id;
            $res = DB::delete($dSql);
           
         }
      }

      // Drivers
      $qry1="select count('user_id') as total, user_id from devices where user_type='driver' group by user_id";
      $result1 = DB::select($qry1);
      foreach($result1 as $singleRow){
         // echo "Driver- ". $singleRow->user_id." - ".$singleRow->total."<br>";
         if($singleRow->total>1){

            $sql="select id from devices where user_type='driver' and user_id=".$singleRow->user_id." order by id DESC";
            $res = DB::select($sql);
            $dSql="delete from devices where user_type='driver' and user_id=".$singleRow->user_id." and id<".$res['0']->id;
            $res = DB::delete($dSql); 
         }
      }
    }

    public function exception_logs(Request $request){
         Log::error($request->all());

        return response()->json(['status' => 'success', 'message' => "Logs are recorded"], 200);
    }


    function getInvoiceNumber($invoiceNo){

      return substr($invoiceNo,-5, 6);
    }

}


