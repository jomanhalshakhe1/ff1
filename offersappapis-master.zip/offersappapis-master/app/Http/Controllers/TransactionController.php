<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Generals\DealController;
use App\Http\Controllers\Mediator\ServiceBookingController;
use App\Http\Controllers\Users\CreditsController;
use App\Http\Controllers\Users\PetrominController;
use App\Http\Controllers\Users\VehicleController;
use App\Models\Accounts\FleetDriver;
use App\Models\Accounts\Payment;
use App\Models\Accounts\PaymentShare;
use App\Models\Accounts\OnsiteLocation;
use App\Models\Accounts\TransactionComment;
use App\Models\Accounts\TransactionDetail;
use App\Models\Accounts\Vehicle;
use App\Models\Generals\City;
use App\Models\Generals\Coupons\Coupon;
use App\Models\Generals\Coupons\CouponLog;
use App\Models\Generals\Deal;
use App\Models\Generals\Lookup;
use App\Models\Generals\Notification;
use App\Models\Generals\NotificationLog;
use App\Models\Generals\Payout;
use App\Models\Generals\RedeemLog;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use App\Models\Accounts\Transaction;
use App\Models\Inventory\MaintenanceLog;
use App\Models\Payments\PaymentGateway;
use App\Models\Regulatory\Location;
use App\Models\Regulatory\Organization;
use App\Models\Regulatory\TechnicianLocation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use App\Models\Accounts\Driver;
use Excel;
use PDF;
use PDFAR;
use App\Http\Controllers\Generals\SendPushNotification;
use Salla\ZATCA\GenerateQrCode;
use Salla\ZATCA\Tags\InvoiceDate;
use Salla\ZATCA\Tags\InvoiceTaxAmount;
use Salla\ZATCA\Tags\InvoiceTotalAmount;
use Salla\ZATCA\Tags\Seller;
use Salla\ZATCA\Tags\TaxNumber;
use App\Models\Accounts\Credit;
use App\Events\NewOrderPlaced;
use App\Events\RequestOfferAvailability;
use App\Events\OfferRedeemed;
use App\Events\AddressRequested;
use App\Events\sendAddressForOnsite;
use App\Events\cancelTranaction;
use App\Events\offerAvailabilityUpdated;
use App\Events\Emails\RedeemedOfferEmail;
use App\Events\Emails\PurchasedAnOfferEmail;
use App\Events\Emails\OfferAvailabilityStatusForAdmin;
use App\Events\Emails\ConsumerCurrentLocationForAdmin;
use App\Models\Accounts\User;
use App\Http\Controllers\Payments\RefundController;
use App\Http\Controllers\tabby\TabbyController;
use App\Http\Controllers\Payments\AdjustmentController;

class TransactionController extends Controller
{

    /**
     * Display a listing of the resource.
     * Access: admin - 17, partner - 19, dealer - 18 prefix: api
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        // all deal provider transactions : web
        $pageno = 1;
        $pagelength = 10;
        $login_type_id = Auth::user()->login_type_id;

        $list = Transaction::where( 'status', 1);

        if (isset($request->status) && $request->status != 'All') {
            if ($request->status == 'Redeemed') {
                $list = $list->where('payment_status', 'Successful')
                  ->where('redeem_quantity','>',0)
                  ->whereRaw("((quantity-revised_quantity)-redeem_quantity)=0");
            } else if ($request->status == 'Refunded') {
                $list = $list->whereRaw("(payment_status='Successful' or payment_status='Available')")
                    ->whereColumn('revised_quantity', '=', 'quantity');
            } else if ($request->status == 'Partial Refund') {
                
                $list = $list->whereRaw("(payment_status='Successful' or payment_status='Available')")
                  ->where('revised_quantity','>',0)
                  ->whereRaw("((quantity-redeem_quantity)-revised_quantity)>0");
            } else if ($request->status == 'Paid') {
                $list = $list->where('payment_status', 'Successful')
                    ->where('redeem_quantity', '>', '0')
                    ->where('revised_quantity', '>', '0');
            } else if ($request->status == 'Successful') {
                $list = $list->where('payment_status', 'Successful')
                    ->where('redeem_quantity', '0')
                    ->where('revised_quantity', '0');
            } else  if (in_array($request->status, array('Failed', 'Cancelled', 'Requests', 'Rejected', 'pending'))) {
                $list = $list->where('payment_status', $request->status);
            } else if ($request->status == 'Available') {
                $list = $list->where('payment_status', 'Available')
                    ->where('redeem_quantity', '0')
                    ->where('revised_quantity', '0');
            } 
        }

        if (isset($request->deal_category) && $request->deal_category != 'All') {
            $list = $list->where('deal_id', $request->deal_category);
        }

        $fromDate=$request->from_date;
        $toDate=$request->to_date;

        if($fromDate!='' && $toDate==''){
            $list = $list->where('created_at','>=',$fromDate." 00:00:00");
        } else if($fromDate=='' && $toDate!=''){
            $list = $list->where('created_at','<=',$toDate." 23:59:59");
        } else if($fromDate!='' && $toDate!=''){
            $list = $list->where('created_at','>=',$fromDate." 00:00:00");
            $list = $list->where('created_at','<=',$toDate." 23:59:59");
        }

        if ($login_type_id == 17) {
            if (isset($request->deal_providers) && $request->deal_providers != 'All') {
                $list = $list->whereHas('item', function ($item) use ($request) {
                    $item->where('delar_id', $request->deal_providers);
                });
            }
        }

        $search=$request->searchby_keyword;

        // If search keyword by customer information(CI)
        if($request->searchby_type=='CI'){
            $list = $list->whereHas('driver', function ($item) use ($search) {
                $item->where('first_name','LIKE',"%{$search}%");
                $item->orWhere('last_name','LIKE',"%{$search}%");
                $item->orWhere('contact_no','LIKE',"%{$search}%");
                $item->orWhere('email','LIKE',"%{$search}%");
            });
        }

        // If search keyword by company name (CA)
        if($request->searchby_type=='CA'){
            $list = $list->whereHas('item.delar', function ($item) use ($search) {
               $item->where('org_name','LIKE',"%{$search}%");
            });
        }

        // If search keyword by Item Name(IN)
        if($request->searchby_type=='IN'){
            $list = $list->whereHas('item', function ($item) use ($search) {
               $item->where('title','LIKE',"%{$search}%");
               $item->orWhere('title_ar','LIKE',"%{$search}%");
               $item->orWhere('description','LIKE',"%{$search}%");
               $item->orWhere('description_ar','LIKE',"%{$search}%");
            });
        }


         // If search keyword by response code(RC)
        if($request->searchby_type=='RC'){
            $list = $list->whereHas('payment', function ($item) use ($search) {
               $item->where('response_code','LIKE',"%{$search}%");
            });
        }

        if ($login_type_id == 18 || $login_type_id == 22) // Delar admin or delar technician login
        {
            $list = $list->whereHas('item', function ($item) {
                $item->where('delar_id', Auth::user()->org_id);
            });
        } else if ($login_type_id == 19) { // partner account
            $list = $list->whereHas('driver.fleet_consumer', function ($item) {
                $item->where('fleet_drivers.fleet_id', Auth::user()->org_id);
            });
        }

        $totalrecords = $list->count();

        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = $list->orderBy('id', 'desc')->skip(($pageno - 1) * $pagelength)->take($pagelength)->get()
                ->map(function ($row) {
                    return $this->format_minimised_list($row);
                });

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    /**
     * Prefix: api, Access: Admin, delar
     * Consumer redeemed deals based on the delar or all delars
     * @return \Illuminate\Http\Response
     */
    public function delar_transactions(Request $request)
    {
        // all deal provider transactions : web
        $pageno = 1;
        $pagelength = 10;
        $login_type_id = Auth::user()->login_type_id;

        // Send only redeem transactions
        $list = Transaction::where('payment_status', 'Successful')
                    ->where('redeem_quantity','>',0)
                    ->whereRaw("((quantity-revised_quantity)-redeem_quantity)<=0");

        if (isset($request->deal_category) && $request->deal_category != 'All') {
            $list = $list->where('deal_id', $request->deal_category);
        }

        $fromDate=$request->from_date;
        $toDate=$request->to_date;

        if($fromDate!='' && $toDate==''){
            $list = $list->where('created_at','>=',$fromDate." 00:00:00");
        } else if($fromDate=='' && $toDate!=''){
            $list = $list->where('created_at','<=',$toDate." 23:59:59");
        } else if($fromDate!='' && $toDate!=''){
            $list = $list->where('created_at','>=',$fromDate." 00:00:00");
            $list = $list->where('created_at','<=',$toDate." 23:59:59");
        }

        if ($login_type_id == 17) {
            if (isset($request->deal_providers) && $request->deal_providers != 'All') {
                $list = $list->whereHas('item', function ($item) use ($request) {
                    $item->where('delar_id', $request->deal_providers);
                });
            }
        }
        else if ($login_type_id == 18) // Delar admin
        {
            $list = $list->whereHas('item', function ($item) {
                $item->where('delar_id', Auth::user()->org_id);
            });
        }

        $totalrecords = $list->count();

        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = $list->orderBy('id', 'desc')->skip(($pageno - 1) * $pagelength)->take($pagelength)->get()
                    ->map(function ($row) {
                        return $this->format_minimised_list($row);
                    });

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;

        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    /**
     * Prefix: api, Access: Admin
     * Consumer redeemed deals based on the partners or all partners
     * @return \Illuminate\Http\Response
     */
    public function partner_transactions(Request $request)
    {
        // all redeemed transactions : web
        $pageno = 1;
        $pagelength = 10;
        $login_type_id = Auth::user()->login_type_id;
        $list = Transaction::with('item', 'offer', 'driver', 'item.delar', 'item.deal', 'refund', 'adjustment',
            'location', 'driver.fleet_consumer', 'approver','payment');

        // Send only redeem transactions
        $list = $list->where('payment_status', 'Successful')
            ->where('redeem_quantity','>',0)
            ->whereRaw("((quantity-revised_quantity)-redeem_quantity)<=0");

        if (isset($request->deal_category) && $request->deal_category != 'All') {
            $list = $list->where('deal_id', $request->deal_category);
        }

        $fromDate=$request->from_date;
        $toDate=$request->to_date;

        if($fromDate!='' && $toDate==''){
            $list = $list->where('created_at','>=',$fromDate." 00:00:00");
        } else if($fromDate=='' && $toDate!=''){
            $list = $list->where('created_at','<=',$toDate." 23:59:59");
        } else if($fromDate!='' && $toDate!=''){
            $list = $list->where('created_at','>=',$fromDate." 00:00:00");
            $list = $list->where('created_at','<=',$toDate." 23:59:59");
        }
        $list = $list->whereNotNull('fleet_id');

        if (isset($request->partners) && $request->partners != 'All') {
            $list = $list->where('fleet_id', $request->partners);
        }

        $totalrecords = $list->count();

        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = $list->orderBy('id', 'desc')->skip(($pageno - 1) * $pagelength)->take($pagelength)->get()
            ->map(function ($row) {
                return $this->format_minimised_list($row);
            });

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;

        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    /**
     * Consumer purchased deals based on the logged in driver
     * My Deals for consumer app
     * @return \Illuminate\Http\Response
     */
    public function consumer_deals()
    {
        // Consumer my deals list
        $list = Transaction::where('created_by', Auth::guard('driver')->id())
            ->whereIn('payment_status', ['Successful', 'Available', 'Requests', 'Rejected', 'Failed'])
            ->with('item', 'location', 'offer', 'payment', 'vehicle_owners')
            ->where('status', 1)->orderBy('id', 'desc')->get()
            ->map(function ($row) {
                $row = $this->format($row);
                $row['vin_no_required'] = 0; $row['plate_no_required'] = 0;
                if($row['offer']['vn_access'] && $row->vehicle_owners)
                    $row['vin_no_required'] = (!$row->vehicle_owners->serial_no) ? 1 : 0;

                if($row['offer']['pn_access'] && $row->vehicle_owners)
                        $row['plate_no_required'] = (!$row->vehicle_owners->plate_no) ? 1 : 0;

                return $row;
            });

        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

       //Get joy purchase status
    public function transaction_row_status($row)
    {

        // if (($row['redeem_quantity'] > 0 && $row['revised_quantity'] > 0) && $row['payment_status'] == 'Successful') {
        //     $transaction_status = 'Paid';
        //     $transaction_status_ar = 'مستخدمة';
        // } else if ($row['quantity'] == $row['revised_quantity'] && ($row['payment_status'] == 'Successful' || $row['payment_status'] == 'Available')) {
        //     $transaction_status = 'Refunded';
        //     $transaction_status_ar = 'مستردة';
        // } else if ($row['payment_status'] == 'Successful' && ($row['revised_quantity'] == '0' && $row['redeem_quantity'] == '0')) {
        //     $transaction_status = 'Successful';
        //     $transaction_status_ar = 'مدفوعة';
        
        // } else if (($row['quantity']-$row['redeem_quantity'])-$row['revised_quantity']>0 && $row['revised_quantity']>0) {
        //     $transaction_status = 'Partial Refund';
        //     $transaction_status_ar = 'مستردة';
        // } else if (($row['quantity']-$row['revised_quantity'])==$row['redeem_quantity'] && $row['redeem_quantity']>0 ) {
        //     $transaction_status = 'Redeemed';
        //     $transaction_status_ar = 'مستخدمة';
        // } else if ($row['payment_status'] == 'pending') {
        //     $transaction_status = 'In Complete';
        //     $transaction_status_ar = 'في اكتمال';
        // } else if ($row['payment_status'] == 'Rejected') {
        //     $transaction_status = 'Rejected';
        //     $transaction_status_ar = 'فشل';
        // } else if ($row['payment_status'] == 'Requests') {
        //     $transaction_status = 'In-process';
        //     $transaction_status_ar = 'تحت المعالجة';
        // } else if ($row['payment_status'] == 'Cancelled') {
        //     $transaction_status = 'Cancelled';
        //     $transaction_status_ar = 'ملغية';
        // } else if ($row['payment_status'] == 'Failed') {
        //     $transaction_status = 'Failed';
        //     $transaction_status_ar = 'فشل';
        // } else if ($row['payment_status'] == 'Available') {
        //     $transaction_status = 'Available';
        //     $transaction_status_ar = 'متاح';
        // }  else {
        //     $transaction_status = $row['payment_status'];
        //     $transaction_status_ar = $row['payment_status'];
        // }




        if (($row['redeem_quantity'] > 0 && $row['revised_quantity'] > 0) && $row['payment_status'] == 'Successful') {
            $transaction_status = 'Paid';
            $transaction_status_ar = 'مستخدمة';
        } else if ($row['quantity'] == $row['revised_quantity'] && ($row['payment_status'] == 'Successful' || $row['payment_status'] == 'Available')) {
            $transaction_status = 'Refunded';
            $transaction_status_ar = 'مستردة';
        } else if (($row['quantity']-$row['redeem_quantity'])-$row['revised_quantity']>0 && $row['revised_quantity']>0 && ($row['payment_status'] == 'Successful' || $row['payment_status'] == 'Available')) {
            $transaction_status = 'Partial Refund';
            $transaction_status_ar = 'مستردة';
        }  else if (($row['quantity']-$row['revised_quantity'])==$row['redeem_quantity'] && $row['redeem_quantity']>0 && ($row['payment_status'] == 'Successful' || $row['payment_status'] == 'Successful')) {
            $transaction_status = 'Redeemed';
            $transaction_status_ar = 'مستخدمة';
        } else if ($row['payment_status'] == 'Successful' && ($row['revised_quantity'] == '0' && $row['redeem_quantity'] == '0')) {
            $transaction_status = 'Successful';
            $transaction_status_ar = 'مدفوعة';
        } else if ($row['payment_status'] == 'pending') {
            $transaction_status = 'In Complete';
            $transaction_status_ar = 'في اكتمال';
        } else if ($row['payment_status'] == 'Rejected') {
            $transaction_status = 'Rejected';
            $transaction_status_ar = 'فشل';
        } else if ($row['payment_status'] == 'Requests') {
            $transaction_status = 'In-process';
            $transaction_status_ar = 'تحت المعالجة';
        } else if ($row['payment_status'] == 'Cancelled') {
            $transaction_status = 'Cancelled';
            $transaction_status_ar = 'ملغية';
        } else if ($row['payment_status'] == 'Failed') {
            $transaction_status = 'Failed';
            $transaction_status_ar = 'فشل';
        } else if ($row['payment_status'] == 'Available') {
            $transaction_status = 'Available';
            $transaction_status_ar = 'متاح';
        }  else {
            $transaction_status = $row['payment_status'];
            $transaction_status_ar = $row['payment_status'];
        }

        return array(
            'transaction_status' => $transaction_status,
            'transaction_status_ar' => $transaction_status_ar
        );
    }

    /*
     * API: partner app, Prefix: dealer
     * Access: delar admin, technician
     * The notified offer transactions will send to the respective delar admin or technician
     * If user as dealer admin, can access all locations
     * If user as dealer technician, can access only respective technican location related offers
     */
    public function transaction_requests(Request $request)
    {
        $pageno = 1;
        $pagelength = 50;

        $login_type_id = Auth::user()->login_type_id;

        // Consumer Transactions on Offer with Notify requests or Onsite Requests
        $list = Transaction::where(function ($qry) {
            $qry->where('payment_status', 'Requests')// Notify Requests
            ->orWhere(function ($query) { // Checking for On Site Requests
                $query->where('payment_status', 'Successful')
                    ->whereNull('is_approved');
            });
        });
        if ($login_type_id == 18 || $login_type_id == 22) { // Delar admin or Delar technician
            $list = $list->whereHas('item', function ($qry) {
                $qry->where('delar_id', Auth::user()->org_id);
            });
            if ($login_type_id == 22) {
                // check the technician eligible for transaction location
                $list = $list->whereIn('transactions.location_id', function ($query) {
                    $query->selectRaw('distinct location_id')
                        ->from('technician_locations')
                        ->where('technician_locations.technician_id', Auth::id())
                        ->where('technician_locations.status', 1);
                });
            }
        }

        $list = $list->whereHas('offer', function ($qry) {
            // Offer with Notify requests or Onsite Requests
            $qry->where('transactions.payment_status', 'Requests')// Notify Requests
            ->orWhere(function ($query) { // On Site Requests
                $query->where('on_site', 1)
                    ->where('transactions.payment_status', 'Successful')
                    ->whereRaw('transactions.quantity - transactions.revised_quantity - transactions.redeem_quantity > 0');
            });
        });

        $list = $list->with('item', 'location', 'offer', 'vehicle_owners', 'payment', 'driver');

        $totalrecords = $list->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = $list->orderBy('id', 'desc')->get()
            ->map(function ($row) {
                return $this->format($row);
            });

        if (explode('/', $request->route()->getPrefix())[0] == 'api') {
            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status' => 'success', 'data' => $data], 200);
        } else {
            return response()->json(['status' => 'success', 'data' => $list], 200);
        }
    }


    /**
     * Prefix: dealer, api Access: Dealer Technician, admin, dealer
     * Partner approve or reject availability for deal request
     * Update availability for is notify request by partner
     * @return \Illuminate\Http\Response
     */
    public function update_availability()
    {
        $request=request();
        $validator = Validator::make($request->all(),
            [
                'transaction_no' => ['required'],
                'is_available' => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach (json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json(['status' => "failed", "response" => $errors], 400);
        }

        $list = Transaction::where('transaction_no', $request['transaction_no'])->first();

        if (!$list)
            return response()->json(['status' => 'failed', 'message' => "Invalid Transaction Id", 'message_ar'=>'معرف المعاملة غير صالح'], 400);

        if($list->approved_by && $request->is_available==3){
            return response()->json(['status' => 'failed', 'message' => "Not allowed to approve", 'message_ar'=>'غير مسموح بالموافقة'], 400); 
        }

        if($list->is_approved && $request->is_available<2){
            $payment_status='accepted';
            $payment_status_ar='قبلت';
            if($list->payment_status=='Rejected'){
               $payment_status='rejected';
               $payment_status_ar='نبيذ';
            }

            return response()->json(['status' => 'failed', 'message' => "Already technicians ".$payment_status, 'message_ar'=>"الفنيين بالفعل  ".$payment_status_ar], 400); 
        }
 
        if(!(Payment::where('transaction_no', $request['transaction_no'])->where('payment_status','Successful')->count()))
             return response()->json(['status' => 'failed',
                'message' => 'Payment not yet completed. Please contact administrator',
                'message_ar' => 'الدفع لم يكتمل بعد. الرجاء الاتصال بالمسؤول'], 400);

        $cnt = Transaction::join('item_master', 'item_master.id', 'transactions.item_id')
            ->join('organizations', 'organizations.id', 'item_master.delar_id')
            ->where('organizations.code', 'PETROMIN')
            ->where('transactions.payment_status', 'Successful')
            ->where('transactions.transaction_no', $request['transaction_no'])
            ->select('transactions.*')->count();

        if($cnt > 0){
            return response()->json(['status' => 'failed',
                'message' => "For petromin services, technician can't approve or reject transaction",
                'message_ar' => 'بالنسبة لخدمات بترومين ، لا يمكن للفني الموافقة على المعاملة أو رفضها'], 400);
        }

        $offer = ItemOffer::where('id', $list['offer_id'])->first();

        if($offer['vn_access'] || $offer['pn_access']){
            // vin no or plate no was required for this transaction
            if ($offer['vn_access'] && Vehicle::where('id', $list['vehicle_id'])->whereNull('serial_no')->count() > 0) {
                return response()->json(['status' => 'failed',
                    'message' => 'Vin no. on this transaction was required',
                    'message_ar' => 'فين لا. على هذه الصفقة كان مطلوبا'], 400);
            }

            if ($offer['pn_access'] && Vehicle::where('id', $list['vehicle_id'])->whereNull('plate_no')->count() > 0) {
                return response()->json(['status' => 'failed',
                    'message' => 'Vehicle plate no. on this transaction was required',
                    'message_ar' => 'رقم لوحة المركبة. على هذه الصفقة كان مطلوبا'], 400);
            }
        }

        /*
         * is_available values
         * 0 - When partner rejected for requested deal
         * 1 - When partner accepted for requested deal
         * 2 - If notify request not yet approved or rejected by partner then admin can "Cancelled"
         * 3 - when technician click on save button for onsite deal in partner app
         * 4 - when technician click on call button for onsite deal in partner app
         *
         * Admin rejects means - it was Cancelled
         * Partner rejects means - it was Rejected
         */

        $msg = "Technician ".($request['is_available'] == 1 ? "accepted" : "rejected"). " offer availablity for purchased item";
        if ($request['is_available'] == "1") //When partner accepted for requested deal
        {
            $payment_status = 'Available';

            if (Payment::where('transaction_no', $request['transaction_no'])
                    ->where('payment_status', 'Successful')
                    ->where('amount_by_banking', '=', 0)->count() > 0
            ) {
                // Transaction only with credits
                $payment_status = 'Available';
            }else {
                // unlock the payments by payment gateway
                $offer_id = Transaction::where('transaction_no', $request['transaction_no'])->pluck('offer_id')->first();
                $is_notify = ItemOffer::where('id', $offer_id)->pluck('is_notify')->first();
                $cnt = Payment::where('transaction_no', $request['transaction_no'])->where('action_code', 4)->count();

                if($is_notify && $cnt > 0){
                    $payment_status = 'Available';
                } else
                    $payment_status = 'Successful';
            }
        } else if($request['is_available'] == "2") { //If notify request not yet approved or rejected by partner then admin can cancelled
            $payment_status = 'Cancelled';
            $request['is_available'] = 0;
            $msg = "Admin rejected offer availablity for purchased item";
        } else if ($request['is_available'] == "3") { //when technician click on save button for onsite deal in partner app
            $msg = "Technician approved for offer availablity for purchased item";
            $payment_status = 'Successful';
        } else if ($request['is_available'] == "4") {//when technician click on call button for onsite deal in partner app
            $msg = "Technician called to customer for offer availablity for purchased item";
            $payment_status = 'Successful';
        } else {
            $msg = "Technician rejected offer availablity for purchased item";
            $payment_status = 'Rejected'; //when partner rejected for requested deal
        }


        $paymentData = Payment::where('transaction_no', $request['transaction_no'])
            ->where('payment_status', 'Successful')->orderBy('id', 'ASC')->first();

        $actionCode = 5;
        if (!empty($paymentData)) {
            if ($paymentData->action_code == '4') { // If action code=4 then payment need to be uncapatured or captured based on payment tatus
                $actionCode = 5;
                if ($payment_status == 'Rejected' || $payment_status == 'Cancelled') {
                    $actionCode = 9;

                    // Only for petromin services
                    $this->delete_servicebooking($request['transaction_no']);
                }

                if($paymentData->payment_on == 50){
                    // capture or reject payments by Tabby
                    (new TabbyTransactionController())->captureTabbypayment($paymentData->payid, $paymentData->amount_by_banking, $actionCode);
                    $paymentArray['payment_status'] = ($actionCode == 5 ? 'Successful' : 'Cancelled');
                    $paymentArray['response_result'] = ($actionCode == 5 ? 'Successful' : 'Cancelled');
                } else if($paymentData->payment_on == 33 || $paymentData->payment_on == 35){
                    // capture or reject payments by urway
                    // 33 - Apple Pay, 35 - Credit Cards
                    $result = (new PaymentController())->unlock_payments($paymentData->payid, $paymentData->amount_by_banking, $request->ip(), $actionCode);
                    
                    $resultData = $result['data'];

                    if($result['payment_status'] != 'Successful'){
                        if($actionCode == 5)
                            $meesage_ar = "فشل التقاط الدفع من بوابة الدفع. حاول مرة اخرى";
                        else
                            $meesage_ar = "فشل رفض الدفع من بوابة الدفع. حاول مرة اخرى";

                        return response()->json([
                            'status' => 'failed',
                            'message' => 'Payment '.($actionCode == 5 ? "Capture" : "rejection"). " was failed from payment gateway. Please try again",
                            'message_ar' => $meesage_ar,
                        ], 400);
                    }

                    $paymentArray['payment_status'] = $result['payment_status'];
                    $paymentArray['response_result'] = $result['Response'];

                    if (!empty($resultData)) {
                        $paymentArray['response_code'] = $resultData->responseCode;
                        $paymentArray['response_amount'] = $resultData->amount;
                    }
                }

                $paymentArray['action_code']= $actionCode;
                $paymentArray['updated_at'] = date('Y-m-d H:i:s');

                Payment::where('transaction_no', $request['transaction_no'])->where('id', $paymentData->id)->update($paymentArray);
            }
        }

        $transData = array(
            'remarks' => $msg,
            'approved_by' => Auth::id(),
            'approved_at' => date('Y-m-d H:i:s')
        );

        if($request['is_available'] < 2) // update only at 1- Approved, 0 - Rejected
        {
            $transData['is_approved'] = $request['is_available'];
            $transData['payment_status'] = $payment_status;
        }

        Transaction::where('transaction_no', $request['transaction_no'])->update($transData);

        if($actionCode == 5) {
            // update invoice no to the transaction
            $this->update_transaction_invoice_no($request['transaction_no']);
        }

        // Send notification to consumer based on the availability status if it is accept or rejected

        if ($request['is_available'] < 2) {
            try {
                // 0 - Rejected, 1 - Accepted & Approved, 2 - Rejected by admin
                // Send notification to consumer , deal admin
                event(new offerAvailabilityUpdated($request['transaction_no'], 41, $request['is_available']));

                // Send email notification to deal admin
                event(new OfferAvailabilityStatusForAdmin($request['transaction_no'], $request['is_available']));
            }catch (\Exception $e){
                Log::error("Transaction Availability events Failed: ". $request['transaction_no']);
                Log::error($e->getMessage());
            }
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Transaction updated successfully',
            'message_ar' => 'تم تحديث المعاملة بنجاح',
        ], 200);
    }

    public function update_transaction_invoice_no($transaction_id){

        $successCount = Transaction::join('payments', 'payments.transaction_no', 'transactions.transaction_no')
            ->where('transactions.transaction_no', $transaction_id)
            ->whereIn('transactions.payment_status', ['Successful', 'Available'])
            ->whereIn('payments.payment_status', ['Successful','Available'])
            ->where('payments.payment_type', '=', 1) // 1 - Main Payment
            ->whereNull('transactions.invoice_no')
            ->count();

        if(!$successCount) // Not Eligible for invoice
            return false;

        $successCount = Transaction::whereNotNull('invoice_no')->count();

        $invoiceNo = 100000000 + $successCount + 1;
        Transaction::where('transaction_no', $transaction_id)->update(['invoice_no' => $invoiceNo]);
        Payment::where('transaction_no', $transaction_id)
            ->where('payment_type', 1) // 1 - Main Payment
            ->update(['invoice_no' => $invoiceNo]);

        // Send Payment success alert
        try{
            (new SendPushNotification())->send_success_tran_alert($transaction_id);
        }
        catch (\Exception $e){
            Log::error("Success alert SMS sent failed: ". $transaction_id);
            Log::error($e->getMessage());
        }
    }


    /**
     * Access: Customer, Prefix: customer
     * Customer Transaction saving amounts will be return here
     * Saving amount applicable for redeemed transactions and successful payments without redeems
     * if a single redeem happened on transaction remaining quantity of savings will not be effected on savings.
     * @return \Illuminate\Http\Response
     */
    public function savings()
    {
        // $list = Transaction::join('transaction_details', 'transactions.transaction_no', 'transaction_details.transaction_no')
        //     ->join('payments', 'payments.transaction_no', 'transactions.transaction_no')
        //     ->where('transactions.payment_status', 'Successful')
        //     ->where('payments.payment_status', 'Successful')
        //     ->where('transactions.created_by', Auth::guard('driver')->id())
        //     ->select('transaction_details.*', 'transactions.redeem_quantity', 'transactions.quantity')
        //     ->get();

        //     $savings = $list->map(function ($row){
        //     $discountedShareJoy = $row['price'] * $row['discount'] / 100;
        //     $basePriceAfterDiscount = $row['price'] - $discountedShareJoy;
        //     $customerDiscountAmount = $discountedShareJoy * (100 - $row['joy_share']) / 100;
        //     $JOYshareRemaingAfterCustomerShare = $discountedShareJoy - $customerDiscountAmount;
        //     $priceAfterCustomerDiscount = $basePriceAfterDiscount + $JOYshareRemaingAfterCustomerShare;
        //     $fleetExtraDiscount = $JOYshareRemaingAfterCustomerShare * $row['partner_discount'] / 100;
        //     $PriceWithFleetExtraDiscount = $priceAfterCustomerDiscount - $fleetExtraDiscount;
        //     $savings = $row['price'] - $PriceWithFleetExtraDiscount;
        //     $quantity = $row['redeem_quantity'] > 0 ? $row['redeem_quantity'] : $row['quantity'];

        //     return [
        //         'transaction_no' => $row['transaction_no'],
        //         'price' => $row['price'],
        //         'discount' => $row['discount'],
        //         'joy_share' => $row['joy_share'],
        //         'partner_discount' => $row['partner_discount'],
        //         'savings' => round($savings * $quantity , 2),
        //     ];
        // })->sum('savings');

        $savings = $this->getTotalSavings(Auth::guard('driver')->id());

        return response()->json(['status' => 'success', 'data' => $savings], 200);
    }


    /**
     * Customer Transaction total saving amounts will be return here
     * Saving amount applicable for redeemed transactions and successful payments without redeems
     * if a single redeem happened on transaction remaining quantity of savings will not be effected on savings.
     * @return \Illuminate\Http\Response
     */
    public function getTotalSavings($userId)
    {
        $list = Transaction::join('transaction_details', 'transactions.transaction_no', 'transaction_details.transaction_no')
            ->join('payments', 'payments.transaction_no', 'transactions.transaction_no')
            ->where('transactions.payment_status', 'Successful')
            ->where('payments.payment_status', 'Successful')
            ->where('transactions.created_by', $userId)
            ->select('transaction_details.*', 'transactions.redeem_quantity', 'transactions.quantity')
            ->get();

        $savings = $list->map(function ($row) {
            $row['price'] += $row['markup_price'];
            $discountedShareJoy = $row['price'] * $row['discount'] / 100;
            $basePriceAfterDiscount = $row['price'] - $discountedShareJoy;
            $customerDiscountAmount = $discountedShareJoy * (100 - $row['joy_share']) / 100;
            $JOYshareRemaingAfterCustomerShare = $discountedShareJoy - $customerDiscountAmount;
            $priceAfterCustomerDiscount = $basePriceAfterDiscount + $JOYshareRemaingAfterCustomerShare;
            $fleetExtraDiscount = $JOYshareRemaingAfterCustomerShare * $row['partner_discount'] / 100;
            $PriceWithFleetExtraDiscount = $priceAfterCustomerDiscount - $fleetExtraDiscount;
            $savings = $row['price'] - $PriceWithFleetExtraDiscount;
            // Savings are upto redeemed quantity, if not redeedmed full quantity
            $quantity = $row['redeem_quantity'] > 0 ? $row['redeem_quantity'] : $row['quantity'];
            // coupon_savings are applied to the transaction without interact with quantity and allocated from admin share
            $savings = ($savings * $quantity) + $row['coupon_savings'];

            return [
                'transaction_no' => $row['transaction_no'],
                'price' => $row['price'],
                'discount' => $row['discount'],
                'joy_share' => $row['joy_share'] - $row['coupon_savings'],
                'partner_discount' => $row['partner_discount'],
                'savings' => round($savings, 2),
            ];
        })->sum('savings');

        return $savings;
    }

    /*
     * API: partner app, Admin portal, Prefix: dealer, api
     * Access: delar admin, technician, admin
     * All Approved or Redeemed transactions are listed here
     * If user as dealer admin, can access all approved offers by himself or by technicains
     * If user as dealer technician, can access only approved or redeemed offers by himself
     * Admin will get all transactions across all deal providers
     */
    public function delartech_transactions(Request $request)
    {

        $pageno = 1;
        $pagelength = 10;
        $login_type_id = Auth::user()->login_type_id;

        $list = Transaction::with('redeems.scanner', 'item', 'location', 'driver', 'item.delar',
            'payment', 'refund', 'adjustment', 'vehicle_owners', 'approver');

        if ($login_type_id == 18 || $login_type_id == 22) { // Delar Admin or Technician
            if (Auth::user()->role_id == 3) // Delar Admin
            {
                // if admin, all transactions related to the organization will be listed
                // Transactions approved by himself and by technicains also
                $list = $list->whereHas('item', function ($qry) {
                    $qry->where('item_master.delar_id', Auth::user()->org_id);
                })
                    ->whereNotNull('approved_by');
            } else {
                // if technician, all transactions approved by or redeemed by himself
                $list = $list->where('approved_by', Auth::id())
                    ->orWhereHas('redeems.scanner', function ($qry) {
                        $qry->where('redeem_log.redeem_by', Auth::id());
                    });
            }
        } else if ($login_type_id == 17) { // only admins, super admins

            if ($request->type == 'scanned') {
                $list = $list->whereNotNull('approved_by')
                    ->whereHas('redeems.scanner', function ($qry) {
                        $qry->whereNotNull('redeem_log.redeem_by');
                    });
            } else {
                $list = $list->whereNotNull('approved_by');
            }
        }

        $totalrecords = $list->orderBy('id', 'desc')->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = $list->orderBy('id', 'desc')->get()
            ->map(function ($row) {
                return $this->format($row);
            });
        if (explode('/', $request->route()->getPrefix())[0] == 'api') {
            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status' => 'success', 'data' => $data], 200);
        } else {
            return response()->json(['status' => 'success', 'data' => $list], 200);
        }
    }


    public function approved_by_user_transactions(Request $request)
    {
        // Delar technicain transactions api
        // All Approved or Redeemed transactions are listed here

        $userId = $request->user_id;
        $pageno = 1;
        $pagelength = 10;

        $userData = User::where('id', $userId)->first();
        if(!$userData){
              return response()->json(['status' => 'failed', 'message' => 'User information not found'], 400);
        }

        $list = Transaction::with('redeems.scanner', 'item', 'location', 'driver', 'item.delar',
            'payment', 'refund', 'adjustment', 'vehicle_owners', 'approver');

        if ($userData->role_id == 3) {
            if ($request->type == 'scanned') {

                $list = $list->whereHas('item', function ($qry) use ($userData) {
                        $qry->where('item_master.delar_id', $userData->org_id);
                    })
                    ->whereHas('redeems.scanner', function ($qry) {
                        $qry->whereNotNull('redeem_log.redeem_by');
                    });
            } else if ($request->type == 'rejected') {
                $list = $list->whereHas('item', function ($qry) use ($userData) {
                    $qry->where('item_master.delar_id', $userData->org_id);
                })->where('payment_status', 'Rejected')
                    ->whereNotNull('approved_by');
            } else {

                // Transactions approved by himself and by technicains also
                $list = $list->whereHas('item', function ($qry) use ($userData) {
                    $qry->where('item_master.delar_id', $userData->org_id);
                })
                ->whereNotNull('approved_by');
            }

        } else {
            if ($request->type == 'scanned') {
                $list = $list->where('approved_by', $userId)
                    ->whereHas('redeems.scanner', function ($qry) use ($userId) {
                        $qry->where('redeem_log.redeem_by', $userId);
                    });
            } else if ($request->type == 'rejected') {
                $list = $list->where('payment_status', 'Rejected')->where('approved_by', $request->user_id);
            } else {
                $list = $list->where('approved_by', $request->user_id);
            }
        }

        $totalrecords = $list->orderBy('id', 'desc')->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }


        $list = $list->orderBy('id', 'desc')->get()
            ->map(function ($row) {
                return $this->format($row);
            });
        if (explode('/', $request->route()->getPrefix())[0] == 'api') {
            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            $data['user_data'] = $userData;
            return response()->json(['status' => 'success', 'data' => $data], 200);
        } else {
            return response()->json(['status' => 'success', 'data' => $list], 200);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a new transaction
     * Item availability check
     * Find Payment type and paymnet shares
     * Create a transaction
     * Send notification to the respective users
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'deal_id' => ['required'],
                'item_id' => ['required'],
                'offer_id' => ['required'],
                'quantity' => ['required'],
                'payment_with' => ['required'],
                'location_id' => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach (json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json(['status' => "failed", "response" => $errors], 400);
        }

        if (!$this->available_quantity($request->all()))
            return response()->json(['status' => "failed", "response" => "Offer was sold out", "response_ar" => "انتهى العرض"], 400);

        if (isset($request['coupon_id']) && $request['coupon_id'] != '' && $request['coupon_id'] != 0
            && CouponLog::where('id', $request['coupon_id'])->whereNull('transaction_no')->count() == 0
        ) {
            // check that coupon was credit coupon
            if(!(CouponLog::where('id', $request['coupon_id'])->whereNotNull('transaction_no')->where('coupon_type', 'C')->count() > 0))
            {
                // if not a credit coupon
                return response()->json([
                    'status' => "failed",
                    "message" => "Coupon already redeemed, please try again",
                    "message_ar" => "تم استرداد القسيمة بالفعل ، يرجى المحاولة مرة أخرى",
                ], 400);
            }
        }

        if (isset($request['coupon_id']) && $request['coupon_id'] != ''
            && CouponLog::where('id', $request['coupon_id'])->whereNull('transaction_no')->count() > 0
            && $request['payment_with'] == 50 // Tabby payment should not allow coupon discounts
        ){
            return response()->json([
                'status' => "failed",
                "message" => "Tabby payments should not allow any coupon discounts",
                "message_ar" => "يجب ألا تسمح مدفوعات Tabby بأي خصومات على القسيمة",
            ], 400);
        }

        $offer = ItemOffer::where('id', $request['offer_id'])->where('item_id', $request['item_id'])->first();

        if ($offer['end_date'] < date("Y-m-d"))
            return response()->json([
                'status' => "failed",
                "message" => "This Offer was expired",
                "message_ar" => "انتهت صلاحية هذا العرض"], 400);

        // Check the offer from petromin
        $item = ItemMaster::where('id', $request['item_id'])->first();

        if(Organization::where('id', $item['delar_id'])->where('code', 'PETROMIN')->count()){
            // For Petromin company offers quantity should not me multiple
            if($request['quantity'] > 1 && ($item['deal_id'] == 4 || $item['deal_id'] == 5)){
                // 4 - Car Wash, 5 - Car Care
                return response()->json([
                    'status' => "failed",
                    "message" => "This Offer doesn't allow multiple quantity",
                    "message_ar" => "هذا العرض لا يسمح بكميات متعددة"], 400);
            }
        }


        if(isset($request['slot_date'])) {
            try {
                $service_id = $offer['service_id'];
                if($service_id){
                    $log = (new ServiceBookingController())->verify_slot([
                        'service_id' => $service_id,
                        'slot_date' => $request['slot_date'],
                        'start_time' => $request['start_time'],
                        'end_time' => $request['end_time']
                    ]);

                    if(isset($log['status'])){
                        if($log['status'] == 'failed'){
                            return response()->json([
                                'status' => "failed",
                                "message" => "This Slot was not available, Please select another one",
                                "message_ar" => "هذه الفتحة غير متوفرة ، يرجى تحديد أخرى"], 400);
                        }
                    }
                }
            } catch (\Exception $e) {
                Log::error("Slot booking No Verified");
                Log::error($e);
            }
        }

        try {
            $finder = $this->payment_with_finder($offer, $request);

            $payment_on = $finder['payment_on'];
            $request['payment_with'] = $finder['payment_with'];
            $request['price'] = $offer['price'];
            $request['discount'] = ($payment_on == 50 ? 0 : $offer['discount']); // For Tabby Discounts are not applied
            $request['fleet_id'] = $finder['fleet_id'];

            $transaction_no = date('Ymd') . sprintf('%02d', $request['deal_id']) .
                sprintf('%04d', $request['item_id']) . mt_rand(1000, 9999);

            $request['remarks'] = 'Initiated Payment transaction';

            $request['transaction_no'] = $transaction_no;
            $request['created_by'] = Auth::guard('driver')->id();
            $request['created_at'] = date('Y-m-d H:i:s');

            $transactionId = Transaction::insertGetId($request->except('coupon_id', 'service_id', 'slot_date', 'start_time', 'end_time'));

            if(isset($request['slot_date'])) {
                try {
                    $service_id = $offer['service_id'];
                    if($service_id){
                        $log = (new ServiceBookingController())->book_service_slot([
                            'service_id' => $service_id,
                            'slot_date' => $request['slot_date'],
                            'start_time' => $request['start_time'],
                            'end_time' => $request['end_time'],
                            'location_id' => $request['location_id']
                        ]);

                        if(isset($log['status'])){
                            if($log['status'] == 'success'){
                                Transaction::where('id', $transactionId)
                                    ->update([
                                        'booking_id' => $log['booking_id'],
                                        'slot_date' => $request['slot_date'],
                                        'start_time' => $request['start_time'],
                                        'end_time' => $request['end_time'],
                                    ]);
                                Log::info("Transaction: ".$transaction_no.", Serivce Booking created. Booking Id: ". $log['booking_id']);
                            }
                            else if($log['status'] == 'failed'){
                                return response()->json([
                                    'status' => "failed",
                                    "message" => "Slot booking creation was failed",
                                    "message_ar" => "فشل إنشاء حجز الفتحة"], 400);
                            }
                        }
                    }
                } catch (\Exception $e) {
                    Log::error("Slot booking failed");
                    Log::error($e);
                }
            }

            $payment_no = date('Ymd') . sprintf('%02d', $request['deal_id'])
                            . sprintf('%04d', $request['item_id']) . mt_rand(1000, 9999);

            $payments = array(
                "payment_no" => $payment_no,
                "transaction_no" => $transaction_no,
                "payment_type" => 1, // Main Payment
                "payment_on" => $payment_on, // 7 - Credits, 34 - Google Pay, 33 - Apple pay, 50 - Tabby, 35 - Credit Cards
                "amount_by_banking" => $finder['amount_by_banking'],
                "amount_by_credits" => $finder['amount_by_credits'],
                "created_at" => date('Y-m-d H:i:s'),
            );

            Payment::insert($payments);

            $filter_flag = $request['filter_flag'] ?? 0;
            if (isset($request['coupon_id']) && $finder['savings'] > 0) {
                // redeem coupon
                CouponLog::where('id', $request['coupon_id'])
                    ->update(['transaction_no' => $transaction_no, 'savings' => $finder['savings']]);
            }

            $data = $this->create_transaction_bill($transaction_no, $filter_flag);
            $tabby_input = null;
            if ($finder['payment_with'] == 7) {
                // only by credits - Payment Success
                $this->update_payment_status($transaction_no, $payment_no, $request, $offer['is_notify']);
            } else if ($payment_on == 34) {// google pay
                // only by Google Pay - Payment Success
                $this->update_payment_status($transaction_no, $payment_no, $request, $offer['is_notify']);
            } else if (env('APP_OTP') == 'local' && $payment_on == 33) {// 33 - apple pay - Payment Success
                $this->update_payment_status($transaction_no, $payment_no, $request, $offer['is_notify']);
            } else if($payment_on == 50 ){
                $tabby_input = (new TabbyTransactionController)->get_tabbysession_input($request, $transaction_no, $transactionId, $finder['amount_by_banking']);
            }

            $request['payment'] = $payments;

            return response()->json([
                'status' => 'success',
                'message' => 'Transaction created successfully',
                'message_ar' => 'تم إنشاء المعاملة بنجاح',
                'data' => $request->all(),
                'tabby_input' => $tabby_input
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'failed',
                'message' => 'Transaction creation failed',
                'message_ar' => 'فشل إنشاء المعاملة',
                "error" => $e->getMessage()], 400);
        }
    }

    private function create_transaction_bill($transaction_no, $filter_flag)
    {

        $trans = Transaction::where('transaction_no', $transaction_no)->first();
        $paymentInfo = Payment::where('transaction_no', $transaction_no)->latest()->first();
        $service_cost = ItemOffer::where('id', $trans->offer_id)->pluck('service_cost')->first();

        $partner_share = $partner_discount = 0;
        if ($trans->fleet_id) {
            $partner = Organization::where('id', $trans->fleet_id)->select('payment_share', 'extra_discount')->first();
            $partner_share = $partner->payment_share;
            $partner_discount = $partner->extra_discount;
        }

        if ($filter_flag) {
            $filter_cost = Vehicle::join('vehicle_models', 'vehicles.model', 'vehicle_models.id')
                ->where('vehicles.id', $trans->vehicle_id)
                ->pluck('vehicle_models.filter_price')->first();
        } else
            $filter_cost = 0;

        $payment_on = $paymentInfo->payment_on ?? '';
        $payShare = PaymentShare::latest()->first();

        if($payment_on == 33 || $payment_on == 35){
            // Urway Payments - 33 - Apple Pay, 35 - Credit Cards
            $pgShare = PaymentGateway::where('id', 1)->first();
            $payShare['pg_fee'] = $pgShare['pg_fee'];
            $payShare['pg_share'] = $pgShare['pg_share'];
        }
        else if($payment_on == 50){
            // Tabby Payments
            $pgShare = PaymentGateway::where('id', 2)->first();
            $payShare['pg_fee'] = $pgShare['pg_fee'];
            $payShare['pg_share'] = $pgShare['pg_share'];

            $payShare['admin_share'] = 0;
            $partner_discount = 0; // Tabby should not give partner discounts
        }

        $admin_share = $payShare['admin_share'];

        $markup_price = Deal::where('id', $trans->deal_id)->pluck('markup_price')->first();
        $coupon_savings = CouponLog::where('transaction_no', $trans->transaction_no)->pluck('savings')->first() ?? 0;

        // $joy_share = $admin_share - ($partner_share + $partner_discount);

        $location = Location::where('id', $trans->location_id)->first();
        $delar = Organization::where('id', $location->org_id)->first();
        $item = ItemMaster::where('id', $trans->item_id)->first();
        $offer = ItemOffer::where('id', $trans->offer_id)->first();
        $city = City::where('id', $location->city)->pluck('city')->first();

        $address = $location->street . ', ' . $city . ', ' . $location->district . ', ' . $location->zipcode . ', ' . $delar->email;

        $data = array(
            'transaction_no' => $trans->transaction_no,
            'price' => $trans->price,
            'discount' => $trans->discount,
            'vat' => $payShare->vat,
            'joy_share' => $admin_share,
            'pg_fee' => $payShare->pg_fee,
            'pg_share' => $payShare->pg_share,
            'partner_share' => $partner_share,
            'partner_discount' => $partner_discount,
            'service_cost' => $service_cost,
            'filter_cost' => $filter_cost,
            'markup_price' => $markup_price,
            'coupon_savings' => $coupon_savings,

            'item_name' => $item->title,
            'item_name_ar' => $item->title_ar,
            'dimensions' => $item->dimensions,
            'volt' => $item->volt,
            'ah' => $item->ah,
            'size' => $item->size,
            'height' => $item->height,
            'width' => $item->width,
            'item_description' => $item->description,
            'item_description_ar' => $item->description_ar,
            'thumbnail_url' => $item->thumbnail_url,

            'offer_name' => $offer->title,
            'offer_name_ar' => $offer->title_ar,
            'offer_description' => $offer->description,
            'offer_description_ar' => $offer->description_ar,
            'terms' => $offer->terms,
            'terms_ar' => $offer->terms_ar,
            'end_date' => $offer->end_date,
            'is_notify' => $offer->is_notify,
            'on_site' => $offer->on_site,

            'delar_name' => $delar->org_name,
            'delar_name_ar' => $delar->org_name_ar,
            'delar_address' => $address,
        );

        TransactionDetail::insert($data);

    }

    /**
     * Access: Customer, prefix: customer
     * Requesting for notify offer and create transaction over it
     * Create Transaction
     * Find Payment type and paymnet shares
     * Create a transaction
     * Send notification to the Technician & delar admin users
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    // not using from 24-11-2022
    /*
    public function request_offer(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'deal_id' => ['required'],
                'item_id' => ['required'],
                'offer_id' => ['required'],
                'quantity' => ['required'],
                'location_id' => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach (json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json(['status' => "failed", "response" => $errors], 400);
        }

        if (!$this->available_quantity($request->all()))
            return response()->json(['status' => "failed", "response" => "Offer was sold out"], 400);

        try {
            $item = ItemOffer::where('id', $request['offer_id'])->where('item_id', $request['item_id'])->first();

            $request['payment_with'] = 34; // Google Pay
            $finder = $this->payment_with_finder($item, $request);

            $payment_on = $finder['payment_on'];
            $request['payment_with'] = $finder['payment_with'];
            $request['price'] = $item['price'];
            $request['discount'] = $item['discount'];
            $request['fleet_id'] = $finder['fleet_id'];

            $transaction_no = date('Ymd') . sprintf('%02d', $request['deal_id']) .
                sprintf('%04d', $request['item_id']) . mt_rand(1000, 9999);

            $request['transaction_no'] = $transaction_no;
            $request['invoice_no'] = substr($transaction_no, -9);
            $request['created_by'] = Auth::guard('driver')->id();
            $request['created_at'] = date('Y-m-d H:i:s');
            $request['payment_status'] = 'Requests';

            Transaction::insert($request->all());

            // update available quantity
            // if($request['deal_id'] == 6 || $request['deal_id'] == 2) // tires & battaries
            //     ItemMaster::where('id', $request['item_id'])->update(['quantity' => DB::raw('quantity - '.$request['quantity'])]);

            // ItemOffer::where('id', $request['offer_id'])->where('item_id', $request['item_id'])
            //     ->update(['quantity' => DB::raw('quantity - '.$request['quantity'])]);


            $payment_no = date('Ymd') . sprintf('%02d', $request['deal_id']) . sprintf('%04d', $request['item_id']) . mt_rand(1000, 9999);
            $payments = array(
                "payment_no" => $payment_no,
                "transaction_no" => $transaction_no,
                "payment_on" => $payment_on,
                "amount_by_banking" => $finder['amount_by_banking'],
                "amount_by_credits" => $finder['amount_by_credits'],
                "created_at" => date('Y-m-d H:i:s'),
            );

            Payment::insert($payments);
            $request['payment'] = $payments;

            // Request for notify offer
            (new SendPushNotification)->addnotifyrequest_notification($transaction_no, 40);//For technician

            return response()->json([
                'status' => 'success',
                'message' => 'Transaction created successfully',
                'message_ar' => 'تم إنشاء المعاملة بنجاح',
                'data' => $request->all()
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'failed',
                'message' => 'Transaction creation failed',
                'message_ar' => 'فشل إنشاء المعاملة',
                "error" => $e], 400);
        }
    }
    */

    /**
     * Prefix: customer, Access: Customer, Reference Method: transaction_status
     * update the payment status of transaction
     * Change the offer quantity on successful payments
     * Create Invoice no to the successful transaction
     * Send notitifaction to the consumer & technicians of purchased status
     *
     * @param  $transaction_no - To find the transaction
     * @param  $payment_no - To update the payment status to the transaction
     * @param  $isNotify - To validate the request was notified or not
     * @return true
     */
    public function update_payment_status($transaction_no, $payment_no, $request, $isNotify)
    {
        // Default payment success method
        // Send email notification to purchased order
        try {
            event(new PurchasedAnOfferEmail($transaction_no));
        } catch (\Exception $e) {
            Log::info("Sent email for new purchased order failed");
            Log::error($e->getMessage());
        }

        $paymentData = Payment::where('payment_no', $payment_no)->first();

      

        if ($request['deal_id'] == 6 || $request['deal_id'] == 2) // tires & battaries
            ItemMaster::where('id', $request['item_id'])
                ->update(['quantity' => DB::raw('quantity - ' . $request['quantity'])]);

        ItemOffer::where('id', $request['offer_id'])->where('item_id', $request['item_id'])
            ->update(['quantity' => DB::raw('quantity - ' . $request['quantity'])]);

        Payment::where('payment_no', $payment_no)
            ->update([
                'action_code' => $isNotify ? 4 : 1, // 1 - Purchased, 4 - Authorized
                'payment_status' => 'Successful',
                'updated_at' => Date('Y-m-d H:i:s')
            ]);

        $tranUpdate = array(
            'payment_status' => $isNotify ? 'Requests' : 'Successful',
            'updated_at' => Date('Y-m-d H:i:s'),
            'remarks' => 'Payment processed was Successfully'
        );
        Transaction::where('transaction_no', $transaction_no)->update($tranUpdate);

        // Check petromin service available for booking
        $this->create_servicebooking($transaction_no);


        if (!$isNotify) {
            $this->update_transaction_invoice_no($transaction_no);
        }

          // Send notification to consumer , deal admin
        try {
            event(new NewOrderPlaced($transaction_no, 27, $paymentData->amount_by_banking + $paymentData->amount_by_credits));
        } catch (\Exception $e) {
            Log::info("Sent firebase notification for new purchased order failed");
            Log::error($e->getMessage());
        }

        if ($isNotify) {
            try {
                event(new RequestOfferAvailability($transaction_no, 40, $paymentData->amount_by_banking + $paymentData->amount_by_credits));

            } catch (\Exception $e) {
                Log::info("Sent firebase notification for offer availability request");
                Log::error($e->getMessage());
            }
        }
    }

    /**
     * To find the payment shares and payment type.
     * Payment share will be through banking or credits.
     * Find the Consumer credits and validate payment share to banking or credits
     * Send notitifaction to the consumer & technicians of purchased status
     *
     * @param  $item - Requested item for the transaction
     * @param  $request - it will give requested purchased quantity and payment type
     * @return payment shares, payment type, final price
     */
    public function payment_with_finder($item, $request)
    {
        $dealShare = new DealController();
        $pricing = $dealShare->price_logic($item['price'], $item['discount'], $item['deal_id']);
        $service_cost = $item['service_cost'];

        $serviveQuantity = 1;
        if ($item['deal_id'] == '4' || $item['deal_id'] == '5') { // 4 - Cleaning, 5 - Deatiling
            $serviveQuantity = $request->quantity;
        }

        $filter_flag = $request['filter_flag'] ?? 0;
        $filter_cost = 0;
        if ($filter_flag) {
            $filter_cost = Vehicle::join('vehicle_models', 'vehicles.model', 'vehicle_models.id')
                ->where('vehicles.id', $request['vehicle_id'])
                ->pluck('vehicle_models.filter_price')->first();
        }

        $finalPrice = $pricing['final_price']; // this is having markup price also
        if($request['payment_with'] == 50 ) // Tabby doesn't have partner discounts
            $finalPrice = $pricing['base_price'];

        $product_price = $finalPrice * $request['quantity'] + ($service_cost * $serviveQuantity) + $filter_cost;

        $savings = 0;
        if (isset($request['coupon_id']) && $request['coupon_id'] != ''
            && CouponLog::where('id', $request['coupon_id'])->whereNull('transaction_no')->count() > 0
            && $request['payment_with'] != 50 // Tabby payment should not allow coupon discounts
        ) {
            // if coupon applied and not yet redeemed
            $couponData = CouponLog::where('id', $request['coupon_id'])->first();
            $couponInfo = Coupon::where('id', $couponData->coupon_id)->first();

            if ($couponInfo->coupon_type == 'C') //Credits
            {
                // Credit coupon amount are added to customer account as credits
                $savings = 0;
            } else if ($couponInfo->coupon_type == 'D') // Discount Percent
            {
                $adminShare = $pricing['admin_share'] * $request['quantity'];
                $fleet_share = $pricing['partner_share'] * $request['quantity'];
                $fleet_discount = $pricing['partner_discount'] * $request['quantity'];

                $savings = ($adminShare - $fleet_share - $fleet_discount) * $couponData->discount / 100;
            }

            CouponLog::where('id', $request['coupon_id'])
                ->update([
                    'discount' => $couponData->discount,
                    'savings' => $savings,
                ]);
        }

        // Deduct Coupon savings on the final payable amount
        $product_price -= $savings;

        /************** Start Payment Method finder ************/
        $amount_by_banking = $amount_by_credits = 0;
        $payment_with = 7;
        /*
                Credit Account - 7
                Banking - 8
                Credit and Bank Accounts - 9
                Apple Pay - 33
                Google Pay - 34
                Cards - 35
            */

        // with credits or credits + banking
        // update payment amounts
        // Check credit payments are enabled or not
        if($request['payment_with'] == 50 )
        {
            // if payment type is tabby, amount payable should be by bank only, credits should be 0
            $credits = 0;
        }
        else if (Lookup::where('id', 7)->where('status', 1)->count() > 0) {
            // Check payment type credits available or not
            $credit = new CreditsController();
            $balance = $credit->consumer_credits();
            $credits = $balance->getData()->accounts->credits;
        } else
            $credits = 0;

        if ($product_price <= $credits) {
            $payment_with = 7; // Credit Account
            $request['payment_with'] = 7;
            $amount_by_credits = $product_price;
        } else if ($product_price > $credits) {
            if ($credits == 0)
                $payment_with = 8; // Banking
            else
                $payment_with = 9; // Credit and Bank Accounts
            $amount_by_credits = $credits;
            $amount_by_banking = $product_price - $credits;

            if ($amount_by_banking < 3) {
                // Banking amount should be minimum 3
                if ($amount_by_credits > 0) {
                    // Change banking amount only credits more than 0
                    // credits amount transafered to banking for minimum price
                    $banking = ($product_price < $amount_by_banking + (3 - $amount_by_banking)) ? $product_price : ($amount_by_banking + (3 - $amount_by_banking));
                    $credits = ($amount_by_credits - (3 - $amount_by_banking)) < 0 ? 0 : ($amount_by_credits - (3 - $amount_by_banking));

                    $amount_by_credits = $credits;
                    $amount_by_banking = $banking;
                }
            }
        }

        /************** End Payment Method finder ************/

        return array(
            'product_price' => round($product_price,2),
            'savings' => round($savings,2),
            'finalPrice' => round($finalPrice,2),
            'quantity' => $request['quantity'],
            'payment_with' => $payment_with,
            'payment_on' => $request['payment_with'],
            'amount_by_credits' => round($amount_by_credits, 2),
            'amount_by_banking' => round($amount_by_banking, 2),
            'fleet_id' => $pricing['fleet_id'],
        );
    }

    /**
     * To save the payment status from the paymnet gateway ( urway, tabby)
     * Change the payment status
     * Assign invoice no. on successful payment
     * Change item quantity on successful payment
     * Send notitifaction to the consumer on successful payment
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function set_pg_status(Request $request)
    {
        // payment response was filed here from the payment gateway
        $validator = Validator::make($request->all(),
            [
                'payment_no' => ['required'],
                'transaction_id' => ['required'],
                'payment_status' => ['required'],
                'payid' => ['required'],
                //'response_code' => ['required'],
                'response_amount' => ['required'],
                'response_result' => ['required'],
                //'card_token' => '',
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach (json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json(['status' => "failed", "response" => $errors], 400);
        }

        Log::info('Payment Response Input: '.$request->transaction_id, $request->all());

        try {

            $item_id = Transaction::where('transaction_no', $request->transaction_id)->pluck('item_id')->first();
            $is_notify = ItemOffer::where('item_id', $item_id)->pluck('is_notify')->first();

            $trans_status = $request->payment_status;
            if (($request->payment_status == 'Successful' || $request->payment_status == 'authorized') && $is_notify)
                $trans_status = 'Requests';
            else if($request->payment_status == 'authorized')
                $trans_status = 'Successful';

            if($request->payment_status == 'authorized' && !$is_notify){
                // update payment authorized to captured
                $purchaseAmount = Payment::where('payment_no', $request->payment_no)->pluck('amount_by_banking')->first();
                $purchaseAmount = ($purchaseAmount) ? $purchaseAmount : 0;
                try {
                    (new TabbyTransactionController())->captureTabbypayment($request['payid'], $purchaseAmount);
                    $request['payment_status'] = 'Successful';
                   
                    $request['action_code'] = 1; // Purchased
                } catch (\Exception $e) {
                    Log::error("Payment Capture Failed");
                }
            }
            else if($request->payment_status == 'authorized' && $is_notify){
                $request['payment_status'] = 'Successful';
                $request['action_code'] = 4;
            }

            $failed_arr = array('Failure', 'Failed', 'rejected', 'expired' );
            $remarks = 'Payment processing was ' . $request->payment_status;
            if ($request->payment_status == 'close') {
                $remarks = 'Payment processing was cancelled by customer';
                $trans_status = 'pending';
                $request['payment_status'] = 'pending';
            }
            else if (in_array($request->payment_status, $failed_arr)) {
                $remarks = 'Payment processing was '.$request->payment_status;
                $trans_status = 'Failed';
                $request['payment_status'] = 'Failed';
            }

            Transaction::where('transaction_no', $request->transaction_id)
                ->update(['payment_status' => $trans_status, 'remarks' => $remarks]);

            $request['transaction_no'] = $request->transaction_id;
            $request['updated_at'] = Date('Y-m-d H:i:s');
            $request['card_brand'] = $request->cardBrand ?? NULL;

            $payment_on = Payment::where('payment_no', $request->payment_no)->pluck('payment_on')->first();
            $pg_id = ($payment_on == 50) ? 2 : 1;

            // update Urway Payment shares, 35 - Credit cards, 33 - Apple pay
            $payShare = PaymentGateway::where('id', $pg_id)->first();
            $arr['pg_fee'] = $payShare->pg_fee;
            $arr['pg_share'] = $payShare->pg_share;
            $arr['updated_at'] = Date('Y-m-d H:i:s');
            TransactionDetail::where('transaction_no', $request->transaction_id)->update($arr);

            Payment::where('payment_no', $request->payment_no)
                ->update($request->except('transaction_id', 'payment_no', 'cardBrand'));

            if ($request->payment_status == 'Successful') {
                $trans = Transaction::where('transaction_no', $request->transaction_id)->first();

                if(!$is_notify) {
                    // For non - notified transactions only update invoice no.
                    $this->update_transaction_invoice_no($request->transaction_id);
                }

                // For petromin services we need to create service on their system
                $this->create_servicebooking($request->transaction_id);

                // update available quantity
                if ($trans['deal_id'] == 6 || $trans['deal_id'] == 2) // tires & battaries
                    ItemMaster::where('id', $trans['item_id'])
                        ->update(['quantity' => DB::raw('quantity - ' . $trans['quantity'])]);

                ItemOffer::where('id', $trans['offer_id'])->where('item_id', $trans['item_id'])
                    ->update(['quantity' => DB::raw('quantity - ' . $trans['quantity'])]);


                /*New Order placed*/
                $paymentData = Payment::where('payment_no', $request->payment_no)->first();

                try {
                    // Send notification to consumer , deal admin and technician
                    event(new PurchasedAnOfferEmail($request->transaction_id));

                    event(new NewOrderPlaced(
                        $request->transaction_id, 27,
                        $paymentData->amount_by_banking + $paymentData->amount_by_credits)
                    );

                    /*New Order placed*/
                    if ($is_notify) {
                        // if offer has notify request send offer availability request6
                        event(new RequestOfferAvailability(
                            $request->transaction_id, 40,
                            $paymentData->amount_by_banking + $paymentData->amount_by_credits)
                        );
                    }

                } catch(\Exception $e){
                    Log::error('Failed to send notification on payment status update: '. $request->transaction_id);
                    Log::error($e->getMessage());
                }
            }

            return response()->json([
                'status' => 'success',
                'message' => 'Transaction successfully completed',
                'message_ar' => 'إتمام المعاملة بنجاح',
            ], 200);

        } catch (\Exception $e) {
            return response()->json(['status' => 'failed', 'message' => 'Transaction failed', "error" => $e->getMessage()], 400);
        }
    }

    public function create_servicebooking($transaction_no){

        $trans = Transaction::where('transaction_no', $transaction_no)->first();
        $vehicle = Vehicle::where('id', $trans['vehicle_id'])->first();
        $offer = ItemOffer::where('id', $trans['offer_id'])->first();

        if(!$vehicle) // If that vehicle was deleted, cannt book the service
            return false;

        $can_book = false;
        if($vehicle['plate_no'] && $offer['provider_reference_subid'])
        {
            // If vehicle plate no. was available, then we can able book the service
            $item = ItemMaster::where('id', $trans['item_id'])->first();
            // For petromin company services only
            if(Organization::where('id', $item['delar_id'])->where('code', 'PETROMIN')->count())
                $can_book = true;
        }

        if($can_book){
            // Create Booking
            try {
                $res = (new PetrominController())->add_service($transaction_no);
                $res = (array)$res->getData();
                if($res['status'] == 'success'){
                    $service_id = $res['data']->service->id;
                    Transaction::where('transaction_no', $transaction_no)->update(['service_id' => $service_id]);

                    if($res['data']->service->bookingStatus == 0){
                        // Successful booking, then Capture payment
                        (new VehicleController())->update_transaction_payment($transaction_no, 5);
                    } else{
                        // on failed booking, delete the service
                        try {
                            /*$res = (new PetrominController())->destroy($service_id);
                            $res = (array)$res->getData();

                            if($res['status'] == 'success'){
                                (new VehicleController())->update_transaction_payment($transaction_no, 9);
                            }*/

                            // (new VehicleController())->update_transaction_payment($transaction_no, 9);

                        }catch (\Exception $e){
                            Log::error("Petromin cancel service booking failed: Transaction No.:". $transaction_no);
                        }
                    }
                } else{
                    // Cancel the transaction
                    // Void Authorize the payment
                    // (new VehicleController())->update_transaction_payment($transaction_no, 9);
                }
            }catch (\Exception $e){
                Log::error("Petromin service booking initiation failed: Transaction No.:". $transaction_no);
            }
        }

        return true;
    }

    /*
     * Cancel petromin service booking on offer not availability or technician rejection
     */
    public function delete_servicebooking($transaction_no){
        $trans = Transaction::where('transaction_no', $transaction_no)->first();
        $item = ItemOffer::where('id', $trans['offer_id'])->first();

        if($item['provider_reference_subid'] && $trans['service_id']){
            // Create Booking
            try {
                (new PetrominController())->destroy($trans['service_id']);
            }catch (\Exception $e){
                Log::error("Petromin cancel service booking failed: Transaction No.:". $transaction_no);
            }
        }

        return true;
    }

    /**
     * It is using for notify request when deal is available purchase and only credits available
     * Findout payment shares & types
     * Assign invoice no. on successful payment
     * Change item quantity on successful payment
     * Send notitifaction to the consumer on successful payment
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function create_payment(Request $request)
    {
        // It is using for notify request when deal is available purchase and only credits available
        $validator = Validator::make($request->all(),
            [
                'transaction_id' => ['required'],
                'payment_with' => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach (json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json(['status' => "failed", "response" => $errors], 400);
        }
        try {
            $trans_details = Transaction::where('transaction_no', $request->transaction_id)
                ->whereIn('payment_status', ['pending', 'Failed', 'Available'])->first();
            if (!$trans_details)
                return response()->json([
                    'status' => 'failed',
                    'message' => 'Transaction already completed',
                    'message_ar' => 'المعاملة التي تم إكمالها بالفعل',
                ], 400);

            $item = ItemOffer::where('id', $trans_details['offer_id'])->where('item_id', $trans_details['item_id'])->first();
            $request['quantity'] = $trans_details['quantity'];
            $request['filter_flag'] = $trans_details['filter_flag'];

            $finder = $this->payment_with_finder($item, $request);

            Transaction::where('transaction_no', $request->transaction_id)
                ->update(['payment_with' => $finder['payment_with']]);


            $payment_no = date('Ymd') . sprintf('%02d', $trans_details->deal_id) . sprintf('%04d', $trans_details->item_id) . mt_rand(1000, 9999);

            $payments = array(
                "payment_no" => $payment_no,
                "transaction_no" => $request->transaction_id,
                "payment_on" => $finder['payment_on'],
                "amount_by_banking" => $finder['amount_by_banking'],
                "amount_by_credits" => $finder['amount_by_credits'],
                "created_at" => date('Y-m-d H:i:s'),
            );
            Payment::insert($payments);
            $trans_details['payment'] = $payments;

            if ($finder['payment_on'] == '7') { // Credit Amounts
                // update available quantity
                if ($trans_details['deal_id'] == 6 || $trans_details['deal_id'] == 2) // tires & battaries
                    ItemMaster::where('id', $trans_details['item_id'])
                        ->update(['quantity' => DB::raw('quantity - ' . $trans_details['quantity'])]);

                ItemOffer::where('id', $trans_details['offer_id'])->where('item_id', $trans_details['item_id'])
                    ->update(['quantity' => DB::raw('quantity - ' . $trans_details['quantity'])]);


                Payment::where('payment_no', $payment_no)
                    ->update(['payment_status' => 'Successful', 'updated_at' => Date('Y-m-d H:i:s')]);

                Transaction::where('transaction_no', $request->transaction_id)
                    ->update(['payment_status' => 'Successful', 'updated_at' => Date('Y-m-d H:i:s')]);

                //Invoice Number Generation
                $this->update_transaction_invoice_no($request->transaction_id);

                //send notification start
                //(new SendPushNotification)->addtrans_notification($request->transaction_id, 27);
                try {
                // Send notification to consumer , deal admin
                event(new NewOrderPlaced($request->transaction_id, 27, $finder['amount_by_credits']+$finder['amount_by_banking']));
                //send notification end

                } catch(\Exception $e){
                    Log::info("Sent notification for new purchased order failed");
                    Log::error($e->getMessage());
                }
            }

            return response()->json([
                'status' => 'success',
                'message' => 'Transaction created successfully',
                'message_ar' => 'تم إنشاء المعاملة بنجاح',
                'data' => $trans_details
            ], 200);

        } catch (\Exception $e) {
            return response()->json(['status' => 'failed', 'message' => 'Transaction failed', "error" => $e], 400);
        }
    }

    /**
     * Findout item requested quantity was available or not
     * Send notitifaction to the consumer on successful payment
     * @param  $offer_id - To find offer available quantity
     * @param  $quantity - Validate requested quantity with available quantity
     * @return Available or Not
     */
    private function available_quantity($request)
    {
        $quantity = ItemOffer::where('id', $request['offer_id'])
            ->where('item_id', $request['item_id'])->pluck('quantity')->first();

        if ($quantity >= $request['quantity'])
            return true;
        else
            return false;
    }

    /**
     * Access: technician, Dealer
     * This is native function only
     *
     * Update transaction status on reddem offer by technicain, admin, dealer (prefix: dealeraccess)
     * dealeraccess : for petromin services
     * if offer was rejected by technician then increase offer quantity
     * update the redeem quantity
     * Send email to the consumer
     * Send notitifaction to the consumer on successful payment
     * @param  $transaction_id - To find transaction
     * @param  $is_approved - Technician may kept purchase should be either apprive or rejected
     * @return true
     */
    public function redeem_offer_quantity($transaction_id, $is_approved)
    {
        $trans = Transaction::where('transaction_no', $transaction_id)->first();

        if(($trans['quantity'] - $trans['revised_quantity'] - $trans['redeem_quantity']) <= 0)
        {
            // already redeemed transaction
            return false;
        }

        if (!$is_approved) {
            ItemMaster::where('id', $trans['item_id'])
                ->increment('quantity', $trans['quantity']);

            ItemOffer::where('item_id', $trans['item_id'])
                ->where('id', $trans['offer_id'])
                ->increment('quantity', $trans['quantity']);
        } else {

            $totalQuantity = 1;

            if ($trans['deal_id'] == 4 || $trans['deal_id'] == 5) { // cleaning & detailing
                $redeem_quantity = ($trans['redeem_quantity'] == 0) ? 1 : $trans['redeem_quantity'] + 1;
            } else {
                $redeem_quantity = $trans['quantity'];
                $totalQuantity = $redeem_quantity;
            }

            Transaction::where('transaction_no', $transaction_id)->update(['redeem_quantity' => $redeem_quantity]);

            RedeemLog::insert([
                'transaction_no' => $transaction_id,
                'quantity' => $totalQuantity,
                'redeem_by' => Auth::id(),
                'redeem_at' => date('Y-m-d H:i:s')
            ]);

            $itemData = ItemOffer::where('id', $trans['offer_id'])->first();

            if ($itemData->on_site) {
                $onsiteLocationData = OnsiteLocation::where('transaction_no', $transaction_id)->orderBy('id', 'DESC')->first();
                if($onsiteLocationData){
                    $addressArray['is_redeemed'] = 1;
                    $addressArray['updated_at'] = date('Y-m-d H:i:s');
                    OnsiteLocation::where('id', $onsiteLocationData->id)->update($addressArray);
                }
            }

            try {
                
                $paymentData = Payment::where('transaction_no', $transaction_id)
                    ->where('payment_status', 'Successful')->orderBy('id', 'ASC')->first();

                event(new OfferRedeemed($transaction_id, 38, $paymentData->amount_by_banking + $paymentData->amount_by_credits));
                
                event(new RedeemedOfferEmail($transaction_id, $redeem_quantity));

            } catch (\Exception $e) {
                Log::error("Failed to send notifications of redeemed: ". $transaction_id);

                Log::error($e->getMessage());
            }
        }

        return true;
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        $list = Transaction::where('transaction_no', $id)
            ->with('item', 'item.offer', 'item.delar', 'item.slider', 'item.delar.location',
                'driver', 'feedback', 'payment_details', 'vehicle_owners', 'driver_address', 'adjustment')
            ->get()
            ->map(function ($row) {
                return $this->format($row);
            })->first();

        if (!$list)
            return response()->json(['status' => 'failed', 'message' => "Invalid Transaction Id"], 400);

        $list['item']['offer']['vehicle'] = null;
        $admin_vat_no = Organization::where('company_type', 'A')->pluck('vat_no')->first();
        $list['vat_no'] = $admin_vat_no; //'311080860200003';

        // data:image/png;base64, .........
        $displayQRCodeAsBase64 = GenerateQrCode::fromArray([
            new Seller('Innvohub'), // seller name
            new TaxNumber($admin_vat_no), // seller tax number
            new InvoiceDate($list['created_at']), // invoice date as Zulu ISO8601 @see https://en.wikipedia.org/wiki/ISO_8601
            new InvoiceTotalAmount($list['final_price']), // invoice total amount
            new InvoiceTaxAmount(round($list['vat_amount'], 2)) // invoice tax amount
            // TODO :: Support others tags
        ])->render();

        $list['qr_image'] = $displayQRCodeAsBase64;

        $list['refund_credits'] = 0;
        if ($list['revised_quantity'] > 0) {
            $list['refund_credits'] = $list['refund_payment']['final_price'];
            $list['refund_no'] = 'R-' . $list['invoice_no'];

            $createdDate = Credit::where('transaction_no', $id)->orderBy('created_at', 'DESC')->pluck('created_at')->first();
            $displayQRCodeAsBase64 = GenerateQrCode::fromArray([
                new Seller('Innvohub'), // seller name
                new TaxNumber($admin_vat_no), // seller tax number
                new InvoiceDate($createdDate), // invoice date as Zulu ISO8601 @see https://en.wikipedia.org/wiki/ISO_8601
                new InvoiceTotalAmount($list['refund_payment']['final_price']), // invoice total amount
                new InvoiceTaxAmount($list['refund_payment']['vat_amount']) // invoice tax amount
                // TODO :: Support others tags
            ])->render();

            $list['qr_image_refund'] = $displayQRCodeAsBase64;
        }

        if ($list['payment_status'] == 'canceled') {
            $list['refund'] = $list['final_price'];
            $list['item']['offer']['refund'] = $list['final_price'];
        } else {
            $list['refund'] = 0;
            $list['item']['offer']['refund'] = 0;
        }

        return response()->json(['status' => 'success', 'data' => $list], 200);
    }


    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function transactionInfo(Request $request, $id)
    {
        $dealShare = new DealController();

        $list = Transaction::where('transaction_no', $id)
            ->with('item', 'item.offer', 'item.delar', 'item.slider', 'item.delar.location',
                'driver', 'feedback', 'payment_details', 'vehicle_owners', 'driver_address', 'adjustment', 'partner')
            ->get()
            ->map(function ($row) {
                return $this->format($row);
            })->first();

        if (!$list)
            return response()->json(['status' => 'failed', 'message' => "Invalid Transaction Id"], 400);

        $pricing = $dealShare->bill_price_logic($list['transaction_no']);
        $sharingsArray = $pricing['sharings'];

        $list['employee_id'] = '';
        if($list['partner']){
            $list['employee_id'] = FleetDriver::where('fleet_id', $list['fleet_id'])
                ->where('driver_id', $list['created_by'])->pluck('employee_id')->first();
        }

        $list['petromin_status'] = '';
        if($list['service_id']){
            try {
                $res = (new PetrominController())->show($list['service_id']);
                $res = (array)$res->getData();

                if ($res['status'] == 'success') {
                    if($res['data']->bookingStatus == 0)
                        $list['petromin_status'] = 'Booking';
                    else if($res['data']->bookingStatus == 1)
                        $list['petromin_status'] = 'Completed';
                    else if($res['data']->bookingStatus == 2)
                        $list['petromin_status'] = 'Failed';
                }
            }catch(\Exception $e){
                Log::error('Petromin find service status failed: '. $list['service_id']);
            }
        }

        $list['item']['offer']['vehicle'] = null;

        $admin_vat_no = Organization::where('company_type', 'A')->pluck('vat_no')->first();
        $list['vat_no'] = $admin_vat_no; //'311080860200003';

        $list['refund_credits'] = 0;
        $refundAmount = 0;
        if ($list['revised_quantity'] > 0) {
            $refundAmount = $pricing['refund_payment']['final_price'];
            $list['refund_credits'] = $refundAmount;
            $list['refund_no'] = 'R-' . $list['invoice_no'];
        }

        $refundInfo = Credit::where('transaction_no', $id)->with('refund_by')->orderBy('created_at', 'ASC')->get();

        $redeemInfo = RedeemLog::where('transaction_no', $id)->with('scanner')->get();

        $vehicleInfo = Vehicle::where('id', $list->vehicle_id)->with('groups','manufacturer','model','colour')->withTrashed()->first();

        $counponInfo = CouponLog::where('transaction_no', $id)->with('coupon_info')->first();

        return response()->json([
            'status' => 'success',
            'data' => $list,
            'refund_info' => $refundInfo,
            'redeem_info' => $redeemInfo,
            'vehicle_info' => $vehicleInfo,
            'counpon_info' => $counponInfo,
            'sharings' => $sharingsArray,
            'refund_amount' => $refundAmount
        ], 200);
    }

    /**
     * Prefix: dealer, Access: delar technicains
     * This is an api for delar app for transaction info
     *
     * @param  $id - transaction_id - To find transaction
     * @return \Illuminate\Http\Response
     */
    public function requests_info($id)
    {
        $trans = Transaction::where('transaction_no', $id)
            ->with('item', 'item.offer', 'item.delar', 'item.slider', 'item.delar.location', 'driver',
                'feedback', 'payment_details', 'vehicle_owners', 'redeems.scanner', 'approver', 'driver_address')
            ->get()
            ->map(function ($row) {
                return $this->format($row);
            })->first();

        if (!isset($trans))
            return response()->json(['status' => 'failed', 'message' => 'Transaction not found', 'message_ar' => 'لم يتم العثور على المعاملة'], 400);

        return response()->json([
            'status' => 'success',
            'message' => 'Transaction Info',
            'message_ar' => 'معلومات المعاملات',
            'data' => $trans
        ], 200);
    }

    /**
     * API: partner app, Super Admin , Prefix: dealer, api
     * Access: delar admin, technician, Super Admin or admin
     * Update transaction status on reddem offer with validation
     * Technician scan the QR code from consumer app to redeem the offer
     * Check the user eligibility to access this api
     * Redeem the offer
     * @param  $id - transaction_id - To find transaction
     * @return Send offer info
     */
    public function approve_transaction_info($id)
    {
        try{
            // info for delar technician user
            // Redeem Transaction process happen here
            $trans = Transaction::where('transaction_no', $id)
                ->with('item', 'item.offer', 'item.delar', 'item.slider', 'item.delar.location', 'driver',
                    'feedback', 'payment_details', 'vehicle_owners', 'redeems.scanner', 'approver')
                ->get()
                ->map(function ($row) {
                    return $this->format($row);
                })->first();

            if (!isset($trans))
                return response()->json(['status' => 'failed', 'message' => 'Transaction not found'], 400);

            $access = $this->verify_access($id);
            if (!$access['status'])
                return response()->json([
                    'status' => 'failed',
                    'message' => $access['message'],
                    'message_ar' => $access['message_ar'],
                ], 400);

            $offer = ItemOffer::where('id', $trans['offer_id'])->where('item_id', $trans['item_id'])->first();

            if ($offer['end_date'] < date("Y-m-d"))
                return response()->json([
                    'status' => "failed",
                    "message" => "This Offer was expired",
                    "message_ar" => "انتهت صلاحية هذا العرض"], 400);

            $paymentStat = Payment::where('transaction_no', $id)->orderBy('id', 'asc')->first();

            if ((isset($paymentStat->amount_by_banking) && $paymentStat->amount_by_banking > 0) && ($paymentStat->payment_on==33 || $paymentStat->payment_on==35)) {
                $payment = new PaymentController();
                // check is amount was paid or not by the payment gateway
                // 33 - Apple Pay, 35 - Credit Cards
                $pay_resp = $payment->find_transaction_status($id);
                
                if (isset($pay_resp['status']) && !$pay_resp['status'])
                    return response()->json([
                        'status' => 'failed',
                        'message' => 'Payment not yet done',
                        'message_ar' => 'لم يتم الدفع بعد',
                    ], 400);
            }

            if ($trans['payment_status'] != 'Successful' && $trans['payment_status'] != 'Available') {
                return response()->json([
                    'status' => 'failed',
                    'message' => "You can't redeem this transaction as it is not yet paid ",
                    'message_ar' => 'لا يمكنك استرداد قيمة هذه المعاملة لأنها لم تدفع بعد ',
                    'data' => $trans
                ], 400);

            } else if (($trans['quantity'] - $trans['revised_quantity']) == 0) {

                return response()->json([
                    'status' => 'failed',
                    'message' => 'This item was refunded',
                    'message_ar' => 'تم رد قيمة هذا المنتج',
                    'data' => $trans
                ], 400);
            } else if ($trans->is_approved == 1 && ($trans['quantity'] - $trans['revised_quantity']) == $trans['redeem_quantity']) {
                return response()->json([
                    'status' => 'failed',
                    'message' => 'This transaction was already redeemed',
                    'message_ar' => 'تم استرداد هذه المعاملة بالفعل',
                    'data' => $trans
                ], 400);
            } else if(($trans['quantity'] - $trans['revised_quantity'] - $trans['redeem_quantity']) <= 0)
            {
                return response()->json([
                    'status' => 'failed',
                    'message' => 'This transaction was already redeemed',
                    'message_ar' => 'تم استرداد هذه المعاملة بالفعل',
                    'data' => $trans
                ], 400);
            } else if ($trans->is_approved == 1) {
                if (RedeemLog::where('transaction_no', $id)->whereRaw('cast(redeem_at as date) = current_date')->count() > 0) {
                    return response()->json([
                        'status' => 'failed',
                        'message' => 'Offer redeemed limit over for today',
                        'message_ar' => 'تم استرداد الحد الأقصى للعرض لهذا اليوم',
                        'data' => $trans
                    ], 400);
                }
            }

            $offer = ItemOffer::where('id', $trans['offer_id'])->first();

            if($offer['vn_access'] || $offer['pn_access']){
                // vin no or plate no was required for this transaction
                if ($offer['vn_access'] && Vehicle::where('id', $trans['vehicle_id'])->whereNull('serial_no')->count() > 0) {
                    return response()->json(['status' => 'failed',
                        'message' => 'Vin no. on this transaction was required',
                        'message_ar' => 'فين لا. على هذه الصفقة كان مطلوبا'], 400);
                }

                if ($offer['pn_access'] && Vehicle::where('id', $trans['vehicle_id'])->whereNull('plate_no')->count() > 0) {
                    return response()->json(['status' => 'failed',
                        'message' => 'Vehicle plate no. on this transaction was required',
                        'message_ar' => 'رقم لوحة المركبة. على هذه الصفقة كان مطلوبا'], 400);
                }
            }

            $is_approved = 1;
            if(!$this->redeem_offer_quantity($id, $is_approved)){
                return response()->json([
                    'status' => 'failed',
                    'message' => 'This transaction was already redeemed',
                    'message_ar' => 'تم استرداد هذه المعاملة بالفعل',
                    'data' => $trans
                ], 400);
            }

            try {
                if (Transaction::where("transaction_no", $id)->whereNull('is_approved')->count() > 0) {
                    // For Direct Transaction Redeem, Approval update here, and at first redeem only consider as approval
                    // For Notify Requests Transaction approval at item availability
                    $approvalInfo = array(
                        "transaction_no" => $id,
                        "is_approved" => $is_approved,
                        "approved_by" => Auth::id(),
                        "approved_at" => date('Y-m-d H:i:s')
                    );
                    Transaction::where("transaction_no", $id)->update($approvalInfo);
                }
                $payment_status = $is_approved ? "Successful" : "Rejected";
                // update payment status of transaction should be successful
                Transaction::where("transaction_no", $id)->update(['payment_status' => $payment_status]);

                $trans = Transaction::where('transaction_no', $id)
                    ->with('item', 'item.offer', 'item.delar', 'item.slider', 'item.delar.location', 'driver',
                        'feedback', 'payment_details', 'vehicle_owners', 'redeems.scanner', 'approver')
                    ->get()
                    ->map(function ($row) {
                        return $this->format($row);
                    })->first();

                return response()->json([
                    'status' => 'success',
                    'message' => 'Transaction updated successfully',
                    'message_ar' => 'تم تحديث المعاملة بنجاح',
                    'data' => $trans
                ], 200);
            } catch (\Exception $e) {
                return response()->json(['status' => 'failed', 'message' => 'Transaction updation failed', "error" => $e], 400);
            }

        } catch(\Exception $e) {
            return response()->json(['status' => 'failed', 'message' => 'Transaction updation failed', "error" => $e], 400);
        }
    }

    /**
     * Find the technician redeem eligibility with user session
     *
     * @param  $id - transaction_id - To find transaction
     * @return Send eligibility status
     */
    public function verify_access($id)
    {
        // Allow the user was an admin or superadmin
        if (Auth::user()->login_type_id == 17)
            return array('status' => 1);

        //check deal_category, deal_provider,technician_location
        $transaction_details = Transaction::where('transaction_no', $id)->first();

       
        $trans_delar_id = ItemMaster::where('id', $transaction_details->item_id)->pluck('delar_id')->first();

        $delar_orgid = Auth::user()->org_id;
        if ($trans_delar_id != $delar_orgid) {
            // transaction delar id not matched with login delar id
            Log::info('Transaction delar id not matched with login delar id');
            return array(
                'status' => 0,
                'message' => 'You are not authorized to approve Transaction',
                'message_ar' => 'أنت غير مخول بالموافقة على المعاملة',
            );
        }

        $check_delar_item = ItemMaster::join('item_offers', 'item_master.id', '=', 'item_offers.item_id')
            ->where('item_master.delar_id', $delar_orgid)
            ->where('item_master.deal_id', $transaction_details->deal_id)
            ->where('item_master.id', $transaction_details->item_id)
            ->where('item_offers.id', $transaction_details->offer_id)
            ->where('item_offers.item_id', $transaction_details->item_id)
            ->where('item_offers.deal_id', $transaction_details->deal_id)
            ->count();

        if ($check_delar_item == 0) {
            // transaction category or provider not matched with login delar or category
            Log::info('Transaction category(deal) or provider not matched with login delar or category(deal)');
            return array(
                'status' => 0,
                'message' => 'You are not authorized to approve Transaction',
                'message_ar' => 'أنت غير مخول بالموافقة على المعاملة',
            );
        }

        if (Auth::user()->role_id == 3) // Delar Admin can access any location
            return array('status' => 1);

        $check_delar_location = TechnicianLocation::where('technician_id', Auth::id())
            ->where('location_id', $transaction_details->location_id)->where('status', 1)->count();


        if ($check_delar_location == 0) {
            // transaction location not matched with login delar location
            Log::info('Transaction location not matched with login delar location');
            $location = Location::join('cities', 'locations.city', 'cities.id')
                ->selectRaw("concat(locations.street,', ',locations.district,', ',cities.city) as location")
                ->where('locations.id', $transaction_details->location_id)
                ->pluck('location')
                ->first();

            return array(
                'status' => 0,
                'message' => 'You are not authorized for transaction location: ' . $location,
                'message_ar' => $location . 'أنت غير مخول بموقع المعاملة:',
            );
        }

        if($transaction_details->payment_status!='Successful' && $transaction_details->payment_status!='Available'){
             return array(
                'status' => 0,
                'message' => 'Payment not yet completed. Please contact administrator',
                'message_ar' => 'الدفع لم يكتمل بعد. الرجاء الاتصال بالمسؤول'
            );
        }

        return array('status' => 1);
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     * To download invoice
     *
     * @param  $trans_id - transaction_id - To find transaction
     * @return File in PDF format
     */
    public function downloadpdf(Request $request, $trans_id)
    {
        $data = Transaction::where('transaction_no', $trans_id)
            ->with('item', 'item.offer', 'item.delar', 'item.delar.location', 'driver', 'trans_location', 'payment_details', 'adjustment')
            ->get()
            ->map(function ($row) {
                return $this->format($row);
            })->first();

        $data['scan_url'] = url('/download_public_invoice/' . $trans_id);

        $admin_vat_no = Organization::where('company_type', 'A')->pluck('vat_no')->first();

        // data:image/png;base64, .........
        $displayQRCodeAsBase64 = GenerateQrCode::fromArray([
            new Seller('Innvohub'), // seller name
            new TaxNumber($admin_vat_no), // seller tax number
            new InvoiceDate($data['created_at']), // invoice date as Zulu ISO8601 @see https://en.wikipedia.org/wiki/ISO_8601
            new InvoiceTotalAmount($data['final_price']), // invoice total amount
            new InvoiceTaxAmount($data['vat_amount']) // invoice tax amount
            // TODO :: Support others tags
        ])->render();

        $data['qr_image'] = $displayQRCodeAsBase64;
        $data['refund_credits'] = 0;
        if ($data['revised_quantity'] > 0) {

            $data['refund_no'] = 'R-' . $data['invoice_no'];
            $data['refund_credits'] = $data['refund_payment']['final_price'];

            $createdDate = Credit::where('transaction_no', $trans_id)->orderBy('created_at', 'DESC')->pluck('created_at')->first();
            $displayQRCodeAsBase64 = GenerateQrCode::fromArray([
                new Seller('Innvohub'), // seller name
                new TaxNumber($admin_vat_no), // seller tax number
                new InvoiceDate($createdDate), // invoice date as Zulu ISO8601 @see https://en.wikipedia.org/wiki/ISO_8601
                new InvoiceTotalAmount($data['refund_payment']['final_price']), // invoice total amount
                new InvoiceTaxAmount($data['refund_payment']['vat_amount']) // invoice tax amount
                // TODO :: Support others tags
            ])->render();

            $data['qr_image_refund'] = $displayQRCodeAsBase64;
        }

        $downloadfileName = 'joy_invoice.pdf';

        $pdf = PDF::loadView('invoice', compact('data', 'admin_vat_no'));
        return $pdf->download($downloadfileName);
        //return $pdf->stream($downloadfileName);
    }

    /**
     * To download invoice for testing
     *
     * @param  $trans_id - transaction_id - To find transaction
     * @return File in PDF format
     */
    public function download_public_pdf(Request $request, $trans_id)
    {
        $data = Transaction::where('transaction_no', $trans_id)
            ->with('item', 'item.offer', 'item.delar', 'item.delar.location', 'driver', 'trans_location')
            ->first();

        $dealShare = new DealController();
        $pricing = $dealShare->bill_price_logic($data['transaction_no']);
        $data['final_price'] = $pricing['final_price'];
        $data['vat'] = $pricing['vat'];

        $data['vat_amount'] = $pricing['vat_amount'];
        $data['item_price'] = $pricing['item_price'];
        $data['discount_amount'] = $pricing['discount_amount'];
        $data['scan_url'] = url('/download_public_invoice/' . $trans_id);


        $downloadfileName = 'joy_invoice.pdf';
        //$html = View::make('emails.upn.pdf-invoice', $data);
        //$pdfUPN = PDF::loadHTML($html)->stream();

        //return view('invoice', compact('data'));
        //$pdf = PDF::loadView('invoice', compact('data'))->setOptions(['isHtml5ParserEnabled' => true, 'isRemoteEnabled' => true, 'defaultFont' => 'sans-serif']);
        $pdf = PDF::loadView('public_invoice', compact('data'));
        return $pdf->download($downloadfileName);
    }

        /**
     * To download M&S invoice for testing
     *
     * @param  $trans_id - transaction_id - To find transaction
     * @return File in PDF format
     */
    public function download_mands_invoice(Request $request, $trans_id)
    {
        try{
            $data = MaintenanceLog::where('transaction_no', $trans_id)
                ->with('item', 'item.delar', 'vehicle', 'vehicle.owner', 'vehicle.groups', 'vehicle.owner.fleet_consumer','item.delar.location')
                ->first();
            if($data){
                $data['invoice_no']=sprintf('%04d', $data['id']);
               
                // data:image/png;base64, .........
                $displayQRCodeAsBase64 = GenerateQrCode::fromArray([
                            new Seller($data->item->delar->org_name), // seller name
                            new TaxNumber($data->item->delar->vat_no), // seller tax number
                            new InvoiceDate(date('Y-m-d H:i:s')), // invoice date as Zulu ISO8601 @see https://en.wikipedia.org/wiki/ISO_8601
                            new InvoiceTotalAmount($data->service_cost), // invoice total amount
                            new InvoiceTaxAmount('0') // invoice tax amount
                            // TODO :: Support others tags
                        ])->render();

                $data['scan_url'] =$displayQRCodeAsBase64;// url('/download_mands_invoice/' . $trans_id);
                $downloadfileName = 'joy_invoice.pdf';
                
                $pdf = PDF::loadView('service_provider_invoice', compact('data'));
               return $pdf->download($downloadfileName);
               //return $pdf->stream($downloadfileName);
           } else {
             echo "Failed to M&S service provider scanned details";
           }
        } catch(\Exception $e) {
            echo "Failed to M&S service provider scanned details";
        }
    }


            /**
     * To get info M&S invoice details
     *
     * @param  $trans_id - transaction_id - To find transaction
     * @return File in PDF format
     */
    public function getMAndSTransactionInfo($trans_id)
    {
        try{
            $data = MaintenanceLog::where('transaction_no', $trans_id)
                ->with('item', 'item.delar', 'vehicle', 'vehicle.owner', 'vehicle.groups', 'vehicle.owner.fleet_consumer','item.delar.location')
                ->first();
            if($data){
                $data['invoice_no']=sprintf('%04d', $data['id']);
                 
                //set M&s Service provider details for qr code   
                // data:image/png;base64, .........
                $displayQRCodeAsBase64 = GenerateQrCode::fromArray([
                    new Seller($data->item->delar->org_name), // seller name
                    new TaxNumber($data->item->delar->vat_no), // seller tax number
                    new InvoiceDate(date('Y-m-d H:i:s')), // invoice date as Zulu ISO8601 @see https://en.wikipedia.org/wiki/ISO_8601
                    new InvoiceTotalAmount($data->service_cost), // invoice total amount
                    new InvoiceTaxAmount('0') // invoice tax amount
                    // TODO :: Support others tags
                ])->render();

                $data['scan_url'] =$displayQRCodeAsBase64;//  

                return response()->json([
                        'status' => 'success',
                        'data' => $data,
                      
                    ], 200);

            } else {
                return response()->json([
                    'status' => 'failed',
                    'message' => 'Failed to M&S service provider scanned details',
                ], 400);
            }
        } catch (\Exception $e) {
            return response()->json(['status' => 'failed', 'message' => 'Failed to M&S service provider scanned details', "error" => $e->getMessage()], 400);
        }
    }

    /**
     * Dummy invoice for testing
     *
     * @param  $trans_id - transaction_id - To find transaction
     * @return File in PDF format
     */
    public function invoicepdf($trans_id)
    {

        $data = Transaction::where('transaction_no', $trans_id)
            ->with('item', 'item.offer', 'item.delar', 'item.delar.location', 'driver')
            ->first();

        $orgData=Organization::where('id',$data->item->delar->org_id)->first();

        // data:image/png;base64, .........
        $displayQRCodeAsBase64 = GenerateQrCode::fromArray([
            new Seller($orgData->org_name), // seller name
            new TaxNumber($orgData->vat_no), // seller tax number
            new InvoiceDate(date('Y-m-d H:i:s')), // invoice date as Zulu ISO8601 @see https://en.wikipedia.org/wiki/ISO_8601
            new InvoiceTotalAmount($data->service_cost), // invoice total amount
            new InvoiceTaxAmount('0') // invoice tax amount
            // TODO :: Support others tags
        ])->render();

        $data['qr_image'] = $displayQRCodeAsBase64;
        $data['scan_url'] = url('/download_public_invoice/' . $trans_id);
        return view('invoice', compact('data'));
    }

    /**
     * API: partner app, Prefix: dealer
     * Access: delar admin, technician
     * Update transaction status by technician is either approved or rejected
     * Find the technician eligibility to approve or reject
     * if technician kept approved the transacation status to redeemed
     * if technician kept rejected the transacation status to rejected
     *
     * @param  $request
     * @return $response
     */
    public function approve_transaction(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'transaction_no' => ['required'],
                'is_approved' => ['required']
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach (json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json(['status' => "failed", "response" => $errors], 400);
        }

        $checkscanstatus = $this->verify_access($request['transaction_no']);
        if (!$checkscanstatus)
            return response()->json([
                'status' => 'failed',
                'message' => 'You are not authorized to approve Transaction',
                'message_ar' => 'أنت غير مخول بالموافقة على المعاملة',
            ], 400);

        $trans = Transaction::where('transaction_no', $request['transaction_no'])->first();

        $offer = ItemOffer::where('id', $trans['offer_id'])->where('item_id', $trans['item_id'])->first();

        if ($offer['end_date'] < date("Y-m-d"))
            return response()->json([
                'status' => "failed",
                "message" => "This Offer was expired",
                "message_ar" => "انتهت صلاحية هذا العرض"], 400);

        if ($trans['payment_status'] != 'Successful' && $trans['payment_status'] != 'Available') {
            return response()->json([
                'status' => 'failed',
                'message' => "You can't redeem this transaction as it is not yet paid ",
                'message_ar' => 'لا يمكنك استرداد قيمة هذه المعاملة لأنها لم تدفع بعد ',
                'data' => $trans
            ], 400);

        } else if (($trans['quantity'] - $trans['revised_quantity']) == 0) {

            return response()->json([
                'status' => 'failed',
                'message' => 'This item was refunded',
                'message_ar' => 'تم رد قيمة هذا المنتج',
                'data' => $trans
            ], 400);
        } else if ($trans['is_approved'] == 1 && ($trans['quantity'] - $trans['revised_quantity']) == $trans['redeem_quantity']) {
            return response()->json([
                'status' => 'failed',
                'message' => 'This transaction was already redeemed',
                'message_ar' => 'تم استرداد هذه المعاملة بالفعل',
                'data' => $trans
            ], 400);
        } else if(($trans['quantity'] - $trans['revised_quantity'] - $trans['redeem_quantity']) <= 0)
        {
            return response()->json([
                'status' => 'failed',
                'message' => 'This transaction was already redeemed',
                'message_ar' => 'تم استرداد هذه المعاملة بالفعل',
                'data' => $trans
            ], 400);
        } else if ($trans['is_approved'] == 1) {
            if (RedeemLog::where('transaction_no', $request['transaction_no'])->whereRaw('cast(redeem_at as date) = current_date')->count() > 0) {
                return response()->json([
                    'status' => 'failed',
                    'message' => 'Offer redeemed limit over for today',
                    'message_ar' => 'تم استرداد الحد الأقصى للعرض لهذا اليوم',
                    'data' => $trans
                ], 400);
            }
        }

        $offer = ItemOffer::where('id', $trans['offer_id'])->first();

        if($offer['vn_access'] || $offer['pn_access']){
            // vin no or plate no was required for this transaction
            if ($offer['vn_access'] && Vehicle::where('id', $trans['vehicle_id'])->whereNull('serial_no')->count() > 0) {
                return response()->json(['status' => 'failed',
                    'message' => 'Vin no. on this transaction was required',
                    'message_ar' => 'فين لا. على هذه الصفقة كان مطلوبا'], 400);
            }

            if ($offer['pn_access'] && Vehicle::where('id', $trans['vehicle_id'])->whereNull('plate_no')->count() > 0) {
                return response()->json(['status' => 'failed',
                    'message' => 'Vehicle plate no. on this transaction was required',
                    'message_ar' => 'رقم لوحة المركبة. على هذه الصفقة كان مطلوبا'], 400);
            }
        }

        try {

            $isRedeemed = $this->redeem_offer_quantity($request['transaction_no'], $request['is_approved']);
            if ($isRedeemed) {
                $approvalInfo = array(
                    "transaction_no" => $request['transaction_no'],
                    "is_approved" => $request['is_approved'],
                    "approved_by" => Auth::id(),
                    "approved_at" => date('Y-m-d H:i:s'),
                    "payment_status" => $request['is_approved'] ? "Successful" : "Rejected"
                );

                Transaction::where("transaction_no", $request['transaction_no'])->update($approvalInfo);

                return response()->json([
                    'status' => 'success',
                    'message' => 'Transaction updated successfully',
                    'message_ar' => 'تم تحديث المعاملة بنجاح',
                ], 200);

            } else {
                return response()->json([
                    'status' => 'failed',
                    'message' => 'You are already redeemed this offer',
                    'message_ar' => 'لقد تم استرداد قيمة هذا العرض بالفعل',
                ], 400);
            }
        } catch (\Exception $e) {
            return response()->json(['status' => 'failed', 'message' => 'Transaction creation failed', "error" => $e], 400);
        }
    }

    /**
     * Aceess: Admin, dealer, partner, prefix: api
     * Customer Transactions by customer id
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id - Customer id
     * @return \Illuminate\Http\Response
     */
    public function consumer_transactions(Request $request, $id)
    {
        $pageno = 1;
        $pagelength = 10;
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = Transaction::where('created_by', $id);

        $login_type_id = Auth::user()->login_type_id;
        if ($login_type_id == 18) // Delar admin or delar technician login
        {
            $list = $list->whereHas('item', function ($item) {
                $item->where('delar_id', Auth::user()->org_id);
            });
        } else if ($login_type_id == 19) { // partner account
            $list = $list->whereHas('driver.fleet_consumer', function ($item) {
                $item->where('fleet_drivers.fleet_id', Auth::user()->org_id);
            });
        }

        $totalrecords = $list->count();

        $list = $list->orderBy('id', 'desc')->skip(($pageno - 1) * $pagelength)->take($pagelength)->get()
                    ->map(function ($row) {
                        return $this->format_minimised_list($row);
                    });

        $customerData = Driver::where('id', $id)->withTrashed()->first();

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;

        return response()->json(['status1' => 'success', 'data' => $data, "customer_data" => $customerData], 200);
    }

    /**
     * API: partner app, Prefix: dealer
     * Access: delar admin, technician
     * List out the approved transaction list
     * If user as dealer admin, can access all approved offers by himself or by technicains
     * If user as dealer technician, can access only approved offers by himself
     *
     * @param  $request
     * @return $response
     */
    public function recent_transactions(Request $request)
    {
        try {
            $list = Transaction::with('item', 'driver', 'item.delar', 'refund', 'adjustment');

            if (Auth::user()->role_id == 3) // Delar Admin
            {
                $list = $list->whereHas('item', function ($qry) {
                    $qry->where('item_master.delar_id', Auth::user()->org_id);
                })
                    ->whereNotNull('approved_by');
            } else {
                $list = $list->where('approved_by', Auth::id());
            }

            $list = $list->orderBy('id', 'desc')->take(10)->skip(0)->get()
                ->map(function ($row) {
                    return $this->format($row);
                });

            return response()->json(['status' => 'success', 'data' => $list], 200);
        } catch (\Exception $e) {
            return response()->json(['status' => 'failed', 'message' => 'No Transactions', "error" => $e], 400);
        }
    }


    /**
     * API: partner app, Prefix: dealer
     * Access: delar admin, technician
     * List out transaction list with slots
     * If user as dealer admin, can access all transaction slots by himself or by technicains
     * If user as dealer technician, can access only related location transaction slots
     *
     * @param  $request
     * @return $response
     */
    public function transaction_slots(Request $request)
    {
        try {
            $list = Transaction::with('item', 'driver', 'item.delar', 'refund', 'adjustment')
                    ->whereNotNull('booking_id');

            if (Auth::user()->role_id == 3) // Delar Admin
            {
                $list = $list->whereHas('item', function ($qry) {
                    $qry->where('item_master.delar_id', Auth::user()->org_id);
                });
            } else {
                if (Auth::user()->login_type_id == 22) {
                    // check the technician eligible for transaction location
                    $list = $list->whereIn('transactions.location_id', function ($query) {
                        $query->selectRaw('distinct location_id')
                            ->from('technician_locations')
                            ->where('technician_locations.technician_id', Auth::id())
                            ->where('technician_locations.status', 1);
                    });
                }
            }

            $list = $list->orderBy('id', 'desc')->take(10)->skip(0)->get()
                ->map(function ($row) {
                    return $this->format($row);
                });

            return response()->json(['status' => 'success', 'data' => $list], 200);
        } catch (\Exception $e) {
            return response()->json(['status' => 'failed', 'message' => 'No Transactions', "error" => $e], 400);
        }
    }


    /**
     * Total scanned purchased deals and total earnings from last payout for technician
     * @return \Illuminate\Http\Response
     */

    public function partner_counters()
    {

        if (isset(Auth::user()->company->company_type) && Auth::user()->company->company_type == 'M') {
            $total_count = MaintenanceLog::where('created_by', Auth::id())->count();
            $total_price = 0.00;
        } else {

            $delar_id = Auth::user()->org_id;
            $paid_date = Payout::where('status', 1)->where('payment_to', $delar_id)->orderBy('id', 'desc')->pluck('paid_date')->first();
            $orginfo['last_paid'] = $paid_date;
            $paid_date = $paid_date ? $paid_date : '2021-10-01';

            if (Auth::user()->login_type_id == 22) // Technician
                $total_count = Transaction::where('approved_by', Auth::id())
                    ->where('approved_at', '>', $paid_date)
                    ->where('redeem_quantity', '>', 0)
                    ->count();
            else if (Auth::user()->login_type_id == 18) // Delar Admin
                $total_count = Transaction::join('item_master', 'item_master.id', 'transactions.item_id')
                    ->where('item_master.delar_id', Auth::user()->org_id)
                    ->where('transactions.approved_at', '>', $paid_date)
                    ->where('transactions.redeem_quantity', '>', 0)
                    ->count();

            $qry = "select bl.*, redeems.quantity
            from transactions as a join item_master as b on a.item_id = b.id
              inner join transaction_details as bl on a.transaction_no = bl.transaction_no
             inner join (
                         select redeem_log.transaction_no, ifnull(sum(redeem_log.quantity),0) as quantity from redeem_log
                         where  redeem_at BETWEEN
                         ( select ifnull(max(payouts.paid_date), '2021-10-01') as paid_date from payouts 
                         where payouts.payment_to = " . $delar_id . " ) AND (current_date - 1)
                         group by redeem_log.transaction_no
               ) as redeems on a.transaction_no = redeems.transaction_no 
            where a.payment_status = 'Successful' and a.redeem_quantity > 0 and a.status = 1 and b.delar_id = " . $delar_id;

            $list = DB::select($qry);
            $list = collect($list);
            $total_price = $list->map(function ($row) {

                $row->price = $row->price + $row->markup_price;
                $discountedShareJoy = $row->price * $row->discount / 100;
                $basePriceAfterDiscount = $row->price - $discountedShareJoy;
                $customerDiscountAmount = $discountedShareJoy * (100 - $row->joy_share) / 100;
                $JOYshareRemaingAfterCustomerShare = $discountedShareJoy - $customerDiscountAmount;
                $priceAfterCustomerDiscount = $basePriceAfterDiscount + $JOYshareRemaingAfterCustomerShare;
                $fleetExtraDiscount = $JOYshareRemaingAfterCustomerShare * $row->partner_discount / 100;
                $PriceWithFleetExtraDiscount = $priceAfterCustomerDiscount - $fleetExtraDiscount;
                $savings = $row->price - $PriceWithFleetExtraDiscount;
                // coupon_savings are applied to the transaction without interact with quantity and allocated from admin share
                $savings = ($savings * $row->quantity) + $row->coupon_savings;

                $payableAmount = ($PriceWithFleetExtraDiscount * $row->quantity - $row->coupon_savings) + $row->service_cost + $row->filter_cost;

                $paymentGatewayShare = $payableAmount * $row->pg_share / 100;
                $paymentGatewayAmount = $row->pg_fee + ((100 - $row->discount) * $paymentGatewayShare / 100);
                $delarShareWithVat = ($row->price - $discountedShareJoy - $paymentGatewayAmount) + $row->service_cost + $row->filter_cost;
                $delarShare = $delarShareWithVat - ($delarShareWithVat - $delarShareWithVat / (1 + $row->vat / 100));

                return [
                    'transaction_no' => $row->transaction_no,
                    'price' => $row->price,
                    'discount' => $row->discount,
                    'joy_share' => $row->joy_share - $row->coupon_savings,
                    'partner_discount' => $row->partner_discount,
                    'savings' => round($savings, 2),
                    'payable_amount' => round($payableAmount, 2),
                    'delar_share' => round($delarShare * $row->quantity, 2),
                ];
            })->sum('delar_share');
        }

        //$cnt = NotificationLog::where('notification_to', Auth::id())->where('notification_for', 'N')->whereNull('read_at')->count();

        $cnt = NotificationLog::where('notification_to', Auth::id())->with('notification_list')
                ->withCount( ['notification_list' => function($q){ $q->where('is_set', 1); }])
                ->Has( 'notification_list', '>' , 0)
                ->where('notification_for', 'N')
                ->whereNull('read_at')
                ->count();

        $user_id = Auth::id();
        $type = 'N';

        $org_id = Auth::user()->org_id;

        $notifications = Notification::select('notifications.*')
            ->join('notifications_log', 'notifications.id', 'notifications_log.notification_id');
        
        $notifications = $notifications->leftjoin('item_master', function ($qry) use ($org_id) {
            $qry->on('notifications.item_id', 'item_master.id');
            $qry->where('item_master.delar_id', $org_id);
        });

        $notifications = $notifications->where('notifications_log.notification_to', $user_id)
            ->where('notifications_log.notification_for', $type)
            ->where('notifications.is_popup', '1')
            ->where('notifications.is_sent', '1')
            ->whereNull('notifications_log.read_at')
            ->whereNull('notifications_log.deleted_at')
            ->with('deal', 'offer', 'deal.deal','location_info', 'transaction', 'transaction.payment_details')
            ->orderBy('notifications.id', 'asc');


        $popupCount = $notifications->count();
        if ($popupCount > 0) {
            $popupCount = $popupCount - 1;
        }
        $popUpnotifications = $notifications->first();


        if ($popUpnotifications) {
            NotificationLog::where('notification_to', $user_id)
                ->where('notification_id', $popUpnotifications->id)
                ->where('notification_for', 'N')
                ->whereNull('read_at')
                ->update(['read_at' => date('Y-m-d H:i:s')]);
        }

        $data = array("transaction_count" => $total_count, "amounts" => $total_price, "is_read" => ($cnt > 0 ? 1 : 0));
        return response()->json(['status' => 'success', 'data' => $data, 'popup_notifications' => $popUpnotifications, 'available_popup_count' => $popupCount], 200);
    }

    /**
     * Cancel transaction if payment status is pending
     * Send notification to consumer for cancellation
     *
     * @param  $transaction_no -Cancel deal for the transaction
     */


    function cancel_payment($transaction_no = null)
    {

        if (Transaction::where('transaction_no', $transaction_no)->count() == 0)
            return response()->json([
                'status' => "failed",
                "message" => "Invalid Transaction Id",
                "message_ar" => "معرف المعاملة غير صالح",
            ], 400);
        if (Transaction::where('transaction_no', $transaction_no)->where('payment_status', 'pending')->count() == 0)
            return response()->json([
                'status' => "failed",
                "message" => "Failed to process Transaction Cancelation",
                "message_ar" => 'فشل في معالجة إلغاء المعاملة',
            ], 400);

        // Transaction::where('transaction_no', $transaction_no)
        //     ->update(['payment_status' => 'Cancelled', 'updated_at' => date('Y-m-d H:i:s') ]);

        // Payment::where('payment_status', 'pending')
        //     ->where('transaction_no',$transaction_no)
        //     ->update(['payment_status' => 'Cancelled', 'updated_at' => date('Y-m-d H:i:s') ]);;

        $trans = Transaction::where('transaction_no', $transaction_no)
            ->with('item', 'item.offer', 'item.delar', 'item.slider', 'item.delar.location', 'driver', 'feedback', 'payment_details', 'vehicle_owners')
            ->first();
        return response()->json([
            'status' => 'success',
            "message" => "Transaction Cancelation was done",
            "message_ar" => "تم إلغاء المعاملة",
            'data' => $trans], 200);

    }

    /**
     * API: partner app, Prefix: dealer
     * Access: delar admin, technician
     * Request address to consumer if deal is onsite
     * Send notification to consumer when techinician requested address
     * @param  $transaction_no - Requested address for the transaction
     */
    function request_for_address($transaction_no = null)
    {
        $transactionData = Transaction::where('transaction_no', $transaction_no)->first();
        if (empty($transactionData))
            return response()->json([
                'status' => "failed",
                "message" => "Invalid Transaction No.",
                "message_ar" => "رقم المعاملة غير الصالحة",
            ], 400);

        if ($transactionData->payment_status != 'Successful' && $transactionData->payment_status != 'Available')
            return response()->json([
                'status' => "failed",
                "message" => "This Transaction No. not yet paid",
                "message_ar" => "رقم هذه المعاملة لم تدفع بعد",
            ], 400);

        $paymentData = Payment::where('transaction_no', $transaction_no)
            ->whereIn('payment_status', ['Successful','Available'])->orderBy('id', 'ASC')->first();
        if (!$paymentData) {
            return response()->json([
                'status' => "failed",
                "message" => "This Transaction No. not yet paid",
                "message_ar" => "رقم هذه المعاملة لم تدفع بعد",
            ], 400);
        }
        $itemData = ItemOffer::where('id', $transactionData['offer_id'])->first();


        if (!$itemData->on_site)
            return response()->json([
                'status' => "failed",
                "message" => "This transaction is not for onsite deal ",
                "message_ar" => "هذه المعاملة ليست للصفقة في الموقع",
            ], 400);

        try {


            $statusArray = $this->transaction_row_status($transactionData);

            if ($statusArray['transaction_status'] == 'Redeemed') {
                return response()->json([
                    'status' => "failed",
                    "message" => "You can't request address as this transaction is already redeemed",
                    "message_ar" => "لا يمكنك طلب العنوان حيث تم استرداد هذه المعاملة بالفعل"], 400);
            }

            if ($transactionData['deal_id'] == 5 || $transactionData['deal_id'] == 4) {
                if ($transactionData['quantity'] - ($transactionData['redeem_quantity'] + $transactionData['revised_quantity']) == 0) {
                    return response()->json([
                        'status' => "failed",
                        "message" => "You can't request address as this transaction is already redeemed",
                        "message_ar" => "لا يمكنك طلب العنوان حيث تم استرداد هذه المعاملة بالفعل"], 400);
                }
            }


            $count = Notification::where('transaction_no', $transaction_no)->where('notification_for', 42)->count();

            try {
                if ($paymentData) {
                    event(new AddressRequested($transaction_no, 42, $paymentData->amount_by_banking + $paymentData->amount_by_credits));

                }
            } catch (\Exception $e) { 
                Log::info("Sent notification for address request");
                Log::error($e->getMessage());
            }


            $addressArray = array('transaction_no' => $transaction_no, 'is_requested' => 1, 'requested_by' => Auth::id());

            $onsiteLocationData = OnsiteLocation::where('transaction_no', $transaction_no)->where('is_redeemed', 0)->orderBy('id', 'DESC')->first();

            if ($onsiteLocationData) {
                $request['updated_at'] = date('Y-m-d H:i:s');
                OnsiteLocation::where('transaction_no', $transaction_no)->update($addressArray);
            } else {
                $request['created_at'] = date('Y-m-d H:i:s');
                $request['updated_at'] = date('Y-m-d H:i:s');
                OnsiteLocation::insert($addressArray);
            }


            return response()->json([
                'status' => 'success',
                "message" => "Send request for address",
                "message_ar" => "إرسال طلب للحصول على العنوان",
                'data' => $transactionData], 200);


        } catch (\Exception $e) {
            return response()->json(['status' => 'failed', 'message' => 'Failed to send request for consumer current location ', 'message_ar' => "فشل إرسال طلب للموقع الحالي للمستهلك", "error" => $e->getMessage()], 400);
        }

    }

    /**
     * If purchased deal is onsite
     * Send address to technician based on the transaction number
     * Send notification for send address to technician
     *
     * @param  \Illuminate\Http\Request $request
     */


    function send_address(Request $request)
    {

        $validator = Validator::make($request->all(),
            [
                'transaction_no' => ['required'],
                'address' => ['required'],
                'longitude' => ['required'],
                'latitude' => ['required']
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach (json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json(['status' => "failed", "response" => $errors], 400);
        }

        $transaction_no = $request->transaction_no;

        $transactionData = Transaction::where('transaction_no', $transaction_no)->first();
        if (empty($transactionData))
            return response()->json([
                'status' => "failed",
                "message" => "Invalid Transaction Id",
                "message_ar" => "معرف المعاملة غير صالح",
            ], 400);
        if ($transactionData->payment_status != 'Successful')
            return response()->json([
                'status' => "failed",
                "message" => "This Transaction id not yet paid",
                "message_ar" => "معرف المعاملة هذا لم يتم دفعه بعد",
            ], 400);

        if ($transactionData->created_by != Auth::guard('driver')->id())
            return response()->json([
                'status' => "failed",
                "message" => "This transaction is not yours",
                "message_ar" => "هذه المعاملة ليست لك",
            ], 400);

        $itemData = ItemOffer::where('id', $transactionData['offer_id'])->first();
        $request['driver_id'] = Auth::guard('driver')->id();

        if (!$itemData->on_site)
            return response()->json([
                'status' => "failed",
                "message" => "Purchased deal is not onsite ",
                "message_ar" => "الصفقة المشتراة ليست في الموقع",
            ], 400);


        try {


            $onsiteLocationData = OnsiteLocation::where('transaction_no', $transaction_no)->orderBy('id', 'DESC')->first();

            if (!$onsiteLocationData) {
                return response()->json([
                    'status' => "failed",
                    "message" => "Technician not yet requested any address",
                    "message_ar" => "فني لم يطلب بعد أي عنوان"], 400);
            } else if ($onsiteLocationData->is_redeemed == 1) {
                return response()->json([
                    'status' => "failed",
                    "message" => "You can't send address as this transaction is already redeemed",
                    "message_ar" => "لا يمكنك إرسال العنوان حيث تم استرداد هذه المعاملة بالفعل"], 400);
            }

            if ($onsiteLocationData->is_requested == 0 && $onsiteLocationData->status == 1) {
                return response()->json([
                    'status' => "failed",
                    "message" => "You have already sent address",
                    "message_ar" => "لقد أرسلت عنوانا بالفعل"], 400);
            }

            $request['is_requested'] = '0';

            $request['updated_at'] = date('Y-m-d H:i:s');
            OnsiteLocation::where('id', $onsiteLocationData->id)->update($request->all());


            // Send push notification to deal admin or technician
            if ($onsiteLocationData->is_requested == 1) {
                try {
                    event(new sendAddressForOnsite($transaction_no, 43, ''));

                    event(new ConsumerCurrentLocationForAdmin($transaction_no));
                } catch (\Exception $e) {
                   Log::info("Sent notification for sent requested address by customer");
                   Log::error($e->getMessage());
                }
            }

            return response()->json([
                'status' => 'success',
                "message" => "You have successfully sent your address",
                "message_ar" => "لقد أرسلت عنوانك بنجاح",
                'data' => $transactionData
            ], 200);

        } catch (\Exception $e) {
            return response()->json(['status' => 'failed', 'message' => 'Failed to send your address', 'message_ar' => "فشل إرسال عنوانك", "error" => $e->getMessage()], 400);
        }

    }

    //Formate transaction details
    public function format($row)
    {

        $dealShare = new DealController();
        $pricing = $dealShare->bill_price_logic($row['transaction_no']); // Sends info for single quantity
        $row['final_price'] = $pricing['final_price'];
        $row['discount'] = $pricing['price_after_discount'];
        $row['vat_amount'] = $pricing['vat_amount'];
        $row['item_price'] = $pricing['item_price'];
        $row['discount_amount'] = $pricing['discount_amount'];

        $row['vat'] = $pricing['vat'];

        $payment_on = $row['payment']['payment_on'] ?? '';
        $action_code = $row['payment']['action_code'] ?? '';
        $row['payment_method'] = $this->findPaymentMethod($row['payment_with'], $payment_on);
        $row['payment_action'] = '';
        if($action_code == 1)
            $row['payment_action'] = 'Purchased';
        else if($action_code == 4)
            $row['payment_action'] = 'Authorized';
        else if($action_code == 5)
            $row['payment_action'] = 'Captured';
        else if($action_code == 9)
            $row['payment_action'] = 'Rejected';

        $row['filter_cost'] = $pricing['filter_cost'];
        $row['service_cost'] = $pricing['service_cost'];
        $row['service_cost_without_vat'] = $pricing['service_cost_without_vat'];
        $row['coupon_savings'] = $pricing['coupon_savings'];
        $row['price_after_discount'] = $pricing['price_after_discount'];

        $row['price_limit'] = $pricing['sharings']['adjustment_limit'];

        if($row['revised_quantity'] > 0)
            $row['refund_payment'] = $pricing['refund_payment'] ?? null;

        $status = $this->transaction_row_status($row);
        $row['transaction_status'] = $status['transaction_status'];
        $row['transaction_status_ar'] = $status['transaction_status_ar'];

        if ($row['item']) {
            $row['item']['title'] = $row['paymentinfo']['item_name'];
            $row['item']['title_ar'] = $row['paymentinfo']['item_name_ar'];
            $row['item']['dimensions'] = $row['paymentinfo']['dimensions'];
            $row['item']['volt'] = $row['paymentinfo']['volt'];
            $row['item']['ah'] = $row['paymentinfo']['ah'];
            $row['item']['size'] = $row['paymentinfo']['size'];
            $row['item']['height'] = $row['paymentinfo']['height'];
            $row['item']['width'] = $row['paymentinfo']['width'];
            $row['item']['description'] = $row['paymentinfo']['item_description'];
            $row['item']['description_ar'] = $row['paymentinfo']['item_description_ar'];
            $row['item']['thumbnail_url'] = $row['paymentinfo']['thumbnail_url'];
        }

        if ($row['offer']) {
            $row['offer']['title'] = $row['paymentinfo']['offer_name'];
            $row['offer']['title_ar'] = $row['paymentinfo']['offer_name_ar'];
            $row['offer']['description'] = $row['paymentinfo']['offer_description'];
            $row['offer']['description_ar'] = $row['paymentinfo']['offer_description_ar'];
            $row['offer']['terms'] = $row['paymentinfo']['terms'];
            $row['offer']['terms_ar'] = $row['paymentinfo']['terms_ar'];
            $row['offer']['end_date'] = $row['paymentinfo']['end_date'];
            $row['offer']['is_notify'] = $row['paymentinfo']['is_notify'];
            $row['offer']['on_site'] = $row['paymentinfo']['on_site'];
            $row['offer']['service_cost'] = $row['paymentinfo']['service_cost'];
        }

        if ($row['item']['delar']) {
            $row['item']['delar']['org_name'] = $row['paymentinfo']['delar_name'];
            $row['item']['delar']['org_name_ar'] = $row['paymentinfo']['delar_name_ar'];
            $row['item']['delar']['address'] = $row['paymentinfo']['delar_address'];
        }

        $row['customer_contactnumber'] = "";
        if ($row['offer']['on_site'] == '1') {
            $row['customer_contactnumber'] = Driver::where('id', $row['created_by'])->pluck('contact_no')->first();
        }

        $row['scan_url'] = url('/download_public_invoice/' . $row['transaction_no']);
        $row['sharings'] = $pricing['sharings'];

        unset($row['paymentinfo']);
        return $row;
    }


    /*
     * Get each transaction of status counts
     * @param $id
     * return $totalArrays
    */
    function getCustomerTransactionCounts($id, $type)
    {

        $cancelledCount = 0;
        $successfulCount = 0;
        $failureCount = 0;
        $refundedCount = 0;
        $partialRefundedCount = 0;
        $redeemedCount = 0;
        $inProcessCount = 0;
        $paidCount = 0;
        $rejectedCount = 0;

        $list = Transaction::with('item', 'item.delar', 'item.deal');

        if ($type == 'driver') {
            $list = $list->where('created_by', $id);
        } else {
            $list = $list->whereHas('item', function ($item) use ($id) {
                $item->where('delar_id', $id);
            });
        }

        $transactionsList = $list->orderBy('id', 'desc')->get();

        if ($transactionsList) {
            foreach ($transactionsList as $row) {
                $statusArray = $this->transaction_row_status($row);
                $status = $statusArray['transaction_status'];
                if ($status == 'Successful') {
                    $successfulCount++;
                } else if ($status == 'Cancelled') {
                    $cancelledCount++;
                } else if ($status == 'Redeemed') {
                    $redeemedCount++;
                } else if ($status == 'Failed') {
                    $failureCount++;
                } else if ($status == 'In-process') {
                    $inProcessCount++;
                } else if ($status == 'Rejected') {
                    $rejectedCount++;
                } else if ($status == 'Partial Refund') {
                    $partialRefundedCount++;
                } else if ($status == 'Paid') {
                    $paidCount++;
                } else if ($status == 'Refunded') {
                    $refundedCount++;
                }
            }
        }

        return [
            'successful_count' => $successfulCount,
            'cancelled_count' => $cancelledCount,
            'failure_count' => $failureCount,
            'redeemed_count' => $redeemedCount,
            'inprocess_count' => $inProcessCount,
            'partial_refunded_count' => $partialRefundedCount,
            'paid_count' => $paidCount,
            'rejected_count' => $rejectedCount,
            'refunded_count' => $refundedCount
        ];
    }


    /*
     * Access: admin, prefix: api
     * Add Transaction Comments
     * @param $transaction_no
     * return $response
    */
    public function add_transaction_comments(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'transaction_no' => ['required'],
                'comments' => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach (json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json(['status' => "failed", "response" => $errors], 400);
        }

        $transaction_no = $request->transaction_no;

        $transactionData = Transaction::where('transaction_no', $transaction_no)->first();
        if (empty($transactionData))
            return response()->json([
                'status' => "failed",
                "message" => "Invalid Transaction Id",
                "message_ar" => "معرف المعاملة غير صالح",
            ], 400);

        try {
            TransactionComment::insert([
                'transaction_no' => $request->transaction_no,
                'comments' => $request->comments,
                'created_at' => date('Y-m-d H:i:s')
            ]);

            return response()->json([
                'status' => 'success',
                "message" => "You have successfully added comment",
                "message_ar" => "لقد قمت بإضافة تعليق بنجاح",
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'status' => 'failed',
                'message' => 'Failed to add comment',
                'message_ar' => "فشل في إضافة تعليق",
                "error" => $e->getMessage()
            ], 400);
        }

    }

    /*
     * Access: admin, prefix: api
     * Transaction Comments List
     * @param $transaction_no
     * return $response
    */
    public function transaction_comments($transaction_no)
    {
        $data = TransactionComment::where('transaction_no', $transaction_no)->get();
        return response()->json(['status' => 'success', "data" => $data ], 200);
    }

    private function findPaymentMethod($payment_with, $payment_on){
        $payment_method = '-';
        if($payment_with == 7)
            $payment_method = 'Joy Credits';
        else if($payment_with == 8 || $payment_with == 9) {
            if($payment_on == '')
                $payment_method = '-';
            else{
                $payment_method = ($payment_with == 9 ? 'Joy Credits & ' : '').
                    Lookup::where('id', $payment_on)->pluck('entity_name')->first();
            }
        }

        return $payment_method;
    }

    private function format_minimised_list($row){
        $payment_on = $row['payment']['payment_on'] ?? '';
        $payment_method = $this->findPaymentMethod($row['payment_with'], $payment_on);

        $status = $this->transaction_row_status($row);
        $status = $status['transaction_status'];

        return array(
            'id' => $row['id'],
            'transaction_no' => $row['transaction_no'],
            'invoice_no' => $row['invoice_no'],
            'created_at' => $row['created_at'],
            'item_id' => $row['item_id'],
            'item_name' => $row['rawdata']['item_name'],
            'offer_id' => $row['offer_id'],
            'offer_name' => $row['rawdata']['offer_name'],
            'quantity' => $row['quantity'],
            'revised_quantity' => $row['revised_quantity'],
            'redeem_quantity' => $row['redeem_quantity'],
            'on_site' => $row['offer']['on_site'],
            'is_notify' => $row['offer']['is_notify'],
            'is_approved' => $row['is_approved'],
            'delar_id' => $row['item']['delar_id'],
            'delar_name' => $row['rawdata']['delar_name'],
            'category_name' => $row['deal']['title'],
            'final_price' => $row['payment']['amount_by_banking'] + $row['payment']['amount_by_credits'],
            'status' => $status,
            'transaction_status' => $status,
            'payment_status' => $row['payment_status'],
            'response_code' => $row['payment']['response_code'],
            'payment_method' => $payment_method,
            'customer_id' => $row['driver']['id'],
            'customer_name' => $row['driver']['first_name'],
            'customer_contact' => $row['driver']['contact_no'],
            'employee_id' => $row['driver']['fleet_consumer'] ? $row['driver']['fleet_consumer']['employee_id'] : '',
            'approver_id' =>$row['approver'] ? $row['approver']['id'] : '',
            'approver_name' =>$row['approver'] ? $row['approver']['first_name'] : '',
            'approver_contact' => $row['approver'] ? $row['approver']['contact_no'] : '',
            'adjustment' =>$row['adjustment'] ? '1' : '0'
        );
    }

    /**
     * When site admin wanted to change status based on the current status
     * @param 
     * @return \Illuminate\Http\Response
     */

    public function changeTransactionStatusByAdmin(Request $request){
        $rules = [
            'status_type' => ['required'],
            'description' => ['required'],
            'transaction_no' => ['required']
        ];

        $messages=array();

        $messages = [
                        'status_type'=>'Transaction type is required'
                    ];

        if($request->status=='availability'){
            $rules = array_merge($rules, array(
                'is_available' => 'required'
            )); 
            $messages = array_merge($messages, array(
                   'is_available'=>'Availability is required'
            ));
        }

        if($request->status=='Refund' || $request->status=='Cancel'){
            $rules = array_merge($rules, array(
                'quantity' => 'required'
            ));  
        }

        if($request->status=='manual_payment'){
            $rules = array_merge($rules, array(
                'amount' => 'required',
                'transaction_id' => 'required',
            ));  
        }

        $validator = Validator::make($request->all(), $rules, $messages);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        $transInfo=Transaction::where('transaction_no', $request->transaction_no)->first();
        if(empty($transInfo)){
            return response()->json([
                'status' => 'failed',
                'message' => 'Transaction details not found'
            ], 400);
        }
        
        try {
            $tranArray['transaction_no']=$request->transaction_no;
            $tranArray['comments']=$request->description;
            $tranArray['status']=1;
            $tranArray['created_at']=date("Y-m-d H:i:s");
            //TransactionComment::insert($tranArray);
            if($request->status_type=='request_address'){
               return $this->request_for_address($request->transaction_no);
            } else if($request->status_type=='redeem'){
               return $this->approve_transaction_info($request->transaction_no);
            } else if($request->status_type=='availability'){
               return $this->update_availability();
            } else if($request->status_type=='Refund'){
               return (new RefundController())->send_refund();
            } else if($request->status_type=='Cancel'){
               return (new TabbyController())->cancelTransaction();
            } else if($request->status_type=='Adjustments'){
               return (new AdjustmentController())->send_adjustment();
            } else if($request->status_type=='manual_payment'){
               return (new PaymentController())->manual_payment($request);
            } else {
               return response()->json([
                'status' => 'failed',
                'message' => "Change status not allowed as it's alredy completed"
               ], 400);
            }
        } catch(\Exception $e){
            return response()->json([
                'status' => 'failed',
                'message' => 'Failed to change status',
                "error" => $e->getMessage()
            ], 400);
        }
    }
}
