<?php

namespace App\Http\Controllers\Notifications;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Events\Emails\VerifyEmailNotificationsEvent;
use App\Models\Accounts\Reset;
use App\Models\Accounts\Driver;
use Illuminate\Support\Facades\Validator;
use App\Models\Accounts\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class SendEmailNotificationController extends Controller
{
     /**
     * verify email by customer
     * @param $request
     * @return \Illuminate\Http\Response
     */
    public function verify_customer_email(Request $request)
    {
        if(explode('/', $request->route()->getPrefix())[0] == 'consumer'){  
           $request->id=Auth::guard('driver')->id();
        }
        
        $result=$this->verify_email($request, 'Driver');
        if($result['status']=='failed'){
            return response()->json($result, 400);
        } else{
            return response()->json($result, 200);
        }
    }

    /**
     * verify email by technician, dealer, fleet, maker
     * @param $request
     * @return \Illuminate\Http\Response
     */
    public function verify_user_email(Request $request)
    {
        if(explode('/', $request->route()->getPrefix())[0] == 'technician'){  
           $request->id=Auth::guard('technician')->id();
        }
        $result=$this->verify_email($request, 'User');
        if($result['status']=='failed'){
            return response()->json($result, 400);
        } else{
            return response()->json($result, 200);
        }
    }

    /**
     * Send Verify email OTP for customer, technician, dealer, service provider or partner
     * @param $request, $userType
     * @return $result
     */

    public function verify_email($request, $userType) {
        
        $validator = Validator::make($request->all(),
            [
                'email'    => ['required', 'string', 'email', 'max:60'],
                'id'=>['required']
            ] 
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return  [ 'status' => "failed", "response" => $errors ];
        }
        try{
            $check_email = User::where('id', $request->id)->where('email', $request->email)->first();
            if($userType=='Driver'){
                $check_email = Driver::where('id', $request->id)->where('email', $request->email)->first();
            }

            if(!$check_email)
                return [
                    'status' => "failed",
                    "response" => "Account details not found.",
                    "response_ar" => "لم يتم العثور على تفاصيل الحساب",
                ];

            //send OTP to entered Email
            $otp = mt_rand(1000, 9999);

            try{
                // Send notification to user
                event(new VerifyEmailNotificationsEvent($request['email'], $check_email->first_name, $otp, $userType, '17'));
            } catch(\Exception $e){
                Log::error('Failed to send email :  '. $e->getMessage());
            }

            Reset::where('email', $request['email'])->where('user_type', 'Driver')->delete();

            $update_otp = Reset::insert(['email' => $request['email'], 'token' => $otp, 'user_type' => $userType, 'created_at' => date('Y-m-d H:i:s')]);

            if($update_otp){
              return  [
                    'status' => "success",
                    "response" => "OTP sent to your registered email. Please check your Email Inbox",
                    "response_ar" => "تم إرسال كلمة المرور لمرة واحدة إلى بريدك الإلكتروني المسجل. يرجى التحقق من صندوق البريد الإلكتروني الخاص بك",
                ];
            } else {
                return [
                    'status' => "failed",
                    "response" => "OTP sent failed",
                    "response_ar" => "فشل إرسال كلمة المرور لمرة واحدة",
                ];
            }

        } catch (\Exception $e) {
            return [
                'status' => "failed",
                "response" => "Email id failed",
                "response_ar" => "Email id failed"
            ];
        }
    }

    /** 
     * Verify OTP to verify email id
     * @param $request
     * @return \Illuminate\Http\Response
     */

    function verify_email_otp(Request $request){
        
        if(explode('/', $request->route()->getPrefix())[0] == 'technician'){ 
            $request->id=Auth::guard('technician')->id();
            $request->user_type='User';
        } else if(explode('/', $request->route()->getPrefix())[0] == 'customer'){ 
           $request->user_type='Driver'; 
           $request->id=Auth::guard('driver')->id();
        }

        $validator = Validator::make($request->all(),
            [
                'email'    => ['required', 'string', 'email', 'max:60'],
                'OTP'    => ['required', 'string', 'min:4'],
                'user_type' =>['required'],
                'id'=>['required']
            ]
        );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{

            if(Reset::where([['email', $request->email],[ 'token' , $request->OTP ],[ 'user_type' , $request->user_type ]] )->count() > 0) {

                Reset::where('email', $request['email'])->where('user_type', $request->user_type)->delete();
                //Update email verification

                $userData = Driver::select('*');
                if($request->user_type=='Driver'){
                    Driver::where('id', $request->id)->update(['is_email_verified'=>'1','updated_at'=>date("Y-m-d H:i:s")]);
                } else {
                    User::where('id', $request->id)->update(['is_email_verified'=>'1','updated_at'=>date("Y-m-d H:i:s")]);
                    $userData = User::select('*');
                }

                $userData=$userData->where('email', $request->email)->where('id', $request->id)->first();

                return response()->json([
                    'status' => "success",
                    "response" => "OTP Verified Successfully",
                    "response_ar" => "تم التحقق من كلمة المرور لمرة واحدة بنجاح",
                    'data' => $userData ]);
            }else{
                return response()->json([
                    'status' => "failed",
                    "response" => "Invalid OTP",
                    "response_ar" => "كلمة مرور صالحة لمرة واحدة",
                ], 400);
            }
        }catch (\Exception $e){
            return response()->json(['status' => "failed", "response" => "Invalid OTP", "response_ar" => "كلمة مرور صالحة لمرة واحدة",], 400);
        }
    }
}
