<?php

namespace App\Http\Controllers\Notifications;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Generals\SendPushNotification;
use Illuminate\Support\Str;
use App\Models\Generals\Notification;
use App\Models\Generals\NotificationLog;
use File;
use App\Models\Accounts\Driver;
use App\Models\Accounts\User;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Models\Accounts\GroupConsumer;
use App\Models\Accounts\ConsumerGroup;
use App\Models\Regulatory\Fleet;
use App\Models\Generals\Device;

class CustomNotificationsController extends Controller
{
    public $msTechnician;
    public $dealerTechnician;
    public $notificationType;
    public $isSent;
    public $isNew;
    public function __construct()
    {
        $this->msTechnician = 7; // Only for M & S Deals - M & S Technician
        $this->dealerTechnician = 8; // Delar Technician
        $this->isSent=1;
        $this->notificationType='GN';
        $this->isNew=true;
    }

       /**
     * send custom notification based on notification types
     * @param $request
     * @return \Illuminate\Http\response
     */
    function sendCustomNotifications(Request $request){

        $rules = [
            'is_inapp' => ['required'],
            'is_firebase' => ['required'],
            'is_popup' => ['required'],
            'notification_to' => ['required'],
            'send_date' =>['required', 'after_or_equal:'.date("Y-m-d H:i:s")]
        ];

        $this->notificationType=$request->notification_to;
        $messages=array();

        $messages = [
                    'send_date.after_or_equal'=>'Send date should be more or equals to present date'
                ];

        if($request->notification_to=='GN' || $request->notification_to=='O'){

            $consumersCount=0;
            if(!isset($request['consumers'])){
                $consumersCount++;
            } else {
                $request['consumers'] = json_decode($request['consumers'], true );

                if($request['consumers']!=''){
                    $count=count($request['consumers']);

                    if($count>0 ){
                        $consumersData=$request['consumers']['0'];
                        if($consumersData['send_for']==10 && $consumersData['send_to']=='')
                            $consumersCount++;
                    } else {
                         $consumersCount++;
                    }
                } else {
                    $consumersCount++;
                }
            }

            
            $groupsCount=0;
            if(!isset($request['groups_list'])){
                $groupsCount++;
            } else {
                $request['groups_list'] = json_decode($request['groups_list'], true );
                if($request['groups_list']!=''){
                    $count=count($request['groups_list']);

                    if($count>0 ){
                        $groupsData=$request['groups_list']['0'];
                        if($groupsData['send_for']==10 && $groupsData['send_to']=='')
                            $groupsCount++;
                    } else {
                        $groupsCount++;
                    }
                } else {
                    $groupsCount++;
                }
            }

            if($request->notification_to=='O'){
                $rules = array_merge($rules, array(
                    'item_id' => 'required',
                    'offer_id' => 'required'
                )); 
            } 

            if($consumersCount>0 && $groupsCount>0){
                $request['groups_list']=[];
                $request['consumers']=[];
                $rules = array_merge($rules, array(
                    'consumers' => 'required'
                )); 


                $messages = array_merge($messages, array(
                       'consumers.required'=>'Either groups or customers list are required'
                ));
            } 


        } else if($request->notification_to=='T'){ 
            
            $techniciansCount=0;
              if(!isset($request['technicians_user'])){
                $techniciansCount++;
             } else {

                $request['technicians_user'] = json_decode($request['technicians_user'], true );
                if($request['technicians_user']!=''){
                    $count=count($request['technicians_user']);

                    if($count>0 ){
                        $consumersData=$request['technicians_user']['0'];
                        if($consumersData['send_for']==10 && $consumersData['send_to']=='')
                            $techniciansCount++;
                    } else {
                         $techniciansCount++;
                    }
                } else {
                    $techniciansCount++; 
                }
            }

            if($techniciansCount>0){
                $request['technicians_user']=[];
                $rules = array_merge($rules, array(
                    'technicians_user' => 'required',
                )); 
            } 

        } else if($request->notification_to=='UN'){   
            if($request->is_inapp)   {
                 return response()->json(['status' => 'failed','message' => "For unregistered users don't allow in app send notifications"], 400);  
            } 

            if($request->is_popup)   {
                 return response()->json(['status' => 'failed','message' => "For unregistered users don't allow to send popup notifications"], 400);  
            } 

            $unRegisteredUserCount=0;
            if(!isset($request['unregistered_user'])){
                $unRegisteredUserCount++;
            } else {
                $request['unregistered_user'] = json_decode($request['unregistered_user'], true );
                if($request['unregistered_user']!=''){
                    $count=count($request['unregistered_user']);

                    if($count>0 ){
                        $consumersData=$request['unregistered_user']['0'];
                        if($consumersData['send_for']==10 && $consumersData['send_to']=='')
                            $unRegisteredUserCount++;
                    } else {
                         $unRegisteredUserCount++;
                    }
                } else {
                    $unRegisteredUserCount++;
                }
            }

            if($unRegisteredUserCount>0){
                $request['unregistered_user']=[];
                $rules = array_merge($rules, array(
                    'unregistered_user' => 'required',
                )); 
            } 

        }  else if($request->notification_to=='G'){
            $guestUserCount=0;
            if(!isset($request['guest_user'])){
                $guestUserCount++;
            } else {
                $request['guest_user'] = json_decode($request['guest_user'], true );
                if($request['guest_user']!=''){
                    $count=count($request['guest_user']);
                    if($count>0 ){
                        $consumersData=$request['guest_user']['0'];
                        if($consumersData['send_for']==10 && $consumersData['send_to']=='')
                            $guestUserCount++;
                    } else {
                         $guestUserCount++;
                    }
                }  else {
                         $guestUserCount++;
                }
            }

            if($guestUserCount>0){
                $request['guest_user']=[];
                $rules = array_merge($rules, array(
                    'guest_user' => 'required',
                )); 
            } 
        }

        if($request->is_inapp || $request->is_firebase) {
            $rules = array_merge($rules, array(
                'notification_title' => 'required',
                'notification_title_ar' => 'required',
                'notification_message' => 'required',
                'notification_message_ar' => 'required',
            ));
        }
        
         
        $messages = array_merge($messages, array(
            'notification_title_ar.required'=> 'Arabic notification title is required',
            'notification_message_ar.required'=> 'Arabic notification message title is required',
            'technicians_user.required'=> 'Technicians are required for send notifications' ,
            'item_id.required'=> 'Item name required for send notifications',
            'offer_id.required'=> 'offer name is required for send notifications',
            'guest_user.required'=>'Guest users are required',
            'unregistered_user.required'=>'Unregistered users list is required'
       ));



        $validator = Validator::make($request->all(), $rules, $messages);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if($request->is_popup){
            if ($file=$request->file('thumbnail')) {
                $request['thumbnail_url']=$this->uploadPicture($request);
            } 
            /*else {
                return response()->json(['status' => 'failed','message' => 'Thumbnail is required'], 400);  
            }*/
        }

        if($request->notification_to=='UN'){
           $results=$this->sendUnRegisteredNotifications($request);
        } else if($request->notification_to=='G'){
           $results=$this->sendGuestNotifications($request);
        } else if($request->notification_to=='T'){
           $results=$this->sendTechniciansNotifications($request);
        } else {
           $results=$this->sendCustomerNotifications($request);
        }

        if($results['status']=='success'){
            return response()->json($results, 200);
        } else {
            return response()->json($results, 400);
        }
    }



    /**
     * send custom notification to gu users
     * @param $request
     * @return \Illuminate\Http\Response
     */

    function sendGuestNotifications($request){
         try{
            $results=$this->insertNotificationInfo($request);
            if($results['status']=='failed'){
                return $results;
            }

            $notificationId=$results['notification_id'];
            $notification=$results['notification'];

            $list =Device::where('user_type', 'guest');
            $guestUsers=$request->guest_user['0'];

            $arr=array();
            if($guestUsers['send_for']==10){
                $arr=explode(',',$guestUsers['send_to']);
                $list=$list->whereIn('id',$arr);
            } else if($guestUsers['send_for']==12 && $guestUsers['deleted_to']!=''){
                $arr=explode(',',$guestUsers['deleted_to']);
                $list=$list->whereNotIn('id',$arr);
            }
            
            $list=$list->get();
            foreach ($list as $userData) {
                $this->sendNewDeviceCustomMessage(
                    $notification,
                    $userData,
                    $request['is_inapp'],
                    $request['is_firebase'],
                    $request['is_popup'],
                    $notificationId,
                    0,
                    $request->notification_to,
                    $request['thumbnail_url']
                );
            }
            return ['status'=> 'success', 'message'=> 'Custom notification sent successfully'];
        }
        catch (\Exception $e){
            return [
                'status' => 'failed',
                'message' => 'Failed to Send custom notification',
                "error" => $e->getMessage() ];
        }
    }

    /**
     * send custom notification to unregistered users
     * @param $request
     * @return \Illuminate\Http\Response
     */

    function sendUnRegisteredNotifications($request){
        try{
            $results=$this->insertNotificationInfo($request);
            if($results['status']=='failed'){
                return $results;
            }

            $notificationId=$results['notification_id'];
            $notification=$results['notification'];

            $list = Device::whereNull('user_id');
            $user_type='driver';
            if($request->unregistered_type=='partner'){
               $user_type='user';
            }
            if(isset($request->unregistered_type) && $user_type!=''){
                $list = $list->where('user_type', $user_type);
            } else {
                $list = $list->where('user_type', ['driver', 'user']);
            }


            $unregisteredUsers=$request->unregistered_user['0'];

            if($unregisteredUsers['send_for']==10){
                $arr=array();
                $arr=explode(',',$unregisteredUsers['send_to']);
                $list=$list->whereIn('id',$arr);
            } else if($unregisteredUsers['send_for']==12 && $unregisteredUsers['deleted_to']!=''){
                $arr=array();
                $arr=explode(',',$unregisteredUsers['deleted_to']);
                $list=$list->whereNotIn('id',$arr);
            }

            $list=$list->get();

            foreach ($list as $userData) {
                $this->sendNewDeviceCustomMessage(
                    $notification,
                    $userData,
                    $request['is_inapp'],
                    $request['is_firebase'],
                    $request['is_popup'],
                    $notificationId,
                    0,
                    $request->notification_to,
                    $request['thumbnail_url']
                );
            }

             return ['status'=> 'success', 'message'=> 'Custom notification sent successfully'];
        }
        catch (\Exception $e){
            return [
                'status' => 'failed',
                'message' => 'Failed to Send custom notification',
                "error" => $e->getMessage() ];
        }
    }

        /**
     * Send custom notifications details to for each consumers
     *
     * @return \Illuminate\Http\Response
    */
    public function sendNewDeviceCustomMessage($notification, $userData, $isInapp, $isFirebase, $isPopup, $notificationId, $groupId, $userType, $imageUrl) {
        Log::info('Custom notification add start');

        if($this->isNew){ 
            // Send notification to Consumer on Add Transaction
            NotificationLog::insert([
                'notification_id' => $notificationId,
                'notification_to' => $userData->id,
                'group_id' => $groupId,
                'notification_for' =>$userType, // Consumer
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        }

        if($isFirebase && $this->isSent){ 
            $notificationTitle=$notification['notification_title'];
            $notificationMsg= $notification['notification_message']; 
            if($userData->fcm!=''){
                   
                   $ctype='consumer';
                   if($userData->user_type=='user'){
                      $ctype='partner';
                   }
                  (new SendPushNotification())->sendNotifyToUser( 
                      $userData->fcm,
                      $notificationTitle,
                      $notificationMsg,
                      $notification['notification_for'],
                      1,
                      1,
                      '',
                      '',
                      $ctype,
                      '',
                      $userData->device_type,
                      '',
                      ''
                    );
              }
        }
    }

    /**
     * send custom notification to technicians
     * @param $request
     * @return \Illuminate\Http\Response
     */

    function sendCustomerNotifications($request){
        try{

            $results=$this->insertNotificationInfo($request);
            if($results['status']=='failed'){
                return $results;
            }

            $notificationId=$results['notification_id'];
            $notification=$results['notification'];

            // Send notifications to group users
            if(isset($request->consumers) && count($request->consumers)>0){
                $this->getCustomersList($request, $notification, $notificationId);
            }

            // Send notifications to customers list
            if(isset($request->groups_list) && count($request->groups_list)>0){
               $this->getGroupConsumers($request, $notification, $notificationId);
            }

            return ['status'=> 'success', 'message'=> 'Custom notification sent successfully'];
        } catch (\Exception $e){
            return [
                'status' => 'failed',
                'message' => 'Failed to Send custom notification',
                "error" => $e->getMessage() ];
        }
    }

    /**
     * Get customers list
     * @param $request, $notification, $notificationId
     */

    function getCustomersList($request, $notification, $notificationId){
          
        $customerData=$request->consumers['0'];
        //$customersList=Driver::where('status',1);
        $org_id=$request->fleet_id;

        if($request->user_type=='P') // Fleet Company
        {
            $customersList = Driver::join('fleet_drivers', 'drivers.id', 'fleet_drivers.driver_id')
                ->select('drivers.*', 'fleet_drivers.employee_id')
                ->where('fleet_drivers.status', 1)
                ->where('drivers.status', 1)
                ->where('drivers.is_verified', 1);

            $customersList = $customersList->where('fleet_drivers.fleet_id', $org_id);
        }  else { // All users for admin
            
            $customersList = Driver::select('drivers.*', DB::raw(" '' as employee_id"))
                        ->where('is_verified', 1)->where('drivers.status', 1);
        }

        if($customerData['send_for']==10 && $customerData['send_to']!=''){
            $arr=array();
            $arr=explode(',',$customerData['send_to']);
            $customersList=$customersList->whereIn('drivers.id', $arr);
        } else if($customerData['send_for']==12 && $customerData['deleted_to']!=''){
            $arr=array();
            $arr=explode(',',$customerData['deleted_to']);
            $customersList=$customersList->whereNotIn('drivers.id',$arr);
        }

        $customersList=$customersList->with('loggedin_devices')->orderBy('drivers.id','DESC')->get();

        foreach ($customersList as $customerData) {
            $this->sendNewCustomMessage(
                $notification,
                $customerData,
                $request['is_inapp'],
                $request['is_firebase'],
                $request['is_popup'],
                $notificationId,
                0,
                'C',
                $request['thumbnail_url'],
                $customerData->id
            );
        }     
    }

    /**
     * Get group consumers list
     * @param $request, $notification, $notificationId
     */
    function getGroupConsumers($request, $notification, $notificationId){

        $groupsData=$request->groups_list['0'];

        // Get Customers list
        $customerArray=array();
        $customerType='10';

        if(isset($request->consumers) && count($request->consumers)>0){
            $customerData=$request->consumers['0'];
            if($customerData['send_for']==10 && $customerData['send_to']!=''){
                $customerArray=explode(',',$customerData['send_to']);  
            } else if($customerData['send_for']==12){
                if($customerData['deleted_to']!=''){
                    $customerArray=explode(',',$customerData['deleted_to']);
                }
                $customerType=12;
            }
        }
        //End Customers list

        $list = ConsumerGroup::with('company','consumers','consumers.loggedin_devices')
                ->withCount( ['consumers' => function($q){ $q->where('status', 1); }])
                ->Has( 'consumers', '>' , 0)
                ->where('status', 1);

        if($groupsData['send_for']==10 && $groupsData['send_to']!=''){
            $arr=array();
            $arr=explode(',',$groupsData['send_to']);
            $list=$list->whereIn('id', $arr);
        } else if($groupsData['send_for']==12 && $groupsData['deleted_to']!=''){
            $arr=array();
            $arr=explode(',',$groupsData['deleted_to']);
            $list=$list->whereNotIn('id',$arr);
        } 

        $org_id=$request->fleet_id;
        
        if($request->user_type == 'P'){ // Fleet Company
            $list = $list->where('company', $org_id);
        } 
 
        $groupCustomerArray=array();

        $list=$list->orderBy('id','DESC')->get();
        foreach ($list as $groupData) {
            $customerList=$groupData->consumers;
            foreach($customerList as $customerData){
                // Check group consumer id already exited in customer list or groups list
                $isSend=true;

                if(isset($request->consumers) && count($request->consumers)>0){
                    if(count($customerArray)>0){
                        if (in_array($customerData->consumer_id, $customerArray) && $customerType=='10') {
                            $isSend=false; 
                        } else if (!in_array($customerData->consumer_id, $customerArray) && $customerType=='12') {
                            $isSend=false;
                        } 
                    } else if ($customerType=='12') {
                        $isSend=false;
                    } 
                }

                if (in_array($customerData->consumer_id, $groupCustomerArray)) {
                    $isSend=false;
                }

                // End Check group consumer id already exited in customer list 
                if($isSend){
                    $groupCustomerArray[]=$customerData->consumer_id;
                    $this->sendNewCustomMessage(
                        $notification,
                        $customerData,
                        $request['is_inapp'],
                        $request['is_firebase'],
                        $request['is_popup'],
                        $notificationId,
                        $customerData->group_id,
                        'C',
                        $request['thumbnail_url'],
                        $customerData->consumer_id 
                    );
                }
            }
        }
    }

    
        /**
     * send custom notification to technicians
     * @param $request
     * @return \Illuminate\Http\Response
     */

    function sendTechniciansNotifications($request){
        try{

          $data = $this->sendNotificationToTechnicians($request);
          return ['status'=> 'success', 'message'=> 'Custom notification sent successfully', "data" => $data ];
        }
        catch (\Exception $e){
            return [
                'status' => 'failed',
                'message' => 'Failed to Send custom notification',
                "error" => $e->getMessage() ];
        }
    }

    /**
     * Send notification to technicians
     * @param $request
     */
    function sendNotificationToTechnicians($request){

        $results=$this->insertNotificationInfo($request);
        if($results['status']=='failed'){
            return $results;
        }

        $notificationId=$results['notification_id'];
        $notification=$results['notification'];

        // Get M&S Technicians list
        $techUsers=$request->technicians_user['0'];
        $techType=$this->msTechnician;
        if($request->technician_type=='deal_technician'){
            $techType=$this->dealerTechnician;
        }

        $technicianData=User::where('status',1)->where('role_id',$techType);

        if($techUsers['send_for']==10){
            $arr=array();
            $arr=explode(',',$techUsers['send_to']);
            $technicianData=$technicianData->whereIn('id',$arr);
        } else if($techUsers['send_for']==12 && $techUsers['deleted_to']!=''){
                $arr=array();
                $arr=explode(',',$techUsers['deleted_to']);
                $technicianData=$technicianData->whereNotIn('id',$arr);
            }

        $technicianData=$technicianData->with('loggedin_devices')->orderBy('id','DESC')->get();

        foreach ($technicianData as $technician) {
            $this->sendNewCustomMessage(
                $notification,
                $technician,
                $request['is_inapp'],
                $request['is_firebase'],
                $request['is_popup'],
                $notificationId,
                0,
                'N',
                $request['thumbnail_url'],
                $technician->id
            );
        }  
    }

    /**
     * insert notification details
     * @param $request
     */

    function insertNotificationInfo($request){
         
        $request['notification_title']=($request['notification_title']!='' && $request['notification_title']!='null') ? $request['notification_title'] : '';
        $request['notification_title_ar']=($request['notification_title_ar']!='' && $request['notification_title_ar']!='null') ? $request['notification_title_ar'] : '';
        
        $request['sub_title']=($request['sub_title']!='' && $request['sub_title']!='null')  ? $request['sub_title'] : '';

        $request['sub_title_ar']=($request['sub_title_ar']!='' && $request['sub_title_ar']!='null') ? $request['sub_title_ar'] : '';

        $request['notification_message']=($request['notification_message']!='' && $request['notification_message']!='null') ? $request['notification_message'] : '';

        $request['notification_message_ar']=($request['notification_message_ar']!='' && $request['notification_message_ar']!='null') ? $request['notification_message_ar'] : '';

        $request['notification_type'] = 'I'; // I - Individual
        $request['notification_for'] = 44; // '44 - Custom message',
        $request['created_at'] = date('Y-m-d H:i:s');
        //$request['expired_on'] =date('Y-m-d H:i:s', strtotime($request['send_date']. ' + 15 days'));
        $request['expired_on'] =date('Y-m-d H:i:s', strtotime("+15 days"));
         //date('Y-m-d', strtotime("+15 days"));
        $request['is_sent']=$this->isSent;
        
        if($request->notification_to=='T'){
            $notification = $request->except('thumbnail','technician_type','technicians_user','fleet_id','user_type','notification_to');
        } else if($request->notification_to=='UN'){
            $notification = $request->except('thumbnail','unregistered_type','unregistered_user','fleet_id','user_type','notification_to');
        } else if($request->notification_to=='G'){
            $notification = $request->except('thumbnail','guest_user','fleet_id','user_type','notification_to');
        }  else if($request->notification_to=='O'){
             $notification = $request->except('thumbnail','notification_to','consumers','groups_list','fleet_id','user_type');
        } else {
            $notification = $request->except('thumbnail','notification_to','consumers','groups_list','fleet_id','user_type');
        }
        
        try{

            $notificationId = Notification::insertGetId($notification);

            return ['status'=>'success', 'notification_id'=>$notificationId,'notification'=>$notification];
        } catch (\Exception $e){
            return ['status'=>'failed', 'message'=>'Failed submit notification details','error'=>$e->getMessage()];
        }
    }
    /**
     * Send custom notifications details to for each consumers
     *
     * @return \Illuminate\Http\Response
    */
    public function sendNewCustomMessage($notification, $userData, $isInapp, $isFirebase, $isPopup, $notificationId, $groupId, $userType, $imageUrl, $userId) {
        Log::info('Custom notification add start');
 
       if($this->isNew){
            // Send notification to Consumer on Add Transaction
            NotificationLog::insert([
                'notification_id' => $notificationId,
                'notification_to' => $userId,
                'group_id' => $groupId,
                'notification_for' =>$userType, // Consumer
                'created_at' => date('Y-m-d H:i:s'),
            ]);
         }


        if($isFirebase && $this->isSent){
            $consumer_tokens = $userData->loggedin_devices;
            if(!empty($consumer_tokens)){
                $notificationTitle=$notification['notification_title'];
                $notificationMsg= $notification['notification_message'];
                if($userData->preferred_language=='ar'){
                    $notificationTitle=$notification['notification_title_ar'];
                    $notificationMsg=$notification['notification_message_ar'];
                }
                foreach ($consumer_tokens as $singleRow) {
                    if($singleRow->fcm!='' && $singleRow->status) {  
                        $itemId=array_key_exists("item_id", $notification) ? $notification['item_id'] : '';
                        $offerId=array_key_exists("offer_id",$notification) ? $notification['offer_id'] : '';
                        (new SendPushNotification())->sendNotifyToUser( 
                          $singleRow->fcm,
                          $notificationTitle,
                          $notificationMsg,
                          $notification['notification_for'],
                          1,
                          $userId,
                          $itemId,
                          $offerId,
                          'consumer',
                          '',
                          $singleRow->device_type,
                          '',
                          ''
                        );
                    }
               } 
            }
        }
    }


    /**
     * Upload image if any
     * @param $request
    */
    function uploadPicture($request){
        $thumbnail_url='';
        if ($file=$request->file('thumbnail')) {
            if(config('app.env') == 'local'){
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/notifications/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $thumbnail_url = '/uploads/notifications/'.$safeName;
            } else {
                $file_name = Storage::disk('s3')->put('uploads/notifications/', $request->file('thumbnail'));
                $thumbnail_url = Storage::disk('s3')->url($file_name);
            }  
        }
        return $thumbnail_url; 
    }

    /**
     * Search deal based on the category and keyword
     * @param $request
     * @return \Illuminate\Http\Response
    */

    function searchDealerDealTitle(Request $request){

        $list = ItemMaster::with('offers','offers.locations')
                ->with( ['offers' => function($q){ 
                    $q->where('status', 1); 
                    $q->where('end_date', '>=', date('Y-m-d')); 
                    $q->where('quantity', '>', 0);
                }])
                ->withCount( ['offers' => function($q){ 
                    $q->where('status', 1); 
                    $q->where('end_date', '>=', date('Y-m-d')); 
                    $q->where('quantity', '>', 0);
                }])
                ->Has( 'offers', '>' , 0)
                ->where('status', 1)
                ->where('deal_id', $request->deal_id);
       
        if(isset($request->dealer_id) && $request->delar_id>0) {
            $list = $list->where('delar_id', $request->delar_id);  
        }

        if(isset($request->search_keyword) && $request->search_keyword!='') {
            $list = $list->where('title','LIKE',"%{$request->search_keyword}%");
        }

        if(isset($request->location_id) && $request->location_id>0) {
            $locationdId=$request->location_id;
            $list = $list->whereHas('offers.locations', function($item) use ($locationdId){
                 $item->where('location_id', $locationdId);
            });
        }

        $list=$list->orderBy('id','DESC')->get();
         
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

   /**
    * Get Custom Notification data based on the id
    * @param $notificationId
    * @return \Illuminate\Http\response
    */
     public function getCustomerNotificationData($notificationId) {

        try{
         
            $list = Notification::where('notification_for','44')->with('created_user')->withCount('inapp_views','popup_views')->where('id',$notificationId)->with('deal','offer','location_info')->first();

            if(empty($list))
                return response()->json(['status'=>'failed', 'message'=> 'Notification details not fount'], 400);

            $notificationsLogs=NotificationLog::select('notification_for', DB::raw('count(*) as total'))
            ->groupBy('notification_for')
            ->where('notification_id', $notificationId)
            ->first();

            $userType='GN';
            if($notificationsLogs){
                $user_type=$notificationsLogs->notification_for;
                if($user_type=='G' || $user_type=='C'){
                    if($list->item_id){
                      $userType='O';
                    } 
                } else if($user_type=='N'){
                    $userType='T';
                } else {
                    $userType=$user_type;
                }
            }
            $list->user_type=$userType;

            if(empty($list)){
                 return response()->json(['status'=>'failed', 'message'=> 'Failed to get notifications information'], 400);
            }
             
            return response()->json(['status'=>'success', 'data' => $list], 200);

        } catch (\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Failed to get notifications information', "error" => $e->getMessage()], 400);
        }
    }


       /**
    * Get Custom Notification data based on the id
    * @param $notificationId
    * @return \Illuminate\Http\response
    */
     public function getUsersListForNotification(Request $request) {

        try{

        $notificationId=$request->notification_id;
         
        $list = Notification::where('notification_for','44')->where('id',$notificationId)->first();
          
         
         $notificationsLogsCount=NotificationLog::select('notification_for', DB::raw('count(*) as total'))
            ->groupBy('notification_for')
            ->where('notification_id', $notificationId)
            ->get();

         $usersArray=array();
         $notification_type='';
         foreach($notificationsLogsCount as $singleRow){

            if($singleRow->notification_for=='G'){
                $UsersList=NotificationLog::where('group_id',0)->where('notification_id', $notificationId)->where('notification_for','G')->with('guest_users');

                $data=$this->getUserData($request, $UsersList);
                
                $notification_type='Guest Users';

                $usersArray['guest_users_list']=$data;

            } else if($singleRow->notification_for=='C'){
                $notification_type='General Notification';

                if($list->item_id>0){
                    $notification_type='On Offers';
                }

                $consumersList=NotificationLog::where('group_id',0)->where('notification_id', $notificationId)->where('notification_for','C')->with('customer_info');
                $dataConsumersList=$this->getUserData($request, $consumersList);

                //$groupsList=NotificationLog::where('group_id','>','0')->where('notification_id', $notificationId)->where('notification_for','C')->with('group_info','customer_info');


                $groupsList=NotificationLog::select('group_id',DB::raw("count(group_id) as group_count"))->where('group_id','>',0)->where('notification_id', $notificationId)
                    ->with('group_info')->groupBy('group_id');
                
                $request['orderBy']='group_id';

                $dataGroupsList=$this->getUserData($request, $groupsList);

                $usersArray['consumers_list']=$dataConsumersList;

                $usersArray['groups_list']=$dataGroupsList;

            }  else if($singleRow->notification_for=='N'){

                $notification_type='Technician';

                $UsersList=NotificationLog::where('group_id',0)->where('notification_id', $notificationId)->where('notification_for','N')->with('technicians_list');

                $techData=$UsersList->first();

                if($techData){ 
                    $notification_type="Deal Provider's Technicians";
                    if($techData->technicians_list->role_id==7){
                        $notification_type="Service Provider's Technicians";
                    }
                }

                $dataTechList=$this->getUserData($request, $UsersList);

                $usersArray['technicians_list']=$dataTechList;

            }  else if($singleRow->notification_for=='UN'){

                $notification_type='Technician';

                $UsersList=NotificationLog::where('group_id',0)->where('notification_id', $notificationId)->where('notification_for','UN')->with('unregistered_users');

                $datUnregisteredUsers=$this->getUserData($request, $UsersList);

                $usersArray['unregistered_users']=$datUnregisteredUsers;
            }

         }

            return response()->json(['status'=>'success','notification_type'=>$notification_type, 'users_list'=>$usersArray], 200);

        } catch (\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Failed to get notifications information', "error" => $e->getMessage()], 400);
        }
    }

    //Get User Data for each type customer notification
    function getUserData($request, $usersList){

        $pageno = 1; $pagelength = 10;
        if(isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $totalrecords = $usersList->count();

        $orderBy=isset($request['orderBy']) ? $request['orderBy'] : 'id';
        $usersList = $usersList->orderBy($orderBy, 'ASC')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

        $data['data'] = $usersList;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;

        return $data;
  
    }

    /**
     * verify email by customer
     * @param $request
     * @return \Illuminate\Http\Response
     */
    function reSendCustomNotifications($notificationId){

        try{
            $list = Notification::where('notification_for','44')->where('id',$notificationId)->first();
            if(empty($list)){
             return response()->json(['status'=>'failed', 'message'=> 'Failed to get notifications information'], 400);
            }

            $notification['notification_title']=$list->notification_title;
            $notification['notification_title_ar']=$list->notification_title_ar;
            $notification['notification_message']=$list->notification_message;
            $notification['notification_message_ar']=$list->notification_message_ar;
            $notification['sub_title']=$list->sub_title;
            $notification['sub_title_ar']=$list->sub_title_ar;
            $notification['item_id']=$list->item_id;
            $notification['offer_id']=$list->offer_id;
            $notification['thumbnail_url']=$list->thumbnail_url;
            $notification['navigation_id']=$list->navigation_id;
            $notification['is_inapp']=$list->is_inapp;
            $notification['is_firebase']=$list->is_firebase;
            $notification['is_popup']=$list->is_popup;

            $notification['notification_type'] = 'I'; // I - Individual
            $notification['notification_for'] = 44; // '44 - Custom message',
            $notification['created_at'] = date('Y-m-d H:i:s');
            $notification['expired_on'] = date('Y-m-d', strtotime("+15 days"));

            $notification_id = Notification::insertGetId($notification);

            $notificationsLogsCount=NotificationLog::select('notification_for', DB::raw('count(*) as total'))
                ->groupBy('notification_for')
                ->where('notification_id', $notificationId)
                ->get();

            $usersArray=array();
            $notification_type='';
            $isPagination=0;

             foreach($notificationsLogsCount as $singleRow){

                if($singleRow->notification_for=='G'){
                    $guestUsers=NotificationLog::where('group_id',0)->where('notification_id', $notificationId)->where('notification_for','G')->with('guest_users')->orderBy('id', 'ASC')->get();
                    
                    if($guestUsers){
                        foreach ($guestUsers as $guestUser) {

                            $userData=$guestUser->guest_users;

                            $this->sendNewDeviceCustomMessage(
                                $notification,
                                $userData,
                                $notification['is_inapp'],
                                $notification['is_firebase'],
                                $notification['is_popup'],
                                $notification_id,
                                0,
                                'G',
                                $notification['thumbnail_url']
                            );
                        }
                    }

                } else if($singleRow->notification_for=='C'){
                   
                    $consumersList=NotificationLog::where('group_id',0)->where('notification_id', $notificationId)->where('notification_for','C')->with('customer_info', 'customer_info.loggedin_devices')->orderBy('id','ASC')->get();
                    
                    if($consumersList){
                        foreach ($consumersList as $customerData) {
                            $userData=$customerData->customer_info;
                            $this->sendNewCustomMessage(
                                $notification,
                                $userData,
                                $notification['is_inapp'],
                                $notification['is_firebase'],
                                $notification['is_popup'],
                                $notification_id,
                                0,
                                'C' ,
                                $notification['thumbnail_url'],
                                $customerData->notification_to
                            );
                        }
                    }


                    $groupsList=NotificationLog::where('group_id','>','0')->where('notification_id', $notificationId)->where('notification_for','C')->with('group_info','customer_info', 'customer_info.loggedin_devices')->orderBy('id', 'ASC')->get();

                    if($groupsList){
                        foreach ($groupsList as $groupData) {
                            $userData=$groupData->customer_info;
                            $this->sendNewCustomMessage(
                                $notification,
                                $userData,
                                $notification['is_inapp'],
                                $notification['is_firebase'],
                                $notification['is_popup'],
                                $notification_id,
                                $groupData->group_id,
                                'C' ,
                                $notification['thumbnail_url'],
                                $groupData->notification_to
                            );
                        }
                    }


                }  else if($singleRow->notification_for=='N'){

                    $UsersList=NotificationLog::where('group_id',0)->where('notification_id', $notificationId)->where('notification_for','N')->with('technicians_list','technicians_list.loggedin_devices')->orderBy('id','ASC')->get();

                    if($UsersList){
                        foreach ($UsersList as $techData) {
                            $userData=$techData->technicians_list;
                            $this->sendNewCustomMessage(
                                $notification,
                                $userData,
                                $notification['is_inapp'],
                                $notification['is_firebase'],
                                $notification['is_popup'],
                                $notification_id,
                                0,
                                'N' ,
                                $notification['thumbnail_url']
                            );
                        }
                    }

                }  else if($singleRow->notification_for=='UN'){

                    $UsersList=NotificationLog::where('group_id',0)->where('notification_id', $notificationId)->where('notification_for','UN')->with('unregistered_users')->orderBy('id','ASC')->get();
                    
                    if($UsersList){
                        foreach ($UsersList as $userInfo) {

                            $userData=$userInfo->unregistered_users;

                            $this->sendNewDeviceCustomMessage(
                                $notification,
                                $userData,
                                $notification['is_inapp'],
                                $notification['is_firebase'],
                                $notification['is_popup'],
                                $notification_id,
                                0,
                                'UN' ,
                                $notification['thumbnail_url']
                            );
                        }
                    }
                }
            }
            return response()->json(['status'=>'success', 'message'=> 'Successfully send custom notification to all users'], 200);
        } catch(\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Failed to resend notifications selected users', "error" => $e->getMessage()], 400);
        }
    }

    /**
     * Send custom notifications for selected users based on the notification type
     * @param $notificationId
     */

    function sendCustomNotificationsCron($notificationId){
        try{
            $list = Notification::where('notification_for','44')->where('id',$notificationId)->first();
            if(empty($list)){
             return response()->json(['status'=>'failed', 'message'=> 'Failed to get notifications information'], 400);
            }

            $notification['notification_title']=$list->notification_title;
            $notification['notification_title_ar']=$list->notification_title_ar;
            $notification['notification_message']=$list->notification_message;
            $notification['notification_message_ar']=$list->notification_message_ar;
            $notification['sub_title']=$list->sub_title;
            $notification['sub_title_ar']=$list->sub_title_ar;
            $notification['item_id']=$list->item_id;
            $notification['offer_id']=$list->offer_id;
            $notification['thumbnail_url']=$list->thumbnail_url;
            $notification['navigation_id']=$list->navigation_id;
            $notification['is_inapp']=$list->is_inapp;
            $notification['is_firebase']=$list->is_firebase;
            $notification['is_popup']=$list->is_popup;
            $notification['notification_type'] = 'I'; // I - Individual
            $notification['notification_for'] = 44; // '44 - Custom message',
             
            $this->isNew=false;
            $this->isSent=1;
 
            $notificationsLogsCount=NotificationLog::select('notification_for')->where('notification_id', $notificationId)
                           ->groupBy('notification_for')
                           ->get();
            $usersArray=array();
            $notification_type='';
            $isPagination=0;

             foreach($notificationsLogsCount as $singleRow){

              
                if($singleRow->notification_for=='G'){
                    $guestUsers=NotificationLog::where('group_id',0)->where('notification_id', $notificationId)->where('notification_for','G')->with('guest_users')->orderBy('id', 'ASC')->get();
                    
                    if($guestUsers){
                        foreach ($guestUsers as $guestUser) {
                            $userData=$guestUser->guest_users;
                            $this->sendNewDeviceCustomMessage(
                                $notification,
                                $userData,
                                $notification['is_inapp'],
                                $notification['is_firebase'],
                                $notification['is_popup'],
                                $notificationId,
                                0,
                                'G',
                                $notification['thumbnail_url']
                            );
                        }
                    }

                } else if($singleRow->notification_for=='C'){
                   
                    $consumersList=NotificationLog::where('group_id',0)->where('notification_id', $notificationId)->where('notification_for','C')->with('customer_info', 'customer_info.loggedin_devices')->orderBy('id','ASC')->get();
                    
                    if($consumersList){
                        foreach ($consumersList as $customerData) {
                            $userData=$customerData->customer_info; 
                            $this->sendNewCustomMessage(
                                $notification,
                                $userData,
                                $notification['is_inapp'],
                                $notification['is_firebase'],
                                $notification['is_popup'],
                                $notificationId,
                                0,
                                'C' ,
                                $notification['thumbnail_url'],
                                $customerData->notification_to
                            ); 
                        }
                    }

                    $groupsList=NotificationLog::where('group_id','>','0')->where('notification_id', $notificationId)->where('notification_for','C')->with('group_info','customer_info', 'customer_info.loggedin_devices')->orderBy('id', 'ASC')->get();

                    if($groupsList){
                        foreach ($groupsList as $groupData) {
                            $userData=$groupData->customer_info;
                            $this->sendNewCustomMessage(
                                $notification,
                                $userData,
                                $notification['is_inapp'],
                                $notification['is_firebase'],
                                $notification['is_popup'],
                                $notificationId,
                                $groupData->group_id,
                                'C' ,
                                $notification['thumbnail_url'],
                                $groupData->notification_to
                            );
                        }
                    }

                }  else if($singleRow->notification_for=='N'){

                    $UsersList=NotificationLog::where('group_id',0)->where('notification_id', $notificationId)->where('notification_for','N')->with('technicians_list','technicians_list.loggedin_devices')->orderBy('id','ASC')->get();

                    if($UsersList){
                        foreach ($UsersList as $techData) {
                            $userData=$techData->technicians_list;
                            $this->sendNewCustomMessage(
                                $notification,
                                $userData,
                                $notification['is_inapp'],
                                $notification['is_firebase'],
                                $notification['is_popup'],
                                $notificationId,
                                0,
                                'N' ,
                                $notification['thumbnail_url'],
                                $userData->id
                            );
                        }
                    }

                }  else if($singleRow->notification_for=='UN'){
 
                    $UsersList=NotificationLog::where('group_id',0)->where('notification_id', $notificationId)->where('notification_for','UN')->with('unregistered_users')->orderBy('id','ASC')->get();

                  

                    if($UsersList){ 
                        foreach ($UsersList as $userInfo) {
                            $userData=$userInfo->unregistered_users;
                             
                            $this->sendNewDeviceCustomMessage(
                                $notification,
                                $userData,
                                $notification['is_inapp'],
                                $notification['is_firebase'],
                                $notification['is_popup'],
                                $notificationId,
                                0,
                                'UN' ,
                                $notification['thumbnail_url']
                            );
                        }
                    }
                }
            }

            return  ['status'=>'success', 'message'=> 'Successfully send custom notification to all users'];
        } catch(\Exception $e){
            return  ['status'=>'failed', 'message'=> 'Failed to resend notifications selected users'];
        }
    }

    /**
     * Get all not sent notifications based on the present date and time
     * 
    */
    function sendCustomNotificationUsingCron(){

        $fromDate = date('Y-m-d H:i:s', strtotime('-1 hour'));
        $toDate=date('Y-m-d H:i:s');
        $notificationList=Notification::where('is_sent',0)->where('send_date','>=',$fromDate)->where('send_date','<=',$toDate)->get();

        if($notificationList){
            foreach($notificationList as $singleRow){
            
                $results=$this->sendCustomNotificationsCron($singleRow->id);
                if($results['status']=='success'){
                    $notificationArray['is_sent']=1;
                    $notificationArray['updated_at']=date("Y-m-d H:i:s");
                    Notification::where('id', $singleRow->id)->update($notificationArray);
                    
                }
            }
        }
    }

    /**
     * Get all custom notifications List
     * @param $request
     * @return \Illuminate\Http\response
     */
    public function custom_notifications_list(Request $request) {
        try{
            // read notifications which are not read
            $pageno = 1; $pagelength = 10;
            $list = Notification::where('notification_for','44')->with('custom_individual','custom_groups');

            $totalrecords = $list->orderBy('id', 'desc')->count();
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
            }
            $list = $list->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get()->map(function($row){
                return $this->format_custom_notifications($row);
            });

            
            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status'=>'success', 'data' => $data], 200);

        } catch (\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Notifications failed', "error" => $e->getMessage()], 400);
        }
    }


    /**
      * Get all users list based on the notification id and either individual or group users
      * @param $request
      * @return \Illuminate\Http\response
    */   
     public function notifications_users_list(Request $request) {
        try{
            // read notifications which are not read
            $pageno = 1; $pagelength = 10;
            $list = NotificationLog::where('notification_id',$request->notification_id)->where('group_id',$request->group_id)->with('customer_info');

            $totalrecords = $list->orderBy('id', 'desc')->count();
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
            }
            $list = $list->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status'=>'success', 'data' => $data], 200);

        } catch (\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Notifications failed', "error" => $e->getMessage()], 400);
        }
    }

    /**
    * Get total count for individual and group counts   
    * @param $row
    * @return $row
    */
    public function format_custom_notifications($row){
        $row['custom_individual_count']=count($row['custom_individual']);
        $row['custom_groups_count']=count($row['custom_groups']);

        unset($row['custom_individual']);
        unset($row['custom_groups']);
        return $row;
    }

}


