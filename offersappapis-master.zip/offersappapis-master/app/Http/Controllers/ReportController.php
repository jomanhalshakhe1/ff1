<?php
namespace App\Http\Controllers;
// Import required dependencies
use Illuminate\Http\Request;
use App\Models\Accounts\Payment;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use App\Models\Accounts\Driver;
use App\Models\Accounts\Transaction;
use App\Models\Regulatory\Delar;
use Excel;
use PDF;
use PDFAR;
use App\Http\Controllers\Generals\DealController;
use App\Models\Accounts\PaymentShare;
use App\Models\Generals\Payout;
use App\Models\Regulatory\Organization;
use App\Models\Regulatory\Location;
use Salla\ZATCA\GenerateQrCode;
use Salla\ZATCA\Tags\InvoiceDate;
use Salla\ZATCA\Tags\InvoiceTaxAmount;
use Salla\ZATCA\Tags\InvoiceTotalAmount;
use Salla\ZATCA\Tags\Seller;
use Salla\ZATCA\Tags\TaxNumber;
use App\Models\Inventory\CreditNotes;
use App\Models\Accounts\Guest;
use App\Models\Generals\Device;
use App\Http\Controllers\Users\CreditsController;
use App\Models\Accounts\Credit;

class ReportController extends Controller
{
       /**
     * Get Successful and redeemed transactions list
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function getSuccessfulTransactionsDetails(Request $request){
        try{
            $list=$this->allTransactionsQuery($request);
            $totalrecords = $list->count();

            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;

                $list = $list->skip(($pageno - 1) * $pagelength)->take($pagelength);
            }

            $list = $list->orderBy('transactions.id', 'desc')->get()->map(function($row){
                $row = $this->calculateSharings($row);
                $row->transaction_status = (new TransactionController())->transaction_row_status($row);
                $row->transaction_status = $row['transaction_status']['transaction_status'];
                return $row;
            });

            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status' => 'success', 'data' => $data], 200);
        } catch(\Exception $e){
             return response()->json(['status' => 'failed', 'message' => "No records found",'error'=>$e->getMessage()], 200);
        }
    }
    /**
    * calculate sharings
    * @param $row
    * @return $row
    */

    private function calculateSharings($row){
        $dealShare = new DealController();
        $pricing = $dealShare->bill_price_logic($row['transaction_no']);
        $row['final_price'] = $pricing['final_price'];
        $row['discount_amount'] = $pricing['discount_amount'];
        $row['service_cost'] = $pricing['service_cost'];
        $row['filter_cost'] = $pricing['filter_cost'];
        $row['coupon_savings'] = $pricing['coupon_savings'];

        $sharings = $pricing['sharings'];

        $row['dealer_share'] = $sharings['delar_share'];
        $row['dealer_share_with_vat'] = round((float)($sharings['delar_share'] + $sharings['delar_share_vat']),2);
        $row['delar_share_get'] = $sharings['delar_share_get'];
        $row['joyshare'] = $sharings['joy_share'];
        $row['partner_share'] = $sharings['partner_share'];
        $row['partner_share_get'] = $sharings['partner_share_get'];
        $row['partner_share_cent'] = $sharings['partner_share_cent'];
        $row['paymentgate_share'] = round((float)($sharings['pg_share'] + $sharings['pg_fee']),2);
        return $row;
    }
     /**
     * Export Successful and redeemed transactions list
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function export_all_transactions(Request $request){

        $list=$this->allTransactionsQuery($request);
        $totalrecords = $list->count();
        if(!$totalrecords){
            return "No records found";
        }

        $list = $list->orderBy('transactions.id', 'desc')->get();

        $fields = array('ID', 'InvoiceNo', 'Company Name', 'Paid On', 'Item Name', 'Customer Name',
            'Quantity', 'Refund Qty.', 'Redeem Qty.', 'Actual Price/1 Qty','Discount(%)','Final Price','Discount Amount',
            'Dealer Share','Dealer Share With VAT','PG Share','Admin Share', 'Partner Share',
            'Service Cost', 'Filter Cost', 'Coupon Savings', 'Status');

        // Display column names as first row
        $excelData = implode("\t", array_values($fields)) . "\n";

        $i=1;
        foreach($list as $row){
             $row=$this->calculateSharings($row);
             $row['transaction_status'] = (new TransactionController())->transaction_row_status($row);
            $row->transaction_status = $row['transaction_status']['transaction_status'];
            $lineData = array(
                $i, $row->invoice_no ,$row->item->delar->org_name, $row['created_at'], $row->item->title, $row->driver->first_name,
                $row->quantity, $row->revised_quantity, $row->redeem_quantity, $row->price, $row->discount, $row->final_price, $row->discount_amount,
                $row['dealer_share'], $row['dealer_share_with_vat'], $row['paymentgate_share'], $row['joyshare'], $row['partner_share'],
                $row['service_cost'],$row['filter_cost'],$row['coupon_savings'],$row['transaction_status'] );

            $excelData .= implode("\t", array_values($lineData)) . "\n";
            $i++;
        }
        //Download excel file
        $fileName="transactions_list.xls";
        header("Content-Type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=\"$fileName\"");
        echo $excelData;
    }
    /**
     * Get all transaction details based on the search criteria
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */

    private function allTransactionsQuery($request){
        $list=Transaction::select('transactions.*','transaction_details.joy_share','transaction_details.pg_fee',
            'transaction_details.pg_fee','transaction_details.service_cost','transaction_details.filter_cost',
            'transaction_details.partner_discount','transaction_details.pg_share','transaction_details.vat',
            'redeem_log.redeem_at','redeem_log.quantity as redeemquantity')
          ->join('transaction_details', 'transaction_details.transaction_no','=','transactions.transaction_no')
          ->leftJoin('redeem_log', 'transactions.transaction_no', '=', 'redeem_log.transaction_no')
          ->where('transactions.payment_status','Successful')
          ->whereColumn('transactions.quantity','>','transactions.revised_quantity')
          ->with('item', 'offer', 'driver', 'item.delar', 'item.deal', 'refund', 'adjustment', 'location', 'driver.fleet_consumer', 'approver','payment');

        $fromDate=$request->from_date;
        $toDate=$request->to_date;

        if ($request->payment_status != 'Redeemed') {
            if($fromDate!='' && $toDate==''){
                $list = $list->where('transactions.created_at','>=',$fromDate." 00:00:00");
            } else if($fromDate=='' && $toDate!=''){
                $list = $list->where('transactions.created_at','<=',$toDate." 23:59:59");
            } else if($fromDate!='' && $toDate!=''){
                $list = $list->where('transactions.created_at','>=',$fromDate." 00:00:00");
                $list = $list->where('transactions.created_at','<=',$toDate." 23:59:59");
            }
        } else {
            if($fromDate!='' && $toDate==''){
                $list = $list->where('redeem_log.redeem_at','>=',$fromDate." 00:00:00");
            } else if($fromDate=='' && $toDate!=''){
                $list = $list->where('redeem_log.redeem_at','<=',$toDate." 23:59:59");
            } else if($fromDate!='' && $toDate!=''){
                $list = $list->where('redeem_log.redeem_at','>=',$fromDate." 00:00:00");
                $list = $list->where('redeem_log.redeem_at','<=',$toDate." 23:59:59");
            }
        }

        if($request->dealer_id!='All' && $request->dealer_id!=''){
            $dealerId=$request->dealer_id;
            $orgData=Organization::where('id', $dealerId)->where('company_type','D')->first();
            if($orgData){
                $list = $list->whereHas('item', function($item) use ($dealerId){
                     $item->where('delar_id', $dealerId);
                });
            }
         }

        if ($request->payment_status == 'Redeemed') {
            $list = $list->where('transactions.payment_status', 'Successful')
                  ->where('transactions.redeem_quantity','>',0)
                  ->whereRaw("((transactions.quantity-transactions.revised_quantity)-transactions.redeem_quantity) = 0");

        } else if ($request->payment_status == 'Successful') {
           $list = $list->where('transactions.payment_status', 'Successful')
                ->where('transactions.redeem_quantity','=',0);
        }

        return $list;
    }


     /**
     * Display a list of consumer purchased deals along with sharings for each dealer.
     * Dealer Reports
     * @return \Illuminate\Http\Response
     */

     public function dealer_reports_summary(Request $request){
        try{
            $list = $this->getDealTransactionsRedeemedQuery($request);

            $totalrecords = $list->count();

            if ($totalrecords > 0) {
                // Create credit notes
                $this->create_creditnotes($totalrecords);
            }

            $list = $list->orderBy('redeem_log.id', 'desc');
            //Get records based on the page limit and page number
            $pagelength = 20; $pageno = 1;
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
            }

            $list = $list->skip(($pageno - 1) * $pagelength)->take($pagelength);
            $list = $list->get()->map(function ($row) {
                return $this->calculateSharings($row);
            });

            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status' => 'success', 'data' => $data], 200);

        } catch (\Exception $e) {
            return response()->json(['status' => 'failed', 'data' => '', 'message' => 'Something went wrong', 'error' => $e->getMessage()], 200);
        }
    }

    /**
     * Get all redeemed list based on the search criteria
     * @param $request
     * @return $list
    */
    private function getDealTransactionsRedeemedQuery($request){

        $list = Transaction::select('transactions.*','transaction_details.joy_share','transaction_details.pg_fee',
            'transaction_details.pg_fee','transaction_details.service_cost','transaction_details.filter_cost',
            'transaction_details.partner_discount','transaction_details.pg_share','transaction_details.vat',
            'redeem_log.redeem_at','redeem_log.quantity as redeemquantity')
        ->join('transaction_details', 'transaction_details.transaction_no','=','transactions.transaction_no')
        ->join('redeem_log', 'redeem_log.transaction_no','=','transactions.transaction_no')
        ->with('item', 'offer', 'item.delar', 'item.deal');

        if(Auth::user()){
            if(Auth::user()->login_type_id==18){
                $request->dealer_id=Auth::user()->org_id;
            }
        }

        if($request->dealer_id>0){
            $dealerId=$request->dealer_id;
            $orgData=Organization::where('id', $dealerId)->where('company_type','D')->first();
            if($orgData){
                $list = $list->whereHas('item', function($item) use ($dealerId){
                     $item->where('delar_id', $dealerId);
                });
            }
        }

        if($request->category_id>0){
            $list = $list->where('transactions.deal_id',$request->category_id);
        }

        if($request->from_date!='' && $request->to_date==''){
            $list = $list->where('redeem_log.redeem_at','>=',$request->from_date." 00:00:00");
        } else if($request->from_date=='' && $request->to_date!=''){
            $list = $list->where('redeem_log.redeem_at','<=',$request->to_date." 23:59:59");
        } else if($request->from_date!='' && $request->to_date!=''){
            $list = $list->where('redeem_log.redeem_at','>=',$request->from_date." 00:00:00");
            $list = $list->where('redeem_log.redeem_at','<=',$request->to_date." 23:59:59");
        }

        $list = $list->where('transactions.payment_status','=','Successful');
        $list = $list->where('transactions.redeem_quantity','>','0');
        return $list;
    }

    /**
     * Download summary report based on the selections
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
    */
    public function download_dealer_report_summary(Request $request){
        //Get redeemed deals query
        $list = $this->getDealTransactionsRedeemedQuery($request);
        $totalrecords = $list->count();

        if (!$totalrecords) {
            return response()->json(['status' => 'failed', 'message' => 'Dealer summary details not found'], 400);
        }

        $list = $list->orderBy('redeem_log.id', 'desc')->get()->map(function ($row) {
                        return $this->calculateSharings($row);
                    });

        if($request->file_type=='pdf'){
            //Download
            $downloadfileName = "delar_summary_reports.pdf";
            $pdf = PDF::loadView('dealernewreports', [
                'list' => $list,
            ], ['orientation' => 'L', 'format' => 'A4-L']);

            return $pdf->download($downloadfileName);
            //return $pdf->stream($downloadfileName);
        } else { 
            //Export using excel
            $fields = array('S.No.', 'Redeemed Date', 'Item Name', 'Redeem Quantity', 'Deal Price', 'Discount(%)','Dealer Share','Company Name');

            // Display column names as first row
            $excelData = implode("\t", array_values($fields)) . "\n";

            $i=1;
            foreach($list as $row){ 
                $lineData =[
                    $i,
                    date("M dS Y, h:s A", strtotime($row->redeem_at)),
                    $row->item->title,
                    $row->redeem_quantity,
                    $row->final_price,
                    $row->discount,
                    $row->delar_share_get,
                    $row->item->delar->org_name
                ];
                $excelData .= implode("\t", array_values($lineData)) . "\n";
                $i++;
            }
            //Download excel file
            $fileName="dealer_summary_report.xls";
            header("Content-Type: application/vnd.ms-excel");
            header("Content-Disposition: attachment; filename=\"$fileName\"");
            echo $excelData; 
        }
    }

    /**
     * Get All Dealar invoices created by user
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
    */
    function dealer_invoices(Request $request){

        $pageno = 1; $pagelength = 10;
        $login_type_id = Auth::user()->login_type_id;

        $list = CreditNotes::with('dealers','category','created_user')->where('company_type',$request->company_type);

        if($login_type_id==18  && Auth::check()){ //If logged in user is dealer 
            $list = $list->where('dealer_id',Auth::user()->org_id);
        }
        $totalrecords = $list->orderBy('created_at','DESC')->count();

        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = $list->orderBy('created_at','DESC')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;
        return response()->json(['status' => 'success', 'data' => $data], 200);

    }

        /**
     * Display a list of consumer purchased deals along with sharings for each dealer.
     * Dealer Reports
     * @return \Illuminate\Http\Response
     */

     function exportTotalSalesByItem(Request $request){

        $list=$this->getTotalSalesByItemsQuery($request);
        $listInfo = $list->get();
        if($listInfo){
            $dealShare = new DealController();
            foreach($listInfo as $row){
                // $pricing = $dealShare->bill_price_logic($row['transaction_no']);
                // $row['total_price'] = round( $pricing['final_price'],2);

                $row['total_price']=0;
                if($row['offer']['transactions_list']){
                    $transactionsInfo=$row['offer']['transactions_list'];
                    $totalPrice=0;
                    foreach($transactionsInfo as $transaction){
                        $pricing = $dealShare->bill_price_logic($transaction->transaction_no);
                        $totalPrice= $totalPrice+round($pricing['final_price'],2);
                    }
                    $row['total_price']=number_format($totalPrice,2);
                }
            }

            if($request->file_type=='pdf'){
                $downloadfileName =  "sales_by_items.pdf";
                $pdf = PDF::loadView('salesbyitems', [
                  'list'=>$listInfo,
                  "login_type_id"=>17
                ], ['orientation' => 'L', 'format' => 'A4-L']);

                return $pdf->download($downloadfileName);

               // return $pdf->stream($downloadfileName);

            } else { 
            //Export using excel
            $fields = array('S.No.', 'Item Name', 'Dealer Name', 'Total Sales Qty.', 'Total Price');

            // Display column names as first row
            $excelData = implode("\t", array_values($fields)) . "\n";

            $i=1;

            foreach($listInfo as $row){ 
                $lineData =[
                    $i,
                    date("M dS Y, h:s A", strtotime($row->redeem_at)),
                    $row->item->title,
                    $row->item->delar->org_name,
                    $row->total_sales,
                    $row->total_price
                ];
                $excelData .= implode("\t", array_values($lineData)) . "\n";
                $i++;
            }
            //Download excel file
            $fileName="sales_by_items.xls";
            header("Content-Type: application/vnd.ms-excel");
            header("Content-Disposition: attachment; filename=\"$fileName\"");
            echo $excelData; 
         }
      } else {
        echo "No sales items available";
      }
    }

    /**
     * Get total sales by item query
     * @param $request
     * @return $list
     */
    function getTotalSalesByItemsQuery($request){
         $list = Transaction::select('transactions.offer_id','transactions.item_id',\DB::raw('SUM(redeem_log.quantity) as total_sales'))
         ->join('redeem_log', 'redeem_log.transaction_no','=','transactions.transaction_no')
         ->where('transactions.payment_status','=','Successful')
         ->with('item', 'offer', 'item.delar','offer.transactions_list')
         ->groupBy(['transactions.offer_id','transactions.item_id']);

        if($request->dealer_id!='All'){
            $orgData=Organization::where('id',  $request->dealer_id)->where('company_type','D')->first();
            if($orgData){
                $list = $list->whereHas('item', function ($item) use($request) {
                    $item->where('item_master.delar_id', $request->dealer_id);
                });
            }
            //Get last payout for this selected dealer id
            $paid_date=Payout::where('payment_to', $request->dealer_id)->orderBy('paid_date', 'DESC')->pluck('paid_date')->last();

            $fromDate=$paid_date ? $paid_date : '2021-10-01';
            $toDate=date("Y-m-d");

        } 

        $fromDate=$request->from_date;
        $toDate= $request->to_date;
    
        if($fromDate!='' && $toDate==''){
            $list = $list->where('redeem_log.redeem_at','>=',$fromDate." 00:00:00");
        } else if($fromDate=='' && $toDate!=''){
            $list = $list->where('redeem_log.redeem_at','<=',$toDate." 23:59:59");
        } else if($fromDate!='' && $toDate!=''){
            $list = $list->where('redeem_log.redeem_at','>=',$fromDate." 00:00:00");
            $list = $list->where('redeem_log.redeem_at','<=',$toDate." 23:59:59");
        }

        return $list;
    }

    /**
     * Display a list of consumer purchased deals along with sharings for each dealer.
     * Dealer Reports
     * @return \Illuminate\Http\Response
     */

     function total_sales_by_item(Request $request){

        $list=$this->getTotalSalesByItemsQuery($request);

        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        // Get total records
        $record_count = DB::table( "transactions" );
        $record_count->fromSub($list,"query");
        $totalrecords=$record_count->count();

        $listInfo = $list->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

        $dealShare = new DealController();
        foreach($listInfo as $row){
            // $pricing = $dealShare->bill_price_logic($row['transaction_no']);
            // $row['total_price'] = round($pricing['final_price'],2);

            $row['total_price']=0;
            if($row['offer']['transactions_list']){
                $transactionsInfo=$row['offer']['transactions_list'];
                $totalPrice=0;
                foreach($transactionsInfo as $transaction){
                    $pricing = $dealShare->bill_price_logic($transaction->transaction_no);
                    $totalPrice= $totalPrice+round($pricing['final_price'],2);
                }
                $row['total_price']=number_format($totalPrice,2);
            }
            
        }

        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $data['data'] = $listInfo;
            $data['current_page'] =$pageno ? $pageno : '1';
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength ? $pagelength : '200';
            return response()->json(['status' => 'success', 'data' => $data], 200);
        } else {
            return response()->json(['status' => 'success', 'data' => $list], 200);
        }
    }


    /**
     * Search dealer details and create invoice and download invoice
     * @param $dealerId,$categoryId, $fromDate, $toDate
     * @access admin module only
     *
     */
    function download_dealer_report_invoice(Request $request){
        $dealerId=$request->deal_providers;
        $categoryId=$request->deal_category;
        $fromDate=$request->from_date;
        $toDate=$request->to_date;
        
         $list = Transaction::select('transactions.*','redeem_log.redeem_at','redeem_log.quantity as redeemquantity','transaction_details.joy_share','transaction_details.pg_fee','transaction_details.pg_fee','transaction_details.service_cost','transaction_details.filter_cost','transaction_details.partner_discount','transaction_details.pg_share','transaction_details.vat')
          ->join('transaction_details', 'transaction_details.transaction_no','=','transactions.transaction_no')
          ->join('redeem_log', 'redeem_log.transaction_no','=','transactions.transaction_no')
          ->join('item_master', 'item_master.id','=','transactions.item_id')
          ->where('transactions.payment_status', '=','Successful');

        $list =$list->where('item_master.delar_id',$dealerId);

        if($categoryId>0){
            $list = $list->where('transactions.deal_id',$categoryId);
        }

        if($fromDate!='' && $toDate==''){
            $list = $list->where('redeem_log.redeem_at','>=',$fromDate." 00:00:00");
        } else if($fromDate=='' && $toDate!=''){
            $list = $list->where('redeem_log.redeem_at','<=',$toDate." 23:59:59");
        } else if($fromDate!='' && $toDate!=''){
            $list = $list->where('redeem_log.redeem_at','>=',$fromDate." 00:00:00");
            $list = $list->where('redeem_log.redeem_at','<=',$toDate." 23:59:59");
        }

        $list = $list->where('transactions.redeem_quantity','>','0');
        $totalSales = $list->count();

        if($totalSales>0){
            $invNo=CreditNotes::where('report_type','I')->orderBy('id','Desc')->count()+1;

            $invoiceNo=sprintf("%05d", $invNo);
            $invoiceId=CreditNotes::insertGetId([
                'dealer_id'=>$dealerId,
                'invoice_no'=>$invoiceNo,
                'category_id'=>$categoryId,
                'from_date'=>$fromDate,
                'to_date'=>$toDate,
                'created_by'=>Auth::id(),
                'total_count'=>'1'
            ]);
             return response()->json(['status'=>'success', 'message'=> 'Invoice details found', 'invoiceId'=>$invoiceId ], 200);
        } else {
             return response()->json(['status'=>'failed', 'message'=> 'Invoice details not found' ], 400);
        }
    }

    /**
     * Get Dealer invoice details
     * @param $invoiceData
     */
    function dealerInvoice($invoiceData){
        $dealerId=$invoiceData->dealer_id;
        $categoryId=$invoiceData->category_id;
        $fromDate=$invoiceData->from_date;
        $toDate=$invoiceData->to_date;   

        //Total Redeems

         $list = Transaction::select('transactions.*','redeem_log.redeem_at','redeem_log.quantity as redeemquantity','transaction_details.joy_share','transaction_details.pg_fee','transaction_details.pg_fee','transaction_details.service_cost','transaction_details.filter_cost','transaction_details.partner_discount','transaction_details.pg_share','transaction_details.vat')
          ->join('transaction_details', 'transaction_details.transaction_no','=','transactions.transaction_no')
          ->join('redeem_log', 'redeem_log.transaction_no','=','transactions.transaction_no')
          ->join('item_master', 'item_master.id','=','transactions.item_id')
          ->where('transactions.payment_status', '=','Successful');

        $list =$list->where('item_master.delar_id',$dealerId);

        if($categoryId>0){
            $list = $list->where('transactions.deal_id',$categoryId);
        }

        if($fromDate!='' && $toDate==''){
            $list = $list->where('redeem_log.redeem_at','>=',$fromDate." 00:00:00");
        } else if($fromDate=='' && $toDate!=''){
            $list = $list->where('redeem_log.redeem_at','<=',$toDate." 23:59:59");
        } else if($fromDate!='' && $toDate!=''){
            $list = $list->where('redeem_log.redeem_at','>=',$fromDate." 00:00:00");
            $list = $list->where('redeem_log.redeem_at','<=',$toDate." 23:59:59");
        }

        $list = $list->where('transactions.redeem_quantity','>','0');
        $totalSales = $list->count();

        if($totalSales>0){
            $list=$list->orderBy('redeem_log.id', 'desc')->get();

            $totalDealShare=0;$totalWithVat=0;$totalWithOutVat=0;$totalPgShare=0;
            foreach($list as $row){
               $row=$this->calculateSharings($row);
               $totalDealShare=$totalDealShare+$row['dealer_share'];
               $totalWithVat=$totalWithVat+$row['dealer_share_with_vat'];
               $totalWithOutVat=$totalWithOutVat+$row['dealer_share'];
               $totalPgShare=$totalPgShare+ $row['paymentgate_share'];
            }

          //End Total Redeems
          $listTran = Transaction::where('transactions.payment_status','Successful')
         ->join('item_master as im', 'im.id','=','transactions.item_id');

         if($dealerId>0){
             $listTran =$listTran->where('im.delar_id',$dealerId);
         }

         if($categoryId>0){
          $listTran = $listTran->where('transactions.deal_id',$categoryId);
         }

         if($fromDate!='' && $toDate==''){
            $listTran = $listTran->where('transactions.created_at','>=',$fromDate." 00:00:00");
         } else if($fromDate=='' && $toDate!=''){
            $listTran = $listTran->where('transactions.created_at','<=',$toDate." 23:59:59");
         } else if($fromDate!='' && $toDate!=''){
            $listTran = $listTran->where('transactions.created_at','>=',$fromDate." 00:00:00");
            $listTran = $listTran->where('transactions.created_at','<=',$toDate." 23:59:59");
         }

         $totalSalesInfo =$listTran->count();
         $orgData=Organization::where('id',$dealerId)->first();

         $innvohubOrgData=Organization::where('company_type','A')->first();

         $locationData=Location::select('locations.*','cities.city')
             ->join('cities','cities.id','=','locations.city')

            ->where('locations.org_id', $dealerId)->orderBy('locations.id','asc')->first();
         $displayQRCodeAsBase64 = GenerateQrCode::fromArray([
            new Seller($orgData->org_name), // seller name
            new TaxNumber($orgData->vat_no), // seller tax number
            new InvoiceDate(date('Y-m-d H:i:s')), // invoice date as Zulu ISO8601 @see https://en.wikipedia.org/wiki/ISO_8601
            new InvoiceTotalAmount($totalWithVat), // invoice total amount
            new InvoiceTaxAmount($totalWithVat-$totalWithOutVat) // invoice tax amount
            // TODO :: Support others tags
        ])->render();

        $qr_image = $displayQRCodeAsBase64;
         
        $invoiceNo=$invoiceData->invoice_no;
         
        $arrResults=[
            'totalDealShare'=>round($totalDealShare,2),
            'totalWithOutVat'=>round($totalWithOutVat,2),
            'totalWithVat'=>round($totalWithVat,2),
            'totalPgShare'=>round($totalPgShare,2),
            'qr_image'=>$qr_image,
            'totalTransactions'=>$totalSalesInfo,
            'totalSales'=>$totalSales,
            'from_date'=>$fromDate,
            'to_date'=>$toDate,
            'orgData'=>$orgData,
            'locationData'=>$locationData,
            'innvohubOrgData'=>$innvohubOrgData,
            'invoiceNo'=>$invoiceNo
        ];

        $downloadfileName = "dealer_invoice.pdf";
        $pdf = PDF::loadView('delar_invoice', $arrResults, ['orientation' => 'L', 'format' => 'A4-L']);
            return $pdf->download($downloadfileName);
          // return $pdf->stream($downloadfileName);


        //$pdf->save($path);

        return response()->json(['status'=>'success','message'=>'Invoice Generated', 'invoiceId'=>$invoiceId ], 200);

      } else {
        return response()->json(['status'=>'failed', 'message'=> 'Invoice details not found' ], 400);
      }
    }

    /**
     * Get Company payouts based on the search criteria
     * @param $request
     * @return \Illuminate\Http\Response
     */
    function company_payouts(Request $request){
        $orgId=$request['org_id'];
        $fromDate=$request['from_date'];
        $toDate=$request['to_date'];
        $userType=$request->user_type;

        $list=$this->getPayoutsQuery($orgId, $fromDate, $toDate, $userType);
        $totalrecords = $list->orderBy('id', 'desc')->count();

        $company_type='D';
        if($userType=='partner'){
            $company_type='F';
        }

        if($totalrecords){
           $reportCount=CreditNotes::where('dealer_id',$orgId)->where('from_date',$fromDate)->where('to_date',$toDate)->count();
            if(!$reportCount){
                CreditNotes::insert([
                    'dealer_id'=>$orgId,
                    'invoice_no'=>'',
                    'category_id'=>0,
                    'from_date'=>$fromDate,
                    'to_date'=>$toDate,
                    'report_type'=>'P',
                    'company_type'=>$company_type,
                    'created_by'=>Auth::id(),
                    'total_count'=>$totalrecords
                ]);
            }
        }

        $list = $list->orderBy('id', 'desc');
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
            $list = $list->skip( ($pageno-1)*$pagelength )->take($pagelength);
        }
        $list = $list->get();

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;

        return response()->json(['status' => 'success', 'data' => $data], 200);

    }

    /**
     * Download company payouts based on the search criteria
     * @param $request
     * @return \Illuminate\Http\Response
     */
    function download_payouts(Request $request){

        $orgId=$request['deal_providers'];
        $fromDate=$request['from_date'];
        $toDate=$request['to_date'];
        $userType=$request->user_type;

        $list=$this->getPayoutsQuery($orgId, $fromDate, $toDate, $userType);

        $totalrecords =$list->count();
        $list =$list->get();

        if($totalrecords>0){
            if($request->file_type=='pdf'){
                $downloadfileName =  $userType."_payouts.pdf";
                $pdf = PDF::loadView('dealerpayouts', [
                    'list'=>$list,
                    "login_type_id"=>17
                ], ['orientation' => 'L', 'format' => 'A4-L']);

               return $pdf->download($downloadfileName);
               //return $pdf->stream($downloadfileName);
           } else {
                //Export using excel
                $fields = array('S.No.', 'Created Date', 'Payouts Date', 'Company Name', 'Amount', 'Payment Type','Transaction No.');

                // Display column names as first row
                $excelData = implode("\t", array_values($fields)) . "\n";

                $i=1;
                foreach($list as $row){ 
                    $lineData =[
                        $i,
                        date("M dS Y, h:s A", strtotime($row->created_at)),
                        date("M dS Y, h:s A", strtotime($row->paid_date)),
                        $row->company->org_name,
                        $row->amount_paid,
                        $row->payment_type=='M' ? 'Manual' : 'Banking',
                        $row->transaction_id ?  $singleRow->transaction_id: '-'
                    ];
                    $excelData .= implode("\t", array_values($lineData)) . "\n";
                    $i++;
                }
                //Download excel file
                $fileName= $userType."_payouts.xls";
                header("Content-Type: application/vnd.ms-excel");
                header("Content-Disposition: attachment; filename=\"$fileName\"");
                echo $excelData; 
           }
        } else {
            return response()->json(['status'=>'failed', 'message'=> 'Payout details not found'], 400);
        }
    }

    /**
     * Get Payout data
     * @param $orgId, $fromDate, $toDate, $userType
     */
    function getPayoutsQuery($orgId, $fromDate, $toDate, $userType){
        $list = Payout::select('payouts.*')->where('payouts.status','1')
                 ->join('organizations as org', 'org.id','=','payouts.payment_to')
                 ->orderBy('created_at','DESC')
                 ->with('company');

         $company_type='D';
         if($userType=='partner'){
            $company_type='F';
         }
         $list = $list->where('org.company_type', $company_type);

         if($orgId>0){
            $list = $list->whereHas('company', function($company) use ($orgId){
                 $company->where('id', $orgId);
            });
         }

         if($fromDate!='' && $toDate==''){
            $list = $list->where('paid_date','>',$fromDate);
         } else if($fromDate=='' && $toDate!=''){
            $list = $list->where('paid_date','<=',$toDate);
         } else if($fromDate!='' && $toDate!=''){
            $list = $list->where('paid_date','>=',$fromDate);
            $list = $list->where('paid_date','<=',$toDate);
         }

         return $list;
    }

    //End Dealer Reports

    //Starts Partner reports
    /**
     * Display a list of consumer purchased deals along with sharings for each dealer.
     * Dealer Reports
     * @return \Illuminate\Http\Response
    */
    public function partner_reports(Request $request){
        // all deal provider transactions : web
        //Get Query
        $list = $this->partnerSummaryQuery($request);
        $totalrecords = $list->count();

        $partnerId = $request->partnerId > 0 ? $request->partnerId : '0';
        $this->saveCreditNotes($partnerId, '0', $request->from_date, $request->to_date,
            'F', 'S', '', $totalrecords);

        $pagelength = 20;
        $pageno = 1;
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = $list->orderBy('redeem_log.id', 'desc')->skip(($pageno - 1) * $pagelength)->take($pagelength)
            ->get()->map(function ($row) {
                return $this->calculateSharings($row);
            });

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    /**
     * Get query for partner summary
     * @param $request
     * @return $list
     */
    private function partnerSummaryQuery($request){
         $list = Transaction::select('transactions.*','transaction_details.joy_share','transaction_details.partner_share',
             'organizations.org_name','redeem_log.redeem_at','redeem_log.quantity as redeemquantity')
         ->join('organizations', 'organizations.id','=','transactions.fleet_id')
         //->where('transaction_details.partner_share','>',0)
         ->join('transaction_details', 'transaction_details.transaction_no','=','transactions.transaction_no')
         ->join('redeem_log', 'redeem_log.transaction_no','=','transactions.transaction_no')
         ->where('transactions.payment_status','Successful')
         ->with('item', 'offer', 'item.delar', 'item.deal');


        if(Auth::user()){
            if(Auth::user()->login_type_id==19){
                $request->partnerId=Auth::user()->org_id;
            }
        }

        if(isset($request->partnerId) && $request->partnerId>0) // Partner login
        {
           $orgData=Organization::where('id', $request->partnerId)->where('company_type', 'F')->first();
           if($orgData){
               $list=$list->where('transactions.fleet_id', $request->partnerId);
           }
        } 

        $fromDate=$request->from_date;
        $toDate=$request->to_date;

        if($fromDate!='' && $toDate==''){
            $list = $list->where('redeem_log.redeem_at','>=',$fromDate." 00:00:00");
        } else if($fromDate=='' && $toDate!=''){
            $list = $list->where('redeem_log.redeem_at','<=',$toDate." 23:59:59");
        } else if($fromDate!='' && $toDate!=''){
            $list = $list->where('redeem_log.redeem_at','>=',$fromDate." 00:00:00");
            $list = $list->where('redeem_log.redeem_at','<=',$toDate." 23:59:59");
        }

        $list = $list->where('transactions.redeem_quantity','>','0');
        return $list;
    }

    /**
     * Download partner summary details
     * @param $request
    */
   public function download_partner_report_summary(Request $request){

        //$partnerId='All', $fromDate='', $toDate=''
       $list = $this->partnerSummaryQuery($request);
       $totalrecords = $list->count();

       if ($totalrecords > 0) {

            $list = $list->orderBy('redeem_log.id', 'desc')->get()->map(function ($row) {
               return $this->calculateSharings($row);
            });

            if($request->file_type=='pdf'){ //Import data into pdf

               $downloadfileName = "partner_summary_report.pdf";
               $pdf = PDF::loadView('partnernewreports', [
                   'list' => $list,
               ], ['orientation' => 'L', 'format' => 'A4-L']);

               return $pdf->download($downloadfileName);
               //return $pdf->stream($downloadfileName);
           } else {
               //Export using excel
            $fields = array('S.No.', 'Redeemed Date', 'Item Name', 'Redeem Quantity', 'Deal Price', 'Discount(%)','Share(%)','Partner Share','Company Name');

            // Display column names as first row
            $excelData = implode("\t", array_values($fields)) . "\n";

            $i=1;
            foreach($list as $row){ 
                $lineData =[
                    $i,
                    date("M dS Y, h:s A", strtotime($row->redeem_at)),
                    $row->item->title,
                    $row->redeem_quantity,
                    $row->final_price,
                    $row->discount,
                    $row->partner_share_cent,
                    $row->partner_share_get,
                    $row->org_name
                ];
                $excelData .= implode("\t", array_values($lineData)) . "\n";
                $i++;
            }
            //Download excel file
            $fileName="partner_summary_report.xls";
            header("Content-Type: application/vnd.ms-excel");
            header("Content-Disposition: attachment; filename=\"$fileName\"");
            echo $excelData; 
           }
       } else {
           return response()->json(['status' => 'failed', 'message' => 'Partner details not found'], 400);
       }

    }

    /**
     * Download partner invoice
     * @param $request
     */
    function download_partner_report_invoice(Request $request){

        $partnerId=$request->partner_id;
        $fromDate=$request->from_date;
        $toDate=$request->to_date;

         $list = Transaction::select('transactions.*','transaction_details.joy_share','transaction_details.partner_share',
             'organizations.org_name','redeem_log.redeem_at','redeem_log.quantity as redeemquantity')
         ->join('organizations', 'organizations.id','=','transactions.fleet_id')
         ->whereNotNull('transactions.fleet_id')
         ->where('transaction_details.partner_share','>',0)
         ->join('transaction_details', 'transaction_details.transaction_no','=','transactions.transaction_no')
         ->join('redeem_log', 'redeem_log.transaction_no','=','transactions.transaction_no')
         ->with('item', 'offer', 'item.delar', 'item.deal');

        if($partnerId>0){// Partner login
           $list =$list->where('transactions.fleet_id', $partnerId);
        }

         if($fromDate!='' && $toDate==''){
            $list = $list->where('redeem_log.redeem_at','>=',$fromDate." 00:00:00");
         } else if($fromDate=='' && $toDate!=''){
            $list = $list->where('redeem_log.redeem_at','<=',$toDate." 23:59:59");
         } else if($fromDate!='' && $toDate!=''){
            $list = $list->where('redeem_log.redeem_at','>=',$fromDate." 00:00:00");
            $list = $list->where('redeem_log.redeem_at','<=',$toDate." 23:59:59");
         }

        $list = $list->where('transactions.redeem_quantity','>','0');
        $totalrecords = $list->orderBy('redeem_log.id', 'desc')->count();
        $list = $list->orderBy('redeem_log.id', 'desc')->get();


        if($totalrecords>0)
        {
           //Total Sales

        $listTran = Transaction::select(DB::raw('SUM(transactions.quantity-transactions.revised_quantity) As total_quantity'))
            ->where('transactions.payment_status','Successful')
            ->join('transaction_details', 'transaction_details.transaction_no','=','transactions.transaction_no')
            ->whereNotNull('transactions.fleet_id')
            ->where('transaction_details.partner_share','>',0)
            ->join('item_master as im', 'im.id','=','transactions.item_id');


         if($partnerId>0){
             $listTran =$listTran->where('transactions.fleet_id',$partnerId);
         }

         if($fromDate!='' && $toDate==''){
            $listTran = $listTran->where('transactions.created_at','>=',$fromDate." 00:00:00");
         } else if($fromDate=='' && $toDate!=''){
            $listTran = $listTran->where('transactions.created_at','<=',$toDate." 23:59:59");
         } else if($fromDate!='' && $toDate!=''){
            $listTran = $listTran->where('transactions.created_at','>=',$fromDate." 00:00:00");
            $listTran = $listTran->where('transactions.created_at','<=',$toDate." 23:59:59");
         }

         $totalSalesInfo =$listTran->pluck('total_quantity')->first();

        $totalPartnerShare=0;

        foreach($list as $row)
        {
            $row=$this->calculateSharings($row);
            $totalPartnerShare=$totalPartnerShare+$row->partner_share_get;
        }

         $orgData=Organization::where('id',$partnerId)->first();// Partner Organization

         $innvohubOrgData=Organization::where('company_type','A')->first();// Innvohub

         $locationData=Location::select('locations.*','cities.city')
            ->join('cities','cities.id','=','locations.city')
            ->where('locations.org_id', $partnerId)->orderBy('locations.id','asc')->first();


         $displayQRCodeAsBase64 = GenerateQrCode::fromArray([
            new Seller($orgData->org_name), // seller name
            new TaxNumber($orgData->vat_no), // seller tax number
            new InvoiceDate(date('Y-m-d H:i:s')), // invoice date as Zulu ISO8601 @see https://en.wikipedia.org/wiki/ISO_8601
            new InvoiceTotalAmount($totalPartnerShare), // invoice total amount
            new InvoiceTaxAmount('0') // invoice tax amount
            // TODO :: Support others tags
        ])->render();

        $qr_image = $displayQRCodeAsBase64;


        $invNo=CreditNotes::where('report_type','I')->orderBy('id','Desc')->count()+1;

        $invoiceNo=sprintf("%05d", $invNo);

        //Insert credit notes
        $invoiceId=CreditNotes::insertGetId([
            'dealer_id'=>$partnerId,
            'invoice_no'=>$invoiceNo,
            'category_id'=>'0',
            'from_date'=>$fromDate,
            'to_date'=>$toDate,
            'created_by'=>Auth::id(),
            'company_type'=>'F',
            'total_count'=>'1'
        ]);

        //$orgId, $categoryId, $from_date, $to_date, $companyType, $reportType, $invoiceId

        $this->saveCreditNotes($partnerId,'0',$request->from_date,$request->to_date,'F','I',$invoiceNo, '1');

        $arrResults=[
            'totalPartnerShare'=>$totalPartnerShare,
            'qr_image'=>$qr_image,
            'totalTransactions'=>$totalSalesInfo,
            'totalSales'=>$totalrecords,
            'from_date'=>$fromDate,
            'to_date'=>$toDate,
            'orgData'=>$orgData,
            'locationData'=>$locationData,
            'innvohubOrgData'=>$innvohubOrgData,
            'invoiceNo'=>$invoiceNo
        ];

        $fileName =  'partner_invoice'.$invoiceId.'.pdf';
        CreditNotes::where('id', $invoiceId)->update(['invoice_name'=>$fileName]);

        $path = public_path() . '/uploads/invoice/'.$fileName;

        if (!is_dir('uploads/invoice/')) {
           mkdir("uploads/invoice/", 0777);
        }

        $pdf = PDF::loadView('partner_invoice', $arrResults, ['orientation' => 'L', 'format' => 'A4-L']);

        $pdf->save($path);

        //return $pdf->download($fileName);
        //return $pdf->stream($fileName);
        //End Total Sales
         return response()->json(['status'=>'success', 'invoiceId'=>$invoiceId ], 200);

      } else {
        return response()->json(['status'=>'failed', 'message'=> 'Invoice details not found' ], 400);
      }
    }

    /**
     * Check and insert search data for both partner and dealer
     *@param
     */
    function saveCreditNotes($orgId, $categoryId, $from_date, $to_date, $companyType, $reportType, $invoiceId, $totalrecords){
        $reportCount=CreditNotes::where('dealer_id',$orgId)->where('from_date',$from_date)->where('to_date',$to_date)->where('category_id',$categoryId)->where('report_type',$reportType)->where('company_type',$companyType)->count();
        if(!$reportCount){

                       ;
           CreditNotes::insert([
                'dealer_id'=>$orgId,
                'invoice_no'=>$invoiceId,
                'category_id'=>$categoryId,
                'from_date'=>$from_date,
                'to_date'=>$to_date,
                'report_type'=>$reportType,
                'company_type'=>$companyType,
                'created_by'=>Auth::id(),
                'total_count'=>$totalrecords
            ]);
        }
    }


    /**
     * Download invoice
     * @param $fileId
     */

    public function download_invoice($fileId){
        $list = CreditNotes::where('id',$fileId)->first();
        if($list->company_type=='F'){
            $this->downloadPartnerInvoice($list);
        } else {
             $this->dealerInvoice($list);
        }  
    }

    function downloadPartnerInvoice($reportData){
        $partnerId=$reportData->dealer_id;
        $fromDate=$reportData->from_date;
        $toDate=$reportData->to_date;
         $invoiceNo=$reportData->invoice_no;

         $list = Transaction::select('transactions.*','transaction_details.joy_share','transaction_details.partner_share',
             'organizations.org_name','redeem_log.redeem_at','redeem_log.quantity as redeemquantity')
         ->join('organizations', 'organizations.id','=','transactions.fleet_id')
         ->whereNotNull('transactions.fleet_id')
         ->where('transaction_details.partner_share','>',0)
         ->join('transaction_details', 'transaction_details.transaction_no','=','transactions.transaction_no')
         ->join('redeem_log', 'redeem_log.transaction_no','=','transactions.transaction_no')
         ->with('item', 'offer', 'item.delar', 'item.deal');

        if($partnerId>0){// Partner login
           $list =$list->where('transactions.fleet_id', $partnerId);
        }

         if($fromDate!='' && $toDate==''){
            $list = $list->where('redeem_log.redeem_at','>=',$fromDate." 00:00:00");
         } else if($fromDate=='' && $toDate!=''){
            $list = $list->where('redeem_log.redeem_at','<=',$toDate." 23:59:59");
         } else if($fromDate!='' && $toDate!=''){
            $list = $list->where('redeem_log.redeem_at','>=',$fromDate." 00:00:00");
            $list = $list->where('redeem_log.redeem_at','<=',$toDate." 23:59:59");
         }

        $list = $list->where('transactions.redeem_quantity','>','0');
        $totalrecords = $list->orderBy('redeem_log.id', 'desc')->count();
        $list = $list->orderBy('redeem_log.id', 'desc')->get();


        if($totalrecords>0)
        {
           //Total Sales

            $listTran = Transaction::select(DB::raw('SUM(transactions.quantity-transactions.revised_quantity) As total_quantity'))
                ->where('transactions.payment_status','Successful')
                ->join('transaction_details', 'transaction_details.transaction_no','=','transactions.transaction_no')
                ->whereNotNull('transactions.fleet_id')
                ->where('transaction_details.partner_share','>',0)
                ->join('item_master as im', 'im.id','=','transactions.item_id');


             if($partnerId>0){
                 $listTran =$listTran->where('transactions.fleet_id',$partnerId);
             }

             if($fromDate!='' && $toDate==''){
                $listTran = $listTran->where('transactions.created_at','>=',$fromDate." 00:00:00");
             } else if($fromDate=='' && $toDate!=''){
                $listTran = $listTran->where('transactions.created_at','<=',$toDate." 23:59:59");
             } else if($fromDate!='' && $toDate!=''){
                $listTran = $listTran->where('transactions.created_at','>=',$fromDate." 00:00:00");
                $listTran = $listTran->where('transactions.created_at','<=',$toDate." 23:59:59");
             }

            $totalSalesInfo =$listTran->pluck('total_quantity')->first();

            $totalPartnerShare=0;

            foreach($list as $row)
            {
                $row=$this->calculateSharings($row);
                $totalPartnerShare=$totalPartnerShare+$row->partner_share_get;
            }

 
             $orgData=Organization::where('id',$partnerId)->first();// Partner Organization

             $innvohubOrgData=Organization::where('company_type','A')->first();// Innvohub

             $locationData=Location::select('locations.*','cities.city')
                ->join('cities','cities.id','=','locations.city')
                ->where('locations.org_id', $partnerId)->orderBy('locations.id','asc')->first();


             $displayQRCodeAsBase64 = GenerateQrCode::fromArray([
                new Seller($orgData->org_name), // seller name
                new TaxNumber($orgData->vat_no), // seller tax number
                new InvoiceDate(date('Y-m-d H:i:s')), // invoice date as Zulu ISO8601 @see https://en.wikipedia.org/wiki/ISO_8601
                new InvoiceTotalAmount($totalPartnerShare), // invoice total amount
                new InvoiceTaxAmount('0') // invoice tax amount
                // TODO :: Support others tags
            ])->render();

            $qr_image = $displayQRCodeAsBase64;

            
            $arrResults=[
                'totalPartnerShare'=>$totalPartnerShare,
                'qr_image'=>$qr_image,
                'totalTransactions'=>$totalSalesInfo,
                'totalSales'=>$totalrecords,
                'from_date'=>$fromDate,
                'to_date'=>$toDate,
                'orgData'=>$orgData,
                'locationData'=>$locationData,
                'innvohubOrgData'=>$innvohubOrgData,
                'invoiceNo'=>$invoiceNo
            ];

            $fileName =  'partner_invoice'.$reportData->id.'.pdf';
            
            $path = public_path() . '/uploads/invoice/'.$fileName;

            $pdf = PDF::loadView('partner_invoice', $arrResults, ['orientation' => 'L', 'format' => 'A4-L']);

            return $pdf->download($fileName);  
        } else {
            echo "No invoice found";
        } 
    }

    /**
     * Get customers list based on the search filters
     * @param $request
     * @return \Illuminate\Http\Response
     */

     function getCustomersList(Request $request){
         $login_type_id = Auth::user()->login_type_id;

        $pageno = 1; $pagelength = 10;
        $list = Driver::with('fleets')
                ->withCount('transaction_list','ios_device','android_device');

         $fromDate=isset($request->from_date) ? $request->from_date : date('Y-m-d', strtotime("-30 days"));
         $toDate=isset($request->to_date) ? $request->to_date : date('Y-m-d');
 
         if($request->user_type=='deleted'){
             $list=$list->onlyTrashed();
             if($fromDate!='' && $toDate==''){
                $list = $list->where('deleted_at','>=',$fromDate." 00:00:00");
             } else if($fromDate=='' && $toDate!=''){
                $list = $list->where('deleted_at','<=',$toDate." 23:59:59");
             } else if($fromDate!='' && $toDate!=''){
                $list = $list->where('deleted_at','>=',$fromDate." 00:00:00");
                $list = $list->where('deleted_at','<=',$toDate." 23:59:59");
             } 
         } else{
             if($fromDate!='' && $toDate==''){
                $list = $list->where('created_at','>=',$fromDate." 00:00:00");
             } else if($fromDate=='' && $toDate!=''){
                $list = $list->where('created_at','<=',$toDate." 23:59:59");
             } else if($fromDate!='' && $toDate!=''){
                $list = $list->where('created_at','>=',$fromDate." 00:00:00");
                $list = $list->where('created_at','<=',$toDate." 23:59:59");
             } 
         }
 
        $partnerId=$request->partner_id;
        if($request->partner_id>0){
            $list = $list->whereHas('fleets', function($fleet) use($partnerId){
                $fleet->where('fleet_id',$partnerId);
            });
        }

         
        $totalrecords = $list->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)){
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }
        $list = $list->orderBy('id', 'desc')
            ->skip( ($pageno-1)*$pagelength )->take($pagelength)->get()->map(function ($row) {
                return $this->formate_customer($row);
             });

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;
        return response()->json(['status' => 'success', 'data' => $data], 200);
     }

     /**
      * Formate customer details
      * @param $row
      * @return $row
      */
     function formate_customer($row){
        $creditController = new CreditsController();
        $creditsArray=$creditController->getCreditsInfo($row->id);
        $row['total_credits']=$creditsArray['credits'];
        $fleetsInfo=array();
        if($row['fleets']){
            foreach($row['fleets'] as $singleRow){
                $fleetsInfo[]=$singleRow->org_name;
            }
        }

        $row['fleets_info']='';
        if(count($fleetsInfo)){
            $row['fleets_info']=implode(", ", $fleetsInfo);
        }
        $row['device_type']='Android-'.$row->android_device_count.' IOS- '.$row->ios_device_count;
        return $row;
     }

        /**
     * Get guest customers list based on the search filters
     * @param $request
     * @return \Illuminate\Http\Response
     */

     function getGuestCustomersList(Request $request){
        $pageno = 1; $pagelength = 10;
        $list = Device::where('user_type', 'guest');
        $fromDate=isset($request->from_date) ? $request->from_date : date('Y-m-d', strtotime("-30 days"));
        $toDate=isset($request->to_date) ? $request->to_date : date('Y-m-d');
 
        if($fromDate!='' && $toDate==''){
            $list = $list->where('created_at','>=',$fromDate." 00:00:00");
        } else if($fromDate=='' && $toDate!=''){
            $list = $list->where('created_at','<=',$toDate." 23:59:59");
        } else if($fromDate!='' && $toDate!=''){
            $list = $list->where('created_at','>=',$fromDate." 00:00:00");
            $list = $list->where('created_at','<=',$toDate." 23:59:59");
        } 

        $totalrecords = $list->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = $list->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)
            ->get();
        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;
        return response()->json(['status' => 'success', 'data' => $data], 200);
     }

     function export_all_customers(Request $request){
        if($request->user_type=='guest'){ 
            $this->download_guests_customers($request);
        } else{
            $this->download_registered($request);
        }
     }

    /**
     * Get registered customers list based on the search filters
     * @param $request
     * @return \Illuminate\Http\Response
     */

     function download_registered($request){
         
         $list = Driver::with('fleets')
                ->withCount('transaction_list','ios_device','android_device');

         $fromDate=isset($request->from_date) ? $request->from_date : date('Y-m-d', strtotime("-30 days"));
         $toDate=isset($request->to_date) ? $request->to_date : date('Y-m-d');
 
         if($request->user_type=='deleted'){
             $list=$list->onlyTrashed();
             if($fromDate!='' && $toDate==''){
                $list = $list->where('deleted_at','>=',$fromDate." 00:00:00");
             } else if($fromDate=='' && $toDate!=''){
                $list = $list->where('deleted_at','<=',$toDate." 23:59:59");
             } else if($fromDate!='' && $toDate!=''){
                $list = $list->where('deleted_at','>=',$fromDate." 00:00:00");
                $list = $list->where('deleted_at','<=',$toDate." 23:59:59");
             } 
         } else{
             if($fromDate!='' && $toDate==''){
                $list = $list->where('created_at','>=',$fromDate." 00:00:00");
             } else if($fromDate=='' && $toDate!=''){
                $list = $list->where('created_at','<=',$toDate." 23:59:59");
             } else if($fromDate!='' && $toDate!=''){
                $list = $list->where('created_at','>=',$fromDate." 00:00:00");
                $list = $list->where('created_at','<=',$toDate." 23:59:59");
             } 
         }

        $partnerId=$request->partner_id;
        if($request->partner_id>0){
            $list = $list->whereHas('fleets', function($fleet) use($partnerId){
                $fleet->where('fleet_id',$partnerId);
            });
        }

        $totalrecords = $list->count();     
        if(!$totalrecords){
            return "Customer details available";
        }
        $list = $list->orderBy('id', 'desc')->get()
             ->map(function ($row) {
                return $this->formate_customer($row);
             });

        $fields = array('ID', 'Time', 'Date', 'Customer Name', 'Contact No.', 'Email ID','No. of transactions','Device Type','Total SAR','Partner');

        // Display column names as first row
        $excelData = implode("\t", array_values($fields)) . "\n";
        $i=1;
        foreach($list as $row){ 
            $lineData = array($i,date('h:i A', strtotime($row['created_at'])),date('d-m-Y', strtotime($row['created_at'])), $row->first_name, $row->contact_no, $row->email,$row->transaction_list_count,$row->device_type,$row->total_credits, $row->fleets_info);
            $excelData .= implode("\t", array_values($lineData)) . "\n";
            $i++;
        }
        //Download excel file
        $fileName="all_registered_user.xls";
        header("Content-Type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=\"$fileName\"");
        echo $excelData;  
     }

        /**
     * Download guest customers list based on the search filters
     * @param $request
     * @return \Illuminate\Http\Response
     */

     function download_guests_customers($request){
        $list = Device::where('user_type', 'guest');
        $fromDate=isset($request->from_date) ? $request->from_date : date('Y-m-d', strtotime("-30 days"));
        $toDate=isset($request->to_date) ? $request->to_date : date('Y-m-d');
 
        if($fromDate!='' && $toDate==''){
            $list = $list->where('created_at','>=',$fromDate." 00:00:00");
        } else if($fromDate=='' && $toDate!=''){
            $list = $list->where('created_at','<=',$toDate." 23:59:59");
        } else if($fromDate!='' && $toDate!=''){
            $list = $list->where('created_at','>=',$fromDate." 00:00:00");
            $list = $list->where('created_at','<=',$toDate." 23:59:59");
        } 

        $totalrecords = $list->count();
        if(!$totalrecords){
            return "No guest users available";
        }
        $list = $list->orderBy('id', 'desc')->get();

        $fields = array('ID', 'Time', 'Date', 'Device Type', 'Device Model', 'version','app_version','Last Access At', 'Status');

        // Display column names as first row
        $excelData = implode("\t", array_values($fields)) . "\n";

        $i=1;
        foreach($list as $row){
            $row->record_status = "Registered";
            if(!$row->converted_as)
                $row->record_status="Not Registered";

             $lineData = array($i,date('h:i A', strtotime($row['created_at'])),date('d-m-Y', strtotime($row['created_at'])), $row->device_type, $row->device_model, $row->version,$row->app_version,date("d-m-Y h:i A",strtotime($row->last_access_at)),$row->record_status);

            $excelData .= implode("\t", array_values($lineData)) . "\n";
            $i++;
        }
        //Download excel file
        $fileName="all_guest_user.xls";
        header("Content-Type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=\"$fileName\"");
        echo $excelData;
        
     }

     private function create_creditnotes($totalrecords){
         $request = request()->all();

         $reportCount = CreditNotes::where('dealer_id',$request['dealer_id'])
             ->where('company_type','D')
             ->where('category_id',$request['category_id'])
             ->where('from_date',$request['from_date'])
             ->where('to_date',$request['to_date'])
             ->count();

         if(!$reportCount){
             CreditNotes::insert([
                 'dealer_id' => $request['dealer_id'] > 0 ? $request['dealer_id'] : '0',
                 'invoice_no' => '',
                 'category_id' => $request['category_id'] > 0 ? $request['category_id'] : '0',
                 'from_date' => $request['from_date'],
                 'to_date' => $request['to_date'],
                 'report_type' => 'S',
                 'company_type' => 'D',
                 'created_by' => Auth::id(),
                 'total_count' => $totalrecords
             ]);
         }
     }


    /**
     * Download list of consumer purchased deals along with sharings for each dealer.
     * Download Dealer Reports
    */
    public function download_payout_details(Request $request){ 

       $result=$this->download_payouts($request['deal_providers'],$request['from_date'],$request['to_date'],'dealer');
       return $result;
        
    }

    /**
     * Get graphs for registered customers
    */

    public function getSignupsCustomersInfo(Request $request){

        $fromDate='2021-10-01';
        if(isset($request->from_date) && $request->from_date!=''){
            $fromDate=$request->from_date;
        }
        
        $toDate=date("Y-m-d");
        if(isset($request->to_date) && $request->to_date!=''){
           $toDate=$request->to_date;
        }

        $strToTime = strtotime($toDate) - (strtotime($fromDate));
        $days=floor($strToTime/3600/24);

        if($days<=16){
            
           $query="select DATE_FORMAT(created_at, '%b-%d') as date_val, COUNT(*) as count from `drivers` 
            where CAST(created_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."' and  deleted_at is null 
            group by DATE_FORMAT(created_at, '%b-%d') 
            ORDER BY year(created_at) asc,  month(created_at) asc, WEEK(created_at) asc, DAY(created_at) asc";

        }  else if($days>16 && $days<=91){
            $query="SELECT concat('Week-', WEEK(created_at)) AS date_val, COUNT(1) AS count FROM drivers 
                where created_at BETWEEN '".$fromDate."' AND '".$toDate."' and  deleted_at is null
                 GROUP BY concat('Week-', WEEK(created_at)) 
                 ORDER BY year(created_at) asc,  month(created_at) asc, WEEK(created_at) asc ";
        } else {
            //Customer's list by month wise or day wise
            $query="select DATE_FORMAT(created_at, '%b') AS date_val, COUNT(*) as count from `drivers` 
            where CAST(created_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."' 
            and  deleted_at is null group by DATE_FORMAT(created_at, '%b')
            ORDER BY year(created_at) asc, month(created_at) asc ";
        }

        $customersList= DB::select($query);
        $data['customers_list']=$customersList;
        
        //Total customer
        $customersCount= Driver::whereBetween('created_at', [$fromDate, $toDate])->count();

        $data['total_customers']=$customersCount;

        return response()->json(['status' => 'success', 'data' => $data], 200);   
    }


    /**
     * Get graphs for guest users
    */

    function getGuestUsersInfo(Request $request){

        $fromDate='2021-10-01';
        if(isset($request->from_date) && $request->from_date!=''){
            $fromDate=$request->from_date;
        }
        
        $toDate=date("Y-m-d");

        if(isset($request->to_date) && $request->to_date!=''){
           $toDate=$request->to_date;
        }

        $strToTime = strtotime($toDate) - (strtotime($fromDate));
        $days=floor($strToTime/3600/24);

        if($days<=16){   
            $query="select DATE_FORMAT(created_at, '%b-%d') as date_val, COUNT(*) as count from `devices` 
              where CAST(created_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."' 
              and user_type='guest' group by DATE_FORMAT(created_at, '%b-%d')
              ORDER BY year(created_at) asc,  month(created_at) asc, WEEK(created_at) asc, DAY(created_at) asc ";

        } else if($days>16 && $days<=91){
            $query="SELECT concat('Week-', WEEK(created_at)) AS date_val, COUNT(*) AS count FROM devices 
                where cast(created_at as date) BETWEEN '".$fromDate."' AND '".$toDate."' and user_type='guest' 
                GROUP BY concat('Week-', WEEK(created_at)) 
                ORDER BY year(created_at) asc,  month(created_at) asc, WEEK(created_at) asc ";
        } else {
            //Customer's list by month wise or day wise
            $query="select DATE_FORMAT(created_at, '%b-%y') AS date_val, COUNT(*) AS count from `devices` 
              where CAST(created_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."'
              and  user_type='guest' group by DATE_FORMAT(created_at, '%b-%y') 
              ORDER BY year(created_at) asc, month(created_at) asc ";
        }

        $customersList= DB::select($query);
        $data['guest_users']=$customersList;
        
        //Total customer
        $customersCount= Device::whereBetween('created_at', [$fromDate, $toDate])->where('user_type','guest')->count();

        $data['total_guest']=$customersCount;
        return response()->json(['status' => 'success', 'data' => $data], 200);     
    }

    /**
     * Get graphs for deleted acounts
    */
    public function getDeletedAccountCustomersInfo(Request $request){

        $fromDate='2021-10-01';
        if(isset($request->from_date) && $request->from_date!=''){
            $fromDate=$request->from_date;
        }
        
        $toDate=date("Y-m-d");

        if(isset($request->to_date) && $request->to_date!=''){
           $toDate=$request->to_date;
        }

        $strToTime = strtotime($toDate) - (strtotime($fromDate));
        $days=floor($strToTime/3600/24);

        if($days<=16){
             $query="select DATE_FORMAT(deleted_at, '%b-%d') as date_val, COUNT(*) as count from `drivers` 
            where CAST(deleted_at as date) BETWEEN '".$fromDate."' AND '".$toDate."' and deleted_at IS NOT NULL 
            group by DATE_FORMAT(deleted_at, '%b-%d') 
            ORDER BY year(deleted_at) asc,  month(deleted_at) asc, WEEK(deleted_at) asc, DAY(deleted_at) asc";

        } else if($days>16 && $days<=91){
            $query="SELECT concat('Week-', WEEK(deleted_at)) AS date_val, COUNT(id) AS count FROM drivers 
              where cast(deleted_at as date) BETWEEN '".$fromDate."' AND '".$toDate."' 
              and  deleted_at IS NOT NULL GROUP BY concat('Week-', WEEK(deleted_at)) 
              ORDER BY year(deleted_at) asc,  month(deleted_at) asc, WEEK(deleted_at) asc ";

        }  else {
            //Customer's list by month wise or day wise
            $query="select DATE_FORMAT(deleted_at, '%b-%y') AS date_val, COUNT(*) as count from `drivers` 
            where CAST(deleted_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."' 
            and deleted_at IS NOT NULL group by DATE_FORMAT(deleted_at, '%b-%y')
            ORDER BY year(deleted_at) asc, month(deleted_at) asc ";
        }

        $customersList= DB::select($query);
        $data['customers_list']=$customersList;
        
        //Total customer
        $customersCount= Driver::whereBetween('deleted_at', [$fromDate, $toDate])->withTrashed()->count();
        $data['total_customers']=$customersCount;
        return response()->json(['status' => 'success', 'data' => $data], 200); 
    }

    /**
     * Get graphs for transactions counts
    */
    function getTransactionsInfo(Request $request){

        $fromDate='2021-10-01';
        if(isset($request->from_date) && $request->from_date!=''){
            $fromDate=$request->from_date;
        }
        
        $toDate=date("Y-m-d");
        if(isset($request->to_date) && $request->to_date!=''){
           $toDate=$request->to_date;
        }
  
        //Total Pendings
        $data['pending_count']= Transaction::whereBetween('created_at', [$fromDate, $toDate])->where('payment_status','pending')->count();

        //Request Counts
        $data['request_counts']= Transaction::whereBetween('created_at', [$fromDate, $toDate])->where('payment_status','Requests')->count();

        //Available Counts
        $data['available_counts']= Transaction::whereBetween('created_at', [$fromDate, $toDate])->where('payment_status','Available')->count();
        

        //Successful Counts
        $data['successful_counts']= Transaction::whereBetween('created_at', [$fromDate, $toDate])->where('payment_status','Successful')->count();


         //Redeem Counts
        $data['redeem_counts']=Transaction::whereBetween('redeem_log.redeem_at', [$fromDate, $toDate])
             ->join('redeem_log', 'transactions.transaction_no', '=', 'redeem_log.transaction_no')
             ->where('transactions.payment_status','Successful')->count();
       
        //Cancelled Counts
        $data['cancelled_counts']= Transaction::whereBetween('created_at', [$fromDate, $toDate])->where('payment_status','Cancelled')->count();

        //Failure Counts
        $data['failure_counts']= Transaction::whereBetween('created_at', [$fromDate, $toDate])->whereIn('payment_status',['Failure','Failed'])->count();

         //Rejected Counts
        $data['rejected_counts']= Transaction::whereBetween('created_at', [$fromDate, $toDate])->where('payment_status','Rejected')->count();
         
        //Refund Counts
        $data['refunds_count'] = Credit::where('credit_on', 2) // 2 - Refund
                            ->whereBetween('created_at', [$fromDate, $toDate])
                            ->selectRaw('ifnull(count(amount),0) as refunds')
                            ->pluck('refunds')->first();

        return response()->json(['status' => 'success', 'data' => $data], 200);     
    }  


    /**
     * Get graphs for Active Users acounts
    */
    function getActiveUsersInfo(Request $request){

        $fromDate='2021-10-01';
        if(isset($request->from_date) && $request->from_date!=''){
            $fromDate=$request->from_date;
        }
        
        $toDate=date("Y-m-d");
        if(isset($request->to_date) && $request->to_date!=''){
           $toDate=$request->to_date;
        }

        $strToTime = strtotime($toDate) - (strtotime($fromDate));
        $days=floor($strToTime/3600/24);

        if($days<=16){
           $query="select DATE_FORMAT(created_at, '%b-%d') as date_val, COUNT(*) as count from `drivers` 
              where CAST(created_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."' and status=1 
              and  deleted_at is null group by DATE_FORMAT(created_at, '%b-%d')
              ORDER BY year(created_at) asc,  month(created_at) asc, WEEK(created_at) asc, DAY(created_at) asc ";
        } else if($days>16 && $days<=91){
            $query="SELECT concat('Week-', WEEK(created_at)) AS date_val,COUNT(*) AS count  FROM drivers 
                where cast(created_at as date) BETWEEN '".$fromDate."' AND '".$toDate."' and  deleted_at is null 
                GROUP BY concat('Week-', WEEK(created_at)) 
                ORDER BY year(created_at) asc,  month(created_at) asc, WEEK(created_at) asc ";
        } else {
            //Customer's list by month wise or day wise
            $query="select DATE_FORMAT(created_at, '%b-%y') AS date_val, COUNT(*) AS count from `drivers` 
             where CAST(created_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."' and status=1 
             and deleted_at is null group by DATE_FORMAT(created_at, '%b-%y') 
             ORDER BY year(created_at) asc, month(created_at) asc ";
        }

        $customersList= DB::select($query);
        $data['customers_list']=$customersList;
        
        //Total customer
        $customersCount= Driver::whereBetween('created_at', [$fromDate, $toDate])->where('status',1)->count();

        $data['total_customers']=$customersCount;
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }


    /**
     * Get graphs for transactions count who did more than 1 
    */
    public function getTransactionsMoreThanInfo(Request $request){

        $fromDate='2021-10-01';
        if(isset($request->from_date) && $request->from_date!=''){
            $fromDate=$request->from_date;
        }
        
        $toDate=date("Y-m-d");
        if(isset($request->to_date) && $request->to_date!=''){
           $toDate=$request->to_date;
        }

        $strToTime = strtotime($toDate) - (strtotime($fromDate));
        $days=floor($strToTime/3600/24);

        if($days<=16){
           $query="select DATE_FORMAT(created_at, '%b-%d') as date_val, COUNT(*) as count from `transactions` 
                where CAST(created_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."' 
                and (payment_status='Successful' or payment_status='Requests' or payment_status='Available') 
                group by DATE_FORMAT(created_at, '%b-%d') having count(created_by) > 1 
                ORDER BY year(created_at) asc,  month(created_at) asc, WEEK(created_at) asc, DAY(created_at) asc ";

        } else if($days>16 && $days<=91){
             $query="SELECT concat('Week-', WEEK(created_at)) AS date_val,COUNT(*) AS count FROM transactions 
                where cast(created_at as date) BETWEEN '".$fromDate."' AND '".$toDate."' 
                and  (payment_status='Successful' or payment_status='Requests' or payment_status='Available') 
                GROUP BY concat('Week-', WEEK(created_at)) having count(created_by) > 1 
                ORDER BY year(created_at) asc,  month(created_at) asc, WEEK(created_at) asc ";
        } 
        else {
            //Customer's list by month wise or day wise
            $query="select DATE_FORMAT(created_at, '%b-%y') AS date_val, COUNT(*) AS count from `transactions` 
                 where CAST(created_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."' 
                 and (payment_status='Successful' or payment_status='Requests' or payment_status='Available')   
                 group by DATE_FORMAT(created_at, '%b-%y') having count(created_by) > 1 
                 ORDER BY year(created_at) asc, month(created_at) asc ";
        }

        $transactionList= DB::select($query);
        $data['transactions_list']=$transactionList;

        $totalCount=0;
                
        if($transactionList){
          foreach($transactionList as $singleRow){
               $totalCount=$totalCount+$singleRow->count;
          }
        }

        $data['transactions_count']=$totalCount;
        
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    /**
     * Get graphs for transaction types count who did more than 1
     */
    public function getTransactionTypesInfo(Request $request){

        $fromDate='2021-10-01';
        if(isset($request->from_date) && $request->from_date!=''){
            $fromDate=$request->from_date;
        }

        $toDate=date("Y-m-d");
        if(isset($request->to_date) && $request->to_date!=''){
            $toDate=$request->to_date;
        }

        $strToTime = strtotime($toDate) - (strtotime($fromDate));
        $days=floor($strToTime/3600/24);

        if($days<=16){
            $query="select DATE_FORMAT(created_at, '%b-%d') as date_val, COUNT(*) as count from `transactions` 
                where CAST(created_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."' and payment_status='Successful'  
                group by DATE_FORMAT(created_at, '%b-%d')
                 ORDER BY year(created_at) asc,  month(created_at) asc, WEEK(created_at) asc, DAY(created_at) asc ";

        } else if($days>16 && $days<=91){
            $query="SELECT concat('Week-', WEEK(created_at)) AS date_val,COUNT(*) AS count FROM transactions 
                where cast(created_at as date) BETWEEN '".$fromDate."' AND '".$toDate."' and payment_status='Successful' 
                GROUP BY concat('Week-', WEEK(created_at)) 
                ORDER BY year(created_at) asc,  month(created_at) asc, WEEK(created_at) asc  ";
        }
        else {
            //Customer's list by month wise or day wise
            $query="select DATE_FORMAT(created_at, '%b-%y') AS date_val, COUNT(*) AS count from `transactions` 
                 where CAST(created_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."' and payment_status='Successful'    
                 group by DATE_FORMAT(created_at, '%b-%y') having count(created_by) > 1 
                 ORDER BY year(created_at) asc, month(created_at) asc ";
        }

        $successfulList= DB::select($query);
        $data['successful_list'] = $successfulList;

        if($days<=16){
            $rdquery="select DATE_FORMAT(redeem_at, '%b-%d') as date_val, COUNT(*) as count from `redeem_log` 
                where CAST(redeem_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."' 
                group by DATE_FORMAT(redeem_at, '%b-%d') ";

        } else if($days>16 && $days<=91){
            $rdquery="SELECT concat('Week-', WEEK(redeem_at)) AS date_val,COUNT(*) AS count FROM redeem_log 
                where cast(redeem_at as date) BETWEEN '".$fromDate."' AND '".$toDate."' 
                GROUP BY concat('Week-', WEEK(redeem_at)) ";
        }
        else {
            //Customer's list by month wise or day wise
            $rdquery="select DATE_FORMAT(redeem_at, '%b-%y') AS date_val, COUNT(*) AS count from `redeem_log` 
                 where CAST(redeem_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."'   
                 group by DATE_FORMAT(redeem_at, '%b-%y') ";
        }

        $redeemedList = DB::select($rdquery);
        $data['redeemed_list'] = $redeemedList;

        $totalSuccessCount = $totalRedeemCount = 0;
        if($successfulList){
            foreach($successfulList as $singleRow){
                $totalSuccessCount = $totalSuccessCount + $singleRow->count;
            }
        }
        if($redeemedList){
            foreach($redeemedList as $singleRow){
                $totalRedeemCount = $totalRedeemCount + $singleRow->count;
            }
        }
        $data['successful_count'] = $totalSuccessCount;
        $data['redeemed_count'] = $totalRedeemCount;

        return response()->json(['status' => 'success', 'data' => $data], 200);
    }


    /**
     * Get graphs for Active Users acounts
    */
    function getGiftCreditsUsersCountInfo(Request $request){

        $fromDate='2021-10-01';
        if(isset($request->from_date) && $request->from_date!=''){
            $fromDate=$request->from_date;
        }
        
        $toDate=date("Y-m-d");
        if(isset($request->to_date) && $request->to_date!=''){
           $toDate=$request->to_date;
        }

        $strToTime = strtotime($toDate) - (strtotime($fromDate));
        $days=floor($strToTime/3600/24);


        if($days<=16){
           $query="select DATE_FORMAT(created_at, '%b-%d') as date_val, cast(sum(quantity) as SIGNED) as count from `credits` 
                    where CAST(created_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."' and credit_on=1 
                    group by DATE_FORMAT(created_at, '%b-%d') 
                    ORDER BY year(created_at) asc,  month(created_at) asc, WEEK(created_at) asc, DAY(created_at) asc ";
        } else if($days>16 && $days<=91){
              $query="select concat('Week-', WEEK(created_at)) AS date_val, CAST(sum(quantity) as SIGNED) as count from `credits` 
              where CAST(created_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."' and credit_on=1 
              group by concat('Week-', WEEK(created_at)) 
              ORDER BY year(created_at) asc,  month(created_at) asc, WEEK(created_at) asc ";
        } else {
            //Customer's list by month wise or day wise
            $query="select DATE_FORMAT(created_at, '%b-%y') AS date_val, cast(sum(quantity) as SIGNED) as count from `credits` 
                 where CAST(created_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."' 
                 and credit_on=1 group by DATE_FORMAT(created_at, '%b-%y') 
                 ORDER BY year(created_at) asc, month(created_at) asc ";
        }

        $customersList= DB::select($query);
        $data['customers_list']=$customersList;
        
        //Total customer
        $creditsUsersCount= Credit::whereBetween('created_at', [$fromDate, $toDate])->where('credit_on',1)->sum('quantity');

        $data['total_customers']=$creditsUsersCount;
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }


    /**
     * Get graphs for Active Users acounts
    */
    public function getRefundedCountInfo(Request $request){

        $fromDate='2021-10-01';
        if(isset($request->from_date) && $request->from_date!=''){
            $fromDate=$request->from_date;
        }
        
        $toDate=date("Y-m-d");
        if(isset($request->to_date) && $request->to_date!=''){
           $toDate=$request->to_date;
        }

        $strToTime = strtotime($toDate) - (strtotime($fromDate));
        $days=floor($strToTime/3600/24);


        // Refund quanities count
        if($days<=16){
           
            $query="select DATE_FORMAT(b.created_at, '%b-%d') as date_val, COUNT(a.id) as count
        from transactions as a join payments as b on a.transaction_no = b.transaction_no
        where (a.payment_status = 'Successful' or a.payment_status = 'Requests'
           or a.payment_status = 'Available' or a.payment_status = 'Cancelled') and b.payment_status='Successful' 
           and a.revised_quantity > 0 and CAST(b.created_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."'   
           and b.action_code=2 group by DATE_FORMAT(b.created_at, '%b-%d')
            ORDER BY year(b.created_at) asc,  month(b.created_at) asc, WEEK(b.created_at) asc, DAY(b.created_at) asc";

        } else if($days>16 && $days <= 91){

            $query="select concat('Week-', WEEK(b.created_at)) AS date_val,COUNT(*) AS count
            from transactions as a join payments as b on a.transaction_no = b.transaction_no
            where (a.payment_status = 'Successful' or a.payment_status = 'Requests'
           or a.payment_status = 'Available' or a.payment_status = 'Cancelled') 
           and b.payment_status='Successful' and a.revised_quantity>0 
           and CAST(b.created_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."' and b.action_code = 2 
           group by concat('Week-', WEEK(b.created_at)) 
           ORDER BY year(b.created_at) asc,  month(b.created_at) asc, WEEK(b.created_at) asc  ";

        } else {
            //Customer's list by month wise or day wise
              $query="select DATE_FORMAT(b.created_at, '%b-%y') AS date_val, COUNT(*) AS count
            from transactions as a join payments as b on a.transaction_no = b.transaction_no
            where (a.payment_status = 'Successful' or a.payment_status = 'Requests'
               or a.payment_status = 'Available' or a.payment_status = 'Cancelled') 
               and b.payment_status='Successful' and a.revised_quantity>0 
               and CAST(b.created_at as Date) BETWEEN '".$fromDate."' AND '".$toDate."'  
                and b.action_code=2 group by DATE_FORMAT(b.created_at, '%b-%y') 
                ORDER BY year(b.created_at) asc, month(b.created_at) asc ";

        }

        $refundListTotalQuantities= DB::select($query);
        $data['refunds_lists']=$refundListTotalQuantities;

        $RefundsTranasactionscount=Transaction::join('payments as b', 'transactions.transaction_no', 'b.transaction_no')
            ->where('b.payment_status','Successful')
            ->where('transactions.revised_quantity','>',0)
            ->where('b.action_code',2)
            ->whereRaw("(transactions.payment_status = 'Successful' or transactions.payment_status = 'Requests'
           or transactions.payment_status = 'Available' or transactions.payment_status = 'Cancelled')")
            ->whereBetween("b.created_at",[$fromDate, $toDate])
            ->count();

        $data['refunds_lists_counts']=$RefundsTranasactionscount;

        return response()->json(['status' => 'success', 'data' => $data], 200);
    } 

}
