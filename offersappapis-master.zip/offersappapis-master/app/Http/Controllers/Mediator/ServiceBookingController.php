<?php

namespace App\Http\Controllers\Mediator;

use App\Http\Controllers\Controller;
use App\Models\Regulatory\Location;
use App\Models\Regulatory\Organization;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class ServiceBookingController extends Controller
{
    public $base_url;

    public function __construct()
    {
        $this->base_url = env('SERVICEBOOK_URL');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $url = 'bookings/list';
        $data = $this->get($url);

        return response()->json($data);
    }

    /**
     * Show the form for creating a new resource.
     * Access: admin, prefix: api
     * Create a service on service booking system
     *
     * @return \Illuminate\Http\Response
     */
    public function create($offer, $delar_id)
    {
        $provider = $this->find_accessOf_provider($delar_id);
        if(!$provider['data']) // Business was not available, service cannot able to create
            return false;

        $business_id = $provider['data']['id'];
        $insert = array(
            'title' => $offer['title'],
            'start_date' => $offer['start_date'],
            'end_date' => $offer['end_date'],
            'description' => $offer['description'],
            'is_onsite' => $offer['on_site'],
            'business_id' => $business_id,
        );
        try{
            return $this->add_service($insert);
        }catch (\Exception $e){
            return false;
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /*
     * Create a service in service booking system
     */
    public function add_service($body)
    {
        try{
            $data = $this->post('services/add', $body);
            if($data['status'] =='success') {
                //dd('service_id: '. $data['service_id']);
                return $data['service_id'];
            }
            else
                return false;
        }catch (\Exception $e){
            return false;
        }
    }

    /*
     * Update a service in service booking system
     */
    public function edit_service($body, $service_id)
    {
        try{
            $data = $this->post('services/edit/'. $service_id, $body);
            if($data['status'] =='success')
                return $data['service_id'];
            else
                return false;
        }catch (\Exception $e){
            return false;
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $url = 'services/'.$id;
        $data = $this->get($url);

        return response()->json($data);
    }

    public function redeem_check($id)
    {
        $url = 'services/'.$id;
        $data = $this->get($url);

        $booking_status = $data['data']->bookingStatus;
        if($booking_status == 1)
        {
            // we can redeem transaction in joy
            // $this->redeem_joy_transaction($id);
        }

        return response()->json($data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($offer, $service_id)
    {
        $insert = array(
            'title' => $offer['title'],
            'start_date' => $offer['start_date'],
            'end_date' => $offer['end_date'],
            'description' => $offer['description'],
            'is_onsite' => $offer['on_site'],
        );
        try{
            return $this->edit_service($insert, $service_id);
        }catch (\Exception $e){
            // dd($e->getMessage());
            Log::warning('Update service was updated: '. $service_id);
        }

        return false;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }


    public function find_accessOf_provider($delar_id){

        $org = Organization::where('id', $delar_id)->first();

        $body = array(
            'org_name' => $org['org_name'],
            'org_name_ar' => $org['org_name_ar'],
            'code' => $org['code'],
            'country_code' => $org['country_code'],
            'phone' => $org['phone'],
            'email' => $org['email'],
            'locations' => Location::join('cities', 'locations.city', 'cities.id')
                            ->where('org_id', $org['id'])
                            ->select('locations.street', 'locations.district', 'cities.city', 'locations.latitude', 'locations.longitude')
                            ->get()
        );

        try {

            return $this->post('business/verify', $body);
        }catch (\Exception $e) {
            // dd($e->getMessage());
            return array("status" => "failed", "statusCode" => "400", "error" => $e);
        }
    }

    /*
     * Check slot availability
     */
    public function check_availability($service_id){

        $baseUrl = $this->base_url;
        $endPoint = 'business/availability/'.$service_id;

        $client = new \GuzzleHttp\Client();
        try {
            $response = $client->get($baseUrl . $endPoint,
                ['headers' => $this->headers()]
            );
            return json_decode($response->getBody(), true);
        }catch (\Exception $e){

            $list = [];
            $start_date = date('Y-m-d');
            $end_date = date('Y-m-d', strtotime($start_date.'+29 days'));

            while (strtotime($start_date) <= strtotime($end_date)) {
                $check_day = (date('w', strtotime($start_date)) + 1);
                $list[]= array(
                    'dayOfWeek' => $check_day,
                    'slot_date' => $start_date,
                    'available' => 0,
                    'timeSlots' => [],
                );

                $start_date = date ("Y-m-d", strtotime("+1 days", strtotime($start_date)));
            }

            return ['status'=>'success', 'data'=> $list ];
            // return array( "status" => "failed", "statusCode" => "400", "error" => $e);
        }
    }

    /*
     * Verify slot before booking the service
     * Access: Sub function from transaction creation
     */
    public function verify_slot($input){
        $body = array(
            'service_id' => $input['service_id'],
            'service_on' => $input['slot_date'],
            'from_time' => $input['start_time'],
            'to_time' => $input['end_time']
        );

        try {
            $data = $this->post('business/verify_slot', $body);
            if(isset($data['status'])) {
                return $data;
            }
            else
                return false;
        }catch (\Exception $e) {
            return array( "status" => "failed", "statusCode" => "400", "error" => $e);
        }
    }

    /*
     * Book slot availability to Booking System
     * Access: Sub function from transaction creation
     */
    public function book_service_slot($input){

        $body = array(
            'service_id' => $input['service_id'],
            'service_on' => $input['slot_date'],
            'from_time' => $input['start_time'],
            'to_time' => $input['end_time'],
            'customer_name' => Auth::guard('driver')->user()->first_name ?? '',
            'country_code' => Auth::guard('driver')->user()->country_code ?? '',
            'contact_no' => Auth::guard('driver')->user()->contact_no ?? ''
        );

        try {
            $data = $this->post('bookings/add', $body);
            if(isset($data['status'])) {
                return $data;
            }
            else
                return false;
        }catch (\Exception $e) {
            return array( "status" => "failed", "statusCode" => "400", "error" => $e);
        }
    }

    private function get($url){
        $client = new \GuzzleHttp\Client([
            // Base URI is used with relative requests
            'base_uri' => $this->base_url,
            // You can set any number of default request options.
            'timeout'  => 3.0,
            'headers' => $this->headers(),
        ]);

        $url = $this->base_url.$url;
        // $data string variable is defined same as above.

        try {
            // Provide the body as a string.
            $response = $client->request('get', $url );
            $status = $response->getStatusCode();

            return json_decode($response->getBody(), true);
        }catch (\Exception $e) {
            // dd($e->getMessage());
            return array( "status" => "failed", "statusCode" => "400", "error" => $e);
        }
    }

    private function post($url, $body){
        $client = new \GuzzleHttp\Client([
            // Base URI is used with relative requests
            'base_uri' => $this->base_url,
            // You can set any number of default request options.
            'timeout'  => 3.0,
            'headers' => $this->headers(),
        ]);

        $url = $this->base_url.$url;
        // $data string variable is defined same as above.

        try {
            // Provide the body as a string.
            $response = $client->request('POST', $url, ['json' => $body]);
            $status = $response->getStatusCode();

            return json_decode($response->getBody(), true);
        }catch (\Exception $e) {
            // dd($e->getMessage());
            return array( "status" => "failed", "statusCode" => "400", "error" => $e);
        }
    }

    private function headers(){
        $cred = array(
            'user' => env('SERVICEBOOK_USER', 'joy'),
            'pass' => env('SERVICEBOOK_PWD', 'joy@123')
        );

        $base64 = base64_encode($cred['user'].":".$cred['pass']);
        $header = [
            'Content-Type' => 'application/json',
            "Accept" => "application/json",
            'Authorization' => "Basic " . $base64
        ];

        return $header;
    }

}
