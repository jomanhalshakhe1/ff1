<?php

namespace App\Http\Controllers\Generals;

use App\Http\Controllers\Controller;
use App\Models\Generals\Favourite;
use App\Models\Generals\Manufacturer;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\Maintenance;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class FavouriteController extends Controller
{

    private $msdealid;
    public function __construct()
    {
        $this->msdealid = 9; // M & S services deal Id
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $consumer_id = Auth::guard('driver')->id();

       $list=$this->get_customer_favourites($consumer_id);

       return response()->json([ 'status' => 'success', 'data' => $list ], 200);
    }

    /* Get Customer favourites list based on the id
    * @param $consumer_id
    * return $list
    */
    function get_customer_favourites($consumer_id){
      $dealShare = new DealController();

      $list = ItemMaster::join('item_offers', 'item_offers.item_id', 'item_master.id')
          ->join('favourites', 'favourites.offer_id', 'item_offers.id')
          ->where('favourites.user_id', $consumer_id)
          ->select('item_master.id', 'item_master.title', 'item_master.title_ar', 'item_master.code', 'item_master.company',
              'item_master.dimensions', 'item_master.deal_id', 'item_master.delar_id', 'item_master.thumbnail_url',
              'item_master.volt', 'item_master.ah', 'item_master.size', 'item_master.height', 'item_master.width', 'item_master.status',
              'item_offers.price', 'item_offers.discount', 'item_offers.start_date', 'item_offers.end_date',
              'item_offers.is_notify', 'item_offers.on_site', 'favourites.city_id', 'favourites.location_id')
          ->selectRaw('item_offers.id as offer_id')
          ->selectRaw('favourites.id as favourite_id')
          ->where('favourites.deal_id', '!=' , $this->msdealid)
          ->get()->map(function($row) use($dealShare){
              $pricing = $dealShare->price_logic($row['price'], $row['discount'], $row['deal_id']);
              return array(
                  "id" => $row->id,
                  "title" => $row->title,
                  "title_ar" => $row->title_ar,
                  "code" => $row->code,
                  "company" => $row->company,
                  "price" => $pricing['actual_price'],
                  "final_price" => $pricing['final_price'],
                  "dimensions" => $row->dimensions,
                  "deal_id" => $row->deal_id,
                  "delar_id" => $row->delar_id,
                  "thumbnail_url" => $row->thumbnail_url,
                  "volt" => $row->volt,
                  "ah" => $row->ah,
                  "size" => $row->size,
                  "height" => $row->height,
                  "width" => $row->width,
                  "status" => $row->status,
                  //"distance" => 0,
                  "offer_id" => $row->offer_id,
                  "start_date" => $row->start_date,
                  "end_date" => $row->end_date,
                  "location_id" => $row->location_id,
                  "city_id" => $row->city_id,
                  "is_notify" => $row->is_notify,
                  "on_site" => $row->on_site,
                  "is_favorite" => 1,
                  "favourite_id" => $row->favourite_id,
              );
          })->toArray();

        $msList = Maintenance::join('favourites', function ($join)use($consumer_id){
                  $join->on('maintenances.id', 'favourites.offer_id');
                  $join->where('favourites.deal_id', 9); // M & S Offers
                  $join->where('favourites.user_id', $consumer_id);
              })
              ->join('organizations', 'maintenances.delar_id', 'organizations.id')
              ->select('maintenances.*', 'organizations.thumbnail_url')
              ->selectRaw('organizations.org_name as company')
              ->selectRaw('9 as deal_id')
              ->selectRaw('if(favourites.id is null, 0, 1) as is_favourite')
              ->selectRaw('favourites.id as favourite_id')
              ->orderBy('maintenances.id', 'desc')->get()->toArray();

      if(count($list) > 0)
        array_push($msList, ...$list);
      $res = collect($msList)->sortByDesc('favourite_id')->values()->all();

      return $res;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $where = array(
          'user_id' => Auth::guard('driver')->id(),
          'deal_id' => request()->deal_id,
          'offer_id' => request()->offer_id,
        );
        if(request()->deal_id != 9) // Except for M & S offers
        {
            $where['city_id'] = request()->city_id;
            $where['location_id'] = request()->location_id;
        }

        if(Favourite::where($where)->count() == 0)
            Favourite::insert($where);

        return response()->json([
            'status' => 'success',
            'message' => 'Favoirites Added Successfully',
            'message_ar' => 'تمت إضافة المفضلين بنجاح',
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy()
    {
        $where = array(
            'user_id' => Auth::guard('driver')->id(),
            'deal_id' => request()->deal_id,
            'offer_id' => request()->offer_id,
        );
        if(request()->deal_id != 9) // Except for M & S offers
        {
            $where['city_id'] = request()->city_id;
            $where['location_id'] = request()->location_id;
        }

        Favourite::where($where)->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Favoirites Deleted Successfully',
            'message_ar' => 'تم حذف المفضلات بنجاح',
        ], 200);
    }


    /**
     * Get all customer favourites list for admin
     *
     * @return \Illuminate\Http\Response
     */
    public function get_all_customer_favourites(Request $request)
    {
    
        $pageno = 1; $pagelength = 10;
        $dealShare = new DealController();
 
        $list = ItemMaster::join('item_offers', 'item_offers.item_id', 'item_master.id')
            ->join('favourites', 'favourites.offer_id', 'item_offers.id')
            ->join('drivers', 'favourites.user_id', 'drivers.id');
        if(isset($request->customer_id)){
          $list =$list->where('favourites.user_id', $request->customer_id);
        }




        $list = $list->select('item_master.id', 'item_master.title', 'item_master.title_ar', 'item_master.code', 'item_master.company',
                'item_master.dimensions', 'item_master.deal_id', 'item_master.delar_id', 'item_master.thumbnail_url',
                'item_master.volt', 'item_master.ah', 'item_master.size', 'item_master.height', 'item_master.width', 'item_master.status',
                'item_offers.price', 'item_offers.discount', 'item_offers.start_date', 'item_offers.end_date',
                'item_offers.is_notify', 'item_offers.on_site', 'favourites.city_id', 'favourites.location_id', 'drivers.id as customer_id', 'drivers.first_name', 'drivers.contact_no')
            ->selectRaw('item_offers.id as offer_id');

        $login_type_id = Auth::user()->login_type_id;
        if($login_type_id == 19) // Fleet Company
        {
            $org_id = Auth::user()->org_id;
            $list=$list->join('fleet_drivers','fleet_drivers.driver_id','=','drivers.id')
                  ->where('fleet_drivers.status', '1')
                  ->where('fleet_drivers.fleet_id', $org_id)
                  ->whereNotNull('fleet_drivers.employee_id');
        }    

        $totalrecords = $list->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)){
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }
        $list = $list->orderBy('id', 'desc')
            ->skip( ($pageno-1)*$pagelength )->take($pagelength)->get()->map(function($row) use($dealShare){
                $pricing = $dealShare->price_logic($row['price'], $row['discount'], $row['deal_id']);
                return array(
                    "id" => $row->id,
                    "title" => $row->title,
                    "title_ar" => $row->title_ar,
                    "code" => $row->code,
                    "company" => $row->delar->org_name,
                    "price" => $pricing['actual_price'],
                    "final_price" => $pricing['final_price'],
                    "dimensions" => $row->dimensions,
                    "deal_id" => $row->deal_id,
                    "delar_id" => $row->delar_id,
                    "thumbnail_url" => $row->thumbnail_url,
                    "volt" => $row->volt,
                    "ah" => $row->ah,
                    "size" => $row->size,
                    "height" => $row->height,
                    "width" => $row->width,
                    "status" => $row->status,
                    "offer_id" => $row->offer_id,
                    "start_date" => $row->start_date,
                    "end_date" => $row->end_date,
                    "location_id" => $row->location_id,
                    "city_id" => $row->city_id,
                    "is_notify" => $row->is_notify,
                    "on_site" => $row->on_site,
                    "is_favorite" => 1,
                    'customer_id'=>$row->customer_id,
                    "customer_name" => $row->first_name,
                    "customer_contact" => $row->contact_no,
                );
            });

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;
        return response()->json(['status' => 'success', 'data' => $data], 200);

    }
}
