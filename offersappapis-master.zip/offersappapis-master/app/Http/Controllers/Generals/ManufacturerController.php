<?php

namespace App\Http\Controllers\Generals;

use App\Http\Controllers\Controller;
use App\Models\Generals\Manufacturer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class ManufacturerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $pageno = 1; $pagelength = 10; 
            $totalrecords = Manufacturer::count();
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
                $list = Manufacturer::orderBy('id','desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();
                $data['data'] = $list;
                $data['current_page'] = $pageno;
                $data['total'] = $totalrecords;
                $data['per_page'] = $pagelength;
                return response()->json(['status' => 'success', 'data' => $data], 200);
            }else{
                $list = Manufacturer::where('status', '1')->get();
            }
        }else{
            $list = Manufacturer::where('status', '1')->get();
        }
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    public function active_list()
    {
        // TODO: Active Manufacturer List
        $list = Manufacturer::where('status', '1')->get();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    public function list(Request $request)
    {
        //$list = Manufacturer::all();
        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $pageno = 1; $pagelength = 10; 
            $totalrecords = Manufacturer::count();
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
                $list = Manufacturer::skip( ($pageno-1)*$pagelength )->take($pagelength)->get();
                $data['data'] = $list;
                $data['current_page'] = $pageno;
                $data['total'] = $totalrecords;
                $data['per_page'] = $pagelength;
                return response()->json(['status' => 'success', 'data' => $data], 200);
            }else{
                $list = Manufacturer::all();
            }
        }else{
            $list = Manufacturer::all();
        }
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'title' => 'required|max:100|unique:manufacturers',
            'status' => 'required',
            'thumbnail' => ['required', 'mimes:jpeg,jpg,png', 'max:500' ],
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/manufacturers/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/manufacturers/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('manufacturers/', $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $request['created_at'] = date('Y-m-d H:i:s');
            
            Manufacturer::insert($request->except('thumbnail'));
            return response()->json(['status' => 'success', 'response' => 'Successfully added a Manufacturer'], 200);
        }
        catch(\Exception $e){
            return response()->json(['status' => 'failed', 'response' => 'Failed to add Manufacturer', "error" => $e], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $list = Manufacturer::where('id', $id)->first();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(),[
            'title' => 'required|max:100|unique:manufacturers,title,'.$id,
            'status' => 'required',
            //'thumbnail' => ['required', 'mimes:jpeg,jpg,png', 'max:500' ],
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/manufacturers/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/manufacturers/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('manufacturers/', $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $request['updated_at'] = date('Y-m-d H:i:s');

            Manufacturer::where('id', $id)->update($request->except('thumbnail'));
            return response()->json(['status' => 'success', 'response' => 'Successfully updated a Manufacturer'], 200);
        }
        catch(\Exception $e){
            return response()->json(['status' => 'failed', 'response' => 'Failed to update Manufacturer', "error" => $e], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
