<?php

namespace App\Http\Controllers\Generals;

use App\Http\Controllers\Controller;
use App\Models\Generals\Payout;
use App\Models\Regulatory\Organization;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Models\Accounts\Transaction;


class PayoutController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $pageno = 1; $pagelength = 10;
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        
        $list = Payout::with('company');

        if(isset($request->org_id) && $request->org_id>0){
           $list = $list->where('payment_to',$request->org_id);
        } else if($request->login_type_id!=17 && Auth::user()->login_type_id!=17){
          $list =$list->where('payment_to',Auth::user()->org_id);
        }
        
        $totalrecords =$list->count();

        $list = $list->orderBy('id', 'desc')
            ->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'payment_to'    => ['required'],
                'payment_type'    => ['required'],
                'amount_paid'    => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        DB::enableQueryLog();
        try {
            $request['paid_date'] = date('Y-m-d',strtotime("-1 days"));
            $request['created_at'] = date('Y-m-d H:i:s');
            $request['created_by'] = Auth::id();
            Payout::insert($request->all());

            return response()->json(['status' => 'success', 'response' => 'Payout added successfully' ], 200);
        }
        catch (\Exception $e){
            return response()->json(['status' => 'failed', 'message' => 'Payout add Failed', 'error' => $e,
                "qry" => DB::getQueryLog()], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = Payout::where('id', $id)->where('status', 1)->first();
        return response(['status' => 'success', 'data' => $data ], 200);
    }

    public function payoutinfo_by_org($org_id)
    {
        $data = Payout::where('payment_to', $org_id)->latest()->first();
        return response(['status' => 'success', 'data' => $data ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(),
            [
                'payment_to'    => ['required'],
                'payment_type'    => ['required'],
                'paid_date'    => ['required'],
                'amount_paid'    => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try {
            $request['updated_at'] = date('Y-m-d H:i:s');
            $request['updated_by'] = Auth::id();
            Payout::where('id', $id)->update($request->all());

            return response()->json(['status' => 'success', 'response' => 'Payout updated successfully' ], 200);
        }
        catch (\Exception $e){
            return response()->json(['status' => 'failed', 'message' => 'Payout update Failed', 'error' => $e], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Payout::where('id', $id)->update(['status' => 0]);
        return response()->json(['status' => 'success', 'response' => 'Payout deactivated successfully' ], 200);
    }

    public function payout_limit($id = null) {
        try{

            $orginfo = Organization::where('id', $id)->first();
            if(!$orginfo)
                return response()->json(['status' => 'failed', 'message' => 'Invalid Organization'], 400);

            $paid_date = Payout::where('status', 1)->where('payment_to', $id)->orderBy('id', 'desc')->pluck('paid_date')->first();
            $orginfo['last_paid'] = $paid_date;
            $paid_date = $paid_date ? $paid_date : '2021-10-01';

            $amount_paid = Payout::where('status', 1)
                ->where('payment_to', $id)->where('paid_date', $paid_date)
                ->orderBy('id', 'desc')->pluck('amount_paid')->first();

            $amount_paid = $amount_paid ? $amount_paid : 0;

            $todayDate=date("Y-m-d");
            $toDate = date('Y-m-d', strtotime($todayDate .' -1 day'));


            if($orginfo['company_type'] == 'D') { // Deal Provider
              $totalDealerShare=$this->getDealerPayoutLimit($id, $paid_date, $toDate);
              $orginfo['pay_limit'] =round($totalDealerShare,2);
            }
            else if($orginfo['company_type'] == 'F'){ // partner share

                $totalPartnerShare=$this->getPartnerShareLimit($id, $paid_date, $toDate);
                $orginfo['pay_limit'] = $totalPartnerShare;
            }
            else{
                $paylimit = DB::select("select
                  ROUND(ifnull(sum(
                                   ((price * discount/100) * payment_share.admin_share/ 100) -
                                   (((price * discount/100) * payment_share.admin_share/ 100) * ifnull(c.payment_share,0) / 100)
                               )
                               * (select ifnull(sum(quantity),0) as quantity from redeem_log
                  where redeem_log.transaction_no = transaction_no
                        and cast(redeem_at as date) BETWEEN '".$paid_date."' AND CAST(current_date - 1 AS DATE) ),0), 2) as admin_share
                from transactions as a
                  LEFT JOIN fleet_drivers as b on a.created_by = b.driver_id
                  LEFT JOIN organizations as c on b.fleet_id = c.id
                  join (select * from payment_shares ORDER BY id DESC limit 1) as payment_share
                where a.payment_status = 'Successful' and a.redeem_quantity > 0 and a.status = 1
                      and a.created_at BETWEEN '".$paid_date."' AND CAST(current_date - 1 AS DATE)");

                $orginfo['pay_limit'] = $paylimit[0]->admin_share - $amount_paid;
            }

            return response()->json(['status' => 'success', 'data' => $orginfo], 200);
        } catch (\Exception $e){
            return response()->json(['status' => 'failed', 'message' => 'Payout Limit Wrong', "error" => $e->getMessage()], 400);
        }
    }


        /* Get dealer shares payout information
    *@param $id
    *
    *return $id, $paid_date, $toDate
    */

    function getDealerPayoutLimit($id, $paid_date, $toDate){
       $list = Transaction::select('transactions.*','redeem_log.redeem_at','redeem_log.quantity as redeemquantity','bills.joy_share','bills.pg_fee','bills.pg_fee','bills.service_cost','bills.filter_cost','bills.partner_discount','bills.pg_share','bills.vat')
          ->join('bills', 'bills.transaction_no','=','transactions.transaction_no')
          ->join('item_master', 'item_master.id','=','transactions.item_id')
          ->join('redeem_log', 'redeem_log.transaction_no','=','transactions.transaction_no')
          ->where('item_master.delar_id', $id)
          ->where('transactions.payment_status','Successful');
         
        
        $list = $list->where('redeem_log.redeem_at','>=',$paid_date." 00:00:00");
        $list = $list->where('redeem_log.redeem_at','<=',$toDate." 23:59:59");


        $list = $list->where('transactions.redeem_quantity','>','0');       
        $totalSales = $list->count();

        $totalDealerShare=0;
        if($totalSales>0){
         $list=$list->orderBy('redeem_log.id', 'desc')->get();
          foreach($list as $row){
              $discountedShareJoy = $row->price * $row->discount / 100;
              $basePriceAfterDiscount = $row->price - $discountedShareJoy;
             
              $customerDiscountAmount = $discountedShareJoy * (100 - $row->joy_share) / 100; 
              $JOYshareRemaingAfterCustomerShare = $discountedShareJoy - $customerDiscountAmount;
              $priceAfterCustomerDiscount = $basePriceAfterDiscount + $JOYshareRemaingAfterCustomerShare;

   
               $fleetExtraDiscount = $JOYshareRemaingAfterCustomerShare * $row->partner_discount / 100;
               $PriceWithFleetExtraDiscount = $priceAfterCustomerDiscount - $fleetExtraDiscount;
              
              $savings = $row->price - $PriceWithFleetExtraDiscount;
              $payableAmount = $PriceWithFleetExtraDiscount + $row->service_cost + $row->filter_cost;

              $paymentGatewayShare = $payableAmount * $row->pg_share / 100;
              
              $paymentGatewayAmount = $row->pg_fee + ((100-$row->discount)* $paymentGatewayShare / 100);
              
              $delarShareWithVat = ($row->price - $discountedShareJoy - $paymentGatewayAmount) + $row->service_cost + $row->filter_cost;

              $delarShare = $delarShareWithVat - ($delarShareWithVat - $delarShareWithVat/ (1 + $row->vat/100));

             //$totalWithVat=$totalWithVat+($delarShareWithVat*$row->redeemquantity);

             $totalDealerShare=$totalDealerShare+($delarShare*$row->redeemquantity);
            
          }
      }
      return $totalDealerShare;
    }

    /* Get partner shares payout information
    *@param $id
    *
    *return $id, $paid_date, $toDate
    */

    function getPartnerShareLimit($id, $paid_date, $toDate){
      $list = Transaction::select('transactions.*','bills.joy_share','bills.partner_share','organizations.org_name','redeem_log.redeem_at','redeem_log.quantity as redeemquantity')
       ->join('organizations', 'organizations.id','=','transactions.fleet_id')
       ->whereNotNull('transactions.fleet_id')
       ->where('bills.partner_share','>',0)
       ->join('bills', 'bills.transaction_no','=','transactions.transaction_no')
       ->join('redeem_log', 'redeem_log.transaction_no','=','transactions.transaction_no')
       ->with('item', 'offer', 'item.delar', 'item.deal');
      
       $list =$list->where('transactions.fleet_id', $id);               

       $list = $list->where('redeem_log.redeem_at','>=',$paid_date." 00:00:00");
       $list = $list->where('redeem_log.redeem_at','<=',$toDate." 23:59:59");
       $list = $list->where('transactions.redeem_quantity','>','0');     
       $totalrecords = $list->orderBy('redeem_log.id', 'desc')->count();
       $list = $list->orderBy('redeem_log.id', 'desc')->get();

        $totalPartnerShare=0;
        if($totalrecords>0){
          $list = collect($list);
          foreach($list as $row)
          {
              $discountedShareJoy = $row->price * $row->discount / 100;
              $customerShare=$discountedShareJoy*(100-$row->joy_share)/100;
              $joyShare=$discountedShareJoy-$customerShare;
              $fleetShare=$joyShare*$row->partner_share/100;
              $totalPartnerShare=$totalPartnerShare+($fleetShare*$row->redeemquantity);   
          } 
        }
        return $totalPartnerShare;
    }
}
