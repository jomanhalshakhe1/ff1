<?php

namespace App\Http\Controllers\Generals;

use App\Http\Controllers\Controller;
use App\Models\Generals\Lookup;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
 

class AppNavigationURLsController extends Controller
{
    // Variable declarations
    private $group_id;

    /*Default constructor
    *
    * @param CouponsService,CouponsLogsService
    *
    */
    public function __construct() {
        $this->group_id = 8; // App navigation Url lookup group id
    }

    /**
     * Display a all app navigation urls listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        try{
            $pageno = 1; $pagelength = 10;
            $totalrecords = Lookup::where('group_id', $this->group_id)->count();
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
            }

            $list = Lookup::where('group_id', $this->group_id)->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();
            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;

            return response()->json(['status' => 'success', 'data' => $data], 200);
        } catch(\Exception $e){
            return response()->json(['Status' => 'failed', 'Response' => $e->getMessage()], 400);
        }
    }

    /**
     * Access: Admin Portal, Partner app, Customer App
     * Prefix: api, customer, dealer
     * Get all active app navigation urls listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function activeList()
    {
        try{
           $data = Lookup::where('group_id', $this->group_id)->where('id','!=',52)->where('status' , 1)->get();

           return response()->json(['status' => 'success', 'data' => $data], 200);
        } catch(\Exception $e){
            return response()->json(['Status' => 'failed', 'Response' => $e->getMessage()], 400);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $validator = Validator::make($request->all(),
            [
                'title'   => ['required'],
                'status'=>['required'],   
                 
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $entityId = Lookup::insertGetId(array(
                'entity_name' => $request['title'],
                'group_id' => $this->group_id,
                'status' => $request['status'],
            ));
            Lookup::where('id', $entityId)->update(['code' => $entityId]);

            return response()->json(['status'=>'success', 'message'=> 'App navigation URL details created successfully'], 200);
        }
        catch (\Exception $e)
        {
             return response()->json(['status'=>'failed', 'message'=> 'Failed to create new app navigation URL details','error'=>$e->getMessage()], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        try {
          $data = Lookup::where('id',$id)->first();
          return response()->json(['status'=>'success', 'data' => $data], 200);
        } catch (\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Failed to get app navigation URL details', "error" => $e->getMessage()], 400);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(),
            [
                'title'   => ['required'],
                'status'=>['required'],       
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            Lookup::where('id', $request['id'])
                ->update([
                   'entity_name' => $request['title'],
                   'status' => $request['status'],
                ]);

            return response()->json(['status'=>'success', 'message'=> 'App navigation URL details created successfully'], 200);
        }
        catch (\Exception $e)
        {
             return response()->json(['status'=>'failed', 'message'=> 'Failed to update app navigation URL details','error'=>$e->getMessage()], 400);
        }       //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
