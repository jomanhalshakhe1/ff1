<?php

namespace App\Http\Controllers\Generals;

use App\Http\Controllers\Controller;
use App\Models\Generals\Exchange;
use App\Models\Regulatory\Organization;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class ExchangeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $pageno = 1; $pagelength = 10;
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $totalrecords = Exchange::count();
        $list = Exchange::with('company');

        if(Auth::user()->login_type_id != 17) // Delar or partner
           $list = $list->where('payment_to', Auth::user()->org_id);

        $list = $list->orderBy('id', 'desc')
            ->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'payment_to'    => ['required'],
                'payment_type'    => ['required'],
                'paid_date'    => ['required'],
                'amount_paid'    => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try {
            $request['created_at'] = date('Y-m-d H:i:s');
            $request['created_by'] = Auth::id();
            Exchange::insert($request->all());

            return response()->json(['status' => 'success', 'response' => 'Exchange added successfully' ], 200);
        }
        catch (\Exception $e){
            return response()->json(['status' => 'failed', 'message' => 'Exchange add Failed', 'error' => $e ], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = Exchange::where('id', $id)->where('status', 1)->first();
        return response(['status' => 'success', 'data' => $data ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(),
            [
                'payment_to'    => ['required'],
                'payment_type'    => ['required'],
                'paid_date'    => ['required'],
                'amount_paid'    => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try {
            $request['updated_at'] = date('Y-m-d H:i:s');
            $request['updated_by'] = Auth::id();
            Exchange::where('id', $id)->update($request->all());

            return response()->json(['status' => 'success', 'response' => 'Exchange updated successfully' ], 200);
        }
        catch (\Exception $e){
            return response()->json(['status' => 'failed', 'message' => 'Exchange update Failed'], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Exchange::where('id', $id)->update(['status' => 0]);
        return response()->json(['status' => 'success', 'response' => 'Exchange deactivated successfully' ], 200);
    }

    public function exchanges_for($exchanges_for){
        $list = Organization::select('id', 'org_name', 'country_code', 'phone', 'email')
            ->where('company_type', $exchanges_for)->where('status', 1)->get();

        return response()->json(['status' => 'success', 'data' => $list ], 200);
    }

}
