<?php

namespace App\Http\Controllers\Generals;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Models\Accounts\Transaction;
use App\Models\Accounts\Driver;
use PDF;
use Illuminate\Support\Facades\DB;
use Salla\ZATCA\GenerateQrCode;
use Salla\ZATCA\Tags\InvoiceDate;
use Salla\ZATCA\Tags\InvoiceTaxAmount;
use Salla\ZATCA\Tags\InvoiceTotalAmount;
use Salla\ZATCA\Tags\Seller;
use Salla\ZATCA\Tags\TaxNumber;
use App\Models\Accounts\ConsumerCredit;
use App\Models\Accounts\ConsumerGroup;
use App\Models\Accounts\Credit;
use App\Models\Accounts\Reset;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use App\Models\Generals\EmailFormates;
use App\Http\Controllers\Generals\DealController;
use App\Models\Accounts\User;
use App\Http\Controllers\GeneralController;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use App\Models\Accounts\TransactionDetail;
use App\Models\Regulatory\Organization;
class EmailController extends Controller
{

    /**
     * Retrieve all available email formates
     *
     * @return \Illuminate\Http\Response
     */

     function email_formates_list(Request $request){
         try{
            // read notifications which are not read
            $pageno = 1; $pagelength = 10;
            $list = EmailFormates::orderBy('id', 'desc');
            $totalrecords = $list->count();
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
            }
            $list = $list->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status'=>'success', 'data' => $data], 200);

        } catch (\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Email formate failed', "error" => $e->getMessage()], 400);
        }
    }


     /**
     * Get notification format details 
     *
     *  @param  $id
     * @return \Illuminate\Http\Response
     */

    function getEmailFormateData($id){
        try
        {
          $data = EmailFormates::where('id',$id)->first();
          return response()->json(['status'=>'success', 'data' => $data], 200);
        } catch (\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Get email formate failed', "error" => $e->getMessage()], 400);
        }
    }


    /**
     * Modify email notification format details 
     *
     * @param  \Illuminate\Http\Request  $request
     * * @param  $id
     * @return \Illuminate\Http\Response
     */ 
    public function updateEmailFormate(Request $request, $id)
    {
        $validator = Validator::make($request->all(),
            [
                'subject'    => ['required'],
                'subject_ar'   => ['required'],
                'message'    => ['required'],
                'message_ar'   => ['required'],
                'isinvoice'=>['required'],
                'status'   => ['required']
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $request['updated_at'] = date('Y-m-d H:i:s');
        EmailFormates::where('id', $id)->update($request->all());
            return response()->json(['status'=>'success', 'message'=> 'Email Formate Details Updated Successfully'], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Email Formate Updation Failed'], 400);
        }
    }

  


    /**
     * When admin or dealer refunded consumer's purchased offer
     *
     * @param  \Illuminate\Http\Request  $request
     * * @param  $transaction_no, $quantity, $amount
     */ 

    function sendRefundAmountNotification($transaction_no, $quantity, $amount, $isNotifyToConsumer, $isnotifyToAdmin, $isnotifyToTechnician){

        $transaction = Transaction::where('transaction_no', $transaction_no)->first();
        $consumerData = Driver::where('id', $transaction['created_by'])->where('is_email_verified', 1)->first();
        if(empty($consumerData)){
            return "No customer details found";
        }

        $tranInfo=$this->getTransactionDetails($transaction);


        // Send Email Notification to Consumer

        $replaceArray=['name'=>$consumerData->first_name, 'amount'=>$amount, 'quantity'=>$quantity, 'transaction_no'=>$transaction_no,'preferred_language'=>$consumerData->preferred_language,'to_email'=>$consumerData->email, 'price'=>$tranInfo['price'], 'discount'=>$tranInfo['discount']];
       
        $this->sendEmail($replaceArray, '2');
        //End Send Email Notification to Consumer

        // Send Email Notification to Partner
        $itemData = ItemMaster::where('id', $transaction['item_id'])->select('title','title_ar','delar_id')->first();

        $orginization_id =$itemData['delar_id'];

        $dealerData=User::where('org_id', $orginization_id)
                ->where('is_email_verified', 1)
                ->orderBy('id', 'asc')->first();

        if($dealerData){
            $replacePartnerArray=['name'=>$dealerData->first_name,'consumer_name'=>$consumerData->first_name, 'amount'=>$amount, 'quantity'=>$quantity, 'transaction_no'=>$transaction_no, 'preferred_language'=>$dealerData->preferred_language,'to_email'=>$dealerData->email, 'price'=>$tranInfo['price'], 'discount'=>$tranInfo['discount']];

             $this->sendEmail($replacePartnerArray, '11');
        }
        
         // Send Email Notification to Partner
    } 

     /**
     * When admin or dealer did some adjustments on consumer's purchased offer
     *
     * @param  \Illuminate\Http\Request  $request
     * * @param  $transaction_no, $amount
     */ 


    function sendAdjustAmountNotification($transaction_no, $amount, $isNotifyToConsumer, $isnotifyToAdmin, $isnotifyToTechnician){

        $transaction = Transaction::where('transaction_no', $transaction_no)->first();
        $consumerData = Driver::where('id', $transaction['created_by'])->where('is_email_verified', 1)->first();
        if(empty($consumerData)){
            return "No customer details found";
        }

        $tranInfo=$this->getTransactionDetails($transaction);

        // Send Email Notification to Consumer

        $replaceArray=['name'=>$consumerData->first_name, 'amount'=>$amount, 'transaction_no'=>$transaction_no,'preferred_language'=>$consumerData->preferred_language,'to_email'=>$consumerData->email, 'price'=>$tranInfo['price'], 'discount'=>$tranInfo['discount']];
        $this->sendEmail($replaceArray, '3');


        // Send Email Notification to Partner
        $itemData = ItemMaster::where('id', $transaction['item_id'])->select('title','title_ar','delar_id')->first();

        $orginization_id =$itemData['delar_id'];
          
        $dealerData=User::where('org_id', $orginization_id)
                ->where('is_email_verified', 1)
                ->orderBy('id', 'asc')->first();

         if($dealerData){
            $replacePartnerArray=['name'=>$dealerData->first_name,'consumer_name'=>$consumerData->first_name, 'amount'=>$amount, 'transaction_no'=>$transaction_no, 'preferred_language'=>$dealerData->preferred_language,'to_email'=>$dealerData->email, 'price'=>$tranInfo['price'], 'discount'=>$tranInfo['discount']];

             $this->sendEmail($replacePartnerArray, '10');
         }
    
         // Send Email Notification to Partner
     }

     /**
     * When a consumer purchased any offer
     *
     * @param  \Illuminate\Http\Request  $request
     * * @param  $transaction_no, $amount
     */ 


    function sendPurchasedOfferNotification($transaction_no, $isNotifyToConsumer, $isnotifyToAdmin, $isnotifyToTechnician){

        $transaction = Transaction::where('transaction_no', $transaction_no)->first();
        $consumerData = Driver::where('id', $transaction['created_by'])->where('is_email_verified', 1)->first();
        if(empty($consumerData)){
            return "No customer details found";
        }

         $tranInfo=$this->getTransactionDetails($transaction);

        $replaceArray=['name'=>$consumerData->first_name, 'amount'=>'', 'transaction_no'=>$transaction_no,'preferred_language'=>$consumerData->preferred_language,'to_email'=>$consumerData->email, 'price'=>$tranInfo['price'], 'discount'=>$tranInfo['discount']];
        $this->sendEmail($replaceArray, '4');


         // Send Email Notification to Partner

        $itemoffer = ItemOffer::where('id', $transaction['offer_id'])->first();

        if($itemoffer->on_site=='1' || $itemoffer->is_notify=='1'){ 

            $itemData = ItemMaster::where('id', $transaction['item_id'])->select('title','title_ar','delar_id')->first();

            $orginization_id =$itemData['delar_id'];          
            
            $dealerData=User::where('org_id', $orginization_id)
                    ->where('is_email_verified', 1)
                    ->orderBy('id', 'asc')->first();

            if($dealerData){
                $replacePartnerArray=['name'=>$dealerData->first_name,'consumer_name'=>$consumerData->first_name, 'transaction_no'=>$transaction_no, 'preferred_language'=>$dealerData->preferred_language,'to_email'=>$dealerData->email, 'price'=>$tranInfo['price'], 'discount'=>$tranInfo['discount']];

                $this->sendEmail($replacePartnerArray, '12');

                if($itemoffer->is_notify=='1'){
                    $this->sendEmail($replacePartnerArray, '13');
                }
            }
           
         }

         // Send Email Notification to Partner
    }


    /**
     * When a consumer redeemed purchased any offer
     *
     * @param  \Illuminate\Http\Request  $request
     * * @param  $transaction_no, $amount
     */ 
    function sendRedeemOfferNotification($transaction_no, $quantity, $isNotifyToConsumer, $isnotifyToAdmin, $isnotifyToTechnician){

        $transaction = Transaction::where('transaction_no', $transaction_no)->first();
        $consumerData = Driver::where('id', $transaction['created_by'])->where('is_email_verified', 1)->first();
        if(empty($consumerData)){
            return "No customer details found";
        }
        $tranInfo=$this->getTransactionDetails($transaction);

        $replaceArray=['name'=>$consumerData->first_name, 'quantity'=>$quantity, 'transaction_no'=>$transaction_no,'preferred_language'=>$consumerData->preferred_language,'to_email'=>$consumerData->email, 'price'=>$tranInfo['price'], 'discount'=>$tranInfo['discount']];
        $this->sendEmail($replaceArray, '5');

          // Send Email Notification to Partner
        $itemData = ItemMaster::where('id', $transaction['item_id'])->select('title','title_ar','delar_id')->first();

        $orginization_id =$itemData['delar_id'];
        
        // Send Email Notification to Partner        
        $dealerData=User::where('org_id', $orginization_id)
                ->where('is_email_verified', 1)
                ->orderBy('id', 'asc')->first();

        if($dealerData){

            $replacePartnerArray=['name'=>$dealerData->first_name,'consumer_name'=>$consumerData->first_name, 'quantity'=>$quantity, 'transaction_no'=>$transaction_no, 'preferred_language'=>$dealerData->preferred_language,'to_email'=>$dealerData->email, 'price'=>$tranInfo['price'], 'discount'=>$tranInfo['discount']];

             $this->sendEmail($replacePartnerArray, '16');
        }  
        
    }



     /**
     * When a consumer Send his/her current location send notification to partner
     *
     * @param  \Illuminate\Http\Request  $request
     * * @param  $transaction_no, $amount
     */ 
    function sendConsumerCurrentLocationNotification($transaction_no){

        $transaction = Transaction::where('transaction_no', $transaction_no)->first();
        $consumerData = Driver::where('id', $transaction['created_by'])->where('is_email_verified', 1)->first();
        if(empty($consumerData)){
            return "No customer details found";
        }
        $tranInfo=$this->getTransactionDetails($transaction);

        // Send Email Notification to Partner
        $itemData = ItemMaster::where('id', $transaction['item_id'])->select('title','title_ar','delar_id')->first();

        $orginization_id =$itemData['delar_id'];
        
        // Send Email Notification to Partner
        $dealerData=User::where('org_id', $orginization_id)
                ->where('is_email_verified', 1)
                ->orderBy('id', 'asc')->first();
        if($dealerData){
            $replacePartnerArray=['name'=>$dealerData->first_name,'consumer_name'=>$consumerData->first_name, 'transaction_no'=>$transaction_no, 'preferred_language'=>$dealerData->preferred_language,'to_email'=>$dealerData->email, 'price'=>$tranInfo['price'], 'discount'=>$tranInfo['discount']];

             $this->sendEmail($replacePartnerArray, '15');
         }  
    }


     /**
     * When technician or admin approve or disapprove offer availablity status to admin
     *
     * @param  \Illuminate\Http\Request  $request
     * * @param  $transaction_no, $amount
     */ 
    function sendOfferAvailabilityStatus($transaction_no, $is_available){

        $transaction = Transaction::where('transaction_no', $transaction_no)->first();
        $consumerData = Driver::where('id', $transaction['created_by'])->where('is_email_verified', 1)->first();
        if(empty($consumerData)){
            return "No customer details found";
        }
        $tranInfo=$this->getTransactionDetails($transaction);

        // Send Email Notification to Partner
        $itemData = ItemMaster::where('id', $transaction['item_id'])->select('title','title_ar','delar_id')->first();

        $orginization_id =$itemData['delar_id'];

        $dealerData=User::where('org_id', $orginization_id)
                ->where('is_email_verified', 1)
                ->orderBy('id', 'asc')->first();

         if($dealerData){
            $availilityStatus='Available';
            if($is_available=='2'){
                $availilityStatus='Cancelled';
            } else if($is_available=='0'){
                $availilityStatus='Rejected';
            }

            $replacePartnerArray=['name'=>$dealerData->first_name, 'consumer_name'=>$consumerData->first_name, 'transaction_no'=>$transaction_no, 'preferred_language'=>$dealerData->preferred_language,'to_email'=>$dealerData->email, 'price'=>$tranInfo['price'], 'discount'=>$tranInfo['discount'], 'availility_status'=>$availilityStatus];

             $this->sendEmail($replacePartnerArray, '14');
         }  
    }




      /**
     * Common Message for activation registration and change password
     *
     * @param  \Illuminate\Http\Request  $request
     * * @param  $transaction_no, $amount
     */ 
    function sendEmaiNotification($emailId, $name, $otp, $userType, $templateId){

        $userData = Driver::where('email', $emailId)->first();
        if($userType=='User'){
          $userData = User::where('email', $emailId)->first();
        }

        if(empty($userData)){
            return "User informattion not found";
        }

        $replaceArray=['name'=>$name, 'otp'=>$otp, 'preferred_language'=>$userData->preferred_language, 'to_email'=>$emailId];
        $this->sendEmail($replaceArray, $templateId); 
    }

   function sendEmail($replaymentVarArray, $id){
        try{
            if(env('APP_EMAIL')=='production') {
                $emailFormate = EmailFormates::where('id',$id)->where('status','1')->first();
                if(!empty($emailFormate)){
                    $msg=$emailFormate->message;
                    $subject=$emailFormate->subject;
                    if($replaymentVarArray['preferred_language']=='ar'){
                        $msg=$emailFormate->message_ar;
                        $subject=$emailFormate->subject_ar;
                    }

                    $html= $this->replaceCommonVaribles($msg, $replaymentVarArray);

                    if($replaymentVarArray['to_email']!='') { 
                      
                        $to_email=$replaymentVarArray['to_email'];

                        $html= $this->replaceCommonVaribles($msg, $replaymentVarArray);
                        $subjectMsg= $this->replaceCommonVaribles($subject, $replaymentVarArray);
                        
                        $data = array('name'=>"Admin",'email'=>$to_email,'body'=>$html);
                        
                        if(!$emailFormate->isinvoice){
                            
                            Mail :: send('mail',$data,function($message) use ($to_email, $subjectMsg)
                            {
                                $message->to($to_email)
                                ->subject('JOY - '.$subjectMsg.'');
                            });

                        } else {
                             /* File attachment code in email */
                            $files = $this->createInvoicePdf($replaymentVarArray['transaction_no']);

                            Mail :: send('mail',$data,function($message) use ($to_email, $subjectMsg, $files)
                            {
                                $message->to($to_email)
                                ->subject('JOY - '.$subjectMsg.'');

                               $message->attach($files);
                            });

                            unlink($files);
                            /* End  File attachment code in email */
                        }
                    }
                }
            }

        } catch (\Exception $e) {
            // return response()->json(['status'=>'failed', 'message'=> 'Semd mail failed', "error" => $e->getMessage() ], 400);

        }
    }

    /**
     * Replace all variables with data using array
     * @param  $msg, $replaymentVarArray
     * @return $msg
     */

    function replaceCommonVaribles($msg, $replaymentVarArray){

        if(array_key_exists("name", $replaymentVarArray)) {
            $msg = str_replace("{name}", $replaymentVarArray['name'], $msg);
        } 

        if(array_key_exists("amount", $replaymentVarArray)) {
            $msg = str_replace("{amount}", $replaymentVarArray['amount'], $msg);
        } 

        if(array_key_exists("quantity", $replaymentVarArray)) {
            $msg = str_replace("{quantity}", $replaymentVarArray['quantity'], $msg);
        } 

        if(array_key_exists("transaction_no", $replaymentVarArray)) {
            $msg = str_replace("{transaction_no}", $replaymentVarArray['transaction_no'], $msg);
        } 

         if(array_key_exists("price", $replaymentVarArray)) {
            $msg = str_replace("{price}", $replaymentVarArray['price'], $msg); 
        } 

        if(array_key_exists("discount", $replaymentVarArray)) {
            $msg = str_replace("{discount}", $replaymentVarArray['discount'], $msg);
        } 

        if(array_key_exists("otp", $replaymentVarArray)) {
            $msg = str_replace("{otp}", $replaymentVarArray['otp'], $msg);
        } 
        
        if(array_key_exists("consumer_name", $replaymentVarArray)) {
            $msg = str_replace("{consumer_name}", $replaymentVarArray['consumer_name'], $msg);
        } 

        if(array_key_exists("availility_status", $replaymentVarArray)) {
            $msg = str_replace("{status}", $replaymentVarArray['availility_status'], $msg);
        } 

        return $msg;           
    }

    /**
     * Get transaction final prices using transaction data
     * @param $transactionData
     * @return $arr
     */
    function getTransactionDetails($transactionData){
        $dealShare = new DealController();
        $pricing = $dealShare->bill_price_logic($transactionData['transaction_no']);
        $finalPrice = $pricing['final_price'];
        $discountAmount = $transactionData['price'] - $finalPrice;
        $actualDiscount=round(($transactionData['price']*$transactionData['discount']/100),2);
        $discount=number_format(($discountAmount/$transactionData['price'])*100,0);
        return array('price'=>$finalPrice, 'discount'=>$discount);
    }


    /**
     * When consumer requested for mobile number changing then this function will call
     *
     * @param  \Illuminate\Http\Request  $request
     * * @param  $emailId, $name and $otp
     */ 
    public function sendMobileNumberChangeMail($EmailId, $name, $otp){
        //Send email notification if server is production
        if(env('APP_EMAIL')=='production') {
            $html='<table align="center" style="width:100%">
                <tbody>
                    <tr>
                        <td>
                        <p>Dear '.$name.',<br />
                        Thank you for your request of change mobile number. Your one time Joy OTP : '.$otp.'</p>
                        <p>Regards,<br />
                        Joy Team</p>
                        </td>
                    </tr>
                </tbody>
            </table>
            ';  
            if($EmailId!=''){
                $to_email=$EmailId;
                $name='Joy';
                $sub="Change mobile number request";
                
                $data = array('name'=>"Admin",'email'=>$to_email,'body'=>$html);

                Mail :: send('mail',$data,function($message) use ($to_email,$sub)
                {
                    $message->to($to_email)
                    ->subject('JOY - '.$sub.'');
                });
            }
        }
    }


    /** 
     * Send final invoice to customer
     * @param $transaction_no
     */
    function sendFinalInvoice($transaction_no){

        //Send email notification if server is production
        if(env('APP_OTP')=='production') {

            $transaction = Transaction::where('transaction_no', $transaction_no)->first();

            $redeemQuantity=$transaction['redeem_quantity'];
            $revicedQuantity=$transaction['revised_quantity'];
            $purchasedQuantity=$transaction['quantity'];
            if($purchasedQuantity==$redeemQuantity+$revicedQuantity){

                $consumerData = Driver::where('id', $transaction['created_by'])->where('is_email_verified', 1)->first();
                if(empty($consumerData)){
                    return "No customer details found";
                }
                
                $html='<table align="center" style="width:100%">
                    <tbody>
                        <tr>
                            <td>
                             <p>Dear '.$consumerData->first_name.',<br />Here is your invoice for transaction number : '.$transaction_no.'. Please check attached invoice</p>
                            <p>Regards,<br />
                            Joy Team</p>
                            </td>
                        </tr>
                    </tbody>
                </table>';  
                    
                $to_email=$consumerData->email;

                if($consumerData->email!='') { 
                    $name='Joy';
                    $sub="Inovice for purchased deal amount for transaction number : ".$transaction_no;        
                    $data = array('email'=>$to_email,'body'=>$html);

                    /* File attachment code in email */

                    $files = $this->createInvoicePdf($transaction_no);

                    Mail :: send('mail',$data,function($message) use ($to_email,$sub, $files)
                    {
                        $message->to($to_email)
                        ->subject('JOY - '.$sub.'');

                       $message->attach($files);
                    });

                    unlink($files);
                }  
            }
        }
    }

    // Send Email Verification

    public function send_activation_mail($EmailId, $name){
        //Send email notification
        if(env('APP_OTP')=='production') {
            $otp = mt_rand(100000, 999999);

            Reset::where('email', $EmailId)->where('user_type', 'User')->delete();

            DB::table('password_resets')->insert([
                'email' => $EmailId,
                'token' =>$otp ,
                'user_type' =>'User' ,
                'created_at' => date("Y-m-d H:i:s")
            ]);

            $html='<table align="center" style="width:100%">
                <tbody>
                    <tr>
                        <td>
                        &nbsp;
                        <p>Dear '.$name.',<br />
                        Thank you for creating account with JOY. Please click here to activate your account.</p>
                        <p>Your one time Joy OTP : '.$otp.'</p>
                        <p>Regards,<br />
                        Joy Team</p>
                        </td>
                    </tr>
                </tbody>
            </table>';  
            
            $to_email=$EmailId;
            $name='Joy';
            $sub="Activate Your Account";
            $data = array('email'=>$to_email,'body'=>$html);
            Mail :: send('mail',$data,function($message) use ($to_email, $sub)
            {
                $message->to($to_email)
                ->subject('JOY - '.$sub.'');
            });
        }
    }


    //End send email verification

    // Forgot Password

    public function send_reset_link($EmailId, $user){
        //Send email notification
        if(env('APP_EMAIL')=='production') {
            $otp = mt_rand(100000, 999999);

            Reset::where('email', $EmailId)->where('user_type', 'User')->delete();

            DB::table('password_resets')->insert([
                'email' => $EmailId,
                'token' =>$otp ,
                'user_type' =>'User' ,
                'created_at' => date("Y-m-d H:i:s")
            ]);

            $html='<table align="center" style="width:100%">
                <tbody>
                    <tr>
                        <td>
                        &nbsp;
                        <p>Dear '.$user->first_name." ".$user->last_name.',<br />
                        You recently requested to reset your password for your joy account. Your one time Joy OTP is: '.$otp.'.</strong>.</p>
                        <p>Regards,<br />
                        Joy Team</p>
                        </td>
                    </tr>
                </tbody>
            </table>';  
            
            $to_email=$EmailId;
            $name='Joy';
            $sub="Reset your passwor";
            
            $data = array('name'=>"Admin",'email'=>$to_email,'body'=>$html);

            Mail :: send('mail',$data,function($message) use ($to_email,$sub)
            {
                $message->to($to_email)
                ->subject('JOY - '.$sub.'');
            });
        }
    }
    //End forgot password


    // Partner APP Registration
    function sendTechnicianRegistration($EmailId, $name){
        //Send email notification
        if(env('APP_EMAIL')=='production') {
            $html='<table align="center" style="width:100%">
                <tbody>
                    <tr>
                        <td>
                        &nbsp;
                        <p>Dear '.$name.',<br />
                        Thank you for registering with JOY. You have successfully created your account with Joy</p>
                        <p>Regards,<br />
                        Joy Team</p>
                        </td>
                    </tr>
                </tbody>
            </table>
            ';  
                
            $to_email=$EmailId;
            $sub="Account creation confirmation mail";
            $data = array('email'=>$to_email,'body'=>$html);

            Mail :: send('mail',$data,function($message) use ($to_email, $sub)
            {
                $message->to($to_email)
                ->subject('JOY - '.$sub.'');
            
            });
        }
    }

    // Partner App Registration
    function createInvoicePdf($trans_id){
        $data = Transaction::where('transaction_no', $trans_id)
            ->with('item', 'item.offer', 'item.delar', 'item.delar.location', 'driver', 'trans_location','payment_details', 'adjustment')
            ->first();

        $admin_vat_no =Organization::where('company_type','A')->pluck('vat_no')->first();

        $dealShare = new DealController();
        $pricing = $dealShare->bill_price_logic($data['transaction_no']);
        $data['final_price'] = $pricing['final_price'];
        $data['vat'] = $pricing['vat'];
        $data['vat_amount'] =  $pricing['vat_amount'];
        $data['item_price'] = $pricing['item_price'];
        $data['discount_amount'] = $pricing['discount_amount'];
        $data['scan_url'] = url('/download_public_invoice/'. $trans_id);

        $data['filter_price'] = $pricing['filter_cost'];
        $data['service_cost'] = $pricing['service_cost'];

        // data:image/png;base64, .........
        $displayQRCodeAsBase64 = GenerateQrCode::fromArray([
            new Seller('Innvohub'), // seller name
            new TaxNumber($admin_vat_no), // seller tax number
            new InvoiceDate($data['created_at']), // invoice date as Zulu ISO8601 @see https://en.wikipedia.org/wiki/ISO_8601
            new InvoiceTotalAmount($data['final_price']), // invoice total amount
            new InvoiceTaxAmount(round($data['vat_amount'], 2)) // invoice tax amount
            // TODO :: Support others tags
        ])->render();

        $data['qr_image'] = $displayQRCodeAsBase64;
        $data['refund_credits']=0;
        if($data['revised_quantity']>0){
            $list['refund_credits'] = $pricing['refund_payment']['final_price'];
            $data['refund_no'] = 'R-'.$data['invoice_no'];

            $createdDate = Credit::where('transaction_no', $trans_id)->orderBy('created_at', 'DESC')->pluck('created_at')->first();
            $displayQRCodeAsBase64 = GenerateQrCode::fromArray([
                new Seller('Innvohub'), // seller name
                new TaxNumber($admin_vat_no), // seller tax number
                new InvoiceDate($createdDate), // invoice date as Zulu ISO8601 @see https://en.wikipedia.org/wiki/ISO_8601
                new InvoiceTotalAmount($pricing['refund_payment']['final_price']), // invoice total amount
                new InvoiceTaxAmount($pricing['refund_payment']['vat_amount']) // invoice tax amount
                // TODO :: Support others tags
            ])->render();

            $data['qr_image_refund'] = $displayQRCodeAsBase64;
        }

        $fileName =  'joy_invoice_'.$trans_id.'.pdf';
        if (!is_dir('uploads/invoice/')) {
           mkdir("uploads/invoice/", 0777); 
        }  
        
        $pdf = PDF::loadView('invoice', compact('data','admin_vat_no'));
        $path = public_path() . '/uploads/invoice/'.$fileName;
        $pdf->save($path);
        return $path;
    }
}
