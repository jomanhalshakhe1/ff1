<?php

namespace App\Http\Controllers\Generals;

use App\Http\Controllers\Controller;
use App\Models\Accounts\Credit;
use App\Models\Accounts\GroupConsumer;
use App\Models\Generals\Notifier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
//use Carbon/Carbon;
use Illuminate\Support\Facades\Mail;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use App\Models\Accounts\Transaction;
use App\Models\Accounts\Driver;
use App\Models\Accounts\User;
use App\Models\Generals\Notification;
use App\Models\Generals\Device;
use App\Models\Accounts\Payment;
use App\Models\Generals\NotificationLog;
use App\Models\Inventory\DealVehicle;
use App\Models\Generals\NotificationsFormats;
use App\Http\Controllers\Generals\NotificationController;
use Illuminate\Support\Str;
use Unifonic;
use Illuminate\Validation\Rule;
use App\Events\Emails\OfferAvailabilityStatusForAdmin;
//use App\Events\Emails\AdjustmentCreatedEmail;
// use App\Events\Emails\RedeemedOfferEmail;
use App\Events\Emails\RefundCreatedEmail;
use File;
use Illuminate\Support\Facades\Session;
//use Session;

class SendPushNotification extends Controller
{

    /**
     * Sending Push to a user Device.
     *
     * @return void
     */

    public function smstesting(Request $request, $contact_no){

        //Unifonic::send(int $recipient, string $message, string $senderID = null);
        $otp = mt_rand(1000, 9999);
        //$text = '<#> Please Verify your account with the OTP '.$otp.' '.'o6oWMqHtpjO';
        //JOY Application OTP is: //+918125273680
        $text = '<#> JOY APP: Your code is 1435 o6oWMqHtpjO';
        //$data =  Unifonic::send('+9660580009004', $text);
        //$data =  Unifonic::send('+918125273680', $text);
        $data =  Unifonic::send($contact_no, $text, env('UNIFONIC_SENDER_ID'));

        if($data->success == true){
            return response()->json($data);
        }else{
            dd($data);
        }
    }

    public function sendTestNotify(){
        try{        
            event(new RefundCreatedEmail('202205040624718473', 1, '250'));
        } catch(\Exception $e) {
             Log::error('Failed to send notification :  '. $e->getMessage());
        }
    }

    public function fcmtesting(Request $request){

        if(!isset($request['device_token_too'])) {
            $device_token_too = 'cyQDvp79SF-gVxJXUcmkuc:APA91bFOZMy1MXE1Txmnbh4nIwIgBNoJ2B_t9zyBhlF5yZamV_Ub8JzVtlFTEOUx7pAPHm667wjOoge2fSU11rgD_GhCH62ixUzQZwosALNKrA4CDuRQFSZM1jDPplza1jFY1D6ynso9';
            $arrNotification["title"] = 'hi';
            $arrNotification["message"] = 'hello';
            $arrNotification["body"] = 'testing';
        }
        else{
            $device_token_too = $request['device_token_too'];
            $arrNotification["title"] = $request['title'];
            $arrNotification["message"] = $request['message'];
            $arrNotification["body"] = $request['body'];
        }

        $arrNotification["sound"] = "default";
        //$arrNotification["click_action"] = "FLUTTER_NOTIFICATION_CLICK";
        $arrNotification["type"] = 1;
        $arrNotification["notify_type"] = '';
        $arrNotification["fromuserid"] = '';
        $arrNotification["touserid"] = '';
        $channel['notification']['channel_id'] = env('APP_NAME');

        Log::info('testing:: input : '. json_encode($arrNotification));
        //if($user->DeviceType != 'ios'){
        $result = $this->push_notification_android(env('ANDROID_USER_PUSH_KEY'), $device_token_too , $arrNotification , $channel);

        return $result;
        // }else{
        //     //$arrNotification["text"] = $message;
        //     $arrNotification["badge"] = 1;
        //     //$result = $this->push_notification_ios(env('IOS_PROVIDER_PUSH_KEY'), $device_token_too , $arrNotification , $channel);
        //     $result = $this->push_notification_android(env('ANDROID_USER_PUSH_KEY'), $device_token_too , $arrNotification , $channel);
        //     return $result;
        // }
    }

    public function send_sms($contact_no, $otp, $readotpcode) {
        try{
            Log::info('Send OTP:: rquest phone: '. $contact_no. ' otp: '.$otp);
            $text = '<#> Your Joy App code is '.$otp.' '.$readotpcode;
            $response = Unifonic::send($contact_no, $text, env('UNIFONIC_SENDER_ID'));
            if($response->success == true){
                Log::info('Send OTP:: response : '. json_encode($response));
                return response()->json(['status'=>'success', 'message'=> 'Send OTP success', 'data' => $response]);
            }else{
                Log::info('Send OTP:: response : '. json_encode($response));
                return response()->json(['status'=>'failed', 'message'=> 'Send OTP Failed'], 400);
            }
        }catch (\Exception $e) {
            return response()->json(['status'=>'failed', 'message'=> 'Send OTP Failed', "error" => $e ], 400);
        }
    }

    // not using - 11/12
    public function newoffer_added(Request $request) {
        $validator = Validator::make($request->all(),
            [
                'item_id' => ['required'],
                'deal_id' => ['required'],
                'offer_id' => ['required'],
             ]
        );
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value){
                $errors[] = $value[0];
            }
            Log::info('SendPushNotification:: New Offer Notification input '. json_encode($errors));
        }
        try{
            $this->add_notification($request->item_id, $request->deal_id, $request->offer_id,23);
        } catch (\Exception $e) {
            Log::info('SendPushNotification:: New Offer Notification catch Exception');
        }
    }

    // deal creation time notification - not using - 11/12
    public function add_notification($item_id, $deal_id, $offer_id = '', $notification_for) {
        Log::info("Notification sent on offer creation item id ".$item_id." offer id ".$offer_id);
        $offers = ItemOffer::where('item_id', $item_id);
        if($offer_id != '')
            $offers = $offers->where('id', $offer_id);

        $offers = $offers->where('status', 1)->get();


         $itemData = ItemMaster::where('id', $item_id)->select('title','title_ar')->first();

        //if($notification_for == 23){
            $notification_type = 'G'; // Group
            $notification_title = 'New Offer';
            $notification_message = 'New Offer added for '.$itemData['title'];

            $notification_title_ar = 'New Offer';
            $notification_message_ar = $itemData['title_ar'].'تم إضافة عرض جديد ';
        // }
        // else{
        //     $notification_type = 'G'; // Group
        //     $notification_title = 'New Offer';
        //     $notification_message = 'New Offer added';


        // }

        // Send notification to the eligible consumers
        // Eligibility: who have related vehicles
        foreach($offers as $offer){
            if($deal_id == 4 || $deal_id == 5) { //4=wash, 5=detailing
                $consumers = Driver::join('vehicles', 'drivers.id', 'vehicles.owner_id')
                    ->join('deal_vehicles', 'vehicles.group_id', 'deal_vehicles.group_id')
                    ->join('devices', 'devices.user_id', 'drivers.id')
                    ->select('drivers.*', 'devices.fcm', 'devices.device_type')
                    ->where('drivers.status', 1)
                    ->where('vehicles.status', 1)
                    ->where('deal_vehicles.offer_id', $offer['id'])
                    ->where('deal_vehicles.item_id', $offer['item_id'])
                    ->where('devices.user_type', 'driver')
                    ->get();
            }
            else{ // 2=tire, 6=battery
                $consumers = Driver::join('devices', 'devices.user_id', 'drivers.id')
                    ->select('drivers.*', 'devices.fcm', 'devices.device_type')
                    ->where('drivers.status', 1)
                    ->where('devices.user_type', 'driver')
                    ->get();
            }

            $notification = [
                'notification_type' => $notification_type,
                'notification_for' => $notification_for,
                'notification_title' => $notification_title,
                'notification_message' => $notification_message,
                'notification_title_ar' => $notification_title_ar,
                'notification_message_ar' => $notification_message_ar,
                'created_by' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'item_id' => $item_id,
                'offer_id' => $offer->id,
            ];
            $notificationId = Notification::insertGetId($notification);
            $consumer_tokens['ar'] = [];
            $consumer_tokens['en'] = [];         

            foreach($consumers as $consumer){
                NotificationLog::insert([
                    'notification_id' => $notificationId,
                    'notification_to' => $consumer['id'],
                    'notification_for' => 'C',
                    'created_at' => date('Y-m-d H:i:s'),
                ]);

                if($consumer['fcm']){
                   
                     if($consumer['preferred_language']=='ar'){
                        $consumer_tokens['ar'][]=$consumer['fcm'];
                     } else {
                         $consumer_tokens['en'][]=$consumer['fcm'];
                     }                  
                }  
            }

               // print_r($consumer_tokens);

            //exit;
            if(count($consumer_tokens['ar'])>0){
                $this->sendNotifyMultipleUsers(
                    $consumer_tokens['ar'],
                    $notification['notification_title_ar'],
                    $notification['notification_message_ar'],
                    $notification['notification_for'],
                    1,
                    '',
                    $notification['item_id'],
                    $notification['offer_id'],
                    ''
                );
            }

            if(count($consumer_tokens['en'])>0){
                $this->sendNotifyMultipleUsers(
                    $consumer_tokens['en'],
                    $notification['notification_title'],
                    $notification['notification_message'],
                    $notification['notification_for'],
                    1,
                    '',
                    $notification['item_id'],
                    $notification['offer_id'],
                    ''
                );
            }
            
        }
    }

    //transaction payment success sent notification
    public function addtrans_notification($transaction_no, $notification_for) {
        Log::info('Transaction add start');
        $transaction = Transaction::where('transaction_no', $transaction_no)->first();
        if(!$transaction)
            return response()->json(['status' => 'failed', 'message' => 'Invalid Transaction'], 400);

        // Add notification to the Consumer
        $fromuser_details = Driver::where('id', $transaction['created_by'])->first();
        // $notification = [
        //     'notification_type' => 'I', // I - Individual
        //     'notification_for' => $notification_for, // 'add_transaction',
        //     'notification_title' => 'Purchased an Offer',
        //     'notification_message' => isset($fromuser_details->first_name)? $fromuser_details->first_name.
        //         '  Purchased an Offer and Transaction Number: '.$transaction_no :
        //         'Purchased an Offer. Transaction Number: '.$transaction_no,
        //     'created_at' => date('Y-m-d H:i:s'),
        //     'item_id' => $transaction['item_id'],
        //     'offer_id' => $transaction['offer_id'],
        //     'transaction_no' => $transaction_no,
        // ];

         $notification = [
            'notification_type' => 'I', // I - Individual
            'notification_for' => $notification_for, // 'add_transaction',
            'notification_title' => 'Purchased an Offer',
            'notification_message' => 'New purchase, the transaction number is: '.$transaction_no,
            'notification_title_ar' => 'تم شراء عرض ',
            'notification_message_ar' => 'عملية شراء جديدة، رقم العملية هو: '.$transaction_no,
            'created_at' => date('Y-m-d H:i:s'),
            'item_id' => $transaction['item_id'],
            'offer_id' => $transaction['offer_id'],
            'transaction_no' => $transaction_no,
        ];

        $notificationId = Notification::insertGetId($notification);

        // Send notification to Consumer on Add Transaction
        NotificationLog::insert([
            'notification_id' => $notificationId,
            'notification_to' => $transaction['created_by'],
            'notification_for' => 'C', // Consumer
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        $consumer_token = Driver::join('devices', 'drivers.id', '=', 'devices.user_id')
            ->where('drivers.id', $transaction['created_by'])
            ->where('devices.user_type', 'driver')
            ->where('devices.fcm','!=','')
            ->orderBy('devices.id', 'desc')
            ->select('devices.fcm','devices.device_type','drivers.preferred_language')->first();


        if(!empty($consumer_token)){

            $notificationTitle=$notification['notification_title'];
            $notificationMsg= $notification['notification_message'];
            if($consumer_token->preferred_language=='ar'){
                $notificationTitle=$notification['notification_title_ar'];
                $notificationMsg=$notification['notification_message_ar'];
            }

            $this->sendNotifyToUser(
                $consumer_token->fcm,
                $notificationTitle,
                $notificationMsg,
                $notification['notification_for'],
                1,
                1,
                $notification['item_id'],
                $notification['offer_id'],
                'consumer',
                $notification['transaction_no'],
                $consumer_token->device_type
            );
        }

        // Add notification to Technician on Add Transaction if offer is onsite or notify=1
       
        $itemData = ItemOffer::where('id', $transaction['offer_id'])->first();

        if($itemData->on_site=='1' || $itemData->is_notify=='1'){ 

             $delar_id = ItemMaster::where('id', $transaction['item_id'])->pluck('delar_id')->first();

            $dealerData=User::where('org_id', $delar_id)
                ->where('status', 1)
                ->orderBy('id', 'asc')->select('id','preferred_language')->first();

            $dealer_notes = [
                    'notification_id' => $notificationId,
                    'notification_to' => $dealerData->id,
                    'notification_for' => 'N', // Techinicians
                    'created_at' => date('Y-m-d H:i:s'),
                ];        

            NotificationLog::insert($dealer_notes);
           // Send notification to Dealer on Add Transaction
         

            $dealer_token = Device::where('devices.user_id', $dealerData->id)
                ->where('devices.user_type', 'user')
                ->where('devices.fcm','!=','')
                ->orderBy('devices.id', 'desc')
                ->select('devices.fcm','devices.device_type')
                ->first();
           
            if(!empty($dealer_token)){
               $dealerToken=$dealer_token->fcm;
               $deviceType=$dealer_token->device_type;
                if($dealer_token->fcm != ''){

                    $notificationTitle=$notification['notification_title'];
                    $notificationMsg= $notification['notification_message'];
                    if($dealerData->preferred_language=='ar'){
                        $notificationTitle=$notification['notification_title_ar'];
                        $notificationMsg=$notification['notification_message_ar'];
                    }


                    $this->sendNotifyToUser(
                        $dealerToken,
                        $notificationTitle,
                        $notificationMsg,
                        $notification['notification_for'],
                        $fromuser_details->id,
                        $dealerData->id,
                        $notification['item_id'],
                        $notification['offer_id'],
                        'partner',
                        $notification['transaction_no'],
                        $deviceType
                    );
                }   
            }


            $technicians = User::join('technician_locations as tl', 'users.id', '=', 'tl.technician_id')
                ->where('users.org_id', $delar_id)
                ->where('users.status', 1)
                ->where('tl.location_id', $transaction['location_id'])
                ->pluck('users.id');

            if(!$technicians)
                return response()->json(['status' => 'success', 'message' => 'Firebase Notifications not available'], 200);

            $tech_notes = [];
            foreach ($technicians as $techid){
                $tech_notes[] = [
                    'notification_id' => $notificationId,
                    'notification_to' => $techid,
                    'notification_for' => 'N', // Non Consumer
                    'created_at' => date('Y-m-d H:i:s'),
                ];
            }
            NotificationLog::insert($tech_notes);
            // Send notification to Technician on Add Transaction
            $technicians_tokens = User::join('technician_locations as tl', 'users.id', '=', 'tl.technician_id')
                ->join('devices', 'users.id', '=', 'devices.user_id')
                ->where('users.org_id', $delar_id)
                ->where('users.status', 1)
                ->where('tl.location_id', $transaction['location_id'])
                ->where('devices.user_type', 'user')
                ->orderBy('devices.id', 'desc')
                ->select('devices.fcm','tl.technician_id','devices.device_type','users.preferred_language')->get();


            if(!empty($technicians_tokens)){
                foreach($technicians_tokens as $singleTechnician){ 
                   $technicianId=$singleTechnician->technician_id;
                   $technicians_tokens=$singleTechnician->fcm;
                   $technicians_device_type=$singleTechnician->device_type;
                    if($technicians_tokens){ 
                        $notificationTitle=$notification['notification_title'];
                        $notificationMsg= $notification['notification_message'];
                        if($singleTechnician->preferred_language=='ar'){
                            $notificationTitle=$notification['notification_title_ar'];
                            $notificationMsg=$notification['notification_message_ar'];
                        }

                        $this->sendNotifyToUser(
                            $technicians_tokens,
                            $notificationTitle,
                            $notificationMsg,
                            $notification['notification_for'],
                            $fromuser_details->id,
                            $technicianId,
                            $notification['item_id'],
                            $notification['offer_id'],
                            'partner',
                            $notification['transaction_no'],
                            $technicians_device_type
                        );
                    }
                }    
            }
        }

        Log::info('Transaction add end');
        return response()->json(['status' => 'success', 'message' => 'Notification Sent'], 200);
    }

    public function addnotifyrequest_notification($transaction_no, $notification_for) {

        Log::info('Request notification start');
        $transaction = Transaction::where('transaction_no', $transaction_no)->first();
        if(!$transaction)
            return response()->json(['status' => 'failed', 'message' => 'Invalid Transaction'], 400);

        // Add notification to the Consumer
        $fromuser_details = Driver::where('id', $transaction->created_by)->first();

        $itemData = ItemMaster::where('id', $transaction->item_id)->select('title','title_ar')->first();
        $msg=$fromuser_details->first_name.' requested availability for '.$itemData->title.' with quantity '.$transaction->quantity;
        $notification = [
            'notification_type' => 'I', // I - Individual
            'notification_for' => $notification_for, // 'Request Quality availability to technician',
            'notification_title' => 'Request for Offer Availability',
            'notification_message' => "Offer availability request for ".$itemData->title,
            'notification_title_ar' => 'طلب تحقق من توفر منتج ',
            'notification_message_ar' => 'طلب تحقق من توفر منتج ... لعدد '.$itemData->title_ar,
            'created_at' => date('Y-m-d H:i:s'),
            'item_id' => $transaction->item_id,
            'offer_id' => $transaction->offer_id,
            'transaction_no' => $transaction_no,
        ];

         $notificationId = Notification::insertGetId($notification);

        // Send notification to Consumer on Add Transaction
        NotificationLog::insert([
            'notification_id' => $notificationId,
            'notification_to' => $fromuser_details->id,
            'notification_for' => 'C', // Consumer
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        // Add notification to Technician on Add Transaction
        $delar_id = ItemMaster::where('id', $transaction->item_id)->pluck('delar_id')->first();
      
          $dealerData=User::where('org_id', $delar_id)
                ->where('status', 1)
                ->orderBy('id', 'asc')->select('id','preferred_language')->first();

            $dealer_notes = [
                'notification_id' => $notificationId,
                'notification_to' => $dealerData->id,
                'notification_for' => 'N', // Non Consumer
                'created_at' => date('Y-m-d H:i:s'),
            ];
       
        NotificationLog::insert($dealer_notes);

       // Send notification to Dealer on Add Transaction
        $dealer_token = Device::where('devices.user_id', $dealerData->id)
            ->where('devices.user_type', 'user')
            ->where('devices.fcm','!=','')
            ->orderBy('devices.id', 'desc')
            ->select('devices.fcm','devices.device_type')
            ->first();

        if(!empty($dealer_token)){
           $dealerToken=$dealer_token->fcm;
           $deviceType=$dealer_token->device_type;
            if($dealer_token->fcm != ''){

                $notificationTitle=$notification['notification_title'];
                $notificationMsg= $notification['notification_message'];
                if($dealerData->preferred_language=='ar'){
                    $notificationTitle=$notification['notification_title_ar'];
                    $notificationMsg=$notification['notification_message_ar'];
                }

                $this->sendNotifyToUser(
                    $dealerToken,
                    $notificationTitle,
                    $notificationMsg,
                    $notification['notification_for'],
                    $fromuser_details->id,
                    $dealerData->id,
                    $notification['item_id'],
                    $notification['offer_id'],
                    'partner',
                    $notification['transaction_no'],
                    $deviceType
                );
            }   
        }

        $technicians = User::join('technician_locations as tl', 'users.id', '=', 'tl.technician_id')
            ->where('users.org_id', $delar_id)
            ->where('users.status', 1)
            ->where('tl.location_id', $transaction->location_id)
            ->pluck('users.id');

        if(!$technicians)
            return response()->json(['status' => 'success', 'message' => 'Firebase Notifications not available'], 200);

        $tech_notes = [];
        foreach ($technicians as $techid){
            $tech_notes[] = [
                'notification_id' => $notificationId,
                'notification_to' => $techid,
                'notification_for' => 'N', // Techinicians, N - Non Consumers
                'created_at' => date('Y-m-d H:i:s'),
            ];
        }
        NotificationLog::insert($tech_notes);

        // Send notification to Technician on Add Transaction
        $technicians_tokens = User::join('technician_locations as tl', 'users.id', '=', 'tl.technician_id')
            ->join('devices', 'users.id', '=', 'devices.user_id')
            ->where('users.org_id', $delar_id)
            ->where('users.status', 1)
            ->where('tl.location_id', $transaction['location_id'])
            ->where('devices.user_type', 'user')
            ->orderBy('devices.created_at', 'desc')
            ->select('devices.fcm','tl.technician_id','devices.device_type','users.preferred_language')->get();

        if(!empty($technicians_tokens)){
            foreach($technicians_tokens as $singleTechnician){
                $technicianId=$singleTechnician->technician_id;
               $technicians_tokens=$singleTechnician->fcm;
               $technicians_device_type=$singleTechnician->device_type;
                if($technicians_tokens){

                    $notificationTitle=$notification['notification_title'];
                    $notificationMsg= $notification['notification_message'];
                    if($singleTechnician->preferred_language=='ar'){
                        $notificationTitle=$notification['notification_title_ar'];
                        $notificationMsg=$notification['notification_message_ar'];
                    }

                    $this->sendNotifyToUser(
                        $technicians_tokens,
                        $notificationTitle,
                        $notificationMsg,
                        $notification['notification_for'],
                        $fromuser_details->id,
                        $technicianId,
                        $notification['item_id'],
                        $notification['offer_id'],
                        'partner',
                        $notification['transaction_no'],
                        $technicians_device_type
                    );
                }
            }    
        }

        Log::info('Request notification end');
        return response()->json(['status' => 'success', 'message' => 'Notification Sent'], 200);
    }

    public function availability_notification($transaction_no, $is_available, $notification_for) {

        Log::info('Availability notification start');
        $transaction = Transaction::where('transaction_no', $transaction_no)->first();
        if(!$transaction)
            return response()->json(['status' => 'failed', 'message' => 'Invalid Transaction'], 400);

        // Add notification to the Consumer
        $fromuser_details =Auth::user();

        $itemData = ItemMaster::where('id', $transaction['item_id'])->select('title','delar_id','title_ar')->first();//->pluck('title')->first();
        $item_name=$itemData['title'];

       
        $msg="Offer availability status for ".$item_name."  is: Rejected";
        $msg_ar="حالة توفر المنتج رقم ".$itemData['title_ar']."  هو: مرفوضة";
        if($is_available=='2')
        {
            $msg="Offer availability status for  ".$item_name."  is: Cancelled";
            $msg_ar="حالة توفر المنتج رقم ".$itemData['title_ar']." هو: ملغي";
        } else if($is_available=="1"){
            $msg="Offer availability status for  ".$item_name."  is: Available";
            $msg_ar="حالة توفر المنتج رقم ".$itemData['title_ar']." هو: متوفر";
        }

        $notification = [
            'notification_type' => 'I', // I - Individual
            'notification_for' => $notification_for, // 'Availability for offer',
            'notification_title' => 'Offer Availability Status',
            'notification_message' => $msg,
            'notification_title_ar' => 'حالة توفر المنتج',
            'notification_message_ar' => $msg_ar,
            'created_at' => date('Y-m-d H:i:s'),
            'item_id' => $transaction['item_id'],
            'offer_id' => $transaction['offer_id'],
            'transaction_no' => $transaction_no,
        ];


         $notificationId = Notification::insertGetId($notification);

        // Send notification to Consumer on Add Transaction
        NotificationLog::insert([
            'notification_id' => $notificationId,
            'notification_to' => $transaction['created_by'],
            'notification_for' => 'C', // Consumer
            'created_at' => date('Y-m-d H:i:s'),
        ]);

       // Technician Notification
        $tech_notes[] = [
            'notification_id' => $notificationId,
            'notification_to' =>  $fromuser_details->id,
            'notification_for' => 'N', // Non Consumer
            'created_at' => date('Y-m-d H:i:s'),
        ];
        
        NotificationLog::insert($tech_notes);

         $consumer_token = Driver::join('devices', 'drivers.id', '=', 'devices.user_id')
            ->where('drivers.id', $transaction['created_by'])
            ->where('devices.user_type', 'driver')
            ->orderBy('devices.id', 'desc')
            ->select('devices.fcm','devices.user_id','devices.device_type','drivers.preferred_language')->first();

        if(!empty($consumer_token)){

            $notificationTitle=$notification['notification_title'];
            $notificationMsg= $notification['notification_message'];
            if($consumer_token->preferred_language=='ar'){
                $notificationTitle=$notification['notification_title_ar'];
                $notificationMsg=$notification['notification_message_ar'];
            }

            $this->sendNotifyToUser(
                $consumer_token->fcm,
                $notificationTitle,
                $notificationMsg,
                $notification['notification_for'],
                $fromuser_details->id,
                $transaction['created_by'],
                $notification['item_id'],
                $notification['offer_id'],
                'consumer',
                $notification['transaction_no'],
                $consumer_token->device_type
            );
        }

        // Deal admin and technicians
          $delar_id =$itemData['delar_id'];

          $dealerData=User::where('org_id', $delar_id)
                ->where('status', 1)
                ->orderBy('id', 'asc')->select('id','preferred_language')->first();

            $dealer_notes = [
                'notification_id' => $notificationId,
                'notification_to' => $dealerData->id,
                'notification_for' => 'N', // Non Consumer
                'created_at' => date('Y-m-d H:i:s'),
            ];
       
            NotificationLog::insert($dealer_notes);

           // Send notification to Dealer on Add Transaction
            $dealer_token = Device::where('devices.user_id', $dealerData->id)
                ->where('devices.user_type', 'user')
                ->where('devices.fcm','!=','')
                ->orderBy('devices.id', 'desc')
                ->select('devices.fcm','devices.device_type')
                ->first();
            
            if(!empty($dealer_token)){
               $dealerToken=$dealer_token->fcm;
               $deviceType=$dealer_token->device_type;
                if($dealer_token->fcm != ''){
                    
                    $notificationTitle=$notification['notification_title'];
                    $notificationMsg= $notification['notification_message'];
                    if($dealerData->preferred_language=='ar'){
                        $notificationTitle=$notification['notification_title_ar'];
                        $notificationMsg=$notification['notification_message_ar'];
                    }


                    $this->sendNotifyToUser(
                        $dealerToken,
                        $notificationTitle,
                        $notificationMsg,
                        $notification['notification_for'],
                        $fromuser_details->id,
                        $dealerData->id,
                        $notification['item_id'],
                        $notification['offer_id'],
                        'partner',
                        $notification['transaction_no'],
                        $deviceType
                    );
                }   
            }
          
            $technicians = User::join('technician_locations as tl', 'users.id', '=', 'tl.technician_id')
                ->where('users.org_id', $delar_id)
                ->where('users.status', 1)
                ->where('tl.location_id', $transaction['location_id'])
                ->pluck('users.id');

            if(!$technicians)
                return response()->json(['status' => 'success', 'message' => 'Firebase Notifications not available'], 200);

            $tech_notes = [];
            foreach ($technicians as $techid){
                $tech_notes[] = [
                    'notification_id' => $notificationId,
                    'notification_to' => $techid,
                    'notification_for' => 'N', // Techinicians, N - Non Consumers
                    'created_at' => date('Y-m-d H:i:s'),
                ];
            }
            NotificationLog::insert($tech_notes);

            // Send notification to Technician on Add Transaction
            $technicians_tokens = User::join('technician_locations as tl', 'users.id', '=', 'tl.technician_id')
                ->join('devices', 'users.id', '=', 'devices.user_id')
                ->where('users.org_id', $delar_id)
                ->where('users.status', 1)
                ->where('tl.location_id', $transaction['location_id'])
                ->where('devices.user_type', 'user')
                ->orderBy('devices.created_at', 'desc')
                ->select('devices.fcm','tl.technician_id','devices.device_type','users.preferred_language')->get();

            if(!empty($technicians_tokens)){
                foreach($technicians_tokens as $singleTechnician){
                    $technicianId=$singleTechnician->technician_id;
                   $technicians_tokens=$singleTechnician->fcm;
                   $technicians_device_type=$singleTechnician->device_type;
                    if($technicians_tokens){

                        $notificationTitle=$notification['notification_title'];
                        $notificationMsg= $notification['notification_message'];
                        if($singleTechnician->preferred_language=='ar'){
                            $notificationTitle=$notification['notification_title_ar'];
                            $notificationMsg=$notification['notification_message_ar'];
                        }

                        $this->sendNotifyToUser(
                            $technicians_tokens,
                            $notificationTitle,
                            $notificationMsg,
                            $notification['notification_for'],
                            $fromuser_details->id,
                            $technicianId,
                            $notification['item_id'],
                            $notification['offer_id'],
                            'partner',
                            $notification['transaction_no'],
                            $technicians_device_type
                        );
                    }
                }    
            }

        // End Deal admin and technician
        Log::info('Availability notification end');
        return response()->json(['status' => 'success', 'message' => 'Notification Sent'], 200);
    }


    public function sendNotifyToUser($to, $title, $message, $notify_type = false, $fromuserid = false,
                                     $touserid = false, $item_id = false, $offer_id = false, $app_key = false,$transaction_no = false, $device_type, $smsMessage="", $imageUrl=""){
        
        try{
            Log::info("Notification starts ".$app_key);
            $device_token_too = $to;
            $arrNotification["title"] = $title;
            $arrNotification["body"] = $message;
            //$arrNotification["body"] = $body;
            $arrNotification["sound"] = "default";
            //$arrNotification["click_action"] = "FLUTTER_NOTIFICATION_CLICK";
            $arrNotification["type"] = 1;
            $arrNotification["notify_type"] = $notify_type;
            $arrNotification["fromuserid"] = $fromuserid;
            $arrNotification["touserid"] = $touserid;
            $arrNotification["item_id"] = $item_id;
            $arrNotification["offer_id"] = $offer_id;
            $arrNotification["transaction_no"] = $transaction_no;
            $arrNotification["image_url"] =$imageUrl;
            $arrNotification["image"] =url($imageUrl); //New Image key added for displaying image in push notification 
 
            $channel['notification']['channel_id'] = env('APP_NAME');
           
            if(isset($app_key) && $app_key == 'partner'){
               $result = $this->push_notification_android(
                env('PARTNER_USER_PUSH_KEY'),
                $device_token_too,
                $arrNotification ,
                $channel
               );  

              
              $data=json_decode($result);
              if($data->failure){ // if notifiction sent failed this sms need to send for admin
                 $contactNo = User::where('id', $touserid)->where('status', 1)->where('role_id', 3)->pluck('contact_no')->first();
                 if($contactNo){
                   $response = Unifonic::send($contactNo, $smsMessage, env('UNIFONIC_SENDER_ID'));
                 }
              }
              return $result;   
            } else {
                $result = $this->push_notification_android(
                    env('ANDROID_USER_PUSH_KEY'),
                    $device_token_too ,
                    $arrNotification ,
                    $channel
                );

               return $result;             
            }
            Log::info("Notification ends ".$app_key);
        } catch (\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Send notification failed', "error" => $e->getMessage()], 400);
        }
    }

    public function push_notification_android($api_key, $registatoin_ids, $notification , $channel, $device_type = 'android') {
        $url = 'https://fcm.googleapis.com/fcm/send';
        /*$headers = array(
            'Authorization:key='.env('ANDROID_USER_PUSH_KEY') ,
            'Content-Type:application/json'
        );*/

        
        $headers = array(
            'Authorization:key='.$api_key,
            'Content-Type:application/json'
        );

        if(is_array($registatoin_ids)){
            foreach ($registatoin_ids as $key => $value) {
                $fields = array(
                    'notification'=>$notification,
                    'data' => $notification,
                    'to' => $value,
                    //'click_action' => 'FLUTTER_NOTIFICATION_CLICK',
                );
                $ch = curl_init();
                // Set the url, number of POST vars, POST data
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                // Disabling SSL Certificate support temporarly
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
                $result = curl_exec($ch);
                
                if ($result === FALSE) {
                    // die('Curl failed: ' . curl_error($ch));
                    Log::error('SendPushNotification:: Notify curl error array: '. curl_error($ch));
                }
                Log::info('SendPushNotification:: Notify response array: '. $result);
                curl_close($ch);
            }
            //return $result;
        }else{
            $fields = array(
                'to' => $registatoin_ids,
                'notification'=>$notification,
                'data' => $notification,
                //'click_action' => 'FLUTTER_NOTIFICATION_CLICK',
                'android' => $channel,
            );
            Log::info('SendPushNotification:: Notify payload single: '. json_encode($fields));
            //dd( json_encode($fields));
            $ch = curl_init();
            // Set the url, number of POST vars, POST data
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            // Disabling SSL Certificate support temporarly
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
            $result = curl_exec($ch);
            if ($result === FALSE) {
                // die('FCM Send Error Single: ' . curl_error($ch));
                Log::error('SendPushNotification:: Notify curl error single: '. curl_error($ch));
            }
            Log::info('SendPushNotification:: Notify response single: '. $result);
            curl_close($ch);
            return $result;
        }    
    }

    public function push_notification_ios($api_key, $registatoin_ids, $notification , $channel, $device_type = 'ios') {
       if(env('APP_OTP')=='production') {  // if server is production then only send notifications
            $url = 'https://fcm.googleapis.com/fcm/send';
            /*$headers = array(
                'Authorization:key='.$api_key,
                'Content-Type:application/json'
            );*/
            $headers = array();
            $headers[] = 'Content-Type: application/json';
            $headers[] = 'Authorization: key='. $api_key;
            $fields = array(
                'to' => $registatoin_ids,
                'registration_ids' => array($registatoin_ids),
                'notification'=>$notification,
                //'data' => $notification,
                'priority' => 'high',
                'click_action' => 'FLUTTER_NOTIFICATION_CLICK',
                //'android' => $channel,
            );
            //dd( json_encode($fields));
            $ch = curl_init();
            // Set the url, number of POST vars, POST data
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST,"POST");
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            // Disabling SSL Certificate support temporarly
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
            $result = curl_exec($ch);
            if ($result === FALSE) {
                die('Curl failed: ' . curl_error($ch));
            }
            curl_close($ch);
            return $result;
        }
    }

    public function push_notification_androidmultiple($api_key, $registatoin_ids, $notification, $channel, $device_type = 'android') {
        if(env('APP_OTP')=='production') {  // if server is production then only send notifications
            $url = 'https://fcm.googleapis.com/fcm/send';
            $fields = array(
                'registration_ids'  => $registatoin_ids,
                'notification'  => $notification,
                'data' => $notification,
                //'click_action' => 'FLUTTER_NOTIFICATION_CLICK',
                'android' => $channel,
            );
            $headers = array(
                'Authorization:key='.$api_key,
                'Content-Type:application/json'
            );
            Log::info('SendPushNotification:: Group notify payload: '. json_encode($fields));
            $ch = curl_init();
            curl_setopt( $ch,CURLOPT_URL, $url);
            curl_setopt( $ch,CURLOPT_POST, true );
            curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
            curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
            curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
            curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
            $result = curl_exec($ch );
           
            if ($result === FALSE) {
                // die('FCM Send Error: ' . curl_error($ch));
                Log::error('SendPushNotification:: Group notify curl error: '. curl_error($ch));
            }
            Log::info('SendPushNotification:: Group notify response: '. $result);
            $result = json_decode($result,true);
            $responseData['android'] = [
               "result" =>$result
            ];
            curl_close( $ch );
            return $responseData;
        }
    }

    public function push_notification_iosmultiple($api_key, $registatoin_ids, $notification , $device_type = 'ios') {
        if(env('APP_OTP')=='production') {  // if server is production then only send notifications
            $url = "https://fcm.googleapis.com/fcm/send";
            //$notification = array('title' =>$title , 'text' => $body, 'sound' => 'default', 'badge' => '1');
            $arrayToSend = array(
                'registration_ids' => $registatoin_ids,
                'notification' => $notification,
            );
            $json = json_encode($arrayToSend);
            $headers = array();
            $headers[] = 'Content-Type: application/json';
            $headers[] = 'Authorization: key='. $api_key;

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST,"POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
            curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            //Send the request
            $result = curl_exec($ch);

            if ($result === FALSE) {
                die('FCM Send Error: ' . curl_error($ch));
            }
            $result = json_decode($result,true);
            $responseData['ios'] = [
                "result" =>$result
            ];
            //Close request
            curl_close($ch);
            return $responseData;
        }
    }

    public function sendNotifyMultipleUsers($to, $title, $message, $notification_for = false,
                                            $fromuserid = false, $touserids = false,
                                            $item_id = false, $offer_id = false, $transaction_no = false){
       
        $arrNotification["title"] = $title;
        $arrNotification["message"] = $message;
        $arrNotification["body"] = $message;
        $arrNotification["sound"] = "default";
        //$arrNotification["click_action"] = "FLUTTER_NOTIFICATION_CLICK";
        $arrNotification["type"] = 1;
        $arrNotification["notification_for"] = $notification_for;
        $arrNotification["transaction_no"] = $transaction_no;
        $channel['notification']['channel_id'] = env('APP_NAME');
        Log::info('SendPushNotification:: Group notify request: '. json_encode($arrNotification));
       
        //if(count($to['android'])>0){
            $device_token_too = $to;
             // if server is production then only send notifications
            if(env('APP_OTP')=='production') { 
                $result = $this->push_notification_androidmultiple(
                                    env('ANDROID_USER_PUSH_KEY'),
                                    $device_token_too ,
                                    $arrNotification,
                                    $channel, '');

            }

        // } 

        // if(count($to['ios'])>0){
        //     $device_token_too = $to['ios'];
        //     // push_notification_iosmultiple($api_key, $registatoin_ids, $notification , $device_type = 'ios') {
        //      $result = $this->push_notification_iosmultiple(
        //                         env('ANDROID_USER_PUSH_KEY'),
        //                         $device_token_too ,
        //                         $arrNotification,
        //                         '');
        // }

        //dd($result);
    }

    public function notification_destroy(Request $request, $id) {

        if(!Notification::find($id))
            return response()->json([
                'status'=>'failed',
                'message'=> 'Notification not found',
                'message_ar'=> 'لم يتم العثور على الإخطار',
            ], 400);

        // if(Auth::guard('guest')->check()){
        //     NotificationLog::where('notification_to', Auth::guard('guest')->user()->device_id)
        //         ->where('notification_id', $id)
        //         ->update(['deleted_at' => date('Y-m-d H:i:s')]);

        // } else 

        if(Auth::guard('driver')->id()) {

            NotificationLog::where('notification_to', Auth::guard('driver')->id())
                ->where('notification_id', $id)
                ->update(['deleted_at' => date('Y-m-d H:i:s')]);
        } else {
            NotificationLog::where('notification_to', Auth::id())
                ->where('notification_id', $id)
                ->update(['deleted_at' => date('Y-m-d H:i:s')]);
        }

        return response()->json([
            'status'=>'success',
            'message' => 'Notification deleted successfully',
            'message_ar' => 'تم حذف الإخطار بنجاح',
        ], 200);
    }


    public function allnotification_destroy($deviceId=0) {
         
        // if($deviceId){
        //     $userId = $deviceId;
            
        // } else  if(Auth::guard('driver')->id()) {
        //     NotificationLog::where('notification_to', Auth::guard('driver')->id())
        //         ->update(['deleted_at' => date('Y-m-d H:i:s')]);
        // } else {
        //     NotificationLog::where('notification_to', Auth::id())
        //         ->update(['deleted_at' => date('Y-m-d H:i:s')]);
        // }

        if($deviceId){ // guest users
            $user_id = $deviceId;
            $type='G'; // guest user  
        } else if(Auth::guard('driver')->id()){
            $user_id = Auth::guard('driver')->id();
            $type='C'; // Customer  
        } else { 
            $user_id = Auth::id();
            $type='N'; // Non customer - delar technician, M & S Technician
        }

         NotificationLog::where('notification_to', $user_id)->where('notification_for', $type)
                ->update(['deleted_at' => date('Y-m-d H:i:s')]);

        return response()->json([
            'status'=>'success',
            'message' => 'Notification deleted successfully',
            'message_ar' => 'تم حذف الإخطار بنجاح',
        ], 200);
    }


    /*
     * Access: Customer, Delar Technician, M & S Technician prefix: customer, dealer, technicain
     * All In app noticiations will be listed here
     */
    public function notifications_list(Request $request) {
        if(Auth::guard('driver')->id()){
            $user_id = Auth::guard('driver')->id();
            $type='C'; // Customer  
        } else { //Technicians or deal providers or service provider
            $user_id = Auth::id();
            $type='N'; // Non customer - delar technician, M & S Technician
        }

        if(isset(request()->device_id) && request()->device_id!=''){
          $user_id = request()->device_id;
        }

        if(isset(request()->user_type) && request()->user_type!=''){
          $type=request()->user_type;
        }
 
        try{
            // read inapp notifications only which are not read
            NotificationLog::where('notification_to', $user_id)->with('notification_list')
                ->withCount( ['notification_list' => function($q){ $q->where('is_set', 1); }])
                ->Has( 'notification_list', '>' , 0)
                ->where('notification_for', $type)
                ->whereNull('read_at')
                ->update([ 'read_at' => date('Y-m-d H:i:s') ]);

            $notifications = Notification::select('notifications.*')
                ->join('notifications_log', 'notifications.id', 'notifications_log.notification_id');
            
            if($type == 'N')
            {
                $org_id = Auth::user()->org_id;
                $notifications = $notifications->leftjoin('item_master', function($qry) use ($org_id){
                    $qry->on('notifications.item_id', 'item_master.id');
                    $qry->where('item_master.delar_id', $org_id);
                });
            }

            $notifications = $notifications->where('notifications_log.notification_to', $user_id)
                ->where('notifications_log.notification_for', $type)
                ->where('notifications.is_inapp', '1')
                ->where('notifications.status', '1')
                ->where('notifications.expired_on','>',date("Y-m-d H:i:s"))
                ->where('notifications.is_sent',1)
                ->whereNull('notifications_log.deleted_at')
                ->with('deal', 'offer', 'deal.deal', 'transaction', 'transaction.payment_details','location_info')
                ->orderBy('notifications.id', 'desc')
                ->paginate(30);
                // ->map(function ($row) {
                //    if($row->location_id){
                //      $row->city=$row->location_info->city;
                //         $row->deal_id=$row->deal->deal_id;
                //         unset($row['offer']);
                //         unset($row['deal']);
                //         unset($row['location_info']);
                //      }
                //      return $row;
                //  });


            $data['notifications'] = $notifications;
            return response()->json(['status'=>'success', 'data' => $data], 200);

        } catch (\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Notifications failed', "error" => $e], 400);
        }
    }




    /*
    *Get Custom Notification data based on the id
    *@param $notificationId
    */
     public function getCustomerNotificationData($notificationId) {
        try{
         $list = Notification::where('notification_for','44')->where('id',$notificationId)->first();
         

         $individuals=NotificationLog::where('group_id',0)->where('notification_id', $notificationId)->count();

         $groupsList=NotificationLog::select('group_id',DB::raw("count(group_id) as group_count"))->where('group_id','>',0)->where('notification_id', $notificationId)
            ->with('group_info')->groupBy('group_id')->get();

          return response()->json(['status'=>'success', 'data' => $list, 'individuals'=>$individuals, 'groupsList'=>$groupsList], 200);

        } catch (\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Notifications failed', "error" => $e->getMessage()], 400);
        }
    }


    public function partner_notifications_list() { // not used 13/12/21
        if(Auth::guard('driver')->id())
            $user_id = Auth::guard('driver')->id();
        else
            $user_id = Auth::id();

        try{
            // read notifications which are not read
            NotificationLog::where('notification_to', $user_id)
                ->whereNull('read_at')
                ->update(['read_at' => date('Y-m-d H:i:s')]);

            $notifications = Notification::select('notifications.*')
                ->join('notifications_log', 'notifications.id', 'notifications_log.notification_id')
                ->where('notifications_log.notification_to', $user_id)
                ->whereNull('notifications_log.deleted_at')
                ->with('deal', 'offer', 'deal.deal', 'transaction', 'transaction.payment_details')
                ->orderBy('notifications.id', 'desc')
                ->paginate(30);

            $data['notifications'] = $notifications;
            return response()->json(['status'=>'success', 'data' => $data], 200);

        }catch(\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Notifications failed', "error" => $e], 400);
        }
    }

    public function likedoffer_endingsoon(Request $request) {
        try{
            Log::info('Liked offer ending soon notify start');
            $user_id = 1;
            $user = User::where('role_id', 1)->first();
            if($user){
                $user_id = $user['id'];
            }
            //getting item_id
            $driver_id = Auth::guard('driver')->id();
            if(isset($driver_id) && !empty($driver_id)){
                if(isset($request['item_ids']) && count($request['item_ids']) > 0){
                    $consumers_tokens = Device::where('devices.user_id', $driver_id)
                        ->where('devices.user_type', 'driver')
                         ->orderBy('devices.id', 'desc')
                        ->select('devices.fcm','devices.device_type')
                        ->first();

                   // $consumers_tokens = array_unique(array_filter($consumers_tokens));
                    foreach ($request['item_ids'] as $item_id) {
                        $offers = ItemOffer::leftjoin('item_master', 'item_offers.item_id', '=','item_master.id')
                            ->whereRaw('item_offers.end_date <= (DATE(NOW()) + INTERVAL 3 DAY)')
                            ->where('item_offers.item_id', $item_id)
                            ->where('item_offers.status', 1)
                            ->where('item_master.status', 1)
                            ->get();

                        foreach($offers as $offer){
                            $notification = [
                                'from_admin' => 'Offers App',
                                'notification_type' => 'I',
                                'notification_for' => 32, //'likedoffer_endingsoon',
                                'notification_title' => 'Liked offer ending soon',
                                'notification_message' => 'Liked offer ending soon',
                                'created_at' => date('Y-m-d H:i:s'),
                                'item_id' => $offer->item_id,
                                'offer_id' => $offer->id,
                            ];

                           Notification::insert($notification);
                            $response = $this->sendNotifyToUser(
                                $consumers_tokens->fcm,
                                $notification['notification_title'],
                                $notification['notification_message'],
                                $notification['notification_for'],
                                1,
                                1,
                                $notification['item_id'],
                                $notification['offer_id'],
                                'consumer',
                                '',
                                $consumers_tokens->device_type
                            );
                        }
                    }
                }else{
                    Log::info('No Offer ids for liked offers');
                }
            }else{
                Log::info('No loggedin driver for liked offers');
            }
            Log::info('Liked offer ending soon notify end');

            return response()->json([
                'status'=>'success',
                'message'=> 'Notification Sent',
                'message_ar'=> 'تم إرسال الإخطار',
            ], 200);

        }catch(\Exception $e){
            return response()->json([
                'status'=>'failed',
                'message'=> 'Notification Sent failed',
                'message_ar'=> 'فشل إرسال الإخطار',
                'error' => $e
            ], 400);
        }
    }

    public function unredeemed_offersend() {
        try{
            $user_id = 1;
            $user = User::where('role_id', 1)->first();
            if($user){
                $user_id = $user['id'];
            }
            Log::info('Un redeem offers ending soon notify start');
            $transactions = Transaction::join('item_offers', 'transactions.offer_id', '=', 'item_offers.id')
                ->join('drivers', 'transactions.created_by', '=', 'drivers.id')
                ->join('devices', 'drivers.id', '=', 'devices.user_id')
                ->select('transactions.*', 'devices.fcm', 'devices.device_type')
                ->where('transactions.payment_status', 'Successful')
                ->whereNull('transactions.approved_by')
                ->where('drivers.status', 1)
                ->where('devices.user_type', 'driver')
                //->whereRaw('item_offers.end_date <= (DATE(NOW()) + INTERVAL 7 DAY)')
                ->where(DB::raw('DATEDIFF(transactions.created_at,NOW())') , '=', 7)
                ->where('item_offers.status', 1)->get();
            
            Log::info('Un redeem offers ending soon count: '.count($transactions));

            foreach ($transactions as $key => $transaction) {
                if(isset($transaction->created_by, $transaction->fcm) && !empty($transaction->created_by)){
                    $notification = [
                        'from_admin' => 'Offers App',
                        'notification_type' => 'person',
                        'notification_for' => 29, //'unredeem_offerend',
                        'notification_title' => 'Un redeem offers ending soon',
                        'notification_message' => 'Un redeem offers ending soon',
                        'created_at' => date('Y-m-d H:i:s'),
                        'item_id' => $transaction->item_id,
                        'offer_id' => $transaction->offer_id,
                        'transaction_no' => $transaction->transaction_no,
                    ];
                    $notificationId = Notification::insertGetId($notification);

                    NotificationLog::insert([
                        'notification_id' => $notificationId,
                        'notification_to' => $transaction->created_by,
                        'notification_for' => 'C',
                        'created_at' => date('Y-m-d H:i:s'),
                    ]);

                    $this->sendNotifyToUser(
                        $transaction->fcm,
                        $notification['notification_title'],
                        $notification['notification_message'],
                        $notification['notification_for'],
                        1,
                        1,
                        $notification['item_id'],
                        $notification['offer_id'],
                        '',
                        $notification['transaction_no'],
                        $transaction->device_type
                    );
                }
            }
            Log::info('Un redeem offers ending soon notify end');
        }catch(\Exception $e){
            return $e;
        }
    }
    
    public function paid_unredeemed_offersend() {
        try{
            $user_id = 1;
            $user = User::where('role_id', 1)->first();
            if($user){
                $user_id = $user['id'];
            }
            Log::info('Paid Un-redeemed offers for week notify start');
            //$transactions = Transaction::where('payment_status', 'Successful')->whereNull('approved_by')->whereRaw('created_at >= (DATE(NOW()) - INTERVAL 7 DAY)')->get();
            $transactions = Transaction::leftjoin('drivers', 'transactions.created_by', '=', 'drivers.id')->leftjoin('devices', 'drivers.id', '=', 'devices.user_id')->where('payment_status', 'Successful')->whereNull('transactions.approved_by')
                //->whereRaw('transactions.created_at >= (DATE(NOW()) - INTERVAL 7 DAY)')
                ->where(DB::raw('DATEDIFF(transactions.created_at,NOW())') , '>', -7)
                ->where('drivers.status', 1)->where('devices.user_type', 'driver')->get();
            
            Log::info('Paid Un-redeemed offers for week count: '.count($transactions));

            foreach ($transactions as $key => $transaction) {
                if(isset($transaction->created_by, $transaction->fcm) && !empty($transaction->created_by) && !empty($transaction->fcm)){
                    $notification = [
                        'from_admin' => 'Offers App',
                        'notification_type' => 'person',
                        'notification_for' => 30, //'paid_unredeem_offerend',
                        'notification_title' => 'Paid Un-redeemed offers for week',
                        'notification_message' => 'Paid Un-redeemed offers for week',
                        'created_at' => date('Y-m-d H:i:s'),
                        'item_id' => $transaction->item_id,
                        'offer_id' => $transaction->offer_id,
                        'transaction_no' => $transaction->transaction_no,
                    ];
                    Notification::insert($notification);
                    $response = $this->sendNotifyToUser(
                        $transaction->fcm,
                        $notification['notification_title'],
                        $notification['notification_message'],
                        $notification['notification_for'],
                        1,
                        1,
                        $notification['item_id'],
                        $notification['offer_id'],
                        '',
                        $notification['transaction_no'],
                        $transaction->device_type
                    );
                }
            }
            Log::info('Paid Un-redeemed offers for week notify end');
        }catch(\Exception $e){
            return $e;
        }
    }

    public function incomplete_paymentfordeal() {
        try{
            $user_id = 1;
            $user = User::where('role_id', 1)->first();
            if($user){
                $user_id = $user['id'];
            }
            //$transactions = Transaction::where('payment_status', 'pending')->get();
            Log::info('In complete payment for an deal notify start');
            
            $transactions = Transaction::leftjoin('drivers', 'transactions.created_by', '=', 'drivers.id')->leftjoin('devices', 'drivers.id', '=', 'devices.user_id')->whereIn('transactions.payment_status', ['pending', 'Failed'])->whereNull('transactions.approved_by')->where('drivers.status', 1)->where('devices.user_type', 'driver')->get();

            Log::info('In complete payment for an deal count: '.count($transactions));

            foreach ($transactions as $key => $transaction) {
                if(isset($transaction->created_by, $transaction->fcm) && !empty($transaction->created_by) && !empty($transaction->fcm)){
                    $notification = [
                        'from_admin' => 'Offers App',
                        'notification_type' => 'person',
                        'notification_for' => 31, //'incomplete_paymentfordeal',
                        'notification_title' => 'In complete payment for an deal',
                        'notification_message' => 'In complete payment for an deal',
                        'created_at' => date('Y-m-d H:i:s'),
                        'item_id' => $transaction->item_id,
                        'offer_id' => $transaction->offer_id,
                        'transaction_no' => $transaction->transaction_no,
                    ];
                    Notification::insert($notification);
                    $response = $this->sendNotifyToUser(
                        $transaction->fcm,
                        $notification['notification_title'],
                        $notification['notification_message'],
                        $notification['notification_for'],
                        1,
                        1,
                        $notification['item_id'],
                        $notification['offer_id'],
                        '',
                        $notification['transaction_no'],
                        $transaction->device_type
                    );
                }
            }
            Log::info('In complete payment for an deal notify end');
        }catch(\Exception $e){
            return $e;
        }
    }

    public function offer_expiry_warning() {
        try{
            Log::info('Offer expiry Warning notify start');
            $user_id = 1;
            $offers = ItemOffer::select('item_offers.*')
                ->whereRaw('item_offers.end_date >= (DATE(CURRENT_DATE()) + INTERVAL 3 DAY)')
                ->where(DB::raw('DATEDIFF(item_offers.end_date,NOW())') , '=', 3)->get();

            foreach ($offers as $key => $offer) {

                //to delar and delar technicians notification start
                $delarid_org = ItemMaster::where('id', $offer->item_id)->pluck('delar_id')->first();
                $dealer_ids = User::leftjoin('devices', 'users.id', '=', 'devices.user_id')
                    ->where('users.org_id', $delarid_org)
                    ->where('users.status', 1)
                    ->where('devices.user_type', 'user')
                    ->groupBy('users.id')
                    ->pluck('users.id')->toArray(); //->where('users.role_id', 3) // 3= delar

                $delars_tokens = User::leftjoin('devices', 'users.id', '=', 'devices.user_id')
                    ->where('users.org_id', $delarid_org)
                    ->where('users.status', 1)
                    ->where('devices.user_type', 'user')
                    ->select('devices.fcm','devices.device_type')->get();

                 
                $dealer_ids = array_unique(array_filter($dealer_ids));
                //$delars_tokens = array_unique(array_filter($delars_tokens));

                if(!empty($delars_tokens)){ 


                    $delarsTokens['android'] = [];
                    $delarsTokens['ios'] = [];
                    foreach($delars_tokens as $dealer){                       
                        if($dealer->fcm!=''){
                             if($dealer->device_type=='android'){
                                $delarsTokens['android'][]=$dealer->fcm;
                             } else {
                                 $delarsTokens['ios'][]=$dealer->fcm;
                             }                  
                        }              
                    }

                    $notification_todelar = [
                        'from_admin' => 'Offers App',
                        'notification_type' => 'G',
                        'notification_for' => 25, //'offer_expiry_delar',
                        'notification_title' => 'Offer Expire',
                        'notification_message' => 'Offer will Expire within 2 or 3 days',
                        'created_at' => date('Y-m-d H:i:s'),
                        'item_id' => $offer->item_id,
                        'offer_id' => $offer->id,
                    ];

                    Notification::insert($notification_todelar);
                    $response = $this->sendNotifyMultipleUsers(
                        $delarsTokens,
                        $notification_todelar['notification_title'],
                        $notification_todelar['notification_message'],
                        $notification_todelar['notification_for'],
                        1,
                        1,
                        $notification_todelar['item_id'],
                        $notification_todelar['offer_id']
                    );
                    //to delar and delar technicians notification end
                }
            }

            Log::info('Offer expiry Warning notify end');
        }catch(\Exception $e){
            return $e;
        }
    }

    //pending or failed transactions auto cancel after 48 hours
    public function transactions_autocancel() { // not used 13/12/21
        try{
            Log::info('pending or failed transactions auto cancel after 48 hours start');
            
            $transactions = Transaction::leftjoin('drivers', 'transactions.created_by', '=', 'drivers.id')
                ->whereIn('transactions.payment_status', ['pending', 'Failed'])
                ->whereRaw('transactions.created_at < (DATE(NOW()) - INTERVAL 48 HOUR)')
                ->whereNull('transactions.approved_by')->where('drivers.status', 1)->get();

            Log::info('pending or failed transactions auto cancel after 48 hours count: '.count($transactions));

            foreach ($transactions as $key => $transaction) {
                // update available quantity
                if($transaction->deal_id == 6 || $transaction->deal_id == 2){ // tires & battaries
                    ItemMaster::where('id', $transaction->item_id)->update(['quantity' => DB::raw('quantity + '.$transaction->quantity)]);
                }
                ItemOffer::where('id', $transaction->offer_id)->where('item_id', $transaction->item_id)->update(['quantity' => DB::raw('quantity + '.$transaction->quantity)]);

                Transaction::where('transaction_no', $transaction->transaction_no)->update(['payment_status' => 'cancelled', 'updated_at' => date('Y-m-d H:i:s')]);
                Payment::where('transaction_no', $transaction->transaction_no)->whereIn('payment_status', ['pending', 'Failed'])->update(['payment_status' => 'cancelled', 'updated_at' => date('Y-m-d H:i:s')]);
            }
            Log::info('pending or failed transactions auto cancel after 48 hours end');
        }catch(\Exception $e){
            return $e;
        }
    }

    /*
     * Access: Customer, Prefix: customer
     * Add Notifier to know deals status
     */
    public function add_notifier(Request $request)
    {
        // TODO: Notification requests should be saved for deals
        try{
            $request['user_id'] = Auth::guard('driver')->id();
            $notify = Notifier::where('user_id', $request['user_id'])->first();
            if(isset($notify)){
                // update old record
                $request['updated_at'] = date('Y-m-d H:i:s');
                if($notify['is_notify']){
                    $request['is_notify'] = 0;
                    Notifier::where('user_id', $request['user_id'])->update($request->all());
                }
            }
            else{
                // create new record
                $request['created_at'] = date('Y-m-d H:i:s');
                Notifier::insert($request->all());
            }

            return response()->json([
                'status'=>'success',
                'message'=> 'Notifier Created Successfully',
                'message_ar'=> 'تم إنشاء المخطر بنجاح',
            ], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Notifier Creation Failed'], 400);
        }
    }


    public function refund_notification($transaction_no, $notification_for) { 
        Log::info('Refund notification add start');
        $transaction = Transaction::where('transaction_no', $transaction_no)->first();
        if(!$transaction)
            return false;

        // Add notification to the Consumer
        $fromuser_details = Driver::where('id', $transaction['created_by'])->first();
        $refund_amount = Credit::where('credit_on', 2)->where('transaction_no', $transaction_no)->pluck('amount')->first();

        //$item_name = ItemMaster::where('id', $transaction['item_id'])->se('title')->first();
        $itemData = ItemMaster::where('id', $transaction['item_id'])->select('title','title_ar','delar_id')->first();
        $item_name=$itemData['title'];
        $notification = [
            'notification_type' => 'I', // I - Individual
            'notification_for' => $notification_for, // '36 - REFUNDED',
            'notification_title' => 'Refund the purchase',
            'notification_message' => "Hi ".$fromuser_details->first_name.", ".$item_name." amount has been refunded",
            'notification_title_ar' =>'استرجاع مشتريات',
            'notification_message_ar' => 'هلا '.$fromuser_details->first_name.'، تم ارجاع قيمة هذا المنتج '.$itemData['title_ar'],
            'created_at' => date('Y-m-d H:i:s'),
            'item_id' => $transaction['item_id'],
            'offer_id' => $transaction['offer_id'],
            'transaction_no' => $transaction_no,
        ];
        $notificationId = Notification::insertGetId($notification);

        // Send notification to Consumer on Add Transaction
        NotificationLog::insert([
            'notification_id' => $notificationId,
            'notification_to' => $transaction['created_by'],
            'notification_for' => 'C', // Consumer
            'created_at' => date('Y-m-d H:i:s'),
        ]);


              
        $consumer_token = Driver::join('devices', 'drivers.id', '=', 'devices.user_id')
            ->where('drivers.id', $transaction['created_by'])
            ->where('devices.user_type', 'driver')
            ->where('devices.fcm','!=','')
            ->orderBy('devices.id', 'desc')
            ->select('devices.fcm','devices.device_type','drivers.preferred_language')->first();


        if(!empty($consumer_token)){
          $notificationTitle=$notification['notification_title'];
            $notificationMsg= $notification['notification_message'];
            if($consumer_token->preferred_language=='ar'){
                $notificationTitle=$notification['notification_title_ar'];
                $notificationMsg=$notification['notification_message_ar'];
            }
            $this->sendNotifyToUser( 
                $consumer_token->fcm,
                $notificationTitle,
                $notificationMsg,
                $notification['notification_for'],
                1,
                1,
                $notification['item_id'],
                $notification['offer_id'],
                'consumer',
                $notification['transaction_no'],
                $consumer_token->device_type
            );
        }

         // Deal admin 
         
          $delar_id =$itemData['delar_id'];
          
          $dealerData=User::where('org_id', $delar_id)
                ->where('status', 1)
                ->orderBy('id', 'asc')->select('id','preferred_language')->first();

            $dealer_notes = [
                'notification_id' => $notificationId,
                'notification_to' => $dealerData->id,
                'notification_for' => 'N', // Non Consumer
                'created_at' => date('Y-m-d H:i:s'),
            ];
       
            NotificationLog::insert($dealer_notes);

           // Send notification to Dealer on Add Transaction
            $dealer_token = Device::where('devices.user_id', $dealerData->id)
                ->where('devices.user_type', 'user')
                ->where('devices.fcm','!=','')
                ->orderBy('devices.id', 'desc')
                ->select('devices.fcm','devices.device_type')
                ->first();
            
            if(!empty($dealer_token)){
               $dealerToken=$dealer_token->fcm;
               $deviceType=$dealer_token->device_type;
                if($dealer_token->fcm != ''){

                    $notificationTitle=$notification['notification_title'];
                    $notificationMsg= $notification['notification_message'];
                    if($dealerData->preferred_language=='ar'){
                        $notificationTitle=$notification['notification_title_ar'];
                        $notificationMsg=$notification['notification_message_ar'];
                    }

                    $this->sendNotifyToUser(
                        $dealerToken,
                        $notificationTitle,
                        $notificationMsg,
                        $notification['notification_for'],
                        $fromuser_details->id,
                        $dealerData->id,
                        $notification['item_id'],
                        $notification['offer_id'],
                        'partner',
                        $notification['transaction_no'],
                        $deviceType
                    );
                }   
            }
        // End Deal admin 
    }

    public function redeem_notification($transaction_no, $notification_for) {
        Log::info('Redeem notification add start');
        $transaction = Transaction::where('transaction_no', $transaction_no)->first();
        if(!$transaction)
            return false;

        // Add notification to the Consumer
        $fromuser_details = Driver::where('id', $transaction['created_by'])->first();
         $itemData = ItemMaster::where('id', $transaction['item_id'])->select('title','title_ar','delar_id')->first();
        $item_name=$itemData['title'];

        $notification = [
            'notification_type' => 'I', // I - Individual
            'notification_for' => $notification_for, // '38 - REDEEMED',
            'notification_title' => 'Redeem offer',
            'notification_message' => 'Hi '.$fromuser_details->first_name.', Offer'.$item_name.' has been redeemed',
            'notification_title_ar' => 'Redeem offer',
            'notification_message_ar' => 'عهلا '.$fromuser_details->first_name.'، تم استخدام منتج رقم '.$itemData['title_ar'],
            'created_at' => date('Y-m-d H:i:s'),
            'item_id' => $transaction['item_id'],
            'offer_id' => $transaction['offer_id'],
            'transaction_no' => $transaction_no,
        ];
        $notificationId = Notification::insertGetId($notification);

        // Send notification to Consumer on Add Transaction
        NotificationLog::insert([
            'notification_id' => $notificationId,
            'notification_to' => $transaction['created_by'],
            'notification_for' => 'C', // Consumer
            'created_at' => date('Y-m-d H:i:s'),
        ]);



        // $consumer_token = Device::where('user_type', 'driver')
        //     ->where('user_id', $transaction['created_by'])
        //     ->orderBy('id', 'desc')
        //     ->select('fcm','device_type')->first();

         $consumer_token = Driver::join('devices', 'drivers.id', '=', 'devices.user_id')
            ->where('drivers.id', $transaction['created_by'])
            ->where('devices.user_type', 'driver')
            ->where('devices.fcm','!=','')
            ->orderBy('devices.id', 'desc')
            ->select('devices.fcm','devices.device_type','drivers.preferred_language')->first();

        if($consumer_token){
        
            $notificationTitle=$notification['notification_title'];
            $notificationMsg= $notification['notification_message'];
            if($consumer_token->preferred_language=='ar'){
                $notificationTitle=$notification['notification_title_ar'];
                $notificationMsg=$notification['notification_message_ar'];
            }

            $this->sendNotifyToUser(
                $consumer_token->fcm,
                $notificationTitle,
                $notificationMsg,
                $notification['notification_for'],
                1,
                1,
                $notification['item_id'],
                $notification['offer_id'],
                'consumer',
                $notification['transaction_no'],
                $consumer_token->device_type
            );
        }


         // Deal admin and technicians
          $itemData = ItemMaster::where('id', $transaction['item_id'])->select('title','title_ar','delar_id')->first();
          $delar_id =$itemData['delar_id'];


          // $dealerId=User::where('org_id', $delar_id)
          //   ->where('status', 1)
          //   ->where('role_id', 3)
          //   ->orderBy('id', 'asc')->pluck('id')->first();

            $dealerData=User::where('org_id', $delar_id)
                ->where('status', 1)
                ->where('role_id', 3)
                ->orderBy('id', 'asc')
                ->select('id','preferred_language')
                ->first();


            $dealer_notes = [
                'notification_id' => $notificationId,
                'notification_to' => $dealerData->id,
                'notification_for' => 'N', // Non Consumer
                'created_at' => date('Y-m-d H:i:s'),
            ];
       
            NotificationLog::insert($dealer_notes);

           // Send notification to Dealer on Add Transaction
            $dealer_token = Device::where('devices.user_id', $dealerData->id)
                ->where('devices.user_type', 'user')
                ->where('devices.fcm','!=','')
                ->orderBy('devices.id', 'desc')
                ->select('devices.fcm','devices.device_type')
                ->first();
            
            if(!empty($dealer_token)){
               $dealerToken=$dealer_token->fcm;
               $deviceType=$dealer_token->device_type;
                if($dealer_token->fcm != ''){
                   
                    $notificationTitle=$notification['notification_title'];
                    $notificationMsg= $notification['notification_message'];
                    if($dealerData->preferred_language=='ar'){
                        $notificationTitle=$notification['notification_title_ar'];
                        $notificationMsg=$notification['notification_message_ar'];
                    }

                    $this->sendNotifyToUser(
                        $dealerToken,
                        $notificationTitle,
                        $notificationMsg,
                        $notification['notification_for'],
                        $fromuser_details->id,
                        $dealerData->id,
                        $notification['item_id'],
                        $notification['offer_id'],
                        'partner',
                        $notification['transaction_no'],
                        $deviceType
                    );
                }   
            }
          

            if(Auth::user()->role_id=='8'){

              $technicians_note = [
                'notification_id' => $notificationId,
                'notification_to' => Auth::id(),
                'notification_for' => 'N', // Non Consumer
                'created_at' => date('Y-m-d H:i:s'),
              ];
       
              NotificationLog::insert($technicians_note);

               $technicians_tokens = Device::where('user_type', 'user')
                    ->where('user_id', Auth::id())
                    ->orderBy('id', 'desc')
                    ->select('fcm','device_type')->first();


                $technicianPreferredLanguage=User::where('id', Auth::id())
                ->where('status', 1)
                ->where('role_id', 8)
                ->orderBy('id', 'asc')
                ->pluck('preferred_language')
                ->first();



                if(!empty($technicians_tokens)){
                    $notificationTitle=$notification['notification_title'];
                    $notificationMsg= $notification['notification_message'];
                    if($technicianPreferredLanguage=='ar'){
                        $notificationTitle=$notification['notification_title_ar'];
                        $notificationMsg=$notification['notification_message_ar'];
                    }

                    $this->sendNotifyToUser(
                        $technicians_tokens->fcm,
                        $notificationTitle,
                        $notificationMsg,
                        $notification['notification_for'],
                        1,
                        1,
                        $notification['item_id'],
                        $notification['offer_id'],
                        'partner',
                        $notification['transaction_no'],
                        $technicians_tokens->device_type
                    );
                }
             
            } 

        // End Deal admin and technician
    }

    public function adjustment_notification($transaction_no, $notification_for) {
        Log::info('Adjustment notification add start');
        $transaction = Transaction::where('transaction_no', $transaction_no)->first();
        if(!$transaction)
            return false;

        // Add notification to the Consumer
        $fromuser_details = Driver::where('id', $transaction['created_by'])->first();
        $adjustment_amount = Credit::where('credit_on', 3)->where('transaction_no', $transaction_no)->pluck('amount')->first();
        //$item_name = ItemMaster::where('id', $transaction['item_id'])->pluck('title')->first();

         $itemData = ItemMaster::where('id', $transaction['item_id'])->select('title','title_ar','delar_id')->first();
         $item_name=$itemData['title'];
        $notification = [
            'notification_type' => 'I', // I - Individual
            'notification_for' => $notification_for, // '37 - ADJUSTMENT',
            'notification_title' => 'Transaction Adjustments',
            'notification_message' => 'Hai, '. $fromuser_details->first_name.
                ', your purchase on '.$item_name.
                ', adjustment amount: '.$adjustment_amount.', was added ',
            'notification_title_ar' => 'تعديل عملية الشراء',
            'notification_message_ar' => 'هلا '. $fromuser_details->first_name.
                '، تم تعديل قيمة عملية الشراء رقم '.$itemData['title_ar'].' الى: $adjustment_amount ريال',

            'created_at' => date('Y-m-d H:i:s'),
            'item_id' => $transaction['item_id'],
            'offer_id' => $transaction['offer_id'],
            'transaction_no' => $transaction_no,
        ];
        $notificationId = Notification::insertGetId($notification);

        // Send notification to Consumer on Add Transaction
        NotificationLog::insert([
            'notification_id' => $notificationId,
            'notification_to' => $transaction['created_by'],
            'notification_for' => 'C', // Consumer
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        // $consumer_token = Device::where('user_type', 'driver')
        //     ->where('user_id', $transaction['created_by'])
        //     ->orderBy('id', 'desc')
        //     ->select('fcm','device_type')->first();

         $consumer_token = Driver::join('devices', 'drivers.id', '=', 'devices.user_id')
            ->where('drivers.id', $transaction['created_by'])
            ->where('devices.user_type', 'driver')
            ->where('devices.fcm','!=','')
            ->orderBy('devices.id', 'desc')
            ->select('devices.fcm','devices.device_type','drivers.preferred_language')->first();


        if(!empty($consumer_token)){
            $notificationTitle=$notification['notification_title'];
            $notificationMsg= $notification['notification_message'];
            if($consumer_token->preferred_language=='ar'){
                $notificationTitle=$notification['notification_title_ar'];
                $notificationMsg=$notification['notification_message_ar'];
            }

            $this->sendNotifyToUser(
                $consumer_token->fcm,
                $notificationTitle,
                $notification['notification_message'],
                $notificationMsg,
                1,
                1,
                $notification['item_id'],
                $notification['offer_id'],
                'consumer',
                $notification['transaction_no'],
                $consumer_token->device_type
            );
        }

        // Deal admin 
         
          $delar_id =$itemData['delar_id'];
          // $dealerId=User::where('org_id', $delar_id)
          //   ->where('status', 1)
          //   ->where('role_id', 3)
          //   ->orderBy('id', 'asc')->pluck('id')->first();

            $dealerData=User::where('org_id', $delar_id)
                ->where('status', 1)
                ->where('role_id', 3)
                ->orderBy('id', 'asc')
                ->select('id','preferred_language')
                ->first();

            $dealer_notes = [
                'notification_id' => $notificationId,
                'notification_to' => $dealerData->id,
                'notification_for' => 'N', // Non Consumer
                'created_at' => date('Y-m-d H:i:s'),
            ];
       
            NotificationLog::insert($dealer_notes);

           // Send notification to Dealer on Add Transaction
            $dealer_token = Device::where('devices.user_id', $dealerData->id)
                ->where('devices.user_type', 'user')
                ->where('devices.fcm','!=','')
                ->orderBy('devices.id', 'desc')
                ->select('devices.fcm','devices.device_type')
                ->first();
            
            if(!empty($dealer_token)){
               $dealerToken=$dealer_token->fcm;
               $deviceType=$dealer_token->device_type;
                if($dealer_token->fcm != ''){

                    $notificationTitle=$notification['notification_title'];
                    $notificationMsg= $notification['notification_message'];
                    if($dealerData->preferred_language=='ar'){
                        $notificationTitle=$notification['notification_title_ar'];
                        $notificationMsg=$notification['notification_message_ar'];
                    }


                    $this->sendNotifyToUser(
                        $dealerToken,
                        $notificationTitle,
                        $notificationMsg,
                        $notification['notification_for'],
                        $fromuser_details->id,
                        $dealerData->id,
                        $notification['item_id'],
                        $notification['offer_id'],
                        'partner',
                        $notification['transaction_no'],
                        $deviceType
                    );
                }   
            }
        // End Deal admin 
    }

    public function sendCanceledNotifications($transaction_no, $created_by, $item_id, $offer_id, $notification_for, $type){
         Log::info('Cancel payment notification add start');

        $list = Transaction::where('transaction_no', $transaction_no)
            ->with('item', 'item.offer')
            ->first();

          $notification_title="Cancelled your pending payment";
          $notification_message='Incomplete payment for item name '.$list->item->offer->title." was cancelled";

          $notification_title_ar="Cancelled your pending payment";
          $notification_message_ar='Incomplete payment for item name '.$list->item->offer->title." was cancelled";

          if( $type=='Transaction'){
            $notification_title="Payment transaction was cancelled";
            $notification_message="You have cancelled your payment procesing for offer item name ".$list->item->offer->title;
            $notification_title_ar="Payment transaction was cancelled";
           $notification_message_ar="You have cancelled your payment procesing for offer item name ".$list->item->offer->title;
          } else if( $type=='Requests'){
            $notification_title="Cancelled your requested item availability information";
            $notification_message="Requested item availability for offer item name ".$list->item->offer->title." was cancelled";
            $notification_title_ar="Cancelled your requested item availability information";
            $notification_message_ar="Requested item availability for offer item name ".$list->item->offer->title." was cancelled";
          }

          $notification_for=$notification_for; //'31';

          $notification = [
            'notification_type' => 'I', // I - Individual
            'notification_for' => $notification_for, // '37 - ADJUSTMENT',
            'notification_title' =>$notification_title,
            'notification_message' =>$notification_message, 
            'notification_title_ar' => $notification_title_ar,
            'notification_message_ar' => $notification_message_ar, 
            'created_at' => date('Y-m-d H:i:s'),
            'item_id' => $item_id,
            'offer_id' => $offer_id,
            'transaction_no' => $transaction_no,
        ];


        $notificationId = Notification::insertGetId($notification);

        // Send notification to Consumer on Add Transaction
        NotificationLog::insert([
            'notification_id' => $notificationId,
            'notification_to' => $created_by,
            'notification_for' => 'C', // Consumer
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        // $consumer_token = Device::where('user_type', 'driver')
        //     ->where('user_id', $created_by)
        //     ->where('fcm','!=','')
        //     ->orderBy('id', 'desc')
        //     ->select('fcm','device_type')->first();

        $consumer_token = Driver::join('devices', 'drivers.id', '=', 'devices.user_id')
            ->where('drivers.id', $created_by)
            ->where('devices.user_type', 'driver')
            ->where('devices.fcm','!=','')
            ->orderBy('devices.id', 'desc')
            ->select('devices.fcm','devices.device_type','drivers.preferred_language')->first();

        if(!empty($consumer_token)){
            $notificationTitle=$notification['notification_title'];
            $notificationMsg= $notification['notification_message'];
            if($consumer_token->preferred_language=='ar'){
                $notificationTitle=$notification['notification_title_ar'];
                $notificationMsg=$notification['notification_message_ar'];
            }
            $this->sendNotifyToUser(
                $consumer_token->fcm,
                $notificationTitle,
                $notificationMsg,
                $notification['notification_for'],
                1,
                1,
                $notification['item_id'],
                $notification['offer_id'],
                'consumer',
                $notification['transaction_no'],
                $consumer_token->device_type
            );
        }

         Log::info('Cancel payment notification end');
    }

    public function gift_notification($gift_amount, $user_id, $notification_for) {
        Log::info('Gift notification add start');


        // Add notification to the Consumer
        $fromuser_details = Driver::where('id', $user_id)->first();
        $notification = [
            'notification_type' => 'I', // I - Individual
            'notification_for' => $notification_for, // '39 - Gift',
            'notification_title' => 'Gift Credits',
            'notification_message' => 'Hai, '. $fromuser_details->first_name.
                ', Gift amount: '.$gift_amount.', was credited to your account',
            'notification_title_ar' => 'Gift Credits',
            'notification_message_ar' => 'Hai, '. $fromuser_details->first_name.
                ', Gift amount: '.$gift_amount.', was credited to your account',
            'created_at' => date('Y-m-d H:i:s'),
            'item_id' => null,
            'offer_id' => null,
            'transaction_no' => null,
            'is_popup'=>'1'
        ];

        $notificationId = Notification::insertGetId($notification);

        // Send notification to Consumer on Add Transaction
        NotificationLog::insert([
            'notification_id' => $notificationId,
            'notification_to' => $user_id,
            'notification_for' => 'C', // Consumer
            'created_at' => date('Y-m-d H:i:s'),
        ]);

       $consumer_token = Driver::join('devices', 'drivers.id', '=', 'devices.user_id')
            ->where('drivers.id', $user_id)
            ->where('devices.user_type', 'driver')
            ->where('devices.fcm','!=','')
            ->orderBy('devices.id', 'desc')
            ->select('devices.fcm','devices.device_type','drivers.preferred_language')->first();

        if(!empty($consumer_token)){
            $notificationTitle=$notification['notification_title'];
            $notificationMsg= $notification['notification_message'];
            if($consumer_token->preferred_language=='ar'){
                $notificationTitle=$notification['notification_title_ar'];
                $notificationMsg=$notification['notification_message_ar'];
            }

            $this->sendNotifyToUser(
                $consumer_token->fcm,
                $notificationTitle,
                $notificationMsg,
                $notification['notification_for'],
                1,
                1,
                null,
                null,
                'consumer',
                null,
                $consumer_token->device_type
            );
        }
    }

    //transaction payment success sent notification


    /**
     * Request consumer current location if purchased deal is onsite by technician
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */


    public function requestAddressForOnsite($transaction_no, $notification_for) {
        Log::info('Request addrees notification start');
        $transaction = Transaction::where('transaction_no', $transaction_no)->first();
        if(!$transaction)
            return response()->json(['status' => 'failed', 'message' => 'Invalid Transaction','message_ar'=>'معاملة غير صالحة'], 400);

        // Add notification to the Consumer
        $fromuser_details = Driver::where('id', $transaction['created_by'])->first();

        $notification = [
            'notification_type' => 'I', // I - Individual
            'notification_for' => $notification_for, // 42 - Request for onsite address
            'notification_title' => 'Request for address',
            'notification_message' => isset(Auth::user()->first_name)? Auth::user()->first_name.
                '  requested and address for Transaction Number: '.$transaction_no :
                'Requested an address for transaction Number: '.$transaction_no,
            'notification_title_ar' => 'Request for address',
            'notification_message_ar' => isset(Auth::user()->first_name)? Auth::user()->first_name.
                '  requested and address for Transaction Number: '.$transaction_no :
                'Requested an address for transaction Number: '.$transaction_no,
            'created_at' => date('Y-m-d H:i:s'),
            'item_id' => $transaction['item_id'],
            'offer_id' => $transaction['offer_id'],
            'transaction_no' => $transaction_no,
        ];
        $notificationId = Notification::insertGetId($notification);

        // Send notification to Consumer on Add Transaction
        NotificationLog::insert([
            'notification_id' => $notificationId,
            'notification_to' => $transaction['created_by'],
            'notification_for' => 'C', // Consumer
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        $consumer_token = Driver::join('devices', 'drivers.id', '=', 'devices.user_id')
            ->where('drivers.id', $transaction['created_by'])
            ->where('devices.user_type', 'driver')
            ->where('devices.fcm','!=','')
            ->orderBy('devices.id', 'desc')
            ->select('devices.fcm','devices.device_type','drivers.preferred_language')->first();
       
        if(!empty($consumer_token)){
            $notificationTitle=$notification['notification_title'];
            $notificationMsg= $notification['notification_message'];
            if($consumer_token->preferred_language=='ar'){
                $notificationTitle=$notification['notification_title_ar'];
                $notificationMsg=$notification['notification_message_ar'];
            }

            $this->sendNotifyToUser(
                $consumer_token->fcm,
                $notificationTitle,
                $notificationMsg,
                $notification['notification_for'],
                1,
                1,
                $notification['item_id'],
                $notification['offer_id'],
                'consumer',
                $notification['transaction_no'],
                $consumer_token->device_type
            );
        }

        Log::info('Request addrees notification end');
        return response()->json(['status' => 'success', 'message' => 'Notification Sent', 'message_ar' => 'موقع المستخدم المطلوب بنجاح'], 200);
    }

  
   /**
     * Send notification to technicians when consumer submit their current location for onsite
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function sendAddressForOnsite($transaction_no, $notification_for) {
        Log::info('Send address start');
        $transaction = Transaction::where('transaction_no', $transaction_no)->first();
        if(!$transaction)
            return response()->json(['status' => 'failed', 'message' => 'Invalid Transaction'], 400);

        // Add notification to the Consumer
        $fromuser_details = Driver::where('id', $transaction['created_by'])->first();
        $notification = [
            'notification_type' => 'I', // I - Individual
            'notification_for' => $notification_for, // '43 - Send address for onsite',
            'notification_title' => 'Consumer currect location',
            'notification_message' => isset($fromuser_details->first_name)? $fromuser_details->first_name.
                ' sent current location for Transaction Number: '.$transaction_no :
                ' customer sent current location for Transaction Number: '.$transaction_no,
            'notification_title_ar' => 'Consumer currect location',
            'notification_message_ar' => isset($fromuser_details->first_name)? $fromuser_details->first_name.
                ' sent current location for Transaction Number: '.$transaction_no :
                ' customer sent current location for Transaction Number: '.$transaction_no,
            'created_at' => date('Y-m-d H:i:s'),
            'item_id' => $transaction['item_id'],
            'offer_id' => $transaction['offer_id'],
            'transaction_no' => $transaction_no,
        ];
        $notificationId = Notification::insertGetId($notification);

        // Send notification to Consumer on Add Transaction
        NotificationLog::insert([
            'notification_id' => $notificationId,
            'notification_to' => $transaction['created_by'],
            'notification_for' => 'C', // Consumer
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        $consumer_token = Driver::join('devices', 'drivers.id', '=', 'devices.user_id')
            ->where('drivers.id', $transaction['created_by'])
            ->where('devices.user_type', 'driver')
            ->where('devices.fcm','!=','')
            ->orderBy('devices.id', 'desc')
            ->select('devices.fcm','devices.device_type','drivers.preferred_language')->first();

       
        if(!empty($consumer_token)){
             $notificationTitle=$notification['notification_title'];
            $notificationMsg= $notification['notification_message'];
            if($consumer_token->preferred_language=='ar'){
                $notificationTitle=$notification['notification_title_ar'];
                $notificationMsg=$notification['notification_message_ar'];
            }
            $this->sendNotifyToUser(
                $consumer_token->fcm,
                $notificationTitle,
                $notificationMsg,
                $notification['notification_for'],
                1,
                1,
                $notification['item_id'],
                $notification['offer_id'],
                'consumer',
                $notification['transaction_no'],
                $consumer_token->device_type
            );
        }

        // Add notification to Technician on Add Transaction if offer is onsite 
       
        $itemData = ItemOffer::where('id', $transaction['offer_id'])->first();

        if($itemData->on_site=='1'){ 

             $delar_id = ItemMaster::where('id', $transaction['item_id'])->pluck('delar_id')->first();

            
            $dealerData=User::where('org_id', $delar_id)
                ->where('status', 1)
                ->orderBy('id', 'asc')
                ->select('id','preferred_language')
                ->first();


            $dealer_notes = [
                'notification_id' => $notificationId,
                'notification_to' => $dealerData->id,
                'notification_for' => 'N', // Techinicians
                'created_at' => date('Y-m-d H:i:s'),
            ];


            NotificationLog::insert($dealer_notes);
           // Send notification to Dealer on Add Transaction
         

            $dealer_token = Device::where('devices.user_id', $dealerData->id)
                ->where('devices.user_type', 'user')
                ->where('devices.fcm','!=','')
                ->orderBy('devices.id', 'desc')
                ->select('devices.fcm','devices.device_type')
                ->first();
           
          

            if(!empty($dealer_token)){
               $dealerToken=$dealer_token->fcm;
               $deviceType=$dealer_token->device_type;
                if($dealer_token->fcm != ''){

                     $notificationTitle=$notification['notification_title'];
                    $notificationMsg= $notification['notification_message'];
                    if($dealerData->preferred_language=='ar'){
                        $notificationTitle=$notification['notification_title_ar'];
                        $notificationMsg=$notification['notification_message_ar'];
                    }


                    $this->sendNotifyToUser(
                        $dealerToken,
                        $notificationTitle,
                        $notificationMsg,
                        $notification['notification_for'],
                        $fromuser_details->id,
                        $dealerData->id,
                        $notification['item_id'],
                        $notification['offer_id'],
                        'partner',
                        $notification['transaction_no'],
                        $deviceType
                    );
                }   
            }


            $technicians = User::join('technician_locations as tl', 'users.id', '=', 'tl.technician_id')
                ->where('users.org_id', $delar_id)
                ->where('users.status', 1)
                ->where('tl.location_id', $transaction['location_id'])
                ->pluck('users.id');

            if(!$technicians)
                return response()->json(['status' => 'success', 'message' => 'Firebase Notifications not available'], 200);

            $tech_notes = [];
            foreach ($technicians as $techid){
                $tech_notes[] = [
                    'notification_id' => $notificationId,
                    'notification_to' => $techid,
                    'notification_for' => 'N', // Non Consumer
                    'created_at' => date('Y-m-d H:i:s'),
                ];
            }
            NotificationLog::insert($tech_notes);
            // Send notification to Technician on Add Transaction
            $technicians_tokens = User::join('technician_locations as tl', 'users.id', '=', 'tl.technician_id')
                ->join('devices', 'users.id', '=', 'devices.user_id')
                ->where('users.org_id', $delar_id)
                ->where('users.status', 1)
                ->where('tl.location_id', $transaction['location_id'])
                ->where('devices.user_type', 'user')
                ->orderBy('devices.id', 'desc')
                ->select('devices.fcm','tl.technician_id','devices.device_type','users.preferred_language')->get();


            if(!empty($technicians_tokens)){
                foreach($technicians_tokens as $singleTechnician){ 
                   $technicianId=$singleTechnician->technician_id;
                   $technicians_tokens=$singleTechnician->fcm;
                   $technicians_device_type=$singleTechnician->device_type;
                    if($technicians_tokens){ 

                        $notificationTitle=$notification['notification_title'];
                        $notificationMsg= $notification['notification_message'];
                        if($singleTechnician->preferred_language=='ar'){
                            $notificationTitle=$notification['notification_title_ar'];
                            $notificationMsg=$notification['notification_message_ar'];
                        }

                        
                        $this->sendNotifyToUser(
                            $technicians_tokens,
                            $notificationTitle,
                            $notificationMsg,
                            $notification['notification_for'],
                            $fromuser_details->id,
                            $technicianId,
                            $notification['item_id'],
                            $notification['offer_id'],
                            'partner',
                            $notification['transaction_no'],
                            $technicians_device_type
                        );
                    }
                }    
            }
        }

        Log::info('Send address end');
        return response()->json(['status' => 'success', 'message' => 'Your address location Sent Successfully','message_ar'=> 'تم إرسال موقع عنوانك بنجاح'], 200);
    }



   /**
     * Send custom notification to selected consumers
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function send_custom_notifications(Request $request)
    {
        $request['consumers'] = json_decode($request['consumers'], true );
        $rules = [
            'is_inapp' => ['required'],
            'is_firebase' => ['required'],
            'is_popup' => ['required'],
            'consumers' => ['required'],
        ];

        if($request->is_inapp || $request->is_firebase)
        {
            $rules = array_merge($rules, array(
                'notification_title' => 'required',
                'notification_title_ar' => 'required',
                'notification_message' => 'required',
                'notification_message_ar' => 'required',
            ));
        }

        $messages = [
            'notification_title_ar.required'=> 'Arabic notification title is required',
            'notification_message_ar.required'=> 'Arabic notification message title is required' // custom message
        ];

        $validator = Validator::make($request->all(), $rules, $messages);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if($request->is_popup){
            if ($file=$request->file('thumbnail')) {
                if(config('app.env') == 'local'){
                    $extension = $file->extension()?: 'png';
                    $destinationPath = public_path() . '/uploads/notifications/';
                    $safeName = Str::random(10) . '.' . $extension;
                    $file->move($destinationPath, $safeName);
                    $request['thumbnail_url'] = '/uploads/notifications/'.$safeName;
                } else {
                    $file_name = Storage::disk('s3')->put('uploads/notifications/', $request->file('thumbnail'));
                    $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
                }
            } else {
                return response()->json(['status' => 'failed','message' => 'Thumbnail is required'], 400);  
            }
        }

        try{
          $data = $this->sendNotificationToConsumers($request);
          return response()->json(['status'=> 'success', 'message'=> 'Custom messages sent successfully', "data" => $data ], 200);
        }
        catch (\Exception $e){
            return response()->json([
                'status' => 'failed',
                'message' => 'Sent custom notification failed',
                'results' => $request['consumers'],
                "error" => $e->getMessage() ], 400);
        }
    }

    /**
     * Get selected consumers to Send custom notifications details
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function sendNotificationToConsumers($request){
 
        $consumersList= $request['consumers'];
        $groups = $individuals = [];

        foreach ($consumersList as $consumer)
        {
            if(isset($consumer['send_for']) && $consumer['send_for'] == "10")
                array_push($groups, $consumer);
            else
                array_push($individuals, $consumer);
        }

        $group_ids = array_column($groups, 'send_to');
        $individual_filters = [];
        if(count($group_ids) > 0){
            // ignore if individual User was already in Group
            foreach ($individuals as $individual)
            {
                if(GroupConsumer::where('consumer_id', $individual['send_to'])->whereIn('group_id', $group_ids)->count() == 0)
                    array_push($individual_filters, $individual); // if user not available on the group
            }
        }
        else
            $individual_filters = $individuals;

        $request['notification_type'] = 'I'; // I - Individual
        $request['notification_for'] = 44; // '44 - Custom message',
        $request['created_at'] = date('Y-m-d H:i:s');
        $request['expired_on'] = date('Y-m-d', strtotime("+15 days"));
        $notification = $request->except('consumers', 'thumbnail');

        try{
            $notificationId = Notification::insertGetId($request->except('consumers', 'thumbnail'));
        }catch (\Exception $e){
            Log::error($e->getMessage());
            return $e->getMessage();
        }

        foreach ($groups as $consumer)
        {
            $group_users = GroupConsumer::where('group_id', $consumer['send_to'])->get();
            $groupId=$consumer['send_to'];
            foreach($group_users as $user){
                $this->sendCustomMessage(
                    $notification,
                    $user['consumer_id'],
                    $request['is_inapp'],
                    $request['is_firebase'],
                    $request['is_popup'],
                    $notificationId,
                    $groupId,
                    $request['thumbnail_url']
                );
            }
        }

        foreach ($individual_filters as $consumer) {
            $this->sendCustomMessage(
                $notification,
                $consumer['send_to'],
                $request['is_inapp'],
                $request['is_firebase'],
                $request['is_popup'],
                $notificationId,
                0,
                $request['thumbnail_url']
            );
        }
    }

    /**
     * Send custom notifications details to for each consumers
     *
     * @return \Illuminate\Http\Response
     */


   public function sendCustomMessage($notification, $user_id, $isInapp, $isFirebase, $isPopup, $notificationId, $groupId, $imageUrl) {
        Log::info('Custom notification add start');

        // Add notification to the Consumer
        $fromuser_details = Driver::where('id', $user_id)->first();
       
        // Send notification to Consumer on Add Transaction
        NotificationLog::insert([
            'notification_id' => $notificationId,
            'notification_to' => $user_id,
            'group_id' => $groupId,
            'notification_for' => 'C', // Consumer
            'created_at' => date('Y-m-d H:i:s'),
        ]);
       
        if($isFirebase){
           $consumer_token = Driver::join('devices', 'drivers.id', '=', 'devices.user_id')
                ->where('drivers.id', $user_id)
                ->where('devices.user_type', 'driver')
                ->where('devices.fcm','!=','')
                ->orderBy('devices.id', 'desc')
                ->select('devices.fcm','devices.device_type','drivers.preferred_language')->first();

            if(!empty($consumer_token)){
                $notificationTitle=$notification['notification_title'];
                $notificationMsg= $notification['notification_message'];
                if($consumer_token->preferred_language=='ar'){
                    $notificationTitle=$notification['notification_title_ar'];
                    $notificationMsg=$notification['notification_message_ar'];
                }

                $this->sendNotifyToUser(
                    $consumer_token->fcm,
                    $notificationTitle,
                    $notificationMsg,
                    $notification['notification_for'],
                    1,
                    1,
                    null,
                    null,
                    'consumer',
                    null,
                    $consumer_token->device_type,
                    '',
                    $imageUrl
                );
            }
        }
    }

   /**
     * Access: Customer, prefix: customer
     * Get all popup notifications details
     *
     * @return \Illuminate\Http\Response
     */
    function getPopMessages(){ 
        
        if(Auth::guard('driver')->id()){
            $user_id = Auth::guard('driver')->id();
            $type='C'; // Customer  
        } else { //Technicians or deal providers or service provider
            $user_id = Auth::id();
            $type='N'; // Non customer - delar technician, M & S Technician
        }

        if(isset(request()->device_id) && request()->device_id!=''){
            $user_id = request()->device_id;
        }

        if(isset(request()->user_type) && request()->user_type!=''){
            $type=request()->user_type;
        }

        try{
            $popUpnotifications = Notification::select('notifications.*')
                ->join('notifications_log', 'notifications.id', 'notifications_log.notification_id')
                ->where('notifications_log.notification_to', $user_id)
                ->where('notifications_log.notification_for', $type)
                ->where('notifications.is_popup', '1')
                ->where('notifications.is_sent','1')
                ->whereNull('notifications_log.deleted_at')
                ->whereNull('notifications_log.read_popup_at')
                ->with('deal', 'offer','location_info', 'deal.deal', 'transaction', 'transaction.payment_details')
                ->orderBy('notifications.id', 'asc');
            $popupCount=$popUpnotifications->count();

            $popUpnotifications = $popUpnotifications->first();

            if($popUpnotifications){   

                if($popUpnotifications->location_id){
                    $popUpnotifications->city=$popUpnotifications->location_info->city;
                    $popUpnotifications->deal_id=$popUpnotifications->deal->deal_id;
                    unset($popUpnotifications['offer']);
                    unset($popUpnotifications['deal']);
                    unset($popUpnotifications['location_info']);
                }

                // read popup notification as default
                $update = array('read_popup_at' => date('Y-m-d H:i:s'));
                if(!$popUpnotifications->is_inapp)
                {
                    // if notification doesn't has in-app notification then read this
                    $update['read_at'] = date('Y-m-d H:i:s');
                }

                NotificationLog::where('notification_to', $user_id)
                    ->with('notification_list')
                    ->where('notification_for', $type)
                    ->where('notification_id', $popUpnotifications->id)
                    ->whereNull('read_popup_at')
                    ->update($update);

            }

            return response()->json([
                'status' => 'success',
                'data' => array(
                    'count' => $popupCount,
                    "is_read" => ($popupCount > 0 ? 1 : 0), // 1 - Yet to read,  0 - read
                    'list' => $popUpnotifications
                ),
            ], 200);

        } catch (\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Notifications failed', "error" => $e->getMessage()], 400);
        }
    }

    /**
     * Get all notification format details
     *
     * @return \Illuminate\Http\Response
     */
    function formate_notifications_list(Request $request){
         try{
            // read notifications which are not read
            $pageno = 1; $pagelength = 10;
            $list = NotificationsFormats::orderBy('id', 'desc');
            $totalrecords = $list->count();
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
            }
            $list = $list->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status'=>'success', 'data' => $data], 200);

        } catch (\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Notifications failed', "error" => $e->getMessage()], 400);
        }
    }

    /**
     * Get notification format details 
     *
     *  @param  $id
     * @return \Illuminate\Http\Response
     */

    function getNotificationData($id){
        try
        {
          $data = NotificationsFormats::where('id',$id)->first();
          return response()->json(['status'=>'success', 'data' => $data], 200);
        } catch (\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Notifications failed', "error" => $e->getMessage()], 400);
        }
    }


    /**
     * Modify notification format details 
     *
     * @param  \Illuminate\Http\Request  $request
     * * @param  $id
     * @return \Illuminate\Http\Response
     */ 
    public function update_notification(Request $request, $id)
    {
        $validator = Validator::make($request->all(),
            [
                'notification_title'    => 'required|string|max:255',
                'notification_message'    => ['required'],
                'notification_title_ar'   => 'required|string|max:255',
                'notification_message_ar'   => ['required'],
                'sms_message'   => 'required',
                'sms_message_ar'   => ['required'],
                'status'   => ['required'],
                'expired_on'   => ['required']
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $request['updated_at'] = date('Y-m-d H:i:s');
            NotificationsFormats::where('id', $id)->update($request->all());
            return response()->json(['status'=>'success', 'message'=> 'Notification Details Updated Successfully'], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Notification Updation Failed'], 400);
        }
    }


    /*
    Get total count for individual and group counts
    
    */
    public function format_custom_notifications($row){
        $row['custom_individual_count']=count($row['custom_individual']);
        $row['custom_groups_count']=count($row['custom_groups']);

        unset($row['custom_individual']);
        unset($row['custom_groups']);
        return $row;
    }


    public function send_success_tran_alert($transaction_no) {
        try{
            $contact_no = env('PAYMENT_ALERT_TO', '+966557787687');
            $trans = Transaction::where('transaction_no', $transaction_no)->first();
            if(!$trans)
                return false;

            $item = ItemMaster::where('id', $trans['item_id'])->first();

            $text = 'Transaction ('.$transaction_no.') was successfully paid for item: '.$item['title'];
            if(env('APP_OTP') != 'production')
                return false;

            $response = Unifonic::send($contact_no, $text, env('UNIFONIC_SENDER_ID'));
            if($response->success == true){
                Log::info('Send OTP:: response : '. json_encode($response));
                return response()->json(['status'=>'success', 'message'=> 'Send OTP success', 'data' => $response]);
            }else{
                Log::info('Send OTP:: response : '. json_encode($response));
                return response()->json(['status'=>'failed', 'message'=> 'Send OTP Failed'], 400);
            }
        }catch (\Exception $e) {
            return response()->json(['status'=>'failed', 'message'=> 'Send OTP Failed', "error" => $e ], 400);
        }
    }
}
