<?php

namespace App\Http\Controllers\Generals;

use App\Http\Controllers\Controller;
use App\Models\Accounts\FleetDriver;
use App\Models\Accounts\PaymentShare;
use App\Models\Accounts\Transaction;
use App\Models\Accounts\TransactionDetail;
use App\Models\Accounts\Vehicle;
use App\Models\Generals\Deal;
use App\Models\Inventory\ItemMaster;
use App\Models\Regulatory\Organization;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class DealController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $list = Deal::where('status', 1)->orderBy('sort_order', 'asc')->get();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Get all available list based on the pagination
     * @param $request
     * @access in admin module
     * 
     */
    public function deals_all(Request $request)
    {
        //$list = Deal::orderBy('sort_order', 'asc')->get();

        $list = Deal::orderBy('sort_order', 'asc');
        $pageno = 0; $pagelength = 0; 
        $totalrecords = $list->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
            $list = $list->skip( ($pageno-1)*$pagelength )->take($pagelength);
        }  
            
        $list=$list->get();
          
        $data['data'] = $list;
        $data['current_page'] =$pageno ? $pageno : '1';
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength ? $pagelength : '200';

        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    /*
     * Prefix: customer, api, Users: Customer, Admin
     * For Customer: Home page deals are listed from here
     * Admin: Deals list for finance dealer transaction search
     */
    public function deals_list()
    {
        $list = Deal::where('id', '!=', 9)->where('status', 1)->orderBy('sort_order', 'asc')->get();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'title'    => ['required', 'string', 'max:20', 'unique:deals' ],
                'thumbnail'=> ['required', 'mimes:jpeg,jpg,png'],
                'action_type'=> ['required'],
                'sort_order'=> ['required'],
                'status'   => ['required']
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }


        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/deals/list/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/deals/list/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('deals/list/', $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        try{

            $request['created_at'] = date('Y-m-d H:i:s');
            Deal::insert($request->except('thumbnail'));
            return response()->json(['status'=>'success', 'message'=> 'Deal Created Successfully'], 200);
        }
        catch (\Exception $e)
        {
            //return $e;
            return response()->json(['status'=>'failed', 'message'=> 'Deal Creation Failed'], 400);
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        try{
            $deal = Deal::where('id', $id)->first();
            return response()->json(['status'=>'success', 'data'=> $deal], 200);
        }
        catch (\Exception $e)
        {
            //return $e;
            return response()->json(['status'=>'failed', 'message'=> 'No Deal Found'], 400);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(),
            [
                'title'    => ['required', 'string', 'max:20', 'unique:deals,title,'.$id],
                'thumbnail'=> ['nullable', 'mimes:jpeg,jpg,png'],
                'action_type'=> ['required'],
                'sort_order'=> ['required'],
                'status'   => ['required']
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/deals/list/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/deals/list/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('deals/list/', $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        try{

            $request['updated_at'] = date('Y-m-d H:i:s');
            Deal::where('id', $id)->update($request->except('thumbnail'));
            return response()->json(['status'=>'success', 'message'=> 'Deal Updated Successfully'], 200);
        }
        catch (\Exception $e)
        {
            //return $e;
            return response()->json(['status'=>'failed', 'message'=> 'Deal Updation Failed'], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function all_offers($city_id = null){

        $consumer_id = Auth::guard('driver')->id();
        // 4 - Cleaning , 5 - Detailing
        $list = ItemMaster::where('item_master.status', 1)->whereIn('item_master.deal_id', [4,5])
            ->join('item_offers', 'item_offers.item_id', 'item_master.id')
            ->with('delar', 'delar.location');


        $list = $list->with('minoffer', 'minoffer.vehicle_owners', 'minoffer.locations')
            ->whereRaw('item_offers.end_date >= (DATE(NOW()) - INTERVAL 7 DAY)')
            ->where('item_offers.quantity', '>', 0);

        // eligible vehicle offers only start
        if(Vehicle::where('owner_id', $consumer_id)->where('status', 1)->count() > 0) {
            // If consumer dont have vehicles all effective offers will be listed
            $list = $list->join('deal_vehicles', 'deal_vehicles.offer_id', 'item_offers.id')
                ->join('vehicles', 'vehicles.group_id', 'deal_vehicles.group_id')
                ->where('vehicles.status', 1)
                ->where('vehicles.owner_id', $consumer_id);
        }

        $list = $list->with(['minoffer.vehicle_owners' => function($query) use ($consumer_id){
            // only offer effected for that customer
            $query->where('vehicles.owner_id', $consumer_id);
        }]);
        // eligible vehicle offers only end

        // offers locations only by city
        $list = $list->join('offer_locations', 'offer_locations.offer_id', 'item_offers.id')
            ->join('locations', 'locations.id', 'offer_locations.location_id');
        $list = $list->where('locations.city', $city_id);

        $list = $list->with(['minoffer.locations' => function ($query) use ($city_id){
            // only search city locations
            $query->where("locations.city", $city_id);
        }]);

        $list = $list->select('item_master.*', DB::raw('item_offers.id as offer_id'),
            'item_offers.discount', 'offer_locations.location_id')->distinct();
        $list1 = $list->orderBy('item_offers.discount', 'desc')->orderBy('item_master.id', 'desc')->get()->toArray();


        // 2 - Tires, 6 - Batteries
        $list = ItemMaster::where('item_master.status', 1)->whereIn('item_master.deal_id', [2,6])
            ->join('item_offers', 'item_offers.item_id', 'item_master.id')
            ->with('delar', 'delar.location');


        $list = $list->with('minoffer', 'minoffer.locations')
            ->whereRaw('item_offers.end_date >= (DATE(NOW()) - INTERVAL 7 DAY)')
            ->where('item_offers.quantity', '>', 0);

        // offers locations only by city
        $list = $list->join('offer_locations', 'offer_locations.offer_id', 'item_offers.id')
            ->join('locations', 'locations.id', 'offer_locations.location_id');
        $list = $list->where('locations.city', $city_id);

        $list = $list->with(['minoffer.locations' => function ($query) use ($city_id){
            // only search city locations
            $query->where("locations.city", $city_id);
        }]);

        $list = $list->select('item_master.*', DB::raw('item_offers.id as offer_id'),
            'item_offers.discount', 'offer_locations.location_id')->distinct();
        $list2 = $list->orderBy('item_offers.discount', 'desc')->orderBy('item_master.id', 'desc')->get()->toArray();

        $data = array_merge($list1,$list2);

        foreach($data as $row){
            $pricing = $this->price_logic($row['minoffer']['price'], $row['minoffer']['discount'], $row['deal_id']);

            $row['minoffer']['discount'] = $pricing['final_price'];
            $row['minoffer']['vat'] = $pricing['vat'];
        }

        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    public function all_delars($city_id = null){
        $data = Organization::join('locations', 'organizations.id', 'locations.org_id')
            ->join('cities', 'cities.id', 'locations.city')
            ->select('organizations.id', 'organizations.org_name', 'organizations.org_name_ar', 'organizations.thumbnail_url',
                DB::raw('locations.id as location_id, locations.latitude as loc_lat, locations.longitude as loc_long, locations.primary'),
                'cities.city', DB::raw('cities.id as city_id, cities.latitude as city_lat, cities.longitude as city_long') )
            ->where('organizations.status', 1)
            ->where('locations.status', 1);
        if($city_id)
            $data = $data->where('locations.city', $city_id);
        $data = $data->get();

        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    public function delar_offers(Request $request){
        $delar_id = $request->delar_id;
        $city_id = $request->city_id;
        $consumer_id = Auth::guard('driver')->id();

        $list = ItemMaster::where('item_master.status', 1)->where('item_master.delar_id', $delar_id)
            ->join('item_offers', 'item_offers.item_id', 'item_master.id')
            ->with('delar', 'delar.location');


        $list = $list->with('minoffer', 'minoffer.vehicle_owners', 'minoffer.locations')
            ->whereRaw('item_offers.end_date >= (DATE(NOW()) - INTERVAL 7 DAY)')
            ->where('item_offers.quantity', '>', 0);

        // eligible vehicle offers only start
        if(Vehicle::where('owner_id', $consumer_id)->where('status', 1)->count() > 0) {
            // If consumer dont have vehicles all effective offers will be listed
            $list = $list->join('deal_vehicles', 'deal_vehicles.offer_id', 'item_offers.id')
                ->join('vehicles', 'vehicles.group_id', 'deal_vehicles.group_id')
                ->where('vehicles.status', 1)
                ->where('vehicles.owner_id', $consumer_id);
        }

        $list = $list->with(['minoffer.vehicle_owners' => function($query) use ($consumer_id){
            // only offer effected for that customer
            $query->where('vehicles.owner_id', $consumer_id);
        }]);
        // eligible vehicle offers only end

        // offers locations only by city
        $list = $list->join('offer_locations', 'offer_locations.offer_id', 'item_offers.id')
            ->join('locations', 'locations.id', 'offer_locations.location_id');
        $list = $list->where('locations.city', $city_id);

        $list = $list->with(['minoffer.locations' => function ($query) use ($city_id){
            // only search city locations
            $query->where("locations.city", $city_id);
        }]);

        if(isset($request->latitude) && isset($request->longitude)){
            $latitude=$request->latitude;
            $longitude=$request->longitude;

            $sql_distance = DB::raw("round((((acos(sin((".$latitude."*pi()/180)) * sin((locations.latitude*pi()/180))+cos((".$latitude."*pi()/180)) * cos((locations.latitude*pi()/180)) * cos(((".$longitude."-locations.longitude)*pi()/180))))*180/pi())*60*1.1515*1.609344),2) as distance");

            $list = $list->select('item_master.*',$sql_distance, DB::raw('item_offers.id as offer_id'), 'item_offers.discount', 'offer_locations.location_id')->orderBy('distance','ASC')->distinct();
        } else {
            $list = $list->select('item_master.*',DB::raw('0 as distance'), DB::raw('item_offers.id as offer_id'), 'item_offers.discount', 'offer_locations.location_id')->distinct();
        }

        //$list = $list->select('item_master.*', DB::raw('item_offers.id as offer_id'), 'item_offers.discount', 'offer_locations.location_id')->distinct();
        $list1 = $list->orderBy('item_offers.discount', 'desc')->orderBy('item_master.id', 'desc')->get()->toArray();


        // 2 - Tires, 6 - Batteries
        $list = ItemMaster::where('item_master.status', 1)->whereIn('item_master.deal_id', [2,6])
            ->join('item_offers', 'item_offers.item_id', 'item_master.id')
            ->with('delar', 'delar.location');


        $list = $list->with('minoffer', 'minoffer.locations')
            ->whereRaw('item_offers.end_date >= (DATE(NOW()) - INTERVAL 7 DAY)')
            ->where('item_offers.quantity', '>', 0);

        // offers locations only by city
        $list = $list->join('offer_locations', 'offer_locations.offer_id', 'item_offers.id')
            ->join('locations', 'locations.id', 'offer_locations.location_id');
        $list = $list->where('locations.city', $city_id);

        $list = $list->with(['minoffer.locations' => function ($query) use ($city_id){
            // only search city locations
            $query->where("locations.city", $city_id);
        }]);

        if(isset($request->latitude) && isset($request->longitude)){
            $latitude=$request->latitude;
            $longitude=$request->longitude;

            $sql_distance = DB::raw("round((((acos(sin((".$latitude."*pi()/180)) * sin((locations.latitude*pi()/180))+cos((".$latitude."*pi()/180)) * cos((locations.latitude*pi()/180)) * cos(((".$longitude."-locations.longitude)*pi()/180))))*180/pi())*60*1.1515*1.609344),2) as distance");

            $list = $list->select('item_master.*',$sql_distance, DB::raw('item_offers.id as offer_id'), 'item_offers.discount', 'offer_locations.location_id')->orderBy('distance','ASC')->distinct();
        } else {
            $list = $list->select('item_master.*',DB::raw('0 as distance'), DB::raw('item_offers.id as offer_id'), 'item_offers.discount', 'offer_locations.location_id')->distinct();
        }

        //$list = $list->select('item_master.*', DB::raw('item_offers.id as offer_id'), 'item_offers.discount', 'offer_locations.location_id')->distinct();
        $list2 = $list->orderBy('item_offers.discount', 'desc')->orderBy('item_master.id', 'desc')->get()->toArray();

        $data = array_merge($list1,$list2);

        foreach($data as $row){
            $pricing = $this->price_logic($row['minoffer']['price'], $row['minoffer']['discount'], $row['deal_id']);

            $row['minoffer']['discount'] = $pricing['final_price'];
            $row['minoffer']['vat'] = $pricing['vat'];
        }

        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    public function price_logic($price, $discount, $deal_id){
        $price = (float)$price;
        $discount = (float)$discount;
        $fleet_discount = 0; $fleet_share = 0; $fleet_id = null;
        if(Auth::guard('driver')->id()){
            $fleet_info = FleetDriver::join('organizations', 'fleet_drivers.fleet_id', 'organizations.id')
                ->where('driver_id', Auth::guard('driver')->id())
                ->where('fleet_drivers.status', 1)
                ->where('organizations.status', 1)
                ->whereNotNull('fleet_drivers.employee_id')
                ->select('organizations.id', 'organizations.extra_discount', 'organizations.payment_share')
                ->orderBy('organizations.extra_discount', 'desc')->first();

            if($fleet_info)
            {
                $fleet_discount = $fleet_info->extra_discount;
                $fleet_share = $fleet_info->payment_share;
                $fleet_id = $fleet_info->id;
            }
        }

        $payShare = PaymentShare::latest()->first();
        $joyCent = 40; $vatCent = 15;
        if($payShare)
        {
            $joyCent = $payShare['admin_share'];
            $vatCent = $payShare['vat'];
        }

        // Add Markup Price to the actual price
        $markup_price = Deal::where('id', $deal_id)->pluck('markup_price')->first();
        $price += $markup_price;
        //$joyCent = $joyCent - $joyCent* $fleet_discount /100;

        $discountShare = $price * $discount / 100;
        $discounted = $price - $price * $discount / 100;
        $adminShare = $discountShare * $joyCent / 100;
        $fleet_discount = $adminShare * $fleet_discount / 100;
        $finalShare = $discounted + $adminShare - $fleet_discount;
        $fleet_share = $adminShare * $fleet_share / 100;
        $joyShare = $adminShare - $fleet_discount - $fleet_share;

        // Exclustive
        //$vatPrice = $finalShare - $finalShare / (1 + $vatCent / 100);
        //$finalPrice = $finalShare - $vatPrice;
        // Inclusive
        //$vatPrice = $finalShare * $vatCent / 100;
        //$finalPrice = $finalShare + $vatPrice;

        $data = array(
            'base_price' => $price, // With out any other discounts
            'actual_price' => $price,
            'discount_percent' => $discount,
            'admin_share' => $joyShare, // This value using for apply coupon
            'joy_share' => $adminShare,
            'final_price' => round($finalShare, 2),
            'partner_share' => $fleet_share,
            'partner_discount' => $fleet_discount,
            'vat' => $vatCent,
            'fleet_id' => $fleet_id,
        );
        return $data;
    }

    public function bill_price_logic($transaction_no, $quantity=0)
    {
        // TODO: Tranaction bill pricing
        $trans = Transaction::where('transaction_no', $transaction_no)->first();
        $bill = TransactionDetail::where('transaction_no', $transaction_no)->first();

        $mainQuantity=$trans['quantity'];
        if($quantity>0){
            $mainQuantity=$quantity;
        }

        $price = $bill['price'];
        $markup_price = $bill['markup_price'];
        $price += $markup_price;
        $discount = $bill['discount'];
        $joyCent = $bill['joy_share'];
        $fleet_discount = $bill['partner_discount'];
        $fleet_share = $bill['partner_share'];
        $vatCent = $bill['vat'];

        $unit_price = $price;
        $price = $price * $mainQuantity;
        $discountShare = $price * $discount / 100;
        $discounted = $price - $price * $discount / 100;
        $joyShare = $discountShare * $joyCent / 100;
        $adminShare = $joyShare;
        $fleet_discount = $joyShare * $fleet_discount / 100;
        $finalShare = $discounted + $joyShare - $fleet_discount;
        $fleet_share = $joyShare * $fleet_share / 100;
        $joyShare = $joyShare - $fleet_discount - $fleet_share;

        $service_cost = $bill['service_cost'];
        if ($trans['deal_id'] == '4' || $trans['deal_id'] == '5') { // 4 - Cleaning, 5 - Deatiling
            $service_cost *= $mainQuantity; //$bill['quantity'];
        }

        $price_after_discount = $finalShare - $bill['coupon_savings'];
        $joyShare = $joyShare - $bill['coupon_savings'];
        $finalShare = $finalShare + $service_cost + $bill['filter_cost'] - $bill['coupon_savings'];

        $filter_cost_vat = $bill['filter_cost'] - ($bill['filter_cost'] /(1 + $vatCent / 100));
        $filter_cost_without_vat = $bill['filter_cost'] - $filter_cost_vat;

        $service_cost_vat = $service_cost - ($service_cost /(1 + $vatCent / 100));
        $service_cost_without_vat = $service_cost - $service_cost_vat;

        $item_vat = $price_after_discount - ($price_after_discount /(1 + $vatCent / 100));
        $item_price_withoutvat = $price_after_discount - $item_vat;
        $item_price = $item_price_withoutvat + $filter_cost_without_vat;
        $actual_price = $unit_price * $mainQuantity; //$trans['quantit']y;
        $discount_percent = ($actual_price - $price_after_discount) / $actual_price * 100;

        $vat_amount = $item_vat + $filter_cost_vat + $service_cost_vat;

        $data = array(
            'actual_price' => round($actual_price, 2),
            'unit_price' => round($unit_price, 2),
            'price_after_discount' => round($price_after_discount, 2),
            'item_price' => round($item_price, 2),
            'discount_percent' => round($discount_percent,2),
            'discount_amount' => round($actual_price - $price_after_discount, 2),
            'vat' => $vatCent,
            'vat_amount' => round($vat_amount, 2),
            'service_cost_without_vat' => round($service_cost_without_vat, 2),
            'final_price' => round($finalShare, 2),
            'admin_share' => round($joyShare, 2),
            'service_cost' => round($service_cost, 2),
            'filter_cost' => round($bill['filter_cost'], 2),
            'coupon_savings' => round($bill['coupon_savings'], 2),
        );

        if($trans['quantity'] == $trans['revised_quantity']){
            // Full Refund
            $data['refund_payment'] = array(
                'item_price' => round($data['item_price'], 2), // consists filter price without also
                'vat_amount' => round($data['vat_amount'], 2),
                'service_cost' => round($data['service_cost'], 2),
                'discount_amount' => round($data['discount_amount'], 2),
                'final_price' => round($data['final_price'], 2),
            );
        }
        else if($trans['revised_quantity'] > 0){
            // Partial Refund
            $refundQty = $trans['revised_quantity'];

            $item_vat = $price_after_discount - ($price_after_discount /(1 + $data['vat'] / 100));
            $itemWithoutVat = $price_after_discount - $item_vat;
            $itemWithoutVat = ($itemWithoutVat / $trans['quantity']) * $refundQty;
            $item_vat = ($item_vat / $trans['quantity']) * $refundQty;

            $service_cost = $service_cost_vat = 0;
            if ($trans['deal_id'] == '4' || $trans['deal_id'] == '5') { // 4 - Cleaning, 5 - Deatiling
                $service_cost = $bill['service_cost'] * $refundQty;
                $service_cost_vat = $service_cost - ($service_cost /(1 + $vatCent / 100));
            }
            $refundVat = $item_vat + $service_cost_vat;
            $final_price = $itemWithoutVat + $item_vat + $service_cost;

            $data['refund_payment'] = array(
                'item_price' => round($itemWithoutVat, 2),
                'vat_amount' => round($refundVat, 2),
                'service_cost' => round($service_cost, 2),
                'discount_amount' => round(0, 2),
                'final_price' => round($final_price, 2),
            );
        }


        // ********** Delar share calculation start **********
        $pg_share = $finalShare * $bill['pg_share'] /100;
        $total_quantity = $trans['quantity'] - $trans['revised_quantity'];
        $redeemed_quantity = $trans['redeem_quantity'];
        $no_of_redeems = 1;
        if ($trans['deal_id'] == '4' || $trans['deal_id'] == '5') { // 4 - Cleaning, 5 - Deatiling
            $no_of_redeems = $total_quantity;
        }

        // E2 - $price
        // G2 - $discountShare
        // I10 - $bill['pg_fee']
        // F2 - $discount
        // J10 - $bill['pg_share']
        // A10 - $bill['service_cost']
        // B2 - No. Of Redeems Quantity
        // B10 - Filter Cost
        // =(E2-G2-(I10+((100-F2)*J10/100)))+A10*B2 +B10

        //return $no_of_redeems;
        $delarShare = ($price - $discountShare - ($bill['pg_fee'] +((100- $discount ) * $pg_share / 100)))
                        + $bill['service_cost'] * $no_of_redeems + $bill['filter_cost'];

        // =(G10-(G10 - G10/ (1 +E4/100)))
        $delarShareVat = $delarShare - $delarShare/ (1 +$vatCent/100);
        $delarShare = $delarShare-($delarShare - $delarShare/ (1 +$vatCent/100));


        $delarShareGot = $partnerShareGot = 0;
        if($redeemed_quantity > 0 ) {
            $delarShareGot = $delarShare;
            if($no_of_redeems > 1) {
                $delarShareGot = (($price - $discountShare - ($bill['pg_fee'] + ((100 - $discount) * $pg_share / 100))) * $redeemed_quantity / $no_of_redeems)
                    + $bill['service_cost'] * $redeemed_quantity + $bill['filter_cost'];

                $delarShareGot = $delarShareGot - ($delarShareGot - $delarShareGot / (1 + $vatCent / 100));
            }
        }
        // ********** Delar share calculation end **********


        // ********** Partner share calculation start **********
        // =(C5-(C5*(J8 / 100) ))
        $partnerShare = $adminShare * $bill['partner_share'] / 100;
        $partnerShare = $partnerShare - ($partnerShare * ($pg_share / 100));
        if($redeemed_quantity > 0)
            $partnerShareGot = $partnerShare * $redeemed_quantity / $no_of_redeems;

        // ********** Partner share calculation end **********

        $data['sharings'] = array(
            'joy_cent' => $joyCent,
            'joy_share' => round($joyShare,2),
            'admin_share' => round($adminShare,2),
            'delar_share_vat' => round($delarShareVat,2),
            'delar_share' => round($delarShare,2),
            'delar_share_get' => round($delarShareGot,2),
            'partner_share' => round($partnerShare,2),
            'partner_share_get' => round($partnerShareGot,2),
            'partner_share_cent' => $bill['partner_share'],
            'partner_discount_cent' => $bill['partner_discount'],
            'partner_discount' => round($fleet_discount, 2),
            'pg_share_cent' => $bill['pg_share'],
            'pg_share' => round($pg_share,2),
            'pg_fee' => round($bill['pg_fee'],2),
            'adjustment_limit' => round($joyShare + $delarShare,2),
        );

        return $data;
    }
}
