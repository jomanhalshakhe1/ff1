<?php

namespace App\Http\Controllers\Generals;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Users\CreditsController;
use App\Http\Controllers\Users\FleetController;
use App\Models\Accounts\FleetDriver;
use App\Models\Generals\Coupons\Coupon;
use App\Models\Generals\Coupons\CouponDeal;
use App\Models\Generals\Coupons\CouponPartner;
use App\Models\Generals\Notification;
use App\Models\Generals\NotificationLog;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use App\Models\Regulatory\Fleet;
use App\Models\Regulatory\OrgDeal;
use App\Repositories\CouponsRepository;
use Illuminate\Http\Request;
use App\Services\CouponsService;
use Illuminate\Support\Facades\Validator;
use App\Services\CouponsLogsService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Generals\Coupons\CouponLog;


class CouponsController extends Controller
{
    // Variable declarations
    private $service, $couponLogsService, $repository;

    /*Default constructor
    *
    * @param CouponsService,CouponsLogsService
    *
    */
    public function __construct(
        CouponsService $_service,
        CouponsLogsService $_clSevervice,
        CouponsRepository $repository
    ) {
        $this->service = $_service;
        $this->couponLogsService = $_clSevervice;
        $this->repository = $repository;
    }
 
    /**
     * Get All Coupons list
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       try
        {
           $data = $this->service->getAllCouponsList();

           return response()->json(['status' => 'success', 'data' => $data], 200);
        } catch(\Exception $e){
            return response()->json(['Status' => 'failed', 'Response' => $e->getMessage()], 400);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created coupons in database
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $validator = Validator::make($request->all(),
            [
                'code' => 'required|max:10|unique:coupons',
                'expiry_date' => ['required'],
                'discount' => ['required'],
                'description' => ['required'],
                'quantity' => ['required'],
                'quantity_perhead' => ['required'],
                'quantity_perdeal' => ['required'],
                'status' => ['required'],
                'min_price' => ['required'],
                'coupon_type' => ['required'],
                'user_type' => ['required'],
                'coupon_by' => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $request['created_at'] = date('Y-m-d H:i:s');
            $couponsArray = $request->except('partners', 'deals');
            $couponId = $this->service->createCouponData($couponsArray);

            if(isset($request->deals) && sizeof($request->deals) > 0){
                $dealsArray = [];
                foreach($request->deals as $deal)
                    $dealsArray[] = array('coupon_id' => $couponId, 'deal_id' => $deal);

                $this->repository->update_coupon_deals($couponId, $dealsArray);
            }

            if(isset($request->partners) && sizeof($request->partners) > 0){
                $partnersArray = [];
                foreach($request->partners as $partner_id)
                    $partnersArray[] = array('coupon_id' => $couponId, 'org_id' => $partner_id);

                $this->repository->update_coupon_partners($couponId, $partnersArray);
            }

            return response()->json(['status'=>'success', 'message'=> 'Coupon details created successfully'], 200);
        }
        catch (\Exception $e)
        {
             return response()->json(['status'=>'failed', 'message'=> 'Failed to create new coupons details','error'=>$e->getMessage()], 400);
        }
    }

    /**
     * get coupon data based on the specified id.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        try {
          $data = $this->service->getCouponById($id, array('deals', 'partners'));
          return response()->json(['status'=>'success', 'data' => $data], 200);
        } catch (\Exception $e){
            return response()->json(['status'=>'failed', 'message'=> 'Failed to get coupons details', "error" => $e->getMessage()], 400);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * save newly modified coupons data into database
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(),
            [
                'code'    => 'required|max:10|unique:coupons,code,'.$id,
                'expiry_date' => ['required'],
                'discount' => ['required'],
                'description' => ['required'],
                'quantity' => ['required'],
                'quantity_perhead' => ['required'],
                'quantity_perdeal' => ['required'],
                'status' => ['required'],
                'min_price' => ['required'],
                'coupon_type' => ['required'],
                'user_type' => ['required'],
                'coupon_by' => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $request['updated_at'] = date('Y-m-d H:i:s');
            $couponsArray = $request->except('deals', 'partners');
            $this->service->updateCouponData($id, $couponsArray);

            $couponId = $id;
            if(isset($request->deals)){
                $dealsArray = [];
                foreach($request->deals as $deal)
                    $dealsArray[] = array('coupon_id' => $couponId, 'deal_id' => $deal);

                $this->repository->update_coupon_deals($couponId, $dealsArray);
            }

            if(isset($request->partners)){
                $partnersArray = [];
                foreach($request->partners as $partner_id)
                    $partnersArray[] = array('coupon_id' => $couponId, 'org_id' => $partner_id);

                $this->repository->update_coupon_partners($couponId, $partnersArray);
            }

            return response()->json(['status'=>'success', 'message'=> 'Coupon details updated successfully'], 200);
        }
        catch (\Exception $e)
        {
             return response()->json(['status'=>'failed', 'message'=> 'Failed to update coupons details','error'=>$e->getMessage()], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    /**
     * Apply coupon code for driver when they purchase deal
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function apply_coupon(Request $request)
    {
        $resp = $this->couponValidations($request);

        if($resp['status'] == 'failed')
            return response()->json($resp, 400);

        if(isset($resp['is_employee'])){
            // Fleet Coupon
            $result = $this->apply_fleet_coupon($request);
            return response()->json($result, ($result['status'] == 'success' ? 200 : 400));
        }

        $couponData = $this->coupon_savings($request);
        if($couponData['savings'] <= 0 && $couponData['coupon_type'] == 'D')
        {
            return response()->json([
                'status'=>'failed',
                'message'=> 'Coupon not applicable to this offer',
                'message_ar'=> 'القسيمة لا تنطبق على هذا العرض'
            ], 400);
        }

        $couponLogArray = array(
            'coupon_code' => $request->coupon_code,
            'driver_id' => Auth::guard('driver')->id(),
            'coupon_id' => $couponData['coupon_id'],
            'coupon_type' => $couponData['coupon_type'],
            'discount' => $couponData['discount'],
            'savings' => $couponData['savings'],
            'reason' => "Coupon code applied",
        );

        try{
            // When coupon assined to the customer
            if($this->couponLogsService->getCustomerCouponAvailableCount() == 0)
            {
                Coupon::where('id', $couponData['coupon_id'])->decrement('quantity', 1);
                $couponLogArray['created_at'] = date("Y-m-d H:i:s");
            }
            else{
                // Override the previous coupon on coupon type discount in percentage
                $loginfo = $this->couponLogsService->getCustomerCouponAvailableInfo();
                $coupon_id = $loginfo->coupon_id;
                Coupon::where('id', $coupon_id)->increment('quantity', 1);

                $couponLogArray['updated_at'] = date("Y-m-d H:i:s");
            }

            if($couponData['coupon_type'] == 'C') {
                /*
                 * Coupon as credits
                 * Last unredeem coupon will be overrided on coupon logs for coupon type - discount
                 * if coupon type - credits,
                 *      - update transaction_no  with gift credit id, so this coupon will be redeemed
                 *      - Credit amounts added to gift credits
                 *      - So customer will get credit points to his account
                 *      - With the credit points customer can purchase order any time
                 */

                $creditId = (new CreditsController())->send_customer_coupon_credits($couponData['discount']);
                $couponLogArray['transaction_no'] = $creditId; // It means coupon was redeemed
                $couponLogArray['reason'] = 'Coupon credits added';

                $message = 'You won '.$couponData['discount'].' SAR as credits';
                $message_ar = 'ربحت '.$couponData['discount'].' ريال سعودي كرصيد';
            }
            else{
                $message = 'Coupon applied successfully';
                $message_ar = 'تم تطبيق القسيمة بنجاح';
            }

            $couponLogId = $this->saveCouponLogs($couponLogArray);

            return response()->json([
                'status' =>'success',
                'message' => $message,
                'message_ar' => $message_ar,
                'data' => array(
                    'code' => $couponData['code'],
                    'savings' => $couponData['savings'],
                    'coupon_log_id' => $couponLogId,
                )
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'failed',
                'message' => 'Failed to apply coupons details',
                'message_ar' => 'فشل في تطبيق تفاصيل القسائم',
                'error'=>$e->getMessage()], 400);
        }
    }

    /**
     * Save Applied coupon code for customer
     *
     * @param  Array  $couponLogsArray
     *
     */
    private function saveCouponLogs($couponLogsArray){
        return $this->couponLogsService->createCouponLogsData($couponLogsArray);
    }

    private function couponValidations($request){

        $validator = Validator::make($request->all(),
            [
                'coupon_code' => ['required', 'max:10'],
                'deal_cost' => ['required'],
                'deal_id' => ['required'],
                'item_id' => ['required'],
                'offer_id' => ['required'],
                'quantity' => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return [ 'status' => "failed", "response" => $errors ];
        }

        $couponData = $this->service->getCouponByCode($request->coupon_code);
        //Check coupon is available or not
        if(!$couponData){
            // customer registration check for fleet employee

            $cnt = Fleet::where('code', $request['coupon_code'])->where('company_type', 'F')->count();

            $fleet_id = FleetDriver::where('employee_id', $request['coupon_code'])->pluck('fleet_id')->first();
            if($cnt > 0 || $fleet_id)
            {
                // Register for customer as employee
                return [
                    'status'=>'success',
                    'message'=> 'Employee registration was available',
                    'is_employee'=> 1,
                ];

            }

            return [
                'status'=>'failed',
                'message'=> 'Coupon code not available',
                'message_ar'=> 'رمز القسيمة غير متوفر',
            ];
        }

        // check the expiry date to apply code
        if(strtotime(date('Y-m-d')) > strtotime($couponData->expiry_date)){
            return [
                'status'=>'failed',
                'message'=> 'Coupon expired',
                'message_ar'=> 'القسيمة منتهية الصلاحية'
            ];
        }

        // check the available coupons quantity
        if($couponData->quantity == 0){
            return [
                'status'=>'failed',
                'message'=> 'No more coupons available to apply',
                'message_ar'=> 'لا مزيد من الكوبونات المتاحة للتقديم',
            ];
        }

        // check coupon count used by the customer
        $couponCount = $this->couponLogsService->getCustomerTotalCodeApply($request->coupon_code);

        if($couponData->quantity > 0 && $couponCount >= $couponData->quantity_perhead){
            return [
                'status'=>'failed',
                'message'=> "You can't apply coupon code as already you reached your limit",
                'message_ar'=> "لا يمكنك تطبيق رمز القسيمة لأنك وصلت بالفعل إلى الحد الأقصى",
            ];
        }

        $offer = ItemOffer::where('item_id', $request->item_id)->where('id', $request->offer_id)
            ->select('id', 'price', 'discount', 'deal_id')->first();

        if(!$offer){
            return [
                'status'=>'failed',
                'message'=> "Invalid Offer Details",
                'message_ar'=> "تفاصيل العرض غير صالحة",
            ];
        }

        if($couponData->coupon_by == 'C') {
            // check coupon count on deal category used by the customer
            $dealsCoupons = CouponLog::join('transactions', 'coupon_logs.transaction_no', 'transactions.transaction_no')
                ->select('transactions.deal_id')->selectRaw('count(1) as cnt')
                ->where('coupon_logs.driver_id', Auth::guard('driver')->id())
                ->where('coupon_logs.coupon_code', $request->coupon_code)
                ->groupBy('transactions.deal_id')->get();

            if (count($dealsCoupons) > 0) {
                $dealId = $offer->deal_id;
                $dealCouponCount = 0;
                foreach ($dealsCoupons as $dealCoupon) {
                    if ($dealCoupon->deal_id == $dealId) {
                        $dealCouponCount = $dealCoupon->cnt;
                        break;
                    }
                }

                if ($dealCouponCount >= $couponData->quantity_perdeal) {
                    return [
                        'status' => 'failed',
                        'message' => "You can't apply coupon code as already you reached your limit",
                        'message_ar' => "لا يمكنك تطبيق رمز القسيمة لأنك وصلت بالفعل إلى الحد الأقصى",
                    ];
                }
            }
        }

        $dealShare = new DealController();
        $pricing = $dealShare->price_logic($offer->price, $offer->discount, $offer->deal_id);
        $finalPrice = $pricing['final_price'] * $request['quantity'];

        // check minmum price
        if($finalPrice < $couponData->min_price){
            return [
                'status'=>'failed',
                'message'=> 'Minimum amount of '.$couponData->min_price.' SAR is required for applying coupon' ,
                'message_ar'=> 'االحد الأدنى المطلوب هو  '.$couponData->min_price.' SAR لتطبيق القسيمة'
            ];
        }

        if($couponData->coupon_type == 'C') // Credit Coupon
        {
            // Check Admin exchange Credits
            $credits = (new CreditsController())->eligible_gift_accounts();
            $adminCredits = $credits->getData()->data->admins;
            $adminCredits = isset($adminCredits[0]) ? $adminCredits[0]->credits : 0;

            if($adminCredits < $couponData->discount){
                // if admin credits are less than coupon credits, cann't redeem the coupon
                return [
                    'status'=>'failed',
                    'message'=> "Invalid Coupon",
                    'message_ar'=> "قسيمة غير صالحة",
                ];
            }
        }

        $consumer_id = Auth::guard('driver')->id();

        // check it for customer eligibility
        if($couponData->coupon_by == 'P') // Fleet Company users only
        {
            if(FleetDriver::where('driver_id', $consumer_id)
                ->where('status', 1)->count() == 0)
            {
                // Coupon Only Applicable to Fleet Drivers
                return [
                    'status'=>'failed',
                    'message'=> "Invalid Coupon",
                    'message_ar'=> "قسيمة غير صالحة",
                ];
            }

            $fleets = FleetDriver::where('driver_id', $consumer_id)->where('status', 1)->pluck('fleet_id')->toArray();
            $couponPartners = CouponPartner::where('coupon_id', $couponData->id)->where('org_type', 'P')->pluck('org_id')->toArray();
            if(!array_intersect($fleets, $couponPartners)){
                // Coupon not applicable to this Fleet Users
                return [
                    'status'=>'failed',
                    'message'=> "Invalid Coupon",
                    'message_ar'=> "قسيمة غير صالحة",
                ];
            }
        }
        else if($couponData->coupon_by == 'D') {
            // check the offer deal related to the coupon dealers and the respective active deal or not
            $delar_id = ItemMaster::where('id', $offer->item_id)->pluck('delar_id')->first();
            $couponPartners = CouponPartner::where('coupon_id', $couponData->id)->where('org_type', 'D')->pluck('org_id')->toArray();
            if(count($couponPartners) > 0 && !in_array($delar_id, $couponPartners)){
                // Coupon not applicable to this delar
                return [
                    'status'=>'failed',
                    'message'=> "Invalid Coupon",
                    'message_ar'=> "قسيمة غير صالحة",
                ];
            }
            else{
                // check for Active deals
                $actieDeals = OrgDeal::where('org_id', $delar_id)->where('status', 1)->pluck('deal_id')->toArray();
                if(count($actieDeals) > 0 && !in_array($offer->deal_id, $actieDeals)){
                    // Coupon not applicable to this deal
                    return [
                        'status'=>'failed',
                        'message'=> "Invalid Coupon",
                        'message_ar'=> "قسيمة غير صالحة",
                    ];
                }
            }
        }

        // if($couponData->coupon_by == 'C') // Coupon by deal categroy only
        $couponDeals = CouponDeal::where('coupon_id', $couponData->id)->pluck('deal_id')->toArray();

        if(count($couponDeals) > 0 && !in_array($offer->deal_id, $couponDeals)){
            // Coupon not applicable to this deal
            return [
                'status'=>'failed',
                'message'=> "Invalid Coupon",
                'message_ar'=> "قسيمة غير صالحة",
            ];
        }

        return [
            'status'=>'success',
            'message'=> "Valid Coupon",
            'message_ar'=> "قسيمة صالحة",
        ];
    }

    private function coupon_savings($request){

        $couponData = $this->service->getCouponByCode($request->coupon_code);

        $savings = 0;
        if($couponData->coupon_type == 'D') // Discount Percent
        {
            $offer = ItemOffer::where('item_id', $request->item_id)->where('id', $request->offer_id)
                ->select('id', 'price', 'discount', 'deal_id')->first();

            $dealShare = new DealController();
            $pricing = $dealShare->price_logic($offer->price, $offer->discount, $offer->deal_id);

            $adminShare = $pricing['admin_share'];
            $fleet_share = $pricing['partner_share'];
            $fleet_discount = $pricing['partner_discount'];
            if (isset($request['quantity'])) {
                $adminShare = $pricing['admin_share'] * $request['quantity'];
                $fleet_share = $pricing['partner_share'] * $request['quantity'];
                $fleet_discount = $pricing['partner_discount'] * $request['quantity'];
            }

            $savings = ($adminShare - $fleet_share - $fleet_discount) * $couponData->discount / 100;
        }
        else if($couponData->coupon_type == 'C') //Credits
        {
            // Add coupon credits into customer account
            $savings = 0;
        }

        return array(
            'coupon_id' => $couponData->id,
            'code' => $couponData->code,
            'discount' => $couponData->discount,
            'coupon_type' => $couponData->coupon_type,
            'savings' => $savings,
        );
    }

    private function apply_fleet_coupon($request){
        $request['code'] = $request['coupon_code'];
        $result = (new FleetController())->verify_fleet($request);

        $data = $result->getData();
        if($data->status == 'success')
        {
            $company_name = $company_name_ar = '';
            $fleet_id = 0;
            if(Fleet::where('code', $request['coupon_code'])->where('company_type', 'F')->count() > 0){
                // Registered with Company Code
                $fleet = Fleet::where('code', $request['coupon_code'])->where('company_type', 'F')->first();
                $company_name = $fleet['org_name'];
                $company_name_ar = $fleet['org_name_ar'];
                $fleet_id = $fleet['id'];
            }
            else if(FleetDriver::where('employee_id', $request['coupon_code'])->count() > 0)
            {
                // Registered with Employee Id
                $fleet_id = FleetDriver::where('employee_id', $request['coupon_code'])->pluck('fleet_id')->first();
                $fleet = Fleet::where('id', $fleet_id)->where('company_type', 'F')->first();

                $company_name = $fleet['org_name'];
                $company_name_ar = $fleet['org_name_ar'];
            }

            $message = 'Congratulation! now you can enjoy '.$company_name.' discounts';
            $message_ar = "مبرووك. الان يمكنك التمتع بخصم رائع الخاص ب $company_name_ar على جميع الخدمات.";

            $this->send_inapp_notification($fleet_id);

            return [
                'status' =>'success',
                'title' => 'Congratulations',
                'title_ar' => ' تهانينا',
                'message' => $message,
                'message_ar' => $message_ar,
                'data' => array(
                    'code' => $request['coupon_code'],
                    'savings' => 0,
                    'coupon_log_id' => 0,
                )
            ];
        }
        else{
            return [
                'status'=>'failed',
                'message'=> "Invalid Coupon",
                'message_ar'=> "قسيمة غير صالحة",
            ];
        }
    }

    private function send_inapp_notification($fleet_id){
        $fleet = Fleet::where('id', $fleet_id)->first();
        $company_name = $fleet['org_name'];
        $company_name_ar = $fleet['org_name_ar'];

        $notification = array(
            'notification_type' => 'I',
            'notification_for' => 51,
            'notification_title' => $company_name.' code added successfully',
            'notification_title_ar' => $company_name_ar."تم اضافة كود خصم ",
            'notification_message' => $company_name.' code added successfully',
            'notification_message_ar' => $company_name_ar."تم اضافة كود خصم ",
            'created_by' => Auth::guard('driver')->id(),
            'created_at' => date('Y-m-d H:i:s'),
            'is_inapp' => 1,
            'expired_on' => date('Y-m-d H:i:s', strtotime("+15 days"))
        );

        $notificationId = Notification::insertGetId($notification);

        $notificationLog = array(
            'notification_id' => $notificationId,
            'notification_to' => Auth::guard('driver')->id(),
            'notification_for' => 'C',
            'created_at' => date('Y-m-d H:i:s'),
        );

        NotificationLog::insert($notificationLog);

    }

    function coupon_applied_users(Request $request, $couponId){

         $couponData = $this->service->getCouponById($couponId, array('deals', 'partners'));
        $pageno = 1; $pagelength = 10;
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $totalrecords = CouponLog::where('transaction_no','!=','')->where('coupon_id', $couponId)->count();
        $list = CouponLog::where('transaction_no','!=','')->where('coupon_id', $couponId)->with('customer_info','transaction_info')->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();
        $data['data'] = $list;
        $data['coupon_data']=$couponData;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

}
