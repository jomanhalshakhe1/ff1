<?php

namespace App\Http\Controllers\Generals;


use App\Http\Controllers\Controller;
use App\Models\Generals\Slider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;


class SliderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $list = Slider::where('deal_id', 0)->where('status', 1)->get();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'thumbnail' => 'required',
            'status' => 'required',
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/sliders/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/sliders/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('sliders/', $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $request['created_at'] = date('Y-m-d H:i:s');
            Slider::create($request->except('thumbnail'));

            return response()->json([ 'status' => "success", "response" => "Slider created successfully" ], 200);
        }catch (\Exception $e){
            return response()->json([ 'status' => "success", "response" => "Slider creation failed" ], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $list = Slider::where('deal_id', 0)->where('id', $id)->first();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(),[
            'status' => 'required',
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/sliders/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/sliders/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('sliders/', $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $request['updated_at'] = date('Y-m-d H:i:s');

            Slider::where('id', $id)->update($request->except('thumbnail'));

            return response()->json([ 'status' => "success", "response" => "Slider updated successfully" ], 200);
        }catch (\Exception $e){
            //return $e;
            return response()->json([ 'status' => "success", "response" => "Slider updation failed" ], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function delete_slider(Request $request, $id, $slider_id) {
        try{
            $deleteslide = Slider::where('item_id', $id)->where('id', $slider_id)->delete();
            if($deleteslide){
                return response()->json(['status'=>'success', 'message'=> 'Slider deleted successfully'], 200);
            }else{
                return response()->json(['status'=>'failed', 'message'=> 'Slider deletion failed', "error" => '' ], 400);
            }
        }catch (\Exception $e) {
            return response()->json(['status'=>'failed', 'message'=> 'Slider deletion failed', "error" => $e ], 400);
        }
    }

}
