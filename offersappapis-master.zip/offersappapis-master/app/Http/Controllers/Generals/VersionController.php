<?php

namespace App\Http\Controllers\Generals;

use App\Http\Controllers\Controller;
use App\Models\Generals\Device;
use App\Models\Generals\Version;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class VersionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $totalrecords = Version::count();
        $pagelength = $request->pagelength;
        $pageno = $request->pageno;
        $list = Version::withCount('userlist')->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();
        $data['data'] = $list;
        $data['current_page'] = $pageno;
        $data['total'] = $totalrecords;
        $data['per_page'] = $pagelength;

        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                //'version_no' => ['required', 'string', 'max:10' ],
                'version_no' => [
                    'required', 'string', 'max:10',
                    'unique:versions,version_no,NULL,app_type,app_type,'.$request->app_type.',device_type,'.$request->device_type
                ],
                'release_date' => ['required'],
                'app_type' => ['required'],
                'is_mandatory' => ['required'],
                'status' => ['required'],
                'device_type' => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('apk')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/versions/';
                $safeName = Str::random(10).'_'.date('Ymd') . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['app_file'] = '/uploads/versions/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('versions/', $request->file('apk'));
            $request['app_file'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $insert = array(
                'version_no' => $request['version_no'],
                'device_type' => $request['device_type'],
                'release_date' => $request['release_date'],
                'app_type' => $request['app_type'],
                'is_mandatory' => $request['is_mandatory'],
                'app_file' => $request['app_file'],
                'remarks' => $request['remarks'],
                'created_at' => date('Y-m-d H:i:s'),
                'created_by' => Auth::id(),
            );

            Version::insert($insert);
            return response()->json(['status'=>'success', 'message'=> 'Version created successfully'], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Version creation failed', "error" => $e], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $list = Version::find($id);
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(),
            [
                //'version_no' => ['required', 'string', 'max:10' ],
                'version_no' => [
                    'required', 'string', 'max:10',
                    'unique:versions,version_no,'.$id.',id,app_type,'.$request->app_type.',device_type,'.$request->device_type
                ],
                'release_date' => ['required'],
                'app_type' => ['required'],
                'is_mandatory' => ['required'],
                'status' => ['required'],
                'device_type' => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('apk')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/versions/';
                $safeName = Str::random(10).'_'.date('Ymd') . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['app_file'] = '/uploads/versions/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('versions/', $request->file('apk'));
            $request['app_file'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $insert = array(
                'version_no' => $request['version_no'],
                'release_date' => $request['release_date'],
                'app_type' => $request['app_type'],
                'device_type' => $request['device_type'],
                'is_mandatory' => $request['is_mandatory'],
                'app_file' => $request['app_file'],
                'remarks' => $request['remarks'],
                'status' => $request['status'],
                'updated_by' => Auth::id(),
                'updated_at' => date('Y-m-d H:i:s')
            );

            Version::where('id', $id)->update($insert);
            return response()->json(['status'=>'success', 'message'=> 'Version updated successfully'], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Version update failed', "error" => $e], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function verify_version(Request $request){

        // J - Joy, P - Partner apps
        $api_prefix = explode('/', $request->route()->getPrefix())[0];
        if($api_prefix == 'consumer' || $api_prefix == 'customer')
            $app_type = 'J';
        else
            $app_type = 'P';

        $device_type = isset($request['device_type']) ? $request['device_type'] : 'A'; // A - Android, I - Ios

        $version = Version::where('status', 1)->where('app_type', $app_type)->where('device_type', $device_type)->latest('release_date')->first();
        if(!$version)
            return response()->json(['status' => 'failed', 'message' => 'Invalid Version Check', 'message_ar' => 'التحقق من الإصدار غير صالح'], 400);

        if($request['version_no'])
            $request['version_no'] = (substr($request['version_no'], 0,1) == 'v') ? ltrim($request['version_no'], 'v') : $request['version_no'];
        if(isset($request['app_version']))
        {
            $request['app_version'] = (substr($request['app_version'], 0,1) == 'v') ? ltrim($request['app_version'], 'v') : $request['app_version'];
            if(!$request['version_no'])
                $request['version_no'] = $request['app_version'];
        }

        $data = [];
        $version_result = version_compare($version['version_no'], $request['version_no']);
        if($version_result > 0)
        {
            /*
                By default, version_compare() returns
                -1 if the first version is lower than the second,
                0 if they are equal, and
                1 if the second is lower.
            */
            // Version need to update
            $data = array(
                'status' => 'success',
                'message' => "Version Not Matched",
                'message_ar' => "الإصدار غير مطابق",
                "is_updated" => 0,
                'is_mandatory' => $version['is_mandatory'],
                "recommed_version" => $version['version_no']
            );
        }
        else if($version_result <= 0){
            // Version was equal or lower
            $data = array(
                'status' => 'success',
                'message' => "Version Matched",
                'message_ar' => "نسخة مطابقة",
                "is_updated" => 1,
                "recommed_version" => $version['version_no']
            );

            $this->update_user_app_version($request->all());
        }

        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    public function update_user_app_version($request){

        $api_prefix = explode('/', request()->route()->getPrefix())[0];

        $deviceType='android';
        if(isset($request['device_type']) && $request['device_type'] == 'I'){
             $deviceType='ios';
        }
        $version_no = $request['version_no'];
        $user_id = null;
        $userType = 'anonymus';

        if($api_prefix == 'consumer' || $api_prefix == 'customer'){
            $userType = 'driver';
            if(Auth::guard('driver')->id()){
                $user_id = Auth::guard('driver')->id();
            }
        }
        else if($api_prefix == 'dealer' || $api_prefix == 'technician'){
            $userType = 'user';
            if(Auth::guard('technician')->id()){
                $user_id = Auth::guard('technician')->id();
            }
        }

        $where = array( 'user_type' => $userType, 'device_type' => $deviceType);
        if($user_id)
            $where['user_id'] = $user_id;

        if(isset($request['device_id'])) // old apps before 0.1.40 (live) are not handling sending this input
            $where['device_id'] = $request['device_id'];

        if(Device::where($where)->pluck('app_version')->first()){
            if($user_id)
                Device::where($where)->update(['app_version' => $version_no]);
            else
                Device::where($where)->whereNull('user_id')->update(['app_version' => $version_no]);
        }

    }

    public function file_upload(Request $request){
        $file_name = Storage::disk('s3')->put('testupload/', $request->file('apk'));
        $request['app_file'] = Storage::disk('s3')->url($file_name);

        $headers = [
            'Content-Type'        => 'application/jpeg',
            'Content-Disposition' => 'attachment; filename="'. $file_name .'"',
        ];

        $request['read_file'] = Storage::disk('s3')->get($request['app_file']);

        return response()->json(['status' => 'success', 'data' => $request->all()], 200, $headers);
    }


    /* Get total users count based on the version number
    * @return \Illuminate\Http\response
    */
    function getTotalUsersBasedOnVersionNo(){
          $list=Version::withCount('userlist')->get();
          return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /* Get total users count based on the version number and device vice
    * @return \Illuminate\Http\response
    */
    function getTotalUsersBasedOnDevice(){
          //$list=Version::select('device_type','version_no')->withCount('userlist')->groupBy('device_type','version_no')->get();


        $list=Device::select('device_type', DB::raw('count(*) as total_user'))->groupBy('device_type')->get();
          return response()->json(['status' => 'success', 'data' => $list], 200);
    }

}
