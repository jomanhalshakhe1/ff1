<?php

namespace App\Http\Controllers\Generals;

use App\Http\Controllers\Controller;
use App\Models\Generals\Feedback;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class FeedbackController extends Controller
{
    /**
     * Display a listing of the resource.
     * Access: admin, dealer admin, partner prefix: api
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $login_type_id = Auth::user()->login_type_id;
        $pageno = 1; $pagelength = 10; $totalrecords = 0;
        $list = Feedback::with('customer', 'item', 'offer');
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;

            if ($login_type_id == 18) { // Delar Admin or Technician
                if (Auth::user()->role_id == 3) // Delar Admin
                {
                    // if admin, all transactions related to the organization will be listed
                    // Transactions approved by himself and by technicains also
                    $list = $list->whereHas('item', function ($qry) {
                        $qry->where('item_master.delar_id', Auth::user()->org_id);
                    });
                }
            } else if ($login_type_id == 19) { // partner admin
                $list = $list->whereHas('customer.fleet_consumer', function ($item) {
                    $item->where('fleet_drivers.fleet_id', Auth::user()->org_id);
                });
            }

            $totalrecords = $list->count();
            $list = $list->skip( ($pageno-1)*$pagelength )->take($pagelength);
        }

        $list = $list->orderBy('feedbacks.id', 'desc')->get();

        $list = $list->map(function ($row){
            return array(
                "id" => $row['id'],
                "transaction_no" => $row['transaction_no'],
                "item_id" => $row['item_id'],
                "offer_id" => $row['offer_id'],
                "rating" => $row['rating'],
                "message" => $row['message'],
                "created_at" => $row['created_at'],
                "customer_id" => $row['customer_id'],
                "customer_name" => $row->customer->first_name,
                "customer_contact" => $row->customer->contact_no,
                "customer_gender" => $row->customer->gender,
                "customer_profile" => $row->customer->profile_pic,
                "item_name" => $row->item->title,
                "item_name_ar" => $row->item->title_ar,
            );
        });

        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status' => 'success', 'data' => $data], 200);
        }else{
            return response()->json(['status' => 'success', 'data' => $list], 200);
        }
    }

    /*
     * Access: customer, dealer Prefix: customer, dealer
     */
    public function feedback_list(Request $request)
    {
        $user_id = Auth::guard('driver')->id();
        $partner_id = Auth::guard('technician')->user();

        $list = Feedback::with('customer', 'item', 'offer');
        if($user_id){
            $list = $list->where('customer_id', $user_id);
        }else if($partner_id){
            $list = $list->join('item_master as im', 'feedbacks.item_id',  'im.id')
                ->where('im.delar_id', $partner_id->org_id);
        }

        $list = $list->orderBy('feedbacks.id', 'desc')->get();

        $list = $list->map(function ($row){
            return array(
                "id" => $row['id'],
                "transaction_no" => $row['transaction_no'],
                "item_id" => $row['item_id'],
                "offer_id" => $row['offer_id'],
                "rating" => $row['rating'],
                "message" => $row['message'],
                "created_at" => $row['created_at'],
                "customer_id" => $row['customer_id'],
                "customer_name" => $row->customer->first_name,
                "customer_contact" => $row->customer->contact_no,
                "customer_gender" => $row->customer->gender,
                "customer_profile" => $row->customer->profile_pic,
                "customer" => $row->customer, // set this value for old apps
                "item_name" => $row->item->title,
                "item_name_ar" => $row->item->title_ar,
            );
        });

        if(count($list) >0){
            return response()->json(['status' => 'success', 'data' => $list], 200);
        }else{
            return response()->json([
                'status'=>'failed',
                'message'=> 'No Feedback messages',
                'message_ar'=> 'لا توجد رسائل تعليقات',
            ], 400);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
                'customer_id'    => 'required',
                'item_id'    => 'required',
                'offer_id'    => 'required',
                //'rating'    => 'required',
                'transaction_no'    => 'required',
                // 'message'    => 'required',
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $check_feedback = Feedback::where('customer_id', $request->customer_id)
                                ->where('item_id', $request->item_id)
                                ->where('offer_id', $request->offer_id)
                                ->where('transaction_no', $request->transaction_no)->count();

            if($check_feedback == 0){
                $request['created_at'] = date('Y-m-d H:i:s');
                Feedback::insert($request->all());
                return response()->json([
                    'status'=>'success',
                    'message'=> 'Feedback sent successfully',
                    'message_ar'=> 'تم إرسال الملاحظات بنجاح',
                ], 200);
            }else{
                return response()->json([
                    'status'=>'failed',
                    'message'=> 'Feedback already sent',
                    'message_ar'=> 'تم إرسال التعليقات بالفعل',
                ], 200);
            }
        }
        catch (\Exception $e)
        {
            //return $e;
            return response()->json([
                'status'=>'failed',
                'message'=> 'Feedback sent failed',
                'message_ar'=> 'فشل إرسال الملاحظات',
            ], 400);
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        try{
            $feedback = Feedback::with('customer', 'item', 'offer')->where('id', $id)->first();
            return response()->json(['status'=>'success', 'data'=> $feedback], 200);
        }
        catch (\Exception $e)
        {
            //return $e;
            return response()->json(['status'=>'failed', 'message'=> 'Feedback Not Found'], 400);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
                'customer_id'    => 'required',
                'item_id'    => 'required',
                'offer_id'    => 'required',
                //'rating'    => 'required',
                'transaction_no'    => 'required',
                // 'message'    => 'required',
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $request['updated_at'] = date('Y-m-d H:i:s');
            Feedback::where('id', $id)->update($request->all());
            return response()->json([
                'status'=>'success',
                'message'=> 'Feedback Updated Successfully',
                'message_ar'=> 'تم تحديث التعليقات بنجاح',
            ], 200);
        }
        catch (\Exception $e)
        {
            return response()->json([
                'status'=>'failed',
                'message'=> 'Feedback Updation Failed',
                'message_ar'=> 'فشل تحديث التعليقات',
            ], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try{
            Feedback::where('id', $id)->delete();
            return response()->json([
                'status'=>'success',
                'message'=> 'Feedback Deleted Successfully',
                'message_ar'=> 'تم حذف التعليقات بنجاح',
            ], 200);
        }
        catch (\Exception $e)
        {
            //return $e;
            return response()->json(['status'=>'failed', 'message'=> 'Feedback Deletion Failed'], 400);
        }
    }

}
