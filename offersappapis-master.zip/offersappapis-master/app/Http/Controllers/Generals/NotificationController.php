<?php

namespace App\Http\Controllers\Generals;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Events\NotificationCreated;
use App\Models\Accounts\Credit;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use App\Models\Accounts\Transaction;
use App\Models\Accounts\Driver;
use App\Models\Accounts\User;
use App\Models\Generals\Notification;
use App\Models\Generals\Device;
use App\Models\Accounts\Payment;
use App\Models\Generals\NotificationLog;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Models\Generals\NotificationsFormats;
use App\Http\Controllers\Generals\DealController;
use App\Models\Accounts\OnsiteLocation;
use App\Models\Generals\SmsFormate;
use Illuminate\Support\Facades\Auth;
use Unifonic;

class NotificationController extends Controller
{
   
     /**
     * Retrieve notification formates and send notification to consumer ,  deal admin and technician
     *
     * @param  transaction_no, notification_for, transactionData, amount,, Notification to consumer, Notification to admin, Notification to technician
     */

    function getNotificationFormates($transaction_no, $notification_for, $transactionData, $amount, $isNotifyToConsumer, $isnotifyToAdmin, $isnotifyToTechnician, $actionType=''){
        try {

            $notificationFormates = NotificationsFormats::where('notification_for', $notification_for)->where('status', '1');
             if($actionType!=''){
                 // worng column @vijaya Please take a look
                $notificationFormates = $notificationFormates->where('action_type', $actionType);
             } 
             $list=$notificationFormates->orderBy('id', 'asc')->get();

            $notificationFormates = $list;
            $itemData = ItemMaster::where('id', $transactionData['item_id'])->select('title','title_ar','delar_id')->first();

            $driverData = Driver::where('id', $transactionData['created_by'])->first();

            $organizationId =$itemData['delar_id'];

            $dealShare = new DealController();
            $pricing = $dealShare->bill_price_logic($transactionData['transaction_no']);
            $finalPrice = $pricing['final_price'];
            $discountAmount = $transactionData['price'] - $finalPrice;
            $actualDiscount=round(($transactionData['price']*$transactionData['discount']/100),2);
            $discount=number_format(($discountAmount/$transactionData['price'])*100,0);
            
            $notificationId=0;

            $availableQuantity=$transactionData['quantity']-($transactionData['redeem_quantity']+$transactionData['revised_quantity']);

            $dealId=$transactionData['deal_id'];

            // For sms notifications
            $customerName=$driverData->first_name;
            $technician_name='';

            if(Auth::guard('driver')->id()){
                $techData=User::where('org_id', $organizationId)->where('role_id','3')->orderBy('id', 'asc')->select('id','preferred_language')->first();

                $technician_name=$techData->first_name;
            } else {
                $techData=User::where('id', Auth::id())->first();
                $technician_name=$techData->first_name;
            }

            if($notification_for=='42'){
                // Get logged in technician data
                $techData=User::where('id', Auth::id())->first();
                $technician_name=$techData->first_name;
            }

            $smsNotificationArray=array(
                'notification_for'=>$notification_for,
                'transaction_info'=>$transactionData,
                'customer_info'=>$driverData,
                'item_info'=>$itemData,
                'amount'=>$amount,
                'discount'=>$discount,
                'organizationId'=>$organizationId,
                'technician_name'=>$technician_name,
                'status'=>$actionType
            );

            //Send sms notifications to customers, dealers and operation team lead
            $this->sendSMSNotification($smsNotificationArray);

            foreach($notificationFormates as $singleRow){
                $user_type='C';
                if($singleRow->user_type=='D'){
                     $user_type='N';
                }  
 
                $isSend=$this->checkMutltipleNotifications($notification_for, $transaction_no, $singleRow, $user_type, $transactionData['deal_id'], $availableQuantity);
    
                if($isSend){
                    $notification=array();

                    $msg=$singleRow->notification_message; // For english notification
        
                    $replaceVariablesArray=[
                       'msg'=>$msg, 
                       'item_name'=>$itemData['title'],
                       'customer_name'=>$customerName, 
                       'transaction_no'=>$transaction_no,
                       'invoice_no'=>$transactionData->invoice_no, 
                       'amount'=>$amount, 
                       'discount'=>$discount, 
                       'technician_name'=>$technician_name
                    ];

                    $msg=$this->replaceVariables($replaceVariablesArray);    

                    $msg_ar=$singleRow->notification_message_ar; // For arabic notification

                    $replaceVariablesArrayArabic=[
                       'msg'=>$msg_ar, 
                       'item_name'=>$itemData['title_ar'],
                       'customer_name'=>$customerName, 
                       'transaction_no'=>$transaction_no,
                       'invoice_no'=>$transactionData['invoice_no'], 
                       'amount'=>$amount, 
                       'discount'=>$discount, 
                       'technician_name'=>$technician_name
                    ];

                    //$msg_ar=$this->replaceVariables($msg_ar, $itemData['title'], $driverData->first_name, $transaction_no, $transactionData['invoice_no'], $amount, $discount, $technician_name);

                    $msg_ar=$this->replaceVariables($replaceVariablesArrayArabic);

                    $notification = [
                        'notification_type' => 'I',
                        'notification_for' => $notification_for, 
                        'notification_title' => $singleRow->notification_title,
                        'notification_message' => $msg,
                        'notification_title_ar' =>$singleRow->notification_title_ar,
                        'notification_message_ar' =>$msg_ar,
                        'created_at' => date('Y-m-d H:i:s'),
                        'item_id' => $transactionData['item_id'],
                        'offer_id' => $transactionData['offer_id'],
                        'transaction_no' => $transaction_no,
                        'is_inapp'=>0,
                        'is_firebase'=>0,
                        'is_popup'=>0,
                        'is_sent'=>1,
                        'expired_on'=>date('Y-m-d H:i:s', strtotime("+".$singleRow->expired_on." days"))
                    ];

                    // if($notification_for==42){
                    //     $notification['navigation_id']=52;
                    // }
                   
                    $notificationId=0;
                    if($singleRow->type=='A'){
                        $notification['is_inapp']=1;  
                    } else if($singleRow->type=='P'){
                        $notification['is_popup']=1;
                    }  else if($singleRow->type=='F'){
                       $notification['is_firebase']=1;
                    } 

                    $notificationId = Notification::insertGetId($notification);
                    
                    if($singleRow->user_type=='C'){
                        if($isNotifyToConsumer){
                            $this->sendNotificationToConsumer($notification, $notificationId, $transactionData['created_by'], $singleRow->type);  
                        }
                    }

                    if($singleRow->user_type=='D'){
                        if($isnotifyToAdmin){
                           $sms_msg=$singleRow->sms_message; // For english notification
                            $replaceVariablesDArray=[
                               'msg'=>$sms_msg, 
                               'item_name'=>$itemData['title'],
                               'customer_name'=>$driverData->first_name, 
                               'transaction_no'=>$transaction_no,
                               'invoice_no'=>$transactionData->invoice_no, 
                               'amount'=>$amount, 
                               'discount'=>$discount, 
                               'technician_name'=>$technician_name
                            ];
 
                            $sms_msg=$this->replaceVariables($replaceVariablesDArray);

                            $smsmsg_ar=$singleRow->sms_message_ar; // For arabic notification

                            $replaceVariablesDArrayArabic=[
                               'msg'=>$smsmsg_ar, 
                               'item_name'=>$itemData['title_ar'],
                               'customer_name'=>$driverData->first_name, 
                               'transaction_no'=>$transaction_no,
                               'invoice_no'=>$transactionData->invoice_no, 
                               'amount'=>$amount, 
                               'discount'=>$discount, 
                               'technician_name'=>$technician_name
                             ];

                            $smsmsg_ar=$this->replaceVariables($replaceVariablesDArrayArabic);
                            $this->sendNotificationToDealAdmin($notification, $notificationId, $organizationId, $singleRow->type, $sms_msg, $smsmsg_ar);
                        }

                        if($isnotifyToTechnician){
                           $this->sendNotificationToTechnicians($notification, $notificationId, $organizationId, $singleRow->type, $transactionData['location_id']);
                        }
                    }
                }
                
            }
        } catch(\Exception $e){
             Log::error('Failed to send notification: '. $e->getMessage());
        }
    }

    function checkMutltipleNotifications($notification_for, $transaction_no, $singleRow, $user_type,$deal_id, $availableQuantity){
         $isSend=true;
         if($notification_for!='39' && $notification_for!='23'){

            $notificationData=Notification::where('notifications.notification_for', $notification_for)
                ->where('notifications.transaction_no', $transaction_no)
                ->join('notifications_log', 'notifications_log.notification_id', 'notifications.id');
          
            if($singleRow->type=='A'){
              $notificationData=$notificationData->where('notifications.is_inapp', '1');
            } else if($singleRow->type=='P'){
              $notificationData=$notificationData->where('notifications.is_popup', '1');
            }  else if($singleRow->type=='F'){
              $notificationData=$notificationData->where('notifications.is_firebase', '1');
            } 

            $notificationData=$notificationData->where('notifications_log.notification_for', $user_type);            
            $notificationData=$notificationData->get();
            $notificationCount=$notificationData->count();

            if($notificationCount>0 && $singleRow->type!='F'){
                if($notificationData->read_at!='' && $singleRow->type=='A'){
                    $isSend=true;
                } else if($notificationData->read_popup_at!='' && $singleRow->type=='P'){
                    $isSend=true;
                } else if($notificationData->expired_on<date('Y-m-d H:i:s')){
                    $isSend=true;
                } else if($deal_id==5 || $deal_id==4 && $availableQuantity>0){ 
                  $OnsiteCount=OnsiteLocation::where('transaction_no', $transaction_no)->count();
                  if($OnsiteCount==$notificationCount)
                    $isSend=false;
                  else 
                    $isSend=true;
                } else {
                    $isSend=false;
                }
            }
        }
        return  $isSend;
    }

    /**
     * Store a notification log for both consumer and technicians
     *
     * @param  Notification id, userId and userType
     */
    function saveNotificationLog($notificationId, $userId, $userType){

        NotificationLog::insert([
            'notification_id' => $notificationId,
            'notification_to' => $userId,
            'notification_for' => $userType, // Consumer or Admin or Technician
        ]);
    }

    /**
     * Send Notification or create notification logs to Deal Admin
     *
     * @param  notification details, Notification id, orgnization id and notiification type
    */

     function sendNotificationToDealAdmin($notificationArray, $notificationId, $organizationId, $notificationType , $smsMessage, $smsMessageArabic){
         try{
            $dealerData=User::where('org_id', $organizationId)->where('role_id','3')->orderBy('id', 'asc')->select('id','preferred_language')->first();

            if($dealerData) {

                $this->saveNotificationLog($notificationId, $dealerData->id, 'N');     

                if($notificationType=='F'){
                    $notification=$notificationArray;
                    $dealer_tokens = Device::where('devices.user_id', $dealerData->id)
                        ->where('devices.user_type', 'user')
                        ->where('devices.fcm','!=','')
                        ->where('devices.status','=',1)
                        ->orderBy('devices.id', 'desc')
                        ->select('devices.fcm','devices.device_type')
                        ->get();
                    
                    if(!empty($dealer_tokens)){ 

                      foreach ($dealer_tokens as $singleRow) {
                      
                        $dealerToken=$singleRow->fcm;
                        $deviceType=$singleRow->device_type;
                        if($singleRow->fcm != ''){

                            $notificationTitle=$notification['notification_title'];
                            $notificationMsg= $notification['notification_message'];
                            
                            if($dealerData->preferred_language=='ar'){
                                $notificationTitle=$notification['notification_title_ar'];
                                $notificationMsg=$notification['notification_message_ar'];
                                $smsMessage=$smsMessageArabic;
                            }

                            (new SendPushNotification())->sendNotifyToUser(
                                $dealerToken,
                                $notificationTitle,
                                $notificationMsg,
                                $notification['notification_for'],
                                '1',
                                $dealerData->id,
                                $notification['item_id'],
                                $notification['offer_id'],
                                'partner',
                                $notification['transaction_no'],
                                $deviceType,
                                $smsMessage
                            );
                        }  
                      } 
                    }
                }
            }
           
        } catch (\Exception $e) {
             Log::error('Send Notification :: Failed: '. $e->getMessage());
        }
     }

     /**
     * Send Notification or create notification logsto technicians
     *
     * @param  notification details, Notification id, orgnization id and notiification type
     */

     function sendNotificationToTechnicians($notificationArray, $notificationId, $organizationId, $notificationType, $locationId){
        
        try{
            $technicians = User::join('technician_locations as tl', 'users.id', '=', 'tl.technician_id')
                ->where('users.org_id', $organizationId)
                ->where('users.status', 1)
                ->where('tl.location_id', $locationId)
                ->pluck('users.id');

            if(!$technicians)
                return response()->json(['status' => 'success', 'message' => 'Firebase Notifications not available'], 200);

            $tech_notes = [];
            foreach ($technicians as $techid){
                $tech_notes[] = [
                    'notification_id' => $notificationId,
                    'notification_to' => $techid,
                    'notification_for' => 'N', // Non Consumer
                ];
            }
            NotificationLog::insert($tech_notes);    
            if($notificationType=='F'){
                // Send notification to Technician on Add Transaction
                $notification=$notificationArray;
                $technicians_tokens = User::join('technician_locations as tl', 'users.id', '=', 'tl.technician_id')
                    ->join('devices', 'users.id', '=', 'devices.user_id')
                    ->where('users.org_id', $organizationId)
                    ->where('users.status', 1)
                    ->where('tl.location_id', $locationId)
                    ->where('devices.user_type', 'user')
                    ->where('devices.status', 1)
                    ->where('devices.fcm','!=','')
                    ->orderBy('devices.id', 'desc')
                    ->select('devices.fcm','tl.technician_id','devices.device_type','users.preferred_language')->get();


                if(!empty($technicians_tokens)){
                    foreach($technicians_tokens as $singleTechnician){ 
                       $technicianId=$singleTechnician->technician_id;
                       $technicians_tokens=$singleTechnician->fcm;
                       $technicians_device_type=$singleTechnician->device_type;
                        if($technicians_tokens){ 
                            $notificationTitle=$notification['notification_title'];
                            $notificationMsg= $notification['notification_message'];
                            if($singleTechnician->preferred_language=='ar'){
                                $notificationTitle=$notification['notification_title_ar'];
                                $notificationMsg=$notification['notification_message_ar'];
                            }
                            (new SendPushNotification())->sendNotifyToUser(
                                $technicians_tokens,
                                $notificationTitle,
                                $notificationMsg,
                                $notification['notification_for'],
                                '1',
                                $technicianId,
                                $notification['item_id'],
                                $notification['offer_id'],
                                'partner',
                                $notification['transaction_no'],
                                $technicians_device_type
                            );
                        }
                    }    
                }
           }
        } catch (\Exception $e) {
           Log::error('Send Notification to technicians :: Failed: '. $e->getMessage());
        }
     }
    
     /**
     * Send Notification or create notification logs to consumer
     *
     * @param  notification details, Notification id, userId and notification type
     */
    function sendNotificationToConsumer($notificationArray, $notificationId, $consumerId, $notificationType){
        try {
            $this->saveNotificationLog($notificationId, $consumerId, 'C');          
            if($notificationType=='F'){
                $notification=$notificationArray;

                $consumer_tokens = Driver::join('devices', 'drivers.id', '=', 'devices.user_id')
                    ->where('drivers.id', $consumerId)
                    ->where('devices.user_type', 'driver')
                    ->where('devices.fcm','!=','')
                    ->where('devices.status','=',1)
                    ->orderBy('devices.id', 'desc')
                    ->select('devices.fcm','devices.device_type','drivers.preferred_language')->get();

                if(!empty($consumer_tokens)){
                    foreach ($consumer_tokens as $singleRow) {
                      if($singleRow->fcm!='')
                      {
                          $notificationTitle=$notification['notification_title'];
                          $notificationMsg= $notification['notification_message'];
                          if($singleRow->preferred_language=='ar'){
                              $notificationTitle=$notification['notification_title_ar'];
                              $notificationMsg=$notification['notification_message_ar'];
                          }

                          (new SendPushNotification())->sendNotifyToUser( 
                              $singleRow->fcm,
                              $notificationTitle,
                              $notificationMsg,
                              $notification['notification_for'],
                              1,
                              1,
                              $notification['item_id'],
                              $notification['offer_id'],
                              'consumer',
                              $notification['transaction_no'],
                              $singleRow->device_type
                          );
                      }
                   }
                }
            }
         } catch (\Exception $e) {
           Log::error('Send Notification to customer :: Failed: '. $e->getMessage());
        }
     }


     public function send_notificationfor_missing_newoffer_alert(){
        $list = DB::query("select a.id, a.title, a.deal_id, b.id as offer_id, c.item_id from item_master as a join item_offers as b on a.id = b.item_id
            and a.status = 1 and b.status = 1 and b.start_date >= now()
            left join (select DISTINCT item_id, offer_id from notifications where notification_for = 23) as c on
            a.id = c.item_id and b.id = c.offer_id
            where c.item_id is null");

        foreach($list as $row){
            $this->sendNewOfferNotification($row['id'], $row['deal_id'], $row['offer_id'], 23);
        }
     }


      /**
     * Send new offer notification  to consumer
     *
     * @param  item id, deal type, offer id and notification code
     */

     public function sendNewOfferNotification($item_id, $deal_id, $offer_id = '', $notification_for) {

        try{
            Log::info("Notification sent on offer creation item id ".$item_id." offer id ".$offer_id);
            $offers = ItemOffer::where('item_id', $item_id);
            if($offer_id != '')
                $offers = $offers->where('id', $offer_id);
            $offers = $offers->where('status', 1)->get();
            $itemData = ItemMaster::where('id', $item_id)->select('title','title_ar')->first();

            $notificationFormates = NotificationsFormats::where('notification_for', $notification_for)->where('status', '1')->orderBy('id', 'asc')->get();            

            // Eligibility: who have related vehicles
            foreach($offers as $offer){
                if($deal_id == 4 || $deal_id == 5) { //4=wash, 5=detailing
                    $consumers = Driver::join('vehicles', 'drivers.id', 'vehicles.owner_id')
                        ->join('deal_vehicles', 'vehicles.group_id', 'deal_vehicles.group_id')
                        ->join('devices', 'devices.user_id', 'drivers.id')
                        ->select('drivers.*', 'devices.fcm', 'devices.device_type')
                        ->where('drivers.status', 1)
                        ->where('devices.status', 1)
                        ->where('vehicles.status', 1)
                        ->where('deal_vehicles.offer_id', $offer['id'])
                        ->where('deal_vehicles.item_id', $offer['item_id'])
                        ->where('devices.user_type', 'driver')
                        ->where('devices.fcm','!=','')
                        ->get();
                }
                else{ // 2=tire, 6=battery
                    $consumers = Driver::join('devices', 'devices.user_id', 'drivers.id')
                        ->select('drivers.*', 'devices.fcm', 'devices.device_type')
                        ->where('drivers.status', 1)
                        ->where('devices.user_type', 'driver')
                        ->where('devices.status', 1)
                        ->where('devices.fcm','!=','')
                        ->get();
                }

                $dealShare = new DealController();
                $pricing = $dealShare->price_logic($offer['price'], $offer['discount'], $offer['deal_id']);
                $finalPrice = $pricing['final_price'];
                $discountAmount = $offer['price'] - $finalPrice;
                $actualDiscount=round(($offer['price']*$offer['discount']/100),2);
                $discount=number_format(($discountAmount/$offer['price'])*100,0);
              
                if(!empty($consumers)){
                    foreach($consumers as $driverData){
                        foreach($notificationFormates as $singleRow){
                            $notification=array();
                            $msg=$singleRow->notification_message; // For english notification
                            $msg = str_replace("{item_name}", $itemData['title'], $msg);
                            $msg = str_replace("{customer_name}", $driverData['first_name'], $msg);
                            $msg = str_replace("{transaction_no}",'', $msg);
                            $msg = str_replace("{invoice_no}",'', $msg);
                            $msg = str_replace("{amount}",$offer['price'].' SAR' , $msg);
                            $msg = str_replace("{discount}",$discount.'%' , $msg);

                            $msg_ar=$singleRow->notification_message_ar; // For arabic notification
                            $msg_ar = str_replace("{item_name}", $itemData['title_ar'], $msg_ar);
                            $msg_ar = str_replace("{customer_name}", $driverData['first_name'], $msg_ar);
                            $msg_ar = str_replace("{transaction_no}",'' , $msg_ar);
                            $msg_ar = str_replace("{invoice_no}",'' , $msg_ar);
                            $msg_ar = str_replace("{amount}",$offer['price'].' SAR' , $msg_ar);
                            $msg_ar = str_replace("{discount}",$discount.'%' , $msg_ar);

                            $notification = [
                                'notification_type' => 'I',
                                'notification_for' => $notification_for, 
                                'notification_title' => $singleRow->notification_title,
                                'notification_message' => $msg,
                                'notification_title_ar' =>$singleRow->notification_title_ar,
                                'notification_message_ar' =>$msg_ar,
                                'created_by' => 1,
                                'created_at' => date('Y-m-d H:i:s'),
                                'item_id' => $item_id,
                                'offer_id' =>  $offer->id,
                                'transaction_no' => null,
                                'is_inapp'=>0,
                                'is_firebase'=>0,
                                'is_popup'=>0,
                                'is_sent'=>1,
                                'expired_on'=>date('Y-m-d', strtotime("+".$singleRow->expired_on." days"))
                            ];
                           
                            $notificationId=0;
                            if($singleRow->type=='A'){
                                $notification['is_inapp']=1;  
                            } else if($singleRow->type=='P'){
                                $notification['is_popup']=1;
                            }  else if($singleRow->type=='F'){
                               $notification['is_firebase']=1;
                            } 

                            $notificationId = Notification::insertGetId($notification);

                            NotificationLog::insert([
                                'notification_id' => $notificationId,
                                'notification_to' => $driverData['id'],
                                'notification_for' => 'C',
                            ]); 

                            if($singleRow->type=='F'){
                                if($driverData['fcm']){
                                    $notificationTitle=$notification['notification_title'];
                                    $notificationMsg= $notification['notification_message'];
                                    if($driverData['preferred_language']=='ar'){
                                        $notificationTitle=$notification['notification_title_ar'];
                                        $notificationMsg=$notification['notification_message_ar'];
                                    }

                                   (new SendPushNotification())->sendNotifyToUser( 
                                        $driverData['fcm'],
                                        $notificationTitle,
                                        $notificationMsg,
                                        $notification['notification_for'],
                                        1,
                                        1,
                                        $notification['item_id'],
                                        $notification['offer_id'],
                                        'consumer',
                                        '',
                                        ''
                                    );
                                }
                            }   

                        } // echo notification formate

                    } // foreach user
                }  
            } 
        } catch (\Exception $e) {
          Log::error('Send Notification to new offers :: Failed: '. $e->getMessage());
        } 
    }

    /**
     * Send gift credits to all seleced customers
     * 
     * @param $gift_amount, $consumersList, $notification_for
     */
    public function sendGiftCreditsToConsumer($gift_amount, $consumersList, $notification_for, $notificationFormates) {

        try{
            Log::info('Gift notification add start');
            $users = Driver::whereIn('id', $consumersList)->get();

            if(!empty($users)){
                foreach($users as $singleUser){
                    foreach($notificationFormates as $singleRow){
                        $notification=array();

                        $msg=$singleRow->notification_message; // For english notification
                        $msg = str_replace("{customer_name}", $singleUser->first_name, $msg);
                        $msg = str_replace("{amount}", $gift_amount, $msg);
                        $msg = str_replace("{gift_amount}", $gift_amount, $msg);
                       
                        $msg_ar=$singleRow->notification_message_ar; // For arabic notification
                        $msg_ar = str_replace("{customer_name}", $singleUser->first_name, $msg_ar);
                        $msg_ar = str_replace("{amount}",$gift_amount , $msg_ar);
                        $msg_ar = str_replace("{gift_amount}",$gift_amount , $msg_ar);
                       

                        $notification = [
                            'notification_type' => 'I',
                            'notification_for' => $notification_for, 
                            'notification_title' => $singleRow->notification_title,
                            'notification_message' => $msg,
                            'notification_title_ar' =>$singleRow->notification_title_ar,
                            'notification_message_ar' =>$msg_ar,
                            'created_at' => date('Y-m-d H:i:s'),
                            'item_id' =>null,
                            'offer_id' => null,
                            'transaction_no' => null,
                            'is_inapp'=>0,
                            'is_firebase'=>0,
                            'is_popup'=>0,
                            'is_sent'=>1,
                            'expired_on'=>date('Y-m-d', strtotime("+".$singleRow->expired_on." days"))
                        ];
                       
                        $notificationId=0;
                        if($singleRow->type=='A'){
                            $notification['is_inapp']=1;  
                        } else if($singleRow->type=='P'){
                            $notification['is_popup']=1;
                        }  else if($singleRow->type=='F'){
                           $notification['is_firebase']=1;
                        } 

                        $notificationId = Notification::insertGetId($notification);

                        $this->sendNotificationToConsumer($notification, $notificationId, $singleUser->id, $singleRow->type);  

                    } // echo notification formate

                } // foreach user
                
           } // if condition

        } catch (\Exception $e) {
           Log::error('Send Notification to gift credits :: Failed: '. $e->getMessage());
        }
    }


    /**
     * Send gift credits to all seleced customers
     * 
     * @param $gift_amount, $consumersList, $notification_for
    */
    public function sendNewFormateGiftCreditsToConsumer($gift_amount, $customerData, $notification_for, $notificationFormates) {

        try{
            Log::info('Gift notification add start');
            $singleUser=$customerData;
            $group_id=0;
            if(isset($singleUser->group_id)){
               $group_id=$singleUser->group_id;
               $customerId=$singleUser->driver->id;
               $customerName=$singleUser->driver->first_name;
            } else {
                 $customerId=$singleUser->id;
               $customerName=$singleUser->first_name;
            }
 
            foreach($notificationFormates as $singleRow){
                $notification=array();
                $msg=$singleRow->notification_message; // For english notification
                $msg = str_replace("{customer_name}", $customerName, $msg);
                $msg = str_replace("{amount}", $gift_amount, $msg);
                $msg = str_replace("{gift_amount}", $gift_amount, $msg);
               
                $msg_ar=$singleRow->notification_message_ar; // For arabic notification
                $msg_ar = str_replace("{customer_name}", $customerName, $msg_ar);
                $msg_ar = str_replace("{amount}",$gift_amount , $msg_ar);
                $msg_ar = str_replace("{gift_amount}",$gift_amount , $msg_ar);
               
                $notification = [
                    'notification_type' => 'I',
                    'notification_for' => $notification_for, 
                    'notification_title' => $singleRow->notification_title,
                    'notification_message' => $msg,
                    'notification_title_ar' =>$singleRow->notification_title_ar,
                    'notification_message_ar' =>$msg_ar,
                    'created_at' => date('Y-m-d H:i:s'),
                    'item_id' =>null,
                    'offer_id' => null,
                    'transaction_no' => null,
                    'is_inapp'=>0,
                    'is_firebase'=>0,
                    'is_popup'=>0,
                    'is_sent'=>1,
                    'expired_on'=>date('Y-m-d', strtotime("+".$singleRow->expired_on." days"))
                ];
               
                $notificationId=0;
                if($singleRow->type=='A'){
                    $notification['is_inapp']=1;  
                } else if($singleRow->type=='P'){
                    $notification['is_popup']=1;
                }  else if($singleRow->type=='F'){
                   $notification['is_firebase']=1;
                } 

                $notificationId = Notification::insertGetId($notification);
               
               $insertId=NotificationLog::insertGetId([
                    'notification_id' => $notificationId,
                    'notification_to' => $customerId,
                    'group_id'=>$group_id,
                    'notification_for' =>'C', // Consumer or Admin or Technician
                ]);

                if($singleRow->type=='F'){

                    $consumer_tokens = $singleUser->loggedin_devices;
                    if(!empty($consumer_tokens)){
                        $notificationTitle=$notification['notification_title'];
                        $notificationMsg= $notification['notification_message'];
                        if($singleUser->preferred_language=='ar'){
                            $notificationTitle=$notification['notification_title_ar'];
                            $notificationMsg=$notification['notification_message_ar'];
                        }

                        foreach ($consumer_tokens as $singleRow) {
                            if($singleRow->fcm!='' && $singleRow->status) {  
                                (new SendPushNotification())->sendNotifyToUser( 
                                  $singleRow->fcm,
                                  $notificationTitle,
                                  $notificationMsg,
                                  $notification['notification_for'],
                                  1,
                                  $customerId,
                                  '',
                                  '',
                                  'consumer',
                                  '',
                                  $singleRow->device_type,
                                  '',
                                  ''
                                );
                            }
                        } 
                    } // echo notification formate   
                }
            }

        } catch (\Exception $e) {
           Log::error('Send Notification to gift credits :: Failed: '. $e->getMessage());
        }
    }

    /**
    * get all notifications list for admin
    * 
    * @param $user_id, $type
    */

    public function getUserNotificationsList($user_id='', $type='C')
    {
        $notifications = Notification::select('notifications.*')
            ->join('notifications_log', 'notifications.id', 'notifications_log.notification_id');
        if($type == 'N')
        {
            $org_id = User::where('id', $user_id)->pluck('org_id')->first();
            $notifications = $notifications->join('item_master', function($qry) use ($org_id){
                $qry->on('notifications.item_id', 'item_master.id');
                $qry->where('item_master.delar_id', $org_id);
            });
        }
        $list = $notifications->where('notifications_log.notification_to', $user_id)
            ->where('notifications_log.notification_for', $type)
            ->where('notifications.is_inapp', '1')
            ->whereNull('notifications_log.deleted_at')
            ->with('deal', 'offer', 'deal.deal', 'transaction', 'transaction.payment_details')
            ->orderBy('notifications.id', 'desc')
            ->skip(0)->take(10)->get();

        return $list;
    }

    /**
     * send sms to customer, dealer and Operation team leader
     * @param $transactionData, $notification_for
     */
    function sendSMSNotification($notificationArray){
        $smsData = SmsFormate::where('notification_for', $notificationArray['notification_for'])->first();
        try {
            if($smsData){
                $itemData=$notificationArray['item_info'];
                $driverData=$notificationArray['customer_info'];
                $transactionData=$notificationArray['transaction_info'];
                $customerMsg=$smsData->customer_message;
                $amount=$notificationArray['amount'];
                $discount=$notificationArray['discount'];
                $organizationId=$notificationArray['organizationId'];
                $technician_name=$notificationArray['technician_name'];
                $status=$notificationArray['status'];

                //Send notification to customer
                $itemTitle=$itemData['title'];
                $notificationStatus=$notificationArray['status'];
                if($driverData->preferred_language=='ar'){
                    $customerMsg=$smsData->customer_message_ar;
                    $itemTitle=$itemData['title_ar'];
                    $notificationStatus=$this->getArabic($notificationArray['status']);
                }

                $this->sendSMS($customerMsg, $itemTitle, $driverData->first_name, $transactionData->transaction_no,$transactionData->invoice_no, $amount, $discount, $driverData->contact_no, $notificationStatus, $technician_name);

                //Send notification to dealer
                $dealerData=User::select('id','contact_no','preferred_language')->where('org_id', $organizationId)->where('role_id', 3)->orderBy('id','ASC')->first();

                if(!empty($dealerData)) {
                    $dealerMsg=$smsData->dealer_message;
                    $notificationStatus=$notificationArray['status'];
                    if($dealerData->preferred_language=='ar'){
                        $dealerMsg=$smsData->dealer_message_ar;
                        $itemTitle=$itemData['title_ar'];
                        $notificationStatus=$this->getArabic($notificationArray['status']);
                    }

                    $this->sendSMS($dealerMsg, $itemTitle, $dealerData->first_name, $transactionData->transaction_no,$transactionData['invoice_no'], $amount, $discount, $dealerData->contact_no,$notificationStatus, $technician_name);
                }

                //Send notification to operation team leader
                $itemTitle=$itemData['title'];
                $notificationStatus=$notificationArray['status'];
                $operationManagerMsg=$smsData->operator_message;

                $this->sendSMS($operationManagerMsg, $itemTitle, $driverData->first_name, $transactionData->transaction_no,$transactionData['invoice_no'], $amount, $discount, env('OPERATION_TEAM_LEAD_CONTACT'), $notificationStatus, $technician_name);

            }
       } catch (\Exception $e) {
          Log::error('Send SMS notifications for all transaction :: Failed: '. $e->getMessage());
       }
    }

    //Get arabic status
    function getArabic($status){
        $st='متوفر';
        if($status=='Available')
            $st='متوفر';
        else if($status=='Rejected')
            $st='نبيذ';
        else if($status=='Cancelled')
            $st='الغاء';

        return $st;
    }

    /**
     * send sms to particular contact number
     * @param $msg, $itemName, $customerName, $transactionNo, $invoiceNo, $amount, $discount, $contactno, $status
     */
    
    function sendSMS($msg, $itemName, $customerName, $transactionNo, $invoiceNo, $amount, $discount, $contactno, $status, $technician_name){

       // $msg=$this->replaceVariables($msg, $itemName, $customerName, $transactionNo, $invoiceNo, $amount, $discount, $status,'');


        $replaceVariablesArray=[
           'msg'=>$msg, 
           'item_name'=>$itemName,
           'customer_name'=>$customerName, 
           'transaction_no'=>$transactionNo,
           'invoice_no'=>$invoiceNo, 
           'amount'=>$amount, 
           'discount'=>$discount, 
           'status'=>$status,
           'technician_name'=>$technician_name
        ];

        //$msg=$this->replaceVariables($msg, $itemName, $customerName, $transactionNo, $invoiceNo, $amount, $discount, $status,'');

        $msg=$this->replaceVariables($replaceVariablesArray);

        if(env('APP_OTP') != 'production')
            return false;

        try {
            $response = Unifonic::send($contactno, $msg, env('UNIFONIC_SENDER_ID'));
            if ($response->success == true) {
                Log::info('Send SMS:: response : ' . json_encode($response));
            } else {
                Log::error('Send SMS:: Failed : ' . json_encode($response));
            }
        } catch (\Exception $e) {
            Log::error('Send SMS:: Failed: '. $e->getMessage());
        }
    }

    /**
     * Replace variable with orginal values
     * @param $replaceVariablesArray
     */   
    //$msg, $itemName, $customerName, $transactionNo, $invoiceNo, $amount, $discount, $status=''
    function replaceVariables($replaceVariablesArray){

         $msg=$replaceVariablesArray['msg'];

         $msg = str_replace("{item_name}", $replaceVariablesArray['item_name'], $msg);
         $msg = str_replace("{customer_name}", $replaceVariablesArray['customer_name'], $msg);
         
         if(array_key_exists('technician_name',$replaceVariablesArray)){
             $msg = str_replace("{technician_name}", $replaceVariablesArray['technician_name'], $msg);
         }

         $msg = str_replace("{transaction_no}",$replaceVariablesArray['invoice_no'] , $msg);
         $msg = str_replace("{invoice_no}",$replaceVariablesArray['invoice_no'] , $msg);
         $msg = str_replace("{amount}",$replaceVariablesArray['amount'] , $msg);
         $msg = str_replace("{discount}",$replaceVariablesArray['discount']."%" , $msg);

         if(array_key_exists('status',$replaceVariablesArray)){
             $msg = str_replace("{status}",$replaceVariablesArray['status'], $msg);
         }

         return $msg;
    }


    /**
    * get all notifications list for admin
    * 
    * @param $request
    * @return \Illuminate\Http\Response
    */
    public function getNotificationsList(Request $request)
    {    
        try { 
            $org_id = 0;
            $pageno = 1; $pagelength = 10;
            $user_id=$request->user_id;
            $type=$request->user_type;
            
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
            }

            $notifications = Notification::select('notifications.*','notifications_log.read_at')
                ->join('notifications_log', 'notifications.id', 'notifications_log.notification_id');
            if($type == 'N')
            {
                $org_id = User::where('id', $user_id)->pluck('org_id')->first();
                $notifications = $notifications->join('item_master', function($qry) use ($org_id){
                    $qry->on('notifications.item_id', 'item_master.id');
                    $qry->where('item_master.delar_id', $org_id);
                });
            }
            
            $list = $notifications->where('notifications_log.notification_to', $user_id)
                ->where('notifications_log.notification_for', $type)
                ->where('notifications.is_inapp', '1')
                ->whereNull('notifications_log.deleted_at')
                ->with('deal', 'offer', 'deal.deal', 'transaction', 'transaction.payment_details')
                ->orderBy('notifications.id', 'desc');

            $totalrecords = $list->count();
            $list = $list->skip(($pageno-1)*$pagelength)->take($pagelength)->get();

            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status' => 'success', 'data' => $data], 200);
        } catch(\Exception $e){
          return response()->json(['status'=>'failed', 'message'=> 'Failed to get notifications list'], 400);
        }
    } 
}
