<?php

namespace App\Http\Controllers\Generals;

use App\Http\Controllers\Controller;
use App\Models\Generals\Feature;
use App\Models\Generals\Lookup;
use App\Models\Generals\Role;
use App\Models\Generals\RoleFeature;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Models\Regulatory\OrgDeal;
use App\Models\Regulatory\Delar;
use App\Models\Accounts\User;
class RoleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        try {
            $list = Role::where('status', 1)->with('role_type')->withCount('users');

            if(isset($request->login_type_id) && $request->login_type_id!=17){ // list out roles by login specific
                $list->where('login_type_id', $request->login_type_id);
            } 

            $list->whereNotIn('login_type_id', [49, 21, 22]); // Guest, Customer, Technician role not required

            $pageno = 0; $pagelength = 0; 
            $totalrecords = $list->count();
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
                $list = $list->skip( ($pageno-1)*$pagelength )->take($pagelength);
            }  
                
            $list=$list->orderBy('id', 'desc')->get();
              
            $data['data'] = $list;
            $data['current_page'] =$pageno ? $pageno : '1';
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength ? $pagelength : '200';

            return response()->json(['status' => 'success', 'data' => $data], 200);
        } catch( Exception $e) {
            return response()->json(['status' => 'failed', 'message' => 'No Roles'], 400);
        }
    }

 
    /**
     * Active Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function active_roles($login_type = null)
    {
        try {
            $list = Role::where('status', 1);
            if(isset($login_type) && !empty($login_type)){
                $list->where('login_type_id', $login_type);
            }
            $list->where('login_type_id', '!=', 49); // Guest role not required
            $list = $list->orderBy('id', 'desc')->get();
            return response()->json(['status' => 'success', 'data' => $list], 200);
        }catch( Exception $e) {
            return response()->json(['status' => 'failed', 'message' => 'No Roles'], 400);
        }
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'title'    => ['required', 'string', 'max:30', 'unique:roles' ],
                'login_type_id'    => ['required' ],
                'status'    => ['required' ],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try {
            $role_id = Role::insertGetId(array(
                'title' => $request['title'],
                'login_type_id' => $request['login_type_id'],
                'status' => $request['status'],
                'created_at' => date('Y-m-d H:i:s')
            ));

            $request['role_id'] = $role_id;
            $this->setFeatures($request);

            return response()->json([
                'status' => 'success',
                'response' => 'Role added successfully'
            ], 200);
        }
        catch (\Exception $e){
            return response()->json(['status' => 'failed', 'message' => 'Role add Failed','error'=>$e->getMessage()], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $list = Role::whereId($id)->first();
        $features = RoleFeature::where('role_id', $id)->get();

        $list['features'] = $features;

        if($id=='3'){ 

            $orgId=Auth::user()->org_id;

            $dealIDs=array();
            $dealerData = Delar::where('id', $orgId)->with('deal')->where('status', 1)->first();
            if($dealerData){
               $dealsList=$dealerData->deal;

               if($dealsList){
                    foreach($dealsList as $singleRow){
                        
                        // if($singleRow->title=='Oil Changes'){
                        //     $dealIDs[]=161;
                        // } else if($singleRow->title=='Car Wash'){
                        //     $dealIDs[]=124;
                        // } else if($singleRow->title=='Car Care'){
                        //     $dealIDs[]=127;
                        // } else if($singleRow->title=='Tires'){
                        //     $dealIDs[]=121;
                        // } else if($singleRow->title=='Batteries'){
                        //     $dealIDs[]=130;
                        // } 


                        if($singleRow->title=='Oil Changes'){
                            $dealIDs[]=92;
                        } else if($singleRow->title=='Car Wash'){
                            $dealIDs[]=86;
                        } else if($singleRow->title=='Car Care'){
                            $dealIDs[]=87;
                        } else if($singleRow->title=='Tires'){
                            $dealIDs[]=85;
                        } else if($singleRow->title=='Batteries'){
                            $dealIDs[]=88;
                        } 
                    }
                }               
            }
            // Check logged delar able to see his selected categories only
            if(Auth::user()->login_type_id==18){
                foreach($features as $singleRow11){
                    if($singleRow11->feature_id>84 && $singleRow11->feature_id<93){
                        $singleRow11->status=0;  
                        if(in_array($singleRow11->feature_id, $dealIDs)){
                            $singleRow11->status=1;
                        }  
                    }
                }
            }

        }

        return response()->json(['status' => 'success', 'data' => $list], 200);
    }


        /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function getRoleInfo($id)
    {
        $list = Role::whereId($id)->first();
        $features = RoleFeature::where('role_id', $id)->get();
        $list['features'] = $features;
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(),
            [
                'title'    => ['required', 'string', 'max:30' ],
                'login_type_id' => ['required'],
                'status'    => ['required' ],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try {
            //Check logged in user is partner or dealer then they can't modify other company role details
            if(Auth::user()->login_type_id!=17 && $request['login_type_id']!=Auth::user()->login_type_id){ 
                return response()->json(['status' => 'failed', 'response' => "You can't modify other company role details users information"], 400);   
            } 

            if(Auth::user()->role_id==$id){ 
                 return response()->json(['status' => 'failed', 'response' => "You can't modify your logged in user role"], 400);   
            }

            Role::whereId($id)->update(array(
                'title' => $request['title'],
                'login_type_id' => $request['login_type_id'],
                'status' => $request['status'],
                'updated_at' => date('Y-m-d H:i:s')
            ));

            $request['role_id'] = $id;
             $this->setFeatures($request);

 
            return response()->json([
                'status' => 'success',
                'response' => 'Role updated successfully',
            ], 200);
        } catch (\Exception $e){
            return response()->json(['status' => 'failed', 'message' => 'Role update Failed','error'=>$e->getMessage()], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function login_types()
    {
        $login_type_id=Auth::user()->role->login_type_id;

        $list = Lookup::where('group_id', 5);

        if($login_type_id==17){
            $list =$list->where('code','<',21);
        } else {
            $list =$list->where('code',$login_type_id); 
        }

        $list =$list->where('status', 1)->get();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    public function features($login_type_id = null)
    {
        $list = Feature::join('lookup', 'lookup.id', 'features.feature_type')
                    ->select('features.*', 'lookup.entity_name as feature_type')->orderBy('order_by', 'ASC');
        
        if(isset($login_type_id) && !empty($login_type_id)){
            $list->where('login_type_id', $login_type_id);
        }

        $list = $list->where('features.status', 1)->get();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    public function setFeatures($request)
    {
        RoleFeature::where('role_id', $request['role_id'])->delete();
        $featuresArray = [];
        foreach ($request->features as $feature)
        { 
            $featuresArray[] = array(
                'role_id' => $request['role_id'],
                'feature_id' => $feature['feature_id'],
                'status' => $feature['status'],
            );
        }
        RoleFeature::insert($featuresArray); 

       //Update main feature if status=0
      // $this->updateMainFeature($request['role_id']);
    }

    private function updateMainFeature($roleId){
         
        $featureArray=[];
        $roleFeatures=RoleFeature::where('role_id', $roleId)
                      ->with('features_list','features_list.main_feature')
                      ->where('status',1)->get();
        $features = [];
    
        if($roleFeatures){
            foreach($roleFeatures as $singleRow){
                $featureInfo=$singleRow->features_list;
                if($featureInfo->id!=$featureInfo->origin_id){ 
                    if($featureInfo->main_feature->id != $featureInfo->main_feature->origin_id){
                        if(!in_array($featureInfo->main_feature->id, $featureArray)){
                            $featureArray[] = $featureInfo->main_feature->id;
                            $features[] = array(
                                'role_id' => $roleId,
                                'feature_id' =>$featureInfo->main_feature->id,
                                'status' => 1,
                            );
                        }

                        if(!in_array($featureInfo->main_feature->origin_id, $featureArray)){
                            $featureArray[] = $featureInfo->main_feature->origin_id;
                            $features[] = array(
                                'role_id' => $roleId,
                                'feature_id' => $featureInfo->main_feature->origin_id,
                                'status' => 1
                            );
                        } 
                    } 
                } 
            }
        }
 
        if(count($featureArray)>0){
            RoleFeature::where('role_id', $roleId)->whereIn('feature_id', $featureArray)->delete();
            RoleFeature::insert($features);
        }
    }

    public function user_menu()
    {
        // TODO: side Menu navigations listed here
        $list = Feature::join('role_features', 'role_features.feature_id', 'features.id')
                ->select('features.*')
                ->where('role_features.role_id', Auth::user()->role_id)
                ->where('is_menu', 1)
                ->where('role_features.status', 1)
                ->get()->toArray();

        $features = [];
        foreach ($list as $row){
            if($row['feature_type'] == 12){
                $features[] = $row;
            }
            else if($row['feature_type'] == 13)
            {
                for($i = 0; $i < count($features); $i++)
                {
                    if($features[$i]['id'] == $row['origin_id'])
                        $features[$i]['sub'][] = $row;
                }
            }
        }

        return response()->json(['status' => 'success', 'data' => $features], 200);
    }

}
