<?php

namespace App\Http\Controllers\Generals;

use App\Http\Controllers\Controller;
use App\Models\Generals\Feature;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class FeatureController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($login_type = null)
    {
        $data = Feature::where('login_type_id', $login_type)->where('status', 1)->get();
        return response(['status' => 'success', 'data' => $data ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'title'    => ['required', 'string', 'max:30' ],
                'alias_name'    => ['required', 'string', 'max:30' ],
                'url'    => ['required', 'string', 'max:60' ],
                'login_type_id'    => ['required'],
                'is_menu'    => ['required'],
                'feature_type'    => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try {
            $request['created_at'] = date('Y-m-d H:i:s');
            Feature::create($request->all());

            return response()->json(['status' => 'success', 'response' => 'Feature added successfully' ], 200);
        }
        catch (\Exception $e){
            return response()->json(['status' => 'failed', 'message' => 'Feature add Failed'], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = Feature::where('id', $id)->where('status', 1)->first();
        return response(['status' => 'success', 'data' => $data ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(),
            [
                'title'    => ['required', 'string', 'max:30' ],
                'alias_name'    => ['required', 'string', 'max:30' ],
                'url'    => ['required', 'string', 'max:60' ],
                'login_type_id'    => ['required'],
                'is_menu'    => ['required'],
                'feature_type'    => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try {
            $request['created_at'] = date('Y-m-d H:i:s');
            Feature::where('id', $id)->update($request->all());

            return response()->json(['status' => 'success', 'response' => 'Feature added successfully' ], 200);
        }
        catch (\Exception $e){
            return response()->json(['status' => 'failed', 'message' => 'Feature add Failed'], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Feature::where('id', $id)->update(['status' => 0]);
        return response()->json(['status' => 'success', 'response' => 'Feature deactivated successfully' ], 200);
    }
}
