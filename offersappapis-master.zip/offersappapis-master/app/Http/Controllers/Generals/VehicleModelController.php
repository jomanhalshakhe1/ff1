<?php

namespace App\Http\Controllers\Generals;
use App\Models\Accounts\VehicleModel;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class VehicleModelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $pageno = 1; $pagelength = 10; 
            $totalrecords = VehicleModel::count();
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
                $list = VehicleModel::with('vehiclegroup', 'vehiclemaker')
                    ->orderBy('id','desc')
                    ->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();

                $data['data'] = $list;
                $data['current_page'] = $pageno;
                $data['total'] = $totalrecords;
                $data['per_page'] = $pagelength;
                return response()->json(['status' => 'success', 'data' => $data], 200);
            }else{
                $list = VehicleModel::with('vehiclegroup', 'vehiclemaker')->get();
            }
        }else{
            $list = VehicleModel::with('vehiclegroup', 'vehiclemaker')->where('status', 1)->all();
        }
        return response()->json([ 'status' => "success", "data" => $list ], 200);
    }

    public function group_models($vehicle_group_id)
    {
        // api for customer app -> Vehicle adding -> list based on vehicle group
        $list = VehicleModel::where('vehicle_group_id', $vehicle_group_id)->get();
        return response()->json([ 'status' => "success", "data" => $list ], 200);
    }

    public function vehicle_model_groups(){
        // api for all models along with group name and maker
        // this api using at cleaning and detailing offer adding
        $list = VehicleModel::join('vehicle_groups', 'vehicle_groups.id', 'vehicle_models.vehicle_group_id' )
            ->join('manufacturers', 'manufacturers.id', 'vehicle_models.maker')
            ->select('vehicle_models.id',
                DB::raw("concat(manufacturers.title, ',',vehicle_models.model, ',', vehicle_groups.title ) as title"),
                DB::raw("concat(manufacturers.title_ar, ',',vehicle_models.model_ar, ',', vehicle_groups.title_ar) as title_ar"))
            ->where('vehicle_models.status', 1)->get();

        return response()->json([ 'status' => "success", "data" => $list ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'vehicle_group_id' => 'required',
            //'model' => 'required|max:100',
            'model' => 'required|max:100|unique:vehicle_models,model,NULL,id,maker,'.$request->maker,
            'model_ar' => 'required|max:100|unique:vehicle_models,model_ar,NULL,id,maker,'.$request->maker,
            'maker' => 'required|max:100',
            'min_engine_capacity' => 'required|max:100',
            'max_engine_capacity' => 'required|max:100',
            'filter_price'=>'required|min:0',
            'status' => 'required',
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try{
            $request['created_at'] = date('Y-m-d H:i:s');
            VehicleModel::insert($request->all());

            return response()->json(['status' => 'success', 'response' => 'Successfully added a Vehicle Model'], 200);
        }
        catch(\Exception $e){
            return response()->json(['status' => 'failed', 'response' => 'Failed to add Vehicle Model', "error" => $e], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $list = VehicleModel::with('vehiclegroup', 'vehiclemaker')->where('id', $id)->first();
        return response()->json([ 'status' => "success", "data" => $list ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(),[
            'vehicle_group_id' => 'required',
            'model' => 'required|max:100|unique:vehicle_models,model,'.$id.',id,maker,'.$request->maker,
            'model_ar' => 'required|max:100|unique:vehicle_models,model_ar,'.$id.',id,maker,'.$request->maker,
            'maker' => 'required|max:100',
            'min_engine_capacity' => 'required|max:100',
            'max_engine_capacity' => 'required|max:100',
            'filter_price'=>'required|min:0',
            'status' => 'required',
        ]);

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try{
            $request['updated_at'] = date('Y-m-d H:i:s');
            VehicleModel::where('id', $id)->update($request->all());

            return response()->json(['status' => 'success', 'response' => 'Successfully updated a Vehicle Model'], 200);
        }
        catch(\Exception $e){
            return response()->json(['status' => 'failed', 'response' => 'Failed to update Vehicle Model', "error" => $e], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function makers(){
        $list = VehicleModel::join('manufacturers', 'manufacturers.id', 'vehicle_models.maker')
        ->select('manufacturers.id', 'manufacturers.title')
        ->distinct()->get();

        return response()->json([ 'status' => "success", "data" => $list ], 200);
    }

    public function models($maker){
        $list = VehicleModel::select('id', 'model', 'model_ar')
            ->where('maker', $maker )->orderBy('model', 'ASC')->distinct()->get();

        return response()->json([ 'status' => "success", "data" => $list ], 200);
    }

    public function groups($maker, $model){
        $list = VehicleModel::join('vehicle_groups', 'vehicle_groups.id', 'vehicle_models.vehicle_group_id')
            ->select('vehicle_groups.id', 'vehicle_groups.title', 'vehicle_groups.title_ar')
            ->where('vehicle_models.maker', $maker )
            //->where('vehicle_models.model', $model )
            ->where('vehicle_models.id', $model )
            ->distinct()
            ->get();

        return response()->json([ 'status' => "success", "data" => $list ], 200);
    }


    /* Get all active vehicle models list
    *
    * @return \Illuminate\Http\Response
    */

    function active_vehicle_models(){
        $list = VehicleModel::where('status', 1)->get();
        return response()->json([ 'status' => "success", "data" => $list ], 200);
    }
}
