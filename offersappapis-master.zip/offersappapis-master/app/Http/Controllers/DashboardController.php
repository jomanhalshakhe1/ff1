<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Users\CreditsController;
use App\Models\Accounts\ConsumerGroup;
use App\Models\Accounts\Credit;
use App\Models\Accounts\Driver;
use App\Models\Accounts\Transaction;
use App\Models\Generals\Deal;
use App\Models\Generals\RedeemLog;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use App\Models\Inventory\Maintenance;
use App\Models\Inventory\MaintenanceLog;
use App\Models\Inventory\Policy;
use App\Models\Regulatory\Fleet;
use App\Models\Regulatory\Organization;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Generals\Payout;
use App\Http\Controllers\Generals\DealController;

class DashboardController extends Controller
{
    //
    public function fleet_counts(){
        $fleet_id = Auth::user()->org_id;

         //Get counters for last 30days
        //$startDate=Payout::whereRaw("ifnull(paid_date, '2021-10-01') as paid_date")->pluck('paid_date')->where('payment_to',$fleet_id)->orderBy('id','Desc')->first();

        $startDate=Payout::selectRaw("ifnull(max(paid_date), '2021-10-01') as paid_date")->where('payment_to',$fleet_id)->pluck('paid_date');

         //$startDate=//date('Y-m-d', strtotime("-30 days"));
        $endDate=date('Y-m-d');

        $data['active_groups'] = ConsumerGroup::join('organizations', function ($q){
                    $q->on('consumer_groups.company', 'organizations.id');
            })
            ->where('organizations.company_type', 'F')
            ->where('consumer_groups.status', 1)
            ->where('consumer_groups.company', $fleet_id)
            ->count();

        $data['active_drivers'] = Driver::join('fleet_drivers', 'drivers.id', 'fleet_drivers.driver_id')
            ->join('organizations', 'organizations.id', 'fleet_drivers.fleet_id')
            ->where('fleet_drivers.fleet_id', $fleet_id)
            ->where('drivers.status', 1)
            ->where('fleet_drivers.status', 1)
            ->count();

        $data['gifts'] = Credit::whereBetween('created_at', [$startDate,$endDate])
            ->where('credit_on', 1) // 1 - Gift
            ->where('fleet_id', $fleet_id)
            ->selectRaw('ifnull(round(sum(amount),2),0) as gifts')
            ->pluck('gifts')->first();

        $data['gift_per_user'] = Credit::whereBetween('created_at', [$startDate,$endDate])
            ->where('credit_on', 1) // 1 - Gift
            ->where('fleet_id', $fleet_id)
            ->selectRaw('ifnull(round(sum(amount/ quantity),2),0) as gifts')
            ->pluck('gifts')->first();

        $data['credits'] = (new CreditsController)->fleet_shares($fleet_id);

        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    // When user logged in as admin then show dashboard counters and charts
    public function admin_counts(){
        // New offers added since one week
        $data['new_offers'] = ItemOffer::whereBetween('start_date', [
            date('Y-m-d', strtotime("-1 week")),
            date('Y-m-d')
        ])->count();

        //Active offers count
        $data['active_offers'] = ItemOffer::join('item_master', 'item_offers.item_id', 'item_master.id' )
                                    ->where('item_master.status', 1)
                                    ->where('item_offers.end_date', '>=', date('Y-m-d'))
                                    ->count();

        //Total transaction counts using maintenance transactions and deal transactions
        $trans_cnt = MaintenanceLog::whereNotNull('service_cost')->count();
        $trans_cnt += Transaction::where('payment_status', 'Successful')->count();
                        // ->where('created_at', '>', date('Y-m-d', strtotime("-1 week")))

        $data['transactions'] = $trans_cnt;
        //Total Dealers count
        $data['dealers'] = Organization::where('company_type', 'D')->where('status', 1)->count();
        //Active groups
        $data['active_groups'] = ConsumerGroup::where('status', 1)->count();
        //Active drivers or customers count
        $data['active_drivers'] = Driver::where('status', 1)->where('is_verified', 1)->count();

        //Total redeem count
        $data['reedem_count'] = RedeemLog::count();

        $data['notreedem_count'] = Transaction::where('status', 1)
                                    ->where('payment_status', 'Successful')
                                    ->whereRaw('quantity - revised_quantity > redeem_quantity')
                                    ->count();

        $dealShare = new DealController();
        $income = Transaction::where('payment_status', 'Successful')
                    ->get()->map(function ($row) use($dealShare){
                        $pricing = $dealShare->bill_price_logic($row['transaction_no']);
                        return ['income' => $pricing['final_price']];
                    })->sum('income');

        $data['income'] = round($income, 2);

        $data['refunds'] = Credit::where('credit_on', 2) // 2 - Refund
                            ->selectRaw('ifnull(ROUND(sum(amount),2),0) as refunds')
                            ->pluck('refunds')->first();

            // Total gift amount send to all individual and groups customers for today
        $data['gifts'] = Credit::where('status', 1)->where('credit_on', 1) // 1 - Gift
                            ->selectRaw('ifnull(ROUND(sum(amount),2),0) as gifts')
                            ->pluck('gifts')->first();

        $data['gift_per_user'] = Credit::where('status', 1)->where('credit_on', 1) // 1 - Gift
                                ->selectRaw('ifnull(ROUND((sum(amount) / sum(quantity)),2),0) as gifts')
                                ->pluck('gifts')->first();

        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    public function delar_counts(){

        $org_id = Auth::user()->org_id;
        $category = Organization::where('id', $org_id)->pluck('category')->first();

        if($category == 7) // insurance
            $total_products = Policy::where('delar_id', $org_id)->where('status', 1)->count();
        else if($category == 9) // maintenance
            $total_products = Maintenance::where('delar_id', $org_id)->where('status', 1)->count();
        else
            $total_products = ItemMaster::where('delar_id', $org_id)->where('status', 1)->count();

        if($category == 7) // insurance
            $expired_products = Policy::where('delar_id', $org_id)->where('status', 0)->count();
        else if($category == 9) // maintenance
            $expired_products  = Maintenance::where('delar_id', $org_id)->where('end_date', '<', date('Y-m-d'))->where('status', 1)->count();
        else
            $expired_products  = ItemMaster::join('item_offers', 'item_master.id', 'item_offers.item_id')
                ->where('item_master.delar_id', $org_id)
                ->where('item_master.status', 1)
                ->where('item_offers.end_date', '<', date('Y-m-d'))
                ->count();

        if($category == 7) // insurance
            $total_sales = Policy::where('delar_id', $org_id)->where('status', 1)->count();
        else if($category == 9) { // maintenance
            $total_sales = Maintenance::join('maintenance_logs', 'maintenances.id', 'maintenance_logs.item_id')
                ->where('maintenances.delar_id', $org_id)->where('maintenances.status', 1)->count();
        }
        else{
            $total_sales = ItemMaster::join('transactions', 'item_master.id', 'transactions.item_id')
            ->where('item_master.delar_id', $org_id)->where('item_master.status', 1)->count();
        }

        $refunds = $credits = 0;
        if($category == 7) // insurance
            $credits = 0;
        else if($category == 9) // maintenance
            $credits = 0;
        else {
            $credits = (new CreditsController)->delar_credits($org_id);

            
            $paid_date=Payout::selectRaw("ifnull(max(paid_date), '2021-10-01') as paid_date")->where('payment_to',$org_id)->pluck('paid_date');

            $refunds = Credit::join('transactions', 'transactions.transaction_no', 'credits.transaction_no')
                ->join('item_master', 'transactions.item_id', 'item_master.id')
                ->where('item_master.delar_id', $org_id)
                //->whereRaw("cast(credits.created_at as date) = current_date")
                ->whereBetween('credits.created_at', [$paid_date,date('Y-m-d')])
                ->where('credits.credit_on', 2)
                ->selectRaw('ifnull(round(sum(credits.amount),2),0) as refunds')
                ->pluck('refunds')->first();
        }

        $data = array(
            "total_products" => $total_products,
            "expired_products" => $expired_products,
            "total_sales" => $total_sales,
            "credits" => $credits,
            "refunds" => $refunds
        );

        return response()->json(['status' => 'success', 'data' => $data], 200);

    }

    public function total_sales_by_deal($deal_for = 'all'){
        // sales list on basis og revenue
        if($deal_for == 'all'){
            $res = DB::select("select a.id as deal_id, a.title as deal_name,
              round(sum(c.amount_by_banking + c.amount_by_credits),2) as total_amount
            from deals as a left join transactions as b on a.id = b.deal_id
              join payments as c on b.transaction_no = c.transaction_no
            and b.payment_status = 'Successful' and b.redeem_quantity > 0
            group by b.deal_id, a.id, a.title
            having sum(c.amount_by_banking + c.amount_by_credits) > 0 ");
        }
        else if($deal_for == 'delar'){
            $res = DB::select("select b.deal_id, d.title as deal_name,
                  ROUND(sum(
                            ((((a.price - a.price * a.discount/100) - ((a.price * a.discount/100) * payment_share.admin_share / 100)) -
                              (
                                ((a.price - a.price * a.discount/100) - ((a.price * a.discount/100) * payment_share.admin_share / 100)) -
                                ((a.price - a.price * a.discount/100) - ((a.price * a.discount/100) * payment_share.admin_share / 100)) /
                                (1 + payment_share.vat/100)
                              )) -
                             (
                               1 + (((a.price - a.price * a.discount/100) - ((a.price * a.discount/100) * payment_share.admin_share / 100)) -
                                    (
                                      ((a.price - a.price * a.discount/100) - ((a.price * a.discount/100) * payment_share.admin_share / 100)) -
                                      ((a.price - a.price * a.discount/100) - ((a.price * a.discount/100) * payment_share.admin_share / 100)) /
                                      (1 + payment_share.vat /100)
                                    )) * payment_share.pg_share / 100
                             )) * a.redeem_quantity + c.service_cost
                        ),2) as total_amount
                from transactions as a join item_master as b on a.item_id = b.id
                  inner join item_offers as c on b.id = c.item_id
                  inner join (select * from `payment_shares` where `status` = 1 order by `id` desc limit 1) as `payment_share`
                  inner join deals as d on d.id = b.deal_id
                where a.payment_status = 'Successful' and a.redeem_quantity > 0 and a.status = 1
                group by b.deal_id, d.title");
        }
        else if($deal_for == 'admin'){
            $res = DB::select("select b.deal_id, d.title as deal_name,
              ROUND(sum(((a.price * a.discount/100) * payment_share.admin_share / 100)
                    - ((a.price * a.discount/100) * payment_share.admin_share / 100) * ifnull(organizations.payment_share,0) / 100), 2) as total_amount
            from transactions as a join item_master as b on a.item_id = b.id
              inner join item_offers as c on b.id = c.item_id
              left join fleet_drivers on a.created_by = fleet_drivers.driver_id
              left join organizations on fleet_drivers.fleet_id = organizations.id
              inner join (select * from `payment_shares` where `status` = 1 order by `id` desc limit 1) as `payment_share`
              inner join deals as d on d.id = b.deal_id
            where a.payment_status = 'Successful' and a.redeem_quantity > 0 and a.status = 1
            group by b.deal_id, d.title");
        }

        $data = [];
        foreach($res as $row)
            $data[] = array( 'x' => $row->deal_name, 'y' => $row->total_amount, 'text' => $row->deal_name );

        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    //Monthly active users count

    public function monthly_active_users(){
        $res = DB::select("select DATE_FORMAT(created_at, '%b-%y') as reg_month, count(1) as user_count from drivers
where created_at > DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
group by DATE_FORMAT(created_at, '%b-%y') order by YEAR(created_at) asc, MONTH(created_at) asc");

        $data = [];
        foreach($res as $row)
            $data[] = array( 'x' => $row->reg_month, 'y' => $row->user_count );

        //$data = array_reverse($data);
        return response()->json(['status' => 'success', 'data' => $data], 200);
    }


    //Get sales by shares information
    public function sales_share_by_deal(){

        $res = DB::select("select a.id as deal_id, a.title as deal_name,
               sum(b.redeem_quantity) as quantity
        from deals as a left join transactions as b on a.id = b.deal_id
          join payments as c on b.transaction_no = c.transaction_no
                                     and b.payment_status = 'Successful' and b.redeem_quantity > 0
        group by b.deal_id, a.id, a.title
        having sum(b.redeem_quantity) > 0");

        $total = 0;
        foreach($res as $row)
            $total += $row->quantity;
        $data = [];
        foreach($res as $row)
            $data[] = array( 'x' => $row->deal_name, 'y' => $row->quantity,
                    'r' => "". round($row->quantity / $total * 100, 2) ."%" );

        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    public function revenue_share_by_deal($deal_for = 'all'){
        if($deal_for == 'all'){
            $res = DB::select("select a.id as deal_id, a.title as deal_name,
              round(sum(c.amount_by_banking + c.amount_by_credits),2) as total_amount
            from deals as a left join transactions as b on a.id = b.deal_id
              join payments as c on b.transaction_no = c.transaction_no
            and b.payment_status = 'Successful' and b.redeem_quantity > 0
            group by b.deal_id, a.id, a.title
            having sum(c.amount_by_banking + c.amount_by_credits) > 0 ");
        }
        else if($deal_for == 'delar'){
            $res = DB::select("select b.deal_id, d.title as deal_name,
                  ROUND(sum(
                            ((((a.price - a.price * a.discount/100) - ((a.price * a.discount/100) * payment_share.admin_share / 100)) -
                              (
                                ((a.price - a.price * a.discount/100) - ((a.price * a.discount/100) * payment_share.admin_share / 100)) -
                                ((a.price - a.price * a.discount/100) - ((a.price * a.discount/100) * payment_share.admin_share / 100)) /
                                (1 + payment_share.vat/100)
                              )) -
                             (
                               1 + (((a.price - a.price * a.discount/100) - ((a.price * a.discount/100) * payment_share.admin_share / 100)) -
                                    (
                                      ((a.price - a.price * a.discount/100) - ((a.price * a.discount/100) * payment_share.admin_share / 100)) -
                                      ((a.price - a.price * a.discount/100) - ((a.price * a.discount/100) * payment_share.admin_share / 100)) /
                                      (1 + payment_share.vat /100)
                                    )) * payment_share.pg_share / 100
                             )) * a.redeem_quantity + c.service_cost
                        ),2) as total_amount
                from transactions as a join item_master as b on a.item_id = b.id
                  inner join item_offers as c on b.id = c.item_id
                  inner join (select * from `payment_shares` where `status` = 1 order by `id` desc limit 1) as `payment_share`
                  inner join deals as d on d.id = b.deal_id
                where a.payment_status = 'Successful' and a.redeem_quantity > 0 and a.status = 1
                group by b.deal_id, d.title");
        }
        else if($deal_for == 'admin'){
            $res = DB::select("select b.deal_id, d.title as deal_name,
              ROUND(sum(((a.price * a.discount/100) * payment_share.admin_share / 100)
                    - ((a.price * a.discount/100) * payment_share.admin_share / 100) * ifnull(organizations.payment_share,0) / 100), 2) as total_amount
            from transactions as a join item_master as b on a.item_id = b.id
              inner join item_offers as c on b.id = c.item_id
              left join fleet_drivers on a.created_by = fleet_drivers.driver_id
              left join organizations on fleet_drivers.fleet_id = organizations.id
              inner join (select * from `payment_shares` where `status` = 1 order by `id` desc limit 1) as `payment_share`
              inner join deals as d on d.id = b.deal_id
            where a.payment_status = 'Successful' and a.redeem_quantity > 0 and a.status = 1
            group by b.deal_id, d.title");
        }

        $data = [];
        foreach($res as $row)
            $data[] = array( 'x' => $row->deal_name, 'y' => $row->total_amount, 'text' => $row->deal_name );

        return response()->json(['status' => 'success', 'data' => $data], 200);
    }

    public function monthly_sales_by_deal(){

        $res = DB::select("select a.title as deal_name, DATE_FORMAT(b.created_at, '%b-%y') as deal_month,
               round(sum(c.amount_by_banking + c.amount_by_credits),2) as total_amount
        from deals as a left join transactions as b on a.id = b.deal_id
          join payments as c on b.transaction_no = c.transaction_no
                                and c.payment_status = 'Successful' and b.redeem_quantity > 0
        group by b.deal_id, a.title, DATE_FORMAT(b.created_at, '%b-%y')
        having sum(c.amount_by_banking + c.amount_by_credits) > 0 ORDER BY a.title");

        $group = array();
        $deals = array_unique(array_column($res, 'deal_name'));
        foreach ( $deals as $deal ) {
            $tmp['category'] = $deal;
            foreach($res as $row){
                if($deal == $row->deal_name)
                    $tmp['data'][] = array( 'x' => $row->deal_month, 'y' => $row->total_amount);
            }

            $group[] = $tmp;
            $tmp = [];
        }

        return response()->json(['status' => 'success', 'data' => $group], 200);
    }

}
