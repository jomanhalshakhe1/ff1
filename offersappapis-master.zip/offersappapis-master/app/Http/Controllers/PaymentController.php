<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Accounts\Payment;
use App\Models\Accounts\Transaction;
use App\Http\Controllers\Generals\SendPushNotification;
use App\Events\cancelTranaction;
use App\Events\offerAvailabilityUpdated;
use App\Events\Emails\OfferAvailabilityStatusForAdmin;
use Illuminate\Support\Facades\Log;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use App\Events\Emails\PurchasedAnOfferEmail;
use App\Events\NewOrderPlaced;
use App\Http\Controllers\TransactionController;
use Illuminate\Support\Facades\DB;
use App\Events\RequestOfferAvailability;

class PaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

   function cancelRequestedItemAvailability(){
        $currentTime = time();
        $hoursToSubtract = 12;
        $timeToSubtract = ($hoursToSubtract * 60 * 60);
        $timeInPast = $currentTime - $timeToSubtract;
      
        $pendingDate=date("Y-m-d H:i:s", $timeInPast);

        $requestedList=Transaction::where('payment_status','Requests')
                    ->where('created_at','<=',$pendingDate)
                    ->get();

        if(!count($requestedList))
        return response()->json([
            'status'=>'failed',
            'message'=> 'Requested item offer availablity details not found',
        ], 400);

            foreach($requestedList as $singleRequest){

               Transaction::where('transaction_no', $singleRequest->transaction_no)
                ->update([
                    'payment_status' => 'Rejected',
                    'remarks' => 'Technician Rejected offer availablity for purchased item',
                    'is_approved' =>0,
                    'approved_by' => '1',
                    'approved_at' => date('Y-m-d H:i:s')
                ]);

                $paymentData = Payment::where('transaction_no', $singleRequest->transaction_no)
                    ->where('payment_status', 'Successful')->orderBy('id', 'ASC')->first();
                if(!empty($paymentData)){
                    if($paymentData->action_code=='4'){
                       
                        $actionCode=9;
                       
                        $result=$this->unlock_payments($paymentData->payid, $paymentData->amount_by_banking, $_SERVER['SERVER_ADDR'], $actionCode);
                        
                        $resultData=$result['data'];

                        $paymentArray['payment_status']= $result['payment_status'];
                        //$paymentArray['action_code']= $actionCode;
                        $paymentArray['response_result']=$result['Response'];
                        $paymentArray['updated_at']= date('Y-m-d H:i:s');
                        if(!empty($resultData)){
                           $paymentArray['response_code']=$resultData->responseCode;
                           $paymentArray['response_amount']=$resultData->amount;
                        }

                        Payment::where('transaction_no', $singleRequest->transaction_no)->where('id', $paymentData->id)->update($paymentArray);
                    }
                }
                
                try{
                     event(new offerAvailabilityUpdated($singleRequest->transaction_no, 27, '0'));
                     event(new OfferAvailabilityStatusForAdmin($singleRequest->transaction_no, '0'));
                 } catch(\Exception $e){
                     Log::error('Failed to send mail. Please try again later: '. $e->getMessage());
                 }
                return response()->json([
                    'status'=>'success',
                    'message'=> 'Requested item offer availablity details were rejected',
                ], 200);
            }
      
    }

   function cancelledPendingPayments(){

        $currentTime = time();
        $hoursToSubtract = 4;
        $timeToSubtract = ($hoursToSubtract * 60 * 60);
        $timeInPast = $currentTime - $timeToSubtract;
      
        $pendingDate=date("Y-m-d H:i:s", $timeInPast);


         $pendingsList=Transaction::where('payment_status', 'pending')->where('created_at','<=',$pendingDate)->get();

         if(!count($pendingsList))
            return response()->json([
                'status'=>'failed',
                'message'=> 'Pending details not found',
            ], 400);


        $result=Payment::where('payment_status', 'pending')->where('created_at','<=',$pendingDate)->update(['payment_status' => 'Cancelled']);

        $transaction = Transaction::where('payment_status', 'pending')->where('created_at','<=',$pendingDate)->update(['payment_status' => 'Cancelled','remarks' => 'Incomplete payment processing for offer was cancelled automatically']);


        foreach($pendingsList as $singlePayment){
          try{
            event(new cancelTranaction($singlePayment->transaction_no, 31, 'Pending'));   
          } catch(\Exception $e){
             Log::error('Failed to notifications. Please try again later: '. $e->getMessage());
          }
        }
        return response()->json([
            'status'=>'success',
            'message'=> 'Purchased pending details were cancelled',
        ], 200);
    }

   public function unloack_payments1(Request $request){

        $resultData=[];
        $terminalId = env('TERMINAL_ID','joy');//from urway
        $password = env('URWAY_PASSWORD','joy@123');//from urway
        $merchant_key = env('MERCHANT_KEY','f41697cbcce14b3ae7b0b6ba572df6695dbd9191a3ccc98baca2cc911daf3b11');//from urway
        //$call_back_url=config('examzhub.payment_call_back_url');
        $currencycode = "SAR";// get country currency code if you saved previously for an user or you read it from user end
        $idorder = $request->payment_no; // reference id from merchant(our) end(unique id for each transaction)
        $total_amount = sprintf("%.2f", $request->amount); //Please type-cast the amount to float type Example: 10.00
        $email = $request->email; //email of an user
        $ipp = $request->ip(); //Merchant Server IP Address

        try{
            $txn_details = $idorder . '|' . $terminalId . '|' . $password . '|' . $merchant_key . '|' . $total_amount . '|' . $currencycode;

            $hash = hash('sha256', $txn_details);
            $fields = array(
                'trackid' => $idorder,
                'terminalId' => $terminalId,
                'customerEmail' => $email,
                'action' => "1",  // 5 - capture amount, 9 - Reveal amounts
                'merchantIp' => $ipp,
                'password' => $password,
                'currency' => $currencycode,
                'country' => "SA",
                'amount' => $total_amount,
                "udf1" => "Test1",
                "udf2" => 'Test2',//Response page URL
                "udf3" => "",
                "udf4" => "",
                "udf5" => "Test5",
                'requestHash' => $hash  //generated Hash
            );
            $data = json_encode($fields);

            $ch = curl_init(env('PAYMENT_URL')); // Will be provided by URWAY
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json',
                    'Content-Length: ' . strlen($data))
            );
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
            //execute post
            $server_output = curl_exec($ch);

            //close connection
            curl_close($ch);
            $result = json_decode($server_output);

            if (!empty($result->payid) && !empty($result->targetUrl)) {
                $resultData['url'] = $result->targetUrl . '?paymentid=' . $result->payid;
                return response()->json([
                    'data' => $resultData,
                    'status' => true,
                    'api_code'=>'SCZ_EXAM_PAYMENT_INIT',
                    'Response' => "Payment Url",
                    'error'=>'',
                    'status_code'=>200
                ]);
            } else {
                return response()->json([
                    'status' => false,
                    'api_code'=>'SCZ_EXAM_PAYMENT_INIT',
                    'Response' => "Unable to Generate Payment Id",
                    'data' => '',
                    'error'=>$result,
                    'status_code'=>400
                ]);
            }
        }
        catch (\Exception $exception)
        {
            return response()->json([
                'status' => false,
                'api_code'=>'SCZ_EXAM_PAYMENT_INIT',
                'Response' => "Exception Details",
                'data' =>'',
                'error'=>$exception->getMessage(),
                'status_code'=>400
            ]);
        }
    }

   public function unlock_payments($transactionId, $amount, $ip, $actionCode){
        $resultData=[];
        $terminalId = env('TERMINAL_ID','joy');//from urway
        $password = env('URWAY_PASSWORD','joy@123');//from urway
        $merchant_key = env('MERCHANT_KEY','f41697cbcce14b3ae7b0b6ba572df6695dbd9191a3ccc98baca2cc911daf3b11');//from urway
        //$call_back_url=config('examzhub.payment_call_back_url');
        $currencycode = "SAR";// get country currency code if you saved previously for an user or you read it from user end
        $idorder = $transactionId; // reference id from merchant(our) end(unique id for each transaction)
        $total_amount = sprintf("%.2f", $amount); //Please type-cast the amount to float type Example: 10.00
        $email = ''; //email of an user
        $ipp = $ip; //Merchant Server IP Address

        try{
            $txn_details = $idorder . '|' . $terminalId . '|' . $password . '|' . $merchant_key . '|' . $total_amount . '|' . $currencycode;

            $hash = hash('sha256', $txn_details);
            $fields = array(
                'transid'=>$idorder,
                'trackid' => $idorder,
                'terminalId' => $terminalId,
                'customerEmail' => $email,
                'action' => $actionCode,  // 2 - Refunds
                'merchantIp' => $ipp,
                'password' => $password,
                'currency' => $currencycode,
                'country' => "SA",
                'amount' => $total_amount,
                "udf1" => "Test1",
                "udf2" => 'Test2',//Response page URL
                "udf3" => "",
                "udf4" => "",
                "udf5" => "Test5",
                'requestHash' => $hash  //generated Hash
            );
            $data = json_encode($fields);

            $ch = curl_init(env('PAYMENT_URL')); // Will be provided by URWAY
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json',
                    'Content-Length: ' . strlen($data))
            );
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
            //execute post
            $server_output = curl_exec($ch);

            //close connection
            curl_close($ch);
            $paymentResult = json_decode($server_output);
            if($paymentResult){
                if ($paymentResult->result=='Successful') {
                    return [
                        'data' => $paymentResult,
                        'status' => true,
                        'api_code'=>'JOY_PAYMENT_INIT',
                        'payment_status'=>$paymentResult->result,
                        'Response' => $paymentResult->result,
                        'tranid'=>$paymentResult->tranid,
                        'error'=>'',
                        'status_code'=>200
                    ];
                } else {

                    $response = $this->failed_urwayresponse_message($paymentResult->responseCode);

                    return [
                        'status' => false,
                        'api_code'=>'JOY_PAYMENT_INIT',
                        'Response' =>  $response,
                        'data' => $paymentResult,
                        'payment_status'=>'Failed',
                        'tranid'=>$paymentResult->tranid,
                        'error'=>'',
                        'status_code'=>400
                    ];
                }
            } else {
                return [
                        'status' => true,
                        'api_code'=>'JOY_PAYMENT_INIT',
                        'payment_status'=>'Successful',
                        'Response' => 'Successful',
                        'error'=>'',
                        'data' =>'',
                        'status_code'=>200
                    ];
            }
        }
        catch (\Exception $exception)
        {
           return [
                'status' => false,
                'api_code'=>'JOY_PAYMENT_INIT',
                'Response' => "Exception Details",
                'data' =>'',
                'payment_status'=>'Failed',
                'error'=>$exception->getMessage(),
                'tranid'=>'',
                'status_code'=>400
            ];
        }
    }

   public function refund_payments($transactionId, $amount, $ip){
       //Log::debug("Refund Payments Started: TransactionId: ". $transactionId. "  Amount: ".$amount. " Payment Type: 2 (Refund)");
        $resultData=[];
        $terminalId = env('TERMINAL_ID','joy');//from urway
        $password = env('URWAY_PASSWORD','joy@123');//from urway
        $merchant_key = env('MERCHANT_KEY','f41697cbcce14b3ae7b0b6ba572df6695dbd9191a3ccc98baca2cc911daf3b11');//from urway
        //$call_back_url=config('examzhub.payment_call_back_url');
        $currencycode = "SAR";// get country currency code if you saved previously for an user or you read it from user end
        $idorder = $transactionId; // reference id from merchant(our) end(unique id for each transaction)
        $total_amount = sprintf("%.2f", $amount); //Please type-cast the amount to float type Example: 10.00
        $email = ''; //email of an user
        $ipp = $ip; //Merchant Server IP Address

        try{
            $txn_details = $idorder . '|' . $terminalId . '|' . $password . '|' . $merchant_key . '|' . $total_amount . '|' . $currencycode;

            $hash = hash('sha256', $txn_details);
            $fields = array(
                'transid'=>$idorder, // Last Successfull Transaction Reference id
                'trackid' => $idorder, // Last Successfull Transaction Reference id
                'terminalId' => $terminalId,
                'customerEmail' => $email,
                'action' => "2",  // 2 - Refunds
                'merchantIp' => $ipp,
                'password' => $password,
                'currency' => $currencycode,
                'country' => "SA",
                'amount' => $total_amount,
                "udf1" => "Test1",
                "udf2" => 'Test2',//Response page URL
                "udf3" => "",
                "udf4" => "",
                "udf5" => "Test5",
                'requestHash' => $hash  //generated Hash
            );
            $data = json_encode($fields);

            $ch = curl_init(env('PAYMENT_URL')); // Will be provided by URWAY
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json',
                    'Content-Length: ' . strlen($data))
            );
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
            //execute post
            $server_output = curl_exec($ch);

            //close connection
            curl_close($ch);
            $paymentResult = json_decode($server_output);

            

            if($paymentResult){
                if ($paymentResult->result=='Successful') {
                    return [
                        'data' => $paymentResult,
                        'status' => true,
                        'api_code'=>'JOY_PAYMENT_INIT',
                        'payment_status'=>$paymentResult->result,
                        'Response' => $paymentResult->result,
                        'tranid'=>$paymentResult->tranid,
                        'error'=>'',
                        'status_code'=>200
                    ];
                } else {

                    $response = $this->failed_urwayresponse_message($paymentResult->responseCode);
                    
                     return [
                        'status' => false,
                        'api_code'=>'JOY_PAYMENT_INIT',
                        'Response' =>  $response,
                        'data' => $paymentResult,
                        'payment_status'=>'Failed',
                        'tranid'=>$paymentResult->tranid,
                        'error'=>'',
                        'status_code'=>400
                    ];
                }
            } else {
                return [
                        'status' => true,
                        'api_code'=>'JOY_PAYMENT_INIT',
                        'payment_status'=>'Successful',
                        'Response' => 'Successful',
                        'error'=>'',
                        'data' =>'',
                        'status_code'=>200
                    ];
            }
        }
        catch (\Exception $exception)
        {
           return [
                'status' => false,
                'api_code'=>'JOY_PAYMENT_INIT',
                'Response' => $exception->getMessage(),
                'data' =>'',
                'payment_status'=>'Failed',
                'error'=>$exception->getMessage(),
                'tranid'=>'',
                'status_code'=>400
            ];
        }
    }

    private function failed_urwayresponse_message($responseCode){

        switch ($responseCode){
            case '644': $response='Transaction is fully refunded, refund not allowed'; break;
            case '613': $response='Invalid Transaction Reference'; break;
            case '599': $response='Host Response,Please check bank response code'; break;
            case '625': $response='3D Secure Check Failed, Cannot continue transaction'; break;
            case '325': $response='Velocity Check Failed, Transaction amount exceeds Maximum amount allowed, Level - Terminal'; break;
            case '206': $response='Negative IP, Customer is not allowed to perform Transaction'; break;
            case '207': $response='Original Transaction not found'; break;
            case '629': $response='Refund Amount exceeds the Captured/Purchase Amount.'; break;
            case '636': $response='Transaction has been Voided , Multiple voids not allowed.'; break;
            case '001': $response='Pending for Authorisation'; break;
            case '322': $response='Velocity Check Failed, Transaction amount below Minimum amount allowed, Level - Terminal'; break;
            case '603': $response='Transaction timed out.'; break;
            default: $response='Failed'; break;
        }

        return $response;
    }

    public function find_transaction_status($transactionId){
        $resultData=[];
        $terminalId = env('TERMINAL_ID','joy');//from urway
        $password = env('URWAY_PASSWORD','joy@123');//from urway
        $merchant_key = env('MERCHANT_KEY','f41697cbcce14b3ae7b0b6ba572df6695dbd9191a3ccc98baca2cc911daf3b11');//from urway
        //$call_back_url=config('examzhub.payment_call_back_url');
        $currencycode = "SAR";// get country currency code if you saved previously for an user or you read it from user end
        $idorder = $transactionId; // reference id from merchant(our) end(unique id for each transaction)

	    $payment = Payment::where('transaction_no', $idorder)->where('payment_status', 'Successful')->first();
        if(empty($payment)){
             return [
                'status' => false,
                'status_code'=>400
            ];
        }
        $total_amount = sprintf("%.2f", $payment->response_amount ?? 0); //Please type-cast the amount to float type Example: 10.00
        $email = ''; //email of an user
        $ipp = $_SERVER['SERVER_ADDR']; //Merchant Server IP Address

        if(!$payment->payment_no)
        {
            return [
                'status' => false,
                'api_code'=>'JOY_PAYMENT_INIT',
                'Response' => "Exception Details",
                'data' =>'',
                'payment_status'=>'Failed',
                'error'=> 'Payment Not Yet Done',
                'tranid'=> $idorder,
                'status_code'=>400
            ];
        }
        $trackId = $payment->payid;
        $idorder = $payment->payment_no;

        try{
            $txn_details = $idorder . '|' . $terminalId . '|' . $password . '|' . $merchant_key . '|' . $total_amount . '|' . $currencycode;

            $hash = hash('sha256', $txn_details);
            $fields = array(
                'transid'=> $trackId, // Last Transaction referance Id
                'trackid' => $idorder, // payment_no
                'terminalId' => $terminalId,
                'customerEmail' => $email,
                'action' => '10',  // 10 - Enquiry
                'merchantIp' => $ipp,
                'password' => $password,
                'currency' => $currencycode,
                'country' => "SA",
                'amount' => $total_amount,
                "udf1" => "Test1",
                "udf2" => 'Test2',//Response page URL
                "udf3" => "",
                "udf4" => "",
                "udf5" => "Test5",
                'requestHash' => $hash  //generated Hash
            );
            // return $fields;
            $data = json_encode($fields);

            $ch = curl_init(env('PAYMENT_URL')); // Will be provided by URWAY
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json',
                    'Content-Length: ' . strlen($data))
            );
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
            //execute post
            $server_output = curl_exec($ch);

            //close connection
            curl_close($ch);
            $paymentResult = json_decode($server_output);

            if(!isset($paymentResult->result)){
                return [
                    'data' => $paymentResult,
                    'status' => false,
                    'api_code'=>'JOY_PAYMENT_STATUS',
                    'payment_status'=> 'failed',
                    'Response' => 'failed',
                    'tranid' => $idorder,
                    'error' => '',
                    'status_code' => 400
                ];
            }

            if ($paymentResult->result=='Successful') {
                return [
                    'data' => $paymentResult,
                    'status' => true,
                    'api_code'=>'JOY_PAYMENT_INIT',
                    'payment_status'=>$paymentResult->result,
                    'Response' => $paymentResult->result,
                    'tranid'=>$paymentResult->tranid,
                    'error'=>'',
                    'status_code'=>200
                ];
            } else {
                $response = $this->failed_urwayresponse_message($paymentResult->responseCode);

                return [
                    'status' => false,
                    'api_code'=>'JOY_PAYMENT_INIT',
                    'Response' =>  $response,
                    'data' => $paymentResult,
                    'payment_status'=>'Failed',
                    'tranid'=>$paymentResult->tranid,
                    'error'=>'',
                    'status_code'=>400
                ];
            }
        }
        catch (\Exception $exception)
        {
            return [
                'status' => false,
                'api_code'=>'JOY_PAYMENT_INIT',
                'Response' => "Exception Details",
                'data' =>'',
                'payment_status'=>'Failed',
                'error'=>$exception->getMessage(),
                'tranid'=>'',
                'status_code'=>400
            ];
        }
    }


    public function manual_payment($request){
        try{

            $tranData = Transaction::where('transaction_no', $request->transaction_no)->first();
            $is_notify = ItemOffer::where('item_id', $tranData->item_id)->pluck('is_notify')->first();

            $updatedAt=date('Y-m-d H:i:s');


            Transaction::where('transaction_no', $request->transaction_no)
                    ->update(['payment_status' => $is_notify ? 'Requests' : 'Successful', 'remarks' => $request->description,'updated_at'=>$updatedAt,'payment_with'=>'8']);

            $paymentArray['transaction_no'] = $request->transaction_no;
            $paymentArray['payid'] = $request->transaction_id;
            $paymentArray['action_code'] = $is_notify ? 4 : 1;
            $paymentArray['amount_by_credits']=0;
            $paymentArray['amount_by_banking']=$request->amount;
            $paymentArray['payment_on']=53;
            $paymentArray['payment_status']='Successful';
            $paymentArray['payment_type']='1';
            $paymentArray['updated_at']=$updatedAt;

            Payment::where('transaction_no', $request->transaction_no)
                    ->update($paymentArray);


            if ($tranData->deal_id == 6 || $tranData->deal_id == 2) // tires & battaries
                ItemMaster::where('id', $request['item_id'])
                ->update(['quantity' => DB::raw('quantity - ' . $tranData->quantity)]);

            ItemOffer::where('id', $tranData->offer_id)->where('item_id', $tranData->deal_id)
            ->update(['quantity' => DB::raw('quantity - ' . $tranData->quantity)]);

              // Check petromin service available for booking
            (new TransactionController())->create_servicebooking($request->transaction_no);

            if (!$is_notify) {
                (new TransactionController())->update_transaction_invoice_no($request->transaction_no);
            }

            try {
                // Send notification to consumer , deal admin and technician
                event(new PurchasedAnOfferEmail($request->transaction_no));
                event(new NewOrderPlaced($request->transaction_no, 27, $request->amount));
                 
            } catch(\Exception $e){
                Log::error('Failed to send notification on purchased deal: '. $request->transaction_no);
                Log::error($e->getMessage());
            } 
            if ($is_notify) {
                try {
                    event(new RequestOfferAvailability($request->transaction_no, 40, $request->amount));
                } catch (\Exception $e) {
                    Log::info("Sent firebase notification for offer availability request");
                    Log::error($e->getMessage());
                }
            } 
                   
           
            return response()->json(['status'=> 'success', 'message'=> 'You have successfully done manual payment' ], 200);
        } catch(\Exception $e){
            return response()->json(['status'=> 'success', 'message'=> 'Failed to do manual payment',"error"=>$e->getMessage() ], 400);
        }
    }

}
