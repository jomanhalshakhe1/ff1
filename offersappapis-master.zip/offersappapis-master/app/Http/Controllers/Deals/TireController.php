<?php

namespace App\Http\Controllers\Deals;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Generals\DealController;
use App\Http\Controllers\Mediator\ServiceBookingController;
use App\Models\Accounts\Vehicle;
use App\Models\Generals\Favourite;
use App\Models\Generals\Role;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use App\Models\Inventory\OfferLocation;
use App\Models\Generals\Slider;
use App\Models\Generals\Notification;
use App\Models\Accounts\Driver;
use App\Models\Regulatory\Organization;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers\Generals\SendPushNotification;
use App\Events\NewOfferCreated;
use Illuminate\Support\Facades\Log;

class TireController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public $dealTire;
    function __construct()
    {
        // deal_id = 2 for Tire
        $this->dealTire = 2;
    }

    public function index(Request $request)
    {
        // deal_id = 2 for Tires
        $consumer_id = Auth::guard('driver')->id();

        DB::enableQueryLog();
        $list = ItemMaster::where('item_master.deal_id', $this->dealTire);
        if(explode('/', $request->route()->getPrefix())[0] != 'api'){
            $list = $list->join('organizations', 'organizations.id', 'item_master.delar_id');
            $list = $list->where('organizations.status','1');
        }
         
        $list = $list->with('delar', 'delar.location', 'offer.locations');

        $list = $list->join('item_offers', 'item_master.id', 'item_offers.item_id');

        if(isset($request->org_id) && $request->org_id>0)
            $list = $list->where('item_master.delar_id', $request->org_id);

        if($consumer_id){

            // if(isset($request->org_id))
            //     $list = $list->where('item_master.delar_id', $request->org_id);

            // offer selection
            $list = $list->where('item_master.status', 1)
                ->whereRaw('item_offers.end_date >= (DATE(NOW()) - INTERVAL 7 DAY)')
                ->where('item_offers.quantity', '>', 0);

            // offer locations
            $list = $list->join('offer_locations', 'offer_locations.offer_id', 'item_offers.id')
                ->join('locations', 'locations.id', 'offer_locations.location_id');
            //if(isset($request->city) && !empty($request->city)){
                $list = $list->where('locations.city', $request->city);

                $city_id = $request->city;

                $list = $list->with(['offer.locations' => function ($query) use ($city_id){
                    // only search city locations
                    $query->where("locations.city", $city_id);
                }]);
            //}


            // Check for Favourites
            $list = $list->leftJoin('favourites', function($fav) use($consumer_id, $city_id){
                $fav->on('favourites.offer_id', 'item_offers.id' );
                $fav->where('favourites.user_id', $consumer_id );
                $fav->where('favourites.city_id', $city_id );
                $fav->on('favourites.location_id', 'offer_locations.location_id' );
            });

            if(isset($request->latitude) && isset($request->longitude)){
                
                $latitude=$request->latitude;
                $longitude=$request->longitude;

                $sql_distance = DB::raw("if(item_offers.on_site = 0, round((((acos(sin((".$latitude."*pi()/180)) * sin((locations.latitude*pi()/180))+cos((".$latitude."*pi()/180)) * cos((locations.latitude*pi()/180)) * cos(((".$longitude."-locations.longitude)*pi()/180))))*180/pi())*60*1.1515*1.609344),2), 0) as distance");

            } else {
                $sql_distance =  DB::raw('0 as distance');
            }

            $list = $list->select('item_master.*',$sql_distance, DB::raw('item_offers.id as offer_id'),
                    'item_offers.discount', 'offer_locations.location_id', 'locations.city', DB::raw('if(favourites.offer_id is null, 0, 1) as is_favourite')
                )->distinct();
        }
        else{
            $list = $list->select('item_master.*', DB::raw('item_offers.id as offer_id'), 'item_offers.discount')->distinct();
        }

        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            // web logins
            $portal_user = Auth::id();
            if($portal_user){
                // check for delar
                if(Auth::user()->login_type_id == 18) // Delar login
                    $list = $list->where('item_master.delar_id' , Auth::user()->org_id);
            }
        }

        //dealer access start
        if(Session::has('dealer_access_id')){
            $token_dealer_id = Session::get('dealer_access_id');
            if(isset($token_dealer_id) && !empty($token_dealer_id)){
                $list = $list->where('item_master.delar_id' , $token_dealer_id);
            }
        }
        //dealer access end
        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $pageno = 1; $pagelength = 10; 
            $totalrecords = $list->orderBy('id', 'desc')->count();
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
            }
            $list = $list->orderBy('item_master.id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength);
        }else{
            $list = $list->orderBy('item_offers.discount', 'desc')
                ->orderBy('item_master.id', 'desc');
        }
        $list = $list->get();

        // return DB::getQueryLog();
        // > if all offers are onsite, distance filter will be disable
        // > if single offers having non-onsite, distance filter will be enabled
        $distance_filter = 0; // Disable Distance Filter as default
        $onsite_filter = 0; // Disable Distance Filter
        $size = []; $width = []; $height = []; $brands = [];
        foreach ($list as $row) {

            if($distance_filter == 0 && !$row['offer']['on_site'])
                $distance_filter = 1; // Enable Distance Filter, non-onsite offer listed here
            if($row['offer']['on_site']){
               $onsite_filter=1;
            }
            if(explode('/', $request->route()->getPrefix())[0] != 'api') {
                if ($row['size'] && $row['size'] != '')
                    array_push($size, $row['size']);

                if ($row['width'] && $row['width'] != '')
                    array_push($width, $row['width']);

                if ($row['height'] && $row['height'] != '')
                    array_push($height, $row['height']);

                if($row['company'] && $row['company'] != '')
                    array_push($brands, $row['company']);
            }
        }

        $dealShare = new DealController();
        $mapData =  $list->map(function($record) use($dealShare) {

            $row = json_decode(json_encode($record)); // Deep cloning of object, which can prevent overiding of object data
            $pricing = $dealShare->price_logic($record['offer']['price'], $record['offer']['discount'], $record['deal_id']);
            $row->offer->price = $pricing['actual_price'];
            $row->offer->discount = $pricing['final_price'];
            $row->offer->vat = $pricing['vat'];
            $row->price = $row->offer->price;
           
            if(explode('/', request()->route()->getPrefix())[0] == 'customer') {

                return array(
                    "id" => $row->id,
                    "title" => $row->title,
                    "title_ar" => $row->title_ar,
                    "description" => $row->description,
                    "description_ar" => $row->description_ar,
                    "code" => $row->code,
                    "company" => $row->company,
                    "price" => $pricing['actual_price'],
                    "final_price" => $pricing['final_price'],
                    "dimensions" => $row->dimensions,
                    "deal_id" => $row->deal_id,
                    "delar_id" => $row->delar_id,
                    "thumbnail_url" => $row->thumbnail_url,
                    "volt" => $row->volt,
                    "ah" => $row->ah,
                    "size" => $row->size,
                    "height" => $row->height,
                    "width" => $row->width,
                    "status" => $row->status,
                    "distance" => $row->distance,
                    "offer_id" => $row->offer_id,
                    "location_id" => $row->location_id,
                    "city_id" => $row->city,
                    "is_notify" => $row->offer->is_notify,
                    "on_site" => $row->offer->on_site,
                    "is_favorite" => $row->is_favourite,
                    "is_top_deal" => $row->offer->is_top_deal,
                );
            }
            else
                return $row;
        });
        $list = $mapData;

        //from response filter by city end
        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status' => 'success', 'data' => $data], 200);
        }else{

            natcasesort($width);
            natcasesort($height);
           // natcasesort($size);
            natcasesort($brands);

            $sizes=array_unique($size);
            $arrayList = [];
            $matches = [];

            foreach($sizes as $size)
            {
                preg_match_all('#([0-9\.]+)#', $size, $matches);
                $firstInt = $matches[0];
                $matches = $firstInt[0];
                $arrayList[] = array("val" => $size, "firstint" => (float)$matches);
            }

            $size = $this->column_Sort($arrayList, 'firstint');

            $list = collect($list);

            $top_deals = $list->where('is_top_deal', 1)->values()->skip(0)->take(5);
            $top_deal_ids = $top_deals->pluck('offer_id');
            $non_top_deals = $list->whereNotIn('offer_id', $top_deal_ids)->values();
            $non_top_deals = $non_top_deals->map(function($row){ $row['is_top_deal'] = 0; return $row; });

            if(explode('/', request()->route()->getPrefix())[0] == 'customer') {
                $sorted = $non_top_deals->sortBy('final_price')->sortBy('distance');
            }else{
                $sorted = $non_top_deals->sortBy('offer.discount');
            }
            $sorted_offers = $sorted->values()->all();

            $all_deals = $top_deals->merge($sorted_offers);
            return response()->json([
                'status' => 'success',
                'data' => $all_deals,
                'distance_filter' => $distance_filter,
                'onsite_filter' => $onsite_filter, // can be removed
                'onsite_deals_available' => $onsite_filter,
                'filters' => array(
                    'size' => array_values(array_unique($size)),
                    'width' => array_values(array_unique($width)),
                    'height' => array_values(array_unique($height)),
                    'brands' => array_values(array_unique($brands)),
                )
            ], 200);
        }
    }

    //This function is used for  Array Sorting
    function column_Sort($unsorted, $column) {
        $sorted = $unsorted;
        for ($i=0; $i < sizeof($sorted)-1; $i++) {
          for ($j=0; $j<sizeof($sorted)-1-$i; $j++)
            if ($sorted[$j][$column] > $sorted[$j+1][$column]) {
              $tmp = $sorted[$j];
              $sorted[$j] = $sorted[$j+1];
              $sorted[$j+1] = $tmp;
          }
        }

        $groups = [];
        foreach($sorted as $row)
          $groups[$row['firstint']][] = $row['val'];

        $sortedgroups = [];
        foreach($groups as $key => $val)
        {
          natcasesort($val);
          $groups[$key] = $val;
          $sortedgroups = array_merge($sortedgroups, $val);
        }
        return $sortedgroups;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //dealer access start
        if(Session::has('dealer_access_id')){
            $token_dealer_id = Session::get('dealer_access_id');
            if(isset($token_dealer_id) && !empty($token_dealer_id)){
                $request['delar_id'] = $token_dealer_id;
                $request['status'] = 1;
            }
        }
        //dealer access end
        $request['offer'] = json_decode($request['offer'], true);

        $validator = Validator::make($request->all(),
            [
                'title' => ['required', 'string', 'max:100' ],
                'title_ar' => ['required', 'string', 'max:100' ],
                // 'code' => ['required', 'string', 'max:20' ],
                'code'=>[],
                'price' => ['string', 'max:15' ],
                'company' => ['string', 'max:60' ],
                'quantity' => 'required|numeric|gte:1|lte:10000',
                'delar_id' => ['required'],
                'description' => ['required' ],
                'description_ar' => ['required' ],
                'height' => ['required' ],
                'width' => ['required' ],
                'size' => ['required' ],
                'thumbnail' => ['required', 'mimes:jpeg,jpg,png', 'max:500' ],
                'sliders' => 'required',
                'sliders.*' => 'mimes:jpeg,jpg,png',
                'offer.discount' =>'required|numeric|gte:0|lte:100',
                'offer.start_date' => ['required', 'after_or_equal:'.date("Y-m-d")],
                'offer.end_date' => ['required', 'after_or_equal:offer.start_date'],
                'offer.description' => ['required' ],
                'offer.description_ar' => ['required' ],
                'offer.vn_access' => ['required' ],
                'offer.pn_access' => ['required' ],
                'offer.on_site' => ['required' ],
                'offer.is_notify' => ['required' ],
                'offer.is_top_deal' => ['required' ],
                'offer.enable_slots' => ['required' ],
                'offer.terms_ar' => ['required' ],
                'offer.locations.*' => ['required' ],
                'offer.service_cost.*' => 'required|numeric',
            ],
            [
                'offer.start_date.required' => "Start date is required",
                'offer.start_date.after_or_equal'=>"State date should be greater than or equals to today's date",
                'offer.end_date.required' => "End date is required",
                'offer.end_date.after_or_equal'=>"End date should be greater than or equals to start date",
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/deals/tires/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/deals/tires/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('deals/tires/', $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        $sliders = [];
        if($request->hasfile('sliders'))
        {
            foreach($request->file('sliders') as $file)
            {
                $name = Str::random(10).'.'.$file->extension();
                $file->move(public_path().'/uploads/deals/tires/sliders/', $name);
                $sliders[] = '/uploads/deals/tires/sliders/' . $name;
            }
        }

        $is_notify = false;
        if(Organization::where('id', $request['delar_id'])->where('code', 'PETROMIN')->count()){
            // For Petromin company offers should be notified
            $is_notify = true;
        }

        try{
            $insert = array(
                'title' => $request['title'],
                'title_ar' => $request['title_ar'],
                'code' => $request['code'],
                'price' => $request['price'],
                'company' => $request['company'],
                'quantity' => $request['quantity'],
                'delar_id' => $request['delar_id'],
                'deal_id' => $this->dealTire, // tires module
                'description' => $request['description'],
                'description_ar' => $request['description_ar'],
                'height' => $request['height'],
                'width' => $request['width'],
                'size' => $request['size'],
                'status' => $request['status'],
                'thumbnail_url' => $request['thumbnail_url'],
                'created_at' => date('Y-m-d H:i:s'),
                'created_by' => Auth::id(),
            );

            $tire_id = ItemMaster::insertGetId($insert);
            
            $insert = array(
                'item_id' => $tire_id,
                'deal_id' => $this->dealTire,
                'price' => $request['price'],
                'quantity' => $request['quantity'],
                'discount' => $request['offer']['discount'],
                'service_cost' => $request['offer']['service_cost'],
                'start_date' => $request['offer']['start_date'],
                'end_date' => $request['offer']['end_date'],
                'description' => $request['offer']['description'],
                'description_ar' => $request['offer']['description_ar'],
                'terms' => $request['offer']['terms'],
                'terms_ar' => $request['offer']['terms_ar'],
                'vn_access' => $request['offer']['vn_access'],
                'pn_access' => $request['offer']['pn_access'],
                'on_site' => $request['offer']['on_site'],
                'is_notify' => $request['offer']['is_notify'],
                'is_top_deal' => $request['offer']['is_top_deal'],
                'enable_slots' => $request['offer']['enable_slots'],
                'provider_reference_id' => $request['offer']['provider_reference_id'],
                'provider_reference_subid' => $request['offer']['provider_reference_subid'],
                'service_id' => $request['offer']['service_id'],
                'created_at' => date('Y-m-d H:i:s'),
                'created_by' => Auth::id(),
            );

            if($request['offer']['enable_slots']) {
                try {
                    $insert['enable_slots'] = 0;
                    $service = (new ServiceBookingController())->create($request['offer'], $request['delar_id']);
                    if ($service) { // Service id was available
                        $insert['service_id'] = $service; // update service id from booking system
                        $insert['enable_slots'] = 1;
                    }
                } catch (\Exception $e) {
                    Log::error('Service creation on service booking system was failed');
                }
            }

            if($is_notify) {
                $insert['is_notify'] = 1;
                $insert['pn_access'] = 1;
            }

            $offer_id = ItemOffer::insertGetId($insert);

            $insert_offer_location = [];
            foreach($request['offer']['locations'] as $offer_location)
            {
                $insert_offer_location[] = [
                    'location_id' => $offer_location['location_id'],
                    'offer_id' => $offer_id,
                    'created_at' => date('Y-m-d H:i:s'),
                    'created_by' => Auth::id(),
                ];
            }
            if(count($insert_offer_location)> 0){
                OfferLocation::insert($insert_offer_location);
            }

            $insert = [];
            foreach($sliders as $slider)
            {
                $insert[] = [
                    'deal_id' => $this->dealTire,
                    'item_id' => $tire_id,
                    'thumbnail_url' => $slider,
                    'created_at' => date('Y-m-d H:i:s')
                ];
            }

            if(count($insert)> 0)
                Slider::insert($insert);

            // Send notification to consumer
            //// send notifications only at status should be active, and offer date should be equal or less than the current date
            if($request['status'] && date('Y-m-d', strtotime($request['offer']['start_date'])) >= date('Y-m-d')){
                try{
                    event(new NewOfferCreated($tire_id, $this->dealTire, '',23));
                } catch (\Exception $e) {
                     Log::info('failed', 'Failed to send notification :  '. $e->getMessage());
                } 
            }

            return response()->json(['status'=>'success', 'message'=> 'Tire created successfully'], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Tire creation failed', "errors" => $e ], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id, $city_id = null, $location_id = null)
    {
        // deal_id = 2 for Tires
        $list = ItemMaster::where('item_master.id', $id)->where('item_master.deal_id', $this->dealTire)
            ->join('item_offers', 'item_offers.item_id', 'item_master.id')
            ->with('delar', 'offer', 'delar.location', 'slider', 'offer.locations');

        if(isset($city_id) && !empty($city_id)){
            $list = $list->with(['offer' => function($query) use ($city_id, $location_id){
                // only offer effected for that city
                $query->join('offer_locations', 'offer_locations.offer_id', 'item_offers.id');

                if($location_id)
                    $query->where('offer_locations.location_id', $location_id);
                else
                    $query->join('locations', 'locations.id', 'offer_locations.location_id')->where('locations.city', $city_id);

                $query->select('item_offers.*')->distinct();
            },
                'offer.locations' => function($query) use ($city_id, $location_id){
                    // only offer effected for that customer
                    $query->where("locations.city", $city_id);
                    if($location_id)
                        $query->where("locations.id", $location_id);
                }]);
        }

        //dealer access start
        if(Session::has('dealer_access_id')){
            $token_dealer_id = Session::get('dealer_access_id');
            if(isset($token_dealer_id) && !empty($token_dealer_id)){
                $list = $list->where('delar_id' , $token_dealer_id);
            }
        }
        //dealer access end
        $list = $list->select('item_master.*', DB::raw('item_offers.id as offer_id'))->distinct()->first();

        if(explode('/', $request->route()->getPrefix())[0] != 'api') {
            $dealShare = new DealController();
            $pricing = $dealShare->price_logic($list['offer']['price'], $list['offer']['discount'], $list['deal_id']);
            $list['offer']['base_price'] = $pricing['base_price'];
            $list['offer']['price'] = $pricing['actual_price'];
            $list['offer']['discount'] = $pricing['final_price'];
            $list['offer']['vat'] = $pricing['vat'];
            $list['price'] = $list['offer']['price'];

            if(isset($city_id) && isset($location_id) && Auth::guard('driver')->id()){
                $fwhere = array(
                    'user_id' => Auth::guard('driver')->id(),
                    'offer_id' => $list['offer']['id'],
                    'city_id' => $city_id,
                    'location_id' => $location_id,
                );
                $list['is_favourite'] = Favourite::where($fwhere)->count() > 0 ? 1 : 0;
            }
            else
                $list['is_favourite'] = 0;

            $list['enable_mutiple_qty'] = 0;

            $list['vehicles'] = Vehicle::join('vehicle_models', 'vehicle_models.id', 'vehicles.model')
                                ->join('vehicle_groups', 'vehicle_groups.id', 'vehicles.group_id' )
                                ->join('manufacturers', 'manufacturers.id', 'vehicles.company')
                                ->select( 'vehicles.id',
                                    DB::raw("concat(manufacturers.title, ',',vehicle_models.model, ',', vehicle_groups.title ) as title"),
                                    DB::raw("concat(manufacturers.title_ar, ',',vehicle_models.model_ar, ',', vehicle_groups.title_ar ) as title_ar"),
                                    'vehicles.is_primary', 'vehicles.owner_id', 'vehicles.group_id', 'vehicles.plate_no', 'vehicles.serial_no')
                                ->where('vehicles.owner_id', Auth::guard('driver')->id())
                                ->where('vehicles.status', 1)->get();
        }

        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request['offer'] = json_decode($request['offer'], true);
        $validator = Validator::make($request->all(),
            [
                'title' => ['required', 'string', 'max:100' ],
                'title_ar' => ['required', 'string', 'max:100' ],
                // 'code' => ['required', 'string', 'max:20' ],
                'code'=>[],
                'price' => ['string', 'max:15' ],
                'company' => ['string', 'max:60' ],
                'quantity' => 'required|numeric|gte:1|lte:10000',
                'delar_id' => ['required'],
                'description' => ['required' ],
                'description_ar' => ['required' ],
                'height' => ['required' ],
                'width' => ['required' ],
                'size' => ['required' ],
                'offer.discount' => 'required|numeric|gte:0|lte:100',
                'offer.start_date' => ['required' ],
                'offer.end_date' => ['required' , 'after_or_equal:offer.start_date' ],
                'offer.description' => ['required' ],
                'offer.description_ar' => ['required' ],
                'offer.vn_access' => ['required' ],
                'offer.pn_access' => ['required' ],
                'offer.on_site' => ['required' ],
                'offer.is_notify' => ['required' ],
                'offer.is_top_deal' => ['required' ],
                'offer.enable_slots' => ['required' ],
                'offer.terms_ar' => ['required' ],
                'offer.locations.*' => ['required' ],
                'offer.service_cost.*' => 'required|numeric',
            ],
            [
                'offer.end_date.required' => "End date is required",
                'offer.end_date.after_or_equal'=>"End date should be greater than or equals to start date",
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/deals/tires/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/deals/tires/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('deals/tires/', $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        $sliders = [];
        if($request->hasfile('sliders'))
        {
            foreach($request->file('sliders') as $file)
            {
                $name = Str::random(10).'.'.$file->extension();
                $file->move(public_path().'/uploads/deals/tires/sliders/', $name);
                $sliders[] = '/uploads/deals/tires/sliders/' . $name;
            }
        }

        $is_notify = false;
        if(Organization::where('id', $request['delar_id'])->where('code', 'PETROMIN')->count()){
            // For Petromin company offers should be notified
            $is_notify = true;
        }

        try{
            $insert = array(
                'title' => $request['title'],
                'title_ar' => $request['title_ar'],
                'code' => $request['code'],
                'price' => $request['price'],
                'company' => $request['company'],
                'quantity' => $request['quantity'],
                'delar_id' => $request['delar_id'],
                'description' => $request['description'],
                'description_ar' => $request['description_ar'],
                'height' => $request['height'],
                'width' => $request['width'],
                'size' => $request['size'],
                'status' => $request['status'],
                'updated_at' => date('Y-m-d H:i:s'),
                'updated_by' => Auth::id(),
            );

            if ($request->file('thumbnail'))
                $insert['thumbnail_url'] = $request['thumbnail_url'];

            ItemMaster::where('id', $id)->update($insert);

            $insert = array(
                'price' => $request['price'],
                'quantity' => $request['quantity'],
                'discount' => $request['offer']['discount'],
                'service_cost' => $request['offer']['service_cost'],
                'start_date' => $request['offer']['start_date'],
                'end_date' => $request['offer']['end_date'],
                'description' => $request['offer']['description'],
                'description_ar' => $request['offer']['description_ar'],
                'terms' => $request['offer']['terms'],
                'terms_ar' => $request['offer']['terms_ar'],
                'vn_access' => $request['offer']['vn_access'],
                'pn_access' => $request['offer']['pn_access'],
                'on_site' => $request['offer']['on_site'],
                'is_notify' => $request['offer']['is_notify'],
                'is_top_deal' => $request['offer']['is_top_deal'],
                'enable_slots' => $request['offer']['enable_slots'],
                'provider_reference_id' => $request['offer']['provider_reference_id'],
                'provider_reference_subid' => $request['offer']['provider_reference_subid'],
                'service_id' => $request['offer']['service_id'],
                'updated_at' => date('Y-m-d H:i:s'),
                'updated_by' => Auth::id(),
            );

            if($request['offer']['enable_slots']) {
                try {
                    if(empty($request['offer']['service_id']) || !$request['offer']['service_id']) {
                        $insert['enable_slots'] = 0;
                        $service = (new ServiceBookingController())->create($request['offer'], $request['delar_id']);
                        if ($service) { // Service id was available
                            $insert['service_id'] = $service; // update service id from booking system
                            $insert['enable_slots'] = 1;
                        }
                    }
                    else{
                        (new ServiceBookingController())->edit($request['offer'], $request['offer']['service_id']);
                    }
                } catch (\Exception $e) {
                    Log::error('Service creation on service booking system was failed');
                }
            }

            if($is_notify) {
                $insert['is_notify'] = 1;
                $insert['pn_access'] = 1;
            }

            $update_item_offer = ItemOffer::where('item_id', $id)->first();
            $update_item_offer->where('item_id', $id)->update($insert);
            $offer_id = $update_item_offer->id;
            OfferLocation::where('offer_id' , $offer_id)->delete();

            $insert_offer_location = [];
            foreach($request['offer']['locations'] as $offer_location)
            {
                $insert_offer_location[] = [
                    'location_id' => $offer_location['location_id'],
                    'offer_id' => $offer_id,
                    'created_at' => date('Y-m-d H:i:s'),
                    'created_by' => Auth::id(),
                ];
            }
            if(count($insert_offer_location)> 0){
                OfferLocation::insert($insert_offer_location);
            }

            $insert = [];
            foreach($sliders as $slider)
            {
                $insert[] = [
                    'deal_id' => $this->dealTire,
                    'item_id' => $id,
                    'thumbnail_url' => $slider,
                    'created_at' => date('Y-m-d H:i:s')
                ];
            }

            if(count($insert)> 0){
                //Slider::where('deal_id', 2 )->where('item_id', $id)->delete();
                Slider::insert($insert);
            }


            return response()->json(['status'=>'success', 'message'=> 'Tire updated successfully'], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Tire updation failed', "error" => $e ], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
