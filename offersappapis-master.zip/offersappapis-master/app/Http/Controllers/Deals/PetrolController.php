<?php

namespace App\Http\Controllers\Deals;

use App\Http\Controllers\Controller;
use App\Models\Inventory\ItemMaster;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PetrolController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        // deal_id = 8 for Petrol
        // $list = ItemMaster::where('status', 1)->where('deal_id', 8)->with('delar', 'offer')->get();
        // return response()->json(['status' => 'success', 'data' => $list], 200);
        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $pageno = 1; $pagelength = 10; 
            $list = ItemMaster::where('status', 1)->where('deal_id', 8)->with('delar', 'offer');
            $totalrecords = $list->count();
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
            }
            $list = $list->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();
            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status' => 'success', 'data' => $data], 200);
        }else{
            $list = $list = ItemMaster::where('status', 1)->where('deal_id', 8)->with('delar', 'offer')->get();
            return response()->json(['status' => 'success', 'data' => $list], 200);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'delar_id' => ['required'],
                'price' => ['required'],
                'discount' => ['required'],
                'start_date' => ['required'],
                'end_date' => ['required', 'after:start_date'],
                'description' => ['required'],
                'terms' => ['required' ],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try{

            $request['created_at'] = date('Y-m-d H:i:s');
            $request['created_by'] = Auth::id();
            ItemMaster::insert($request->all());

            return response()->json(['status'=>'success', 'message'=> 'Petrol added successfully'], 200);
        }
        catch (\Exception $e)
        {
            //return $e;
            return response()->json(['status'=>'failed', 'message'=> 'Petrol adding failed'], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $list = ItemMaster::where('id', $id)->with('delar', 'delar.location')->first();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(),
            [
                'delar_id' => ['required'],
                'price' => ['required'],
                'discount' => ['required'],
                'start_date' => ['required'],
                'end_date' => ['required', 'after:start_date'],
                'description' => ['required'],
                'terms' => ['required' ],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try{

            $request['updated_at'] = date('Y-m-d H:i:s');
            $request['updated_by'] = Auth::id();
            ItemMaster::where('id', $id)->update($request->all());

            return response()->json(['status'=>'success', 'message'=> 'Petrol updated successfully'], 200);
        }
        catch (\Exception $e)
        {
            //return $e;
            return response()->json(['status'=>'failed', 'message'=> 'Petrol updation failed'], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
