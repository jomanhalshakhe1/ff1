<?php

namespace App\Http\Controllers\Deals;

use App\Http\Controllers\Generals\DealController;
use App\Http\Controllers\Mediator\ServiceBookingController;
use App\Models\Accounts\VehicleGroup;
use App\Models\Generals\Favourite;
use App\Models\Generals\Role;
use App\Models\Inventory\DealVehicle;
use App\Http\Controllers\Controller;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use App\Models\Inventory\OfferLocation;
use App\Models\Accounts\Vehicle;
use App\Models\Generals\Slider;
use App\Models\Regulatory\Organization;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers\Generals\SendPushNotification;
use App\Events\NewOfferCreated;
use Illuminate\Support\Facades\Log;

class WashController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public $dealWash;
    function __construct()
    {
        // deal_id = 4 for Wash
        $this->dealWash = 4;
    }

    public function index(Request $request)
    {
        // deal_id = 4 for Cleaning
        DB::enableQueryLog();
        $consumer_id = Auth::guard('driver')->id();
        $list = ItemMaster::where('item_master.deal_id', $this->dealWash)
            ->join('item_offers', 'item_offers.item_id', 'item_master.id')
            ->where('item_offers.status','!=','2');
        
         if(explode('/', $request->route()->getPrefix())[0] != 'api'){
              $list = $list->join('organizations', 'organizations.id', 'item_master.delar_id');
             $list = $list->where('organizations.status','1');
          }

        $list=$list->with('delar', 'delar.location', 'offer.locations');
        if(isset($request->org_id) && $request->org_id>0)
            $list = $list->where('item_master.delar_id', $request->org_id);


        if($consumer_id)
        {
            // if(isset($request->org_id))
            //     $list = $list->where('item_master.delar_id', $request->org_id);

            $list = $list->where('item_master.status', 1)
                ->with('minoffer', 'minoffer.vehicle_owners', 'minoffer.locations')
                ->whereRaw('item_offers.end_date >= (DATE(NOW()) - INTERVAL 7 DAY)')
                ->where('item_offers.quantity', '>', 0);

            // eligible vehicle offers only start
            if(Vehicle::where('owner_id', $consumer_id)->where('status', 1)->count() > 0) {
                // If consumer dont have vehicles all effective offers will be listed
                $list = $list->join('deal_vehicles', 'deal_vehicles.offer_id', 'item_offers.id')
                    ->join('vehicles', 'vehicles.group_id', 'deal_vehicles.group_id')
                    ->where('vehicles.status', 1)
                    ->where('vehicles.owner_id', $consumer_id);
            }

            $list = $list->with(['minoffer.vehicle_owners' => function($query) use ($consumer_id){
                // only offer effected for that customer
                $query->where('vehicles.owner_id', $consumer_id);
            }]);
            // eligible vehicle offers only end

            // offers locations only by city
            $list = $list->join('offer_locations', 'offer_locations.offer_id', 'item_offers.id')
                ->join('locations', 'locations.id', 'offer_locations.location_id');
            //if(isset($request->city) && !empty($request->city)){
            $list = $list->where('locations.city', $request->city);

            $city_id = $request->city;
            $list = $list->with(['minoffer.locations' => function ($query) use ($city_id){
                // only search city locations
                $query->where("locations.city", $city_id);
            }]);
            //}

            // Check for Favourites
            $list = $list->leftJoin('favourites', function($fav) use($consumer_id, $city_id){
                $fav->on('favourites.offer_id', 'item_offers.id' );
                $fav->where('favourites.user_id', $consumer_id );
                $fav->where('favourites.city_id', $city_id );
                $fav->on('favourites.location_id', 'offer_locations.location_id' );
            });

            if(isset($request->latitude) && isset($request->longitude)){

                $latitude=$request->latitude;
                $longitude=$request->longitude;

                $sql_distance = DB::raw("if(item_offers.on_site = 0, round((((acos(sin((".$latitude."*pi()/180)) * sin((locations.latitude*pi()/180))+cos((".$latitude."*pi()/180)) * cos((locations.latitude*pi()/180)) * cos(((".$longitude."-locations.longitude)*pi()/180))))*180/pi())*60*1.1515*1.609344),2), 0) as distance");
            } else {
                $sql_distance =  DB::raw('0 as distance');
            }

            $list = $list->select('item_master.*',$sql_distance, DB::raw('item_offers.id as offer_id'),
                'item_offers.discount', 'offer_locations.location_id', 'locations.city', DB::raw('if(favourites.offer_id is null, 0, 1) as is_favourite')
            )->distinct();
        }
        else{
            $list = $list->with('minoffer')
                ->select('item_master.*', DB::raw('item_offers.id as offer_id'), 'item_offers.discount')
                ->distinct();
        }

        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $portal_user = Auth::id();
            if($portal_user){
                // check for delar login
                $login_type_id = Role::where('id', Auth::user()->role_id)->pluck('login_type_id')->first();
                if($login_type_id == 18) // Delar login
                    $list = $list->where('item_master.delar_id' , Auth::user()->org_id);
            }
        }

        //dealer access start
        if(Session::has('dealer_access_id')){
            $token_dealer_id = Session::get('dealer_access_id');
            if(isset($token_dealer_id) && !empty($token_dealer_id)){
                $list = $list->where('item_master.delar_id' , $token_dealer_id);
            }
        }
        //dealer access end

        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $pageno = 1; $pagelength = 10;
            $totalrecords = $list->orderBy('item_master.id', 'desc')->count();
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
            }
            $list = $list->orderBy('item_offers.id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength);
        }else{
            $list = $list->orderBy('item_offers.id', 'desc')
                ->orderBy('item_master.id', 'desc');
        }

        $list = $list->get();
        //return DB::getQueryLog();

        /*$distance_filter = 0; // Disable Distance filter
        for($i=0;$i<count($list);$i++){
            if($distance_filter == 0 && !$list[$i]['minoffer']['on_site'])
                $distance_filter = 1; // Enable Distance filter
        }*/
        $distance_filter = 1; // Enable Distance filter for carwash & carcare default from 08/11/22
        $onsite_filter=0; $eligible_groups = [];

        foreach ($list as $row) {
            if($row['minoffer']['on_site']){
               $onsite_filter=1;
            }

            $userVehicles = $row->minoffer->vehicle_owners;
            $group_ids = [];
            foreach($userVehicles as $vehicle)
                array_push($group_ids, (int)$vehicle->group_id);
            $group_ids = array_values(array_unique($group_ids));

            $eligible_groups = array_unique(array_merge($eligible_groups, $group_ids));
        }

        $dealShare = new DealController();
        $mapData =  $list->map(function($record) use($dealShare) {
            
            $row = json_decode(json_encode($record)); // Deep cloning of object, which can prevent overiding of object data
            $pricing = $dealShare->price_logic($record['minoffer']['price'], $record['minoffer']['discount'], $record['deal_id']);
            $row->minoffer->price = $pricing['actual_price'];
            $row->minoffer->discount = $pricing['final_price'];
            $row->minoffer->vat = $pricing['vat'];
            $row->price = $row->minoffer->price;
           
            if(explode('/', request()->route()->getPrefix())[0] == 'customer') {

                $userVehicles = $row->minoffer->vehicle_owners;
                $group_ids = [];
                foreach($userVehicles as $vehicle)
                    array_push($group_ids, (int)$vehicle->group_id);
                $group_ids = array_values(array_unique($group_ids));

                $groups = [];
                foreach($group_ids as $id)
                    array_push($groups, array("group_id" => $id));

                $offerVehicles = $record->minoffer->vehicles;
                $ogroup_ids = [];
                foreach($offerVehicles as $vehicle)
                    array_push($ogroup_ids, (int)$vehicle->id);
                $ogroup_ids = array_values(array_unique($ogroup_ids));
                $ogroups = [];
                foreach($ogroup_ids as $id)
                    array_push($ogroups, array("group_id" => $id));

                return array(
                    "id" => $row->id,
                    "title" => $row->title,
                    "title_ar" => $row->title_ar,
                    "description" => $row->description,
                    "description_ar" => $row->description_ar,
                    "code" => $row->code,
                    "company" => $row->company,
                    "price" => $pricing['actual_price'],
                    "final_price" => $pricing['final_price'],
                    "dimensions" => $row->dimensions,
                    "deal_id" => $row->deal_id,
                    "delar_id" => $row->delar_id,
                    "thumbnail_url" => $row->thumbnail_url,
                    "volt" => $row->volt,
                    "ah" => $row->ah,
                    "size" => $row->size,
                    "height" => $row->height,
                    "width" => $row->width,
                    "status" => $row->status,
                    "distance" => $row->distance,
                    "offer_id" => $row->offer_id,
                    "location_id" => $row->location_id,
                    "city_id" => $row->city,
                    "is_notify" => $row->minoffer->is_notify,
                    "on_site" => $row->minoffer->on_site,
                    "is_top_deal" => $row->minoffer->is_top_deal,
                    "is_favorite" => $row->is_favourite,
                    "user_vehicle_groups" => $groups,
                    "offer_vehicle_groups" => $ogroups,
                );
            }
            else
                return $row;
        });
        $list = $mapData;

        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status' => 'success', 'data' => $data], 200);
        }else{
            $list = collect($list);

            $top_deals = $list->where('is_top_deal', 1)->values()->skip(0)->take(5);
            $top_deal_ids = $top_deals->pluck('offer_id');
            $non_top_deals = $list->whereNotIn('offer_id', $top_deal_ids)->values();
            $non_top_deals = $non_top_deals->map(function($row){ $row['is_top_deal'] = 0; return $row; });

            if(explode('/', request()->route()->getPrefix())[0] == 'customer')
                $sorted = $non_top_deals->sortBy('final_price')->sortBy('distance');
            else
                $sorted = $non_top_deals->sortBy('minoffer.discount');
            $sorted_offers = $sorted->values()->all();

            $all_deals = $top_deals->merge($sorted_offers);

            return response()->json([
                'status' => 'success',
                'data' => $all_deals,
                'distance_filter' => $distance_filter,
                'onsite_filter' => $onsite_filter, // can be removed
                'onsite_deals_available' => $onsite_filter,
                'filters' => array(
                    'vehicle_groups' => VehicleGroup::whereIn('id', $eligible_groups)->get(),
                )
            ], 200);
        }
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function store(Request $request)
    {
        //dealer access start
        if(Session::has('dealer_access_id')){
            $token_dealer_id = Session::get('dealer_access_id');
            if(isset($token_dealer_id) && !empty($token_dealer_id)){
                $request['delar_id'] = $token_dealer_id;
                $request['status'] = 1;
            }
        }
        //dealer access end
        $vehicleslist = []; // for notifications
        $request['offers'] = json_decode($request['offers'], true);
        $validator = Validator::make($request->all(),
            [
                'title' => ['required', 'string', 'max:100' ],
                'title_ar' => ['required', 'string', 'max:100' ],
                // 'code' => ['required', 'string', 'max:20' ],
                'code'=>[],
                'delar_id' => ['required'],
                //'description' => ['required' ],
                //'description_ar' => ['required' ],
                'thumbnail' => ['required', 'mimes:jpeg,jpg,png', 'max:500' ],
                'sliders' => 'required',
                'sliders.*' => 'mimes:jpeg,jpg,png',
                'offers.*.title' => ['required' ],
                'offers.*.title_ar' => ['required' ],
                'offers.*.price' => ['required' ],
                'offers.*.quantity' => 'required|numeric|gte:1|lte:1000000',
                'offers.*.discount' => 'required|numeric|gte:0|lte:100',
                'offers.*.start_date' => ['required', 'after_or_equal:'.date("Y-m-d") ],
                'offers.*.end_date' => ['required', 'after_or_equal:offers.*.start_date'],
                'offers.*.description' => ['required' ],
                'offers.*.description_ar' => ['required' ],
                'offers.*.vn_access' => ['required' ],
                'offers.*.pn_access' => ['required' ],
                'offers.*.on_site' => ['required' ],
                'offers.*.is_top_deal' => ['required' ],
                'offers.*.enable_slots' => ['required' ],
                'terms' => ['required' ],
                'terms_ar' => ['required' ],
                "offers.*.vehicles"    => "required|array|min:1",
                "offers.*.vehicles.*"  => "required|min:1",
                'offers.*.locations.*' => "required",
                'offers.*.service_cost.*' => 'required|numeric',
            ],
            [
                'offers.*.start_date.required' => "Start date is required",
                'offers.*.start_date.after_or_equal'=>"State date should be greater than or equals to today's date",
                'offers.*.end_date.required' => "End date is required",
                'offers.*.end_date.after_or_equal'=>"End date should be greater than or equals to start date",
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/deals/wash/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/deals/wash/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('deals/wash/', $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        $sliders = [];
        if($request->hasfile('sliders'))
        {
            foreach($request->file('sliders') as $file)
            {
                $name = Str::random(10).'.'.$file->extension();
                $file->move(public_path().'/uploads/deals/wash/sliders/', $name);
                $sliders[] = '/uploads/deals/wash/sliders/' . $name;
            }
        }

        $is_notify = false;
        if(Organization::where('id', $request['delar_id'])->where('code', 'PETROMIN')->count()){
            // For Petromin company offers should be notified
            $is_notify = true;
        }

        try{
            $insert = array(
                'title' => $request['title'],
                'title_ar' => $request['title_ar'],
                'code' => $request['code'],
                'price' => 1,
                'quantity' => 1,
                'delar_id' => $request['delar_id'],
                'deal_id' => $this->dealWash, // Cleaning Category
                'description' => $request['description'],
                'description_ar' => $request['description_ar'],
                'thumbnail_url' => $request['thumbnail_url'],
                'status' => $request['status'],
                'created_at' => date('Y-m-d H:i:s'),
                'created_by' => Auth::id(),
            );

            $wash_id = ItemMaster::insertGetId($insert);
            $isSentNotification= false;
            foreach ($request['offers'] as $offer) {

                $insert = array(
                    'item_id' => $wash_id,
                    'deal_id' => $this->dealWash,
                    'title' => $offer['title'],
                    'title_ar' => $offer['title_ar'],
                    'price' => $offer['price'],
                    'quantity' => $offer['quantity'],
                    'discount' => $offer['discount'],
                    'service_cost' => $offer['service_cost'],
                    'start_date' => $offer['start_date'],
                    'end_date' => $offer['end_date'],
                    'description' => $offer['description'],
                    'description_ar' => $offer['description_ar'],
                    'terms' => $request['terms'],
                    'terms_ar' => $request['terms_ar'],
                    'vn_access' => $offer['vn_access'],
                    'pn_access' => $offer['pn_access'],
                    'on_site' => $offer['on_site'],
                    'is_top_deal' => $offer['is_top_deal'],
                    'enable_slots' => $offer['enable_slots'],
                    'provider_reference_id' => $offer['provider_reference_id'],
                    'provider_reference_subid' => $offer['provider_reference_subid'],
                    'service_id' => $offer['service_id'],
                    'created_at' => date('Y-m-d H:i:s'),
                    'created_by' => Auth::id(),
                );

                if($offer['enable_slots']) {
                    $insert['enable_slots'] = 0;
                    try {
                        $service = (new ServiceBookingController())->create($offer, $request['delar_id']);
                        if ($service) { // Service id was available
                            $insert['service_id'] = $service; // update service id from booking system
                            $insert['enable_slots'] = 1;
                        }
                    } catch (\Exception $e) {
                        Log::error('Service creation on service booking system was failed');
                    }
                }

                if($is_notify) {
                    $insert['is_notify'] = 1;
                    $insert['pn_access'] = 1;
                }

                $offer_id = ItemOffer::insertGetId($insert);

                if(date('Y-m-d', strtotime($offer['start_date'])) >= date('Y-m-d'))
                   $isSentNotification= true;

                $insert_offer_location = [];
                foreach ($offer['locations'] as $offer_location) {
                    $insert_offer_location[] = [
                        'location_id' => $offer_location['location_id'],
                        'offer_id' => $offer_id,
                        'created_at' => date('Y-m-d H:i:s'),
                        'created_by' => Auth::id(),
                    ];
                }
                if (count($insert_offer_location) > 0) {
                    OfferLocation::insert($insert_offer_location);
                }

                //foreach ($offer->vehicles as $vehicle) {
                foreach ($offer['vehicles'] as $vehicle) {
                    DealVehicle::insert(array(
                        'item_id' => $wash_id,
                        'offer_id' => $offer_id,
                        'deal_id' => $this->dealWash,
                        'group_id' => $vehicle,
                        'created_at' => date('Y-m-d H:i:s'),
                        'created_by' => Auth::id(),
                    ));

                    array_push($vehicleslist, $vehicle);
                }
            }

            $insert = [];
            foreach($sliders as $slider)
            {
                $insert[] = [
                    'deal_id' => $this->dealWash,
                    'item_id' => $wash_id,
                    'thumbnail_url' => $slider,
                    'created_at' => date('Y-m-d H:i:s')
                ];
            }

            if(count($insert)> 0)
                Slider::insert($insert);

             // Send notification to consumer 
            if($request['status'] && $isSentNotification){
                try{
                    event(new NewOfferCreated($wash_id, $this->dealWash, '',23));
                } catch (\Exception $e) {
                    Log::error('Failed to send notification :  '. $e->getMessage());
                } 
            }

            return response()->json(['status'=>'success', 'message'=> 'Washer Item created successfully'], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Washer Item creation failed', "error" => $e ], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id, $city_id = null, $location_id = null)
    {
        try {
            $consumer_id = Auth::guard('driver')->id();
            // deal_id = 4 for Cleaning
            $list = ItemMaster::where('id', $id)->where('deal_id', $this->dealWash)
                ->with('delar', 'delar.location', 'offer', 'offers', 'offers.locations', 'slider');

            if ($consumer_id) {
                $list = $list->with('offers.vehicle_owners');

                // consumer related offer based on vehicles
                $list = $list->with(['offers' => function ($query) use ($consumer_id) {
                    // only offer effected for that customer
                    $query->where('item_offers.quantity', '>', 0);
                    if (Vehicle::where('owner_id', $consumer_id)->where('status', 1)->count() > 0) {
                        $query->join('deal_vehicles', 'item_offers.id', 'deal_vehicles.offer_id')
                            ->join('vehicles', 'vehicles.group_id', 'deal_vehicles.group_id')
                            ->where('vehicles.status', 1)
                            ->where('vehicles.owner_id', $consumer_id)
                            ->select('item_offers.*', 'vehicles.owner_id')->distinct();
                    }
                },
                    'offers.vehicle_owners' => function ($query) use ($consumer_id) {
                        // only offer effected for that customer
                        $query->where('vehicles.owner_id', $consumer_id);
                    }]);

                // offers locations only by city
                if (isset($city_id) && !empty($city_id)) {

                    $list = $list->with(['offers' => function ($query) use ($city_id, $location_id) {
                        // only offer effected for that city
                        $query->join('offer_locations', 'offer_locations.offer_id', 'item_offers.id');

                        if ($location_id)
                            $query->where('offer_locations.location_id', $location_id);
                        else
                            $query->join('locations', 'locations.id', 'offer_locations.location_id')->where('locations.city', $city_id);

                        $query->select('item_offers.*')->distinct();
                    },
                        'offers.locations' => function ($query) use ($city_id, $location_id) {
                            // only offer effected for that customer
                            $query->where("locations.city", $city_id);
                            if ($location_id)
                                $query->where("locations.id", $location_id);
                        }]);
                }
            } else
                $list = $list->with('offers.vehicles', 'vehicle.vehicles');

            //dealer access start
            if (Session::has('dealer_access_id')) {
                $token_dealer_id = Session::get('dealer_access_id');
                if (isset($token_dealer_id) && !empty($token_dealer_id)) {
                    $list = $list->where('delar_id', $token_dealer_id);
                }
            }
            //dealer access end

            $list = $list->first();

            $dealShare = new DealController();
            if (explode('/', $request->route()->getPrefix())[0] != 'api') {
                $offer_id = '';
                foreach ($list['offers'] as $row) {
                    $pricing = $dealShare->price_logic($row['price'], $row['discount'], $row['deal_id']);
                    $row['base_price'] = $pricing['base_price'];
                    $row['price'] = $pricing['actual_price'];
                    $row['discount'] = $pricing['final_price'];
                    $row['vat'] = $pricing['vat'];
                    $offer_id = $row['id'];
                }

                if(isset($city_id) && isset($location_id) && Auth::guard('driver')->id()){
                    $fwhere = array(
                        'user_id' => Auth::guard('driver')->id(),
                        'offer_id' => $offer_id,
                        'city_id' => $city_id,
                        'location_id' => $location_id,
                    );
                    $list['is_favourite'] = Favourite::where($fwhere)->count() > 0 ? 1 : 0;
                }
                else
                    $list['is_favourite'] = 0;

                $list['enable_mutiple_qty'] = 1;
                if(Organization::where('id', $list['delar_id'])->where('code', 'PETROMIN')->count()){
                    $list['enable_mutiple_qty'] = 0;
                }
            }

            return response()->json(['status' => 'success', 'data' => $list], 200);
        }
        catch (\Exception $e){
            return response()->json(['status' => 'failed', 'error' => $e], 400);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request['offers'] = json_decode($request['offers'], true);
        $validator = Validator::make($request->all(),
            [
                'title' => ['required', 'string', 'max:100' ],
                'title_ar' => ['required', 'string', 'max:100' ],
                // 'code' => ['required', 'string', 'max:20' ],
                'code'=>[],
                'delar_id' => ['required'],
                //'description' => ['required' ],
                //'description_ar' => ['required' ],
                'offers.*.title' => ['required','string', 'max:100' ],
                'offers.*.title_ar' => ['required', 'string', 'max:100' ],
                'offers.*.price' => ['required' ],
                'offers.*.quantity' => 'required|numeric|gte:1|lte:1000000',
                'offers.*.discount' => 'required|numeric|gte:0|lte:100',
                'offers.*.start_date' => ['required' ],
                'offers.*.end_date' => ['required', 'after_or_equal:offers.*.start_date' ],
                'offers.*.description' => ['required' ],
                'offers.*.description_ar' => ['required' ],
                'terms' => ['required' ],
                'terms_ar' => ['required' ],
                'offers.*.vn_access' => ['required' ],
                'offers.*.pn_access' => ['required' ],
                'offers.*.on_site' => ['required' ],
                'offers.*.is_top_deal' => ['required' ],
                'offers.*.enable_slots' => ['required' ],
                "offers.*.vehicles"    => "required|array|min:1",
                "offers.*.vehicles.*"  => "required|min:1",
                'offers.*.locations.*' => "required",
                'offers.*.service_cost.*' => 'required|numeric',
            ],
            [
                'offers.*.end_date.required' => "End date is required",
                'offers.*.end_date.after_or_equal'=>"End date should be greater than or equals to start date",
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('thumbnail')) {
                $extension = $file->extension()?: 'png';
                $destinationPath = public_path() . '/uploads/deals/wash/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['thumbnail_url'] = '/uploads/deals/wash/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('deals/wash/', $request->file('thumbnail'));
            $request['thumbnail_url'] = Storage::disk('s3')->url($file_name);
        }

        $sliders = [];
        if($request->hasfile('sliders'))
        {
            foreach($request->file('sliders') as $file)
            {
                $name = Str::random(10).'.'.$file->extension();
                $file->move(public_path().'/uploads/deals/wash/sliders/', $name);
                $sliders[] = '/uploads/deals/wash/sliders/' . $name;
            }
        }

        $is_notify = false;
        if(Organization::where('id', $request['delar_id'])->where('code', 'PETROMIN')->count()){
            // For Petromin company offers should be notified
            $is_notify = true;
        }

        try{
            $insert = array(
                'title' => $request['title'],
                'title_ar' => $request['title_ar'],
                'code' => $request['code'],
                'price' => 1,
                'quantity' => 1,
                'delar_id' => $request['delar_id'],
                'description' => $request['description'],
                'description_ar' => $request['description_ar'],
                'status' => $request['status'],
                'updated_at' => date('Y-m-d H:i:s'),
                'updated_by' => Auth::id(),
            );

            if ($request->file('thumbnail'))
                $insert['thumbnail_url'] = $request['thumbnail_url'];

            ItemMaster::where('id', $id)->update($insert);
            
            foreach ($request['offers'] as $offer) {

                $insert = array(
                    'title' => $offer['title'],
                    'title_ar' => $offer['title_ar'],
                    'price' => $offer['price'],
                    'quantity' => $offer['quantity'],
                    'discount' => $offer['discount'],
                    'service_cost' => $offer['service_cost'],
                    'start_date' => $offer['start_date'],
                    'end_date' => $offer['end_date'],
                    'description' => $offer['description'],
                    'description_ar' => $offer['description_ar'],
                    'terms' => $request['terms'],
                    'terms_ar' => $request['terms_ar'],
                    'vn_access' => $offer['vn_access'],
                    'pn_access' => $offer['pn_access'],
                    'on_site' => $offer['on_site'],
                    'is_top_deal' => $offer['is_top_deal'],
                    'enable_slots' => $offer['enable_slots'],
                    'provider_reference_id' => $offer['provider_reference_id'],
                    'provider_reference_subid' => $offer['provider_reference_subid'],
                    'service_id' => $offer['service_id'],
                    'updated_at' => date('Y-m-d H:i:s'),
                    'updated_by' => Auth::id(),
                );

                if($offer['enable_slots']) {
                    try {
                        if(empty($offer['service_id']) || !$offer['service_id']) {
                            $insert['enable_slots'] = 0;
                            $service = (new ServiceBookingController())->create($offer, $request['delar_id']);
                            if ($service) { // Service id was available
                                $insert['service_id'] = $service; // update service id from booking system
                                $insert['enable_slots'] = 1;
                            }
                        }
                        else{
                            (new ServiceBookingController())->edit($offer, $offer['service_id']);
                        }
                    } catch (\Exception $e) {
                        Log::error('Service creation on service booking system was failed');
                    }
                }

                if($is_notify) {
                    $insert['is_notify'] = 1;
                    $insert['pn_access'] = 1;
                }

               if (array_key_exists("id",$offer)){
                    $update_item_offer = ItemOffer::where('id', $offer['id'])->first();
                    $update_item_offer->where('id', $offer['id'])->update($insert);
                    $offer_id = $update_item_offer->id;
               } else {
                  $insert['item_id']=$id;
                  $insert['deal_id']=4;
                  $offer_id = ItemOffer::insertGetId($insert);
               }

                OfferLocation::where('offer_id', $offer_id)->delete();

                $insert_offer_location = [];
                foreach ($offer['locations'] as $offer_location) {
                    $insert_offer_location[] = [
                        'location_id' => $offer_location['location_id'],
                        'offer_id' => $offer_id,
                        'created_at' => date('Y-m-d H:i:s'),
                        'created_by' => Auth::id(),
                    ];
                }
                if (count($insert_offer_location) > 0) {
                    OfferLocation::insert($insert_offer_location);
                }

                DealVehicle::where('item_id', $id)->where('offer_id', $offer_id)->where('deal_id', $this->dealWash)->delete();

                foreach ($offer['vehicles'] as $vehicle) {
                    DealVehicle::insert(array(
                        'item_id' => $id,
                        'offer_id' => $offer_id,
                        'deal_id' => $this->dealWash,
                        'group_id' => $vehicle,
                        'created_at' => date('Y-m-d H:i:s'),
                        'created_by' => Auth::id(),
                    ));
                }
            }

            $insert = [];
            foreach($sliders as $slider)
            {
                $insert[] = [
                    'deal_id' => $this->dealWash,
                    'item_id' => $id,
                    'thumbnail_url' => $slider,
                    'created_at' => date('Y-m-d H:i:s')
                ];
            }

            if(count($insert)> 0){
                //Slider::where('deal_id', 4 )->where('item_id', $id)->delete();
                Slider::insert($insert);
            }


            return response()->json(['status'=>'success', 'message'=> 'Washer Item updated successfully'], 200);
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Washer Item updation failed', "error" => $e ], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        try{
            $delete_offer = [
                'status' => 2,
                'updated_at' => date('Y-m-d H:i:s')
            ];
            $update_status = ItemOffer::where('id', $id)->update($delete_offer);
            if($update_status){
                return response()->json(['status'=>'success', 'message'=> 'Washer Item deleted successfully'], 200);
            }else{
                return response()->json(['status'=>'failed', 'message'=> 'Washer Item deletion failed'], 400);
            }
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Washer Item delete failed', "error" => $e ], 400);
        }
    }
}
