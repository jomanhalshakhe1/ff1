<?php

namespace App\Http\Controllers\Deals;

use App\Http\Controllers\Controller;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use App\Models\Generals\Slider;
use App\Models\Inventory\DealVehicle;
use App\Models\Inventory\Maintenance;
use App\Models\Inventory\MaintenanceLog;
use App\Models\Accounts\ManufacturerGroup;
use App\Models\Accounts\VehicleGroup;
use App\Models\Regulatory\DealUpload;
use App\Models\Generals\Manufacturer;
use App\Models\Accounts\Vehicle;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Session;
use App\Imports\DealsBulkUpload;
use Carbon\Carbon;
use Excel;
use PDF;

class BulkUploadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function battery_upload(Request $request) {
        //dealer access start
        $delar_id = '';
        if(Session::has('dealer_access_id')){
            $token_dealer_id = Session::get('dealer_access_id');
            if(isset($token_dealer_id) && !empty($token_dealer_id)){
                $delar_id = $token_dealer_id;
            }
        }
        //dealer access end
        $validator = Validator::make($request->all(),[
            'deals_bulkupload_file'  => 'required|mimes:xls,xlsx,csv,txt'
        ]);
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $path = $request->file('deals_bulkupload_file')->getRealPath();
            $data = Excel::toArray(new DealsBulkUpload, $request->file('deals_bulkupload_file'));
        }catch (\Exception $e){
            
            return response()->json(['status' => "failed", "response" => "Invalid File Format"], 400);
        }

        if ($file=$request->file('deals_bulkupload_file')) {
            $extension = $file->extension()?: 'png';
            $destinationPath = public_path() . '/uploads/deals/battery/';
            $safeName = Str::random(10) . '.' . $extension;
            $file->move($destinationPath, $safeName);
            $request['uploaded_file'] = '/uploads/deals/battery/'.$safeName;
        }
        $dealbulkUpload = array(
            'delar_id'    => $delar_id,
            'uploaded_file'    => $request['uploaded_file'],
            'success_rows'    => 0,
            'failed_rows'    => 0,
            'total_rows'    => 0,
            'created_by' => $delar_id,
            'created_at' => date('Y-m-d H:i:s')
        );
        $sheet_id = DealUpload::insertGetId($dealbulkUpload);

        $inserted = 0;
        if(count($data) > 0) {
            foreach($data as $key => $value) {
                foreach($value as $row) {
                    $battery_insert_data = array(
                        'title' => $row['title'],
                        'code' => $row['code'],
                        'price' => $row['price'],
                        'company' => $row['company'],
                        'quantity' => $row['quantity'],
                        'dimensions' => $row['dimensions'],
                        'delar_id' => $delar_id,
                        'deal_id' => 6, // Deal Category Battery
                        'description' => $row['description'],
                        'volt' => $row['volt'],
                        'ah' => $row['ah'],
                        'status' => 1,
                        //'status' => $row['status'],
                        //'thumbnail_url' => $row['thumbnail_url'],
                        'created_at' => date('Y-m-d H:i:s'),
                        'created_by' => Auth::id(),
                    );
                    $battery_id = ItemMaster::insertGetId($battery_insert_data);

                    //$row['offer'] = json_decode($row['offer'], true);

                    $battery_offer_insert[] = array(
                        'item_id' => $battery_id,
                        'deal_id' => 6, // Deal Category Battery
                        'discount' => $row['discount'],
                        //'start_date' => $row['start_date'],
                        //'end_date' => $row['end_date'],
                        'start_date' => \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($row['start_date'])->format('Y-m-d'),
                        'end_date' => \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($row['end_date'])->format('Y-m-d'),
                        'description' => $row['offer_description'],
                        'terms' => $row['offer_terms'],
                        'created_at' => date('Y-m-d H:i:s'),
                        'created_by' => Auth::id(),
                    );
                    //ItemOffer::insert($battery_offer_insert);
                }
            }
            if(!empty($battery_offer_insert)) {
                $inserted = ItemOffer::insertOrIgnore($battery_offer_insert);
            }
        }

        $deals_batteryUpload = array(
            'success_rows'    => $inserted,
            'failed_rows'    => (count($data) - $inserted),
            'total_rows'    => count($data)
        );
        DealUpload::where('id', $sheet_id)->update($deals_batteryUpload);
        return response()->json(['status' => "success", "message" => "Deals Battery file uploaded successfully", "data" => $deals_batteryUpload  ], 200);
    }

    public function detailing_upload(Request $request) {
        //dealer access start
        $delar_id = '';
        if(Session::has('dealer_access_id')){
            $token_dealer_id = Session::get('dealer_access_id');
            if(isset($token_dealer_id) && !empty($token_dealer_id)){
                $delar_id = $token_dealer_id;
            }
        }
        //dealer access end
        $validator = Validator::make($request->all(),[
            'deals_bulkupload_file'  => 'required|mimes:xls,xlsx,csv,txt'
        ]);
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $path = $request->file('deals_bulkupload_file')->getRealPath();
            $data = Excel::toArray(new DealsBulkUpload, $request->file('deals_bulkupload_file'));
        }catch (\Exception $e){
            
            return response()->json(['status' => "failed", "response" => "Invalid File Format"], 400);
        }

        if ($file=$request->file('deals_bulkupload_file')) {
            $extension = $file->extension()?: 'png';
            $destinationPath = public_path() . '/uploads/deals/detailing/';
            $safeName = Str::random(10) . '.' . $extension;
            $file->move($destinationPath, $safeName);
            $request['uploaded_file'] = '/uploads/deals/detailing/'.$safeName;
        }
        $dealbulkUpload = array(
            'delar_id'    => $delar_id,
            'uploaded_file'    => $request['uploaded_file'],
            'success_rows'    => 0,
            'failed_rows'    => 0,
            'total_rows'    => 0,
            'created_by' => $delar_id,
            'created_at' => date('Y-m-d H:i:s')
        );
        $sheet_id = DealUpload::insertGetId($dealbulkUpload);

        $inserted = 0;
        if(count($data) > 0) {
            foreach($data as $key => $value) {
                foreach($value as $row) {
                    //detailing insertion start
                    $detailing_insert = array(
                        'title' => $row['title'],
                        'code' => $row['code'],
                        'price' => $row['price'],
                        'quantity' => $row['quantity'],
                        'delar_id' => $delar_id,
                        'deal_id' => 5, // Deataling Catergory
                        'description' => $row['description'],
                        //'thumbnail_url' => $request['thumbnail_url'],
                        //'status' => $request['status'],
                        'status' => 1,
                        'created_at' => date('Y-m-d H:i:s'),
                        'created_by' => Auth::id(),
                    );
                    $detailing_id = ItemMaster::insertGetId($detailing_insert);

                    //$row['offer'] = json_decode($row['offer'], true);
                    $row['vehicles'] = json_decode($row['vehicles'], true);

                    $detailing_offer_insert[] = array(
                        'item_id' => $detailing_id,
                        'deal_id' => 5,
                        'discount' => $row['discount'],
                        //'start_date' => $row['start_date'],
                        //'end_date' => $row['end_date'],
                        'start_date' => \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($row['start_date'])->format('Y-m-d'),
                        'end_date' => \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($row['end_date'])->format('Y-m-d'),
                        'description' => $row['offer_description'],
                        'terms' => $row['offer_terms'],
                        'created_at' => date('Y-m-d H:i:s'),
                        'created_by' => Auth::id(),
                    );

                    foreach ($row['vehicles'] as $vehicle) {
                        DealVehicle::insert(array(
                            'item_id' => $detailing_id,
                            'deal_id' => 5,
                            'group_id' => $vehicle,
                            'created_at' => date('Y-m-d H:i:s'),
                            'created_by' => Auth::id(),
                        ));
                    }
                    //detailing insertion end
                }
            }
            if(!empty($detailing_offer_insert)) {
                $inserted = ItemOffer::insertOrIgnore($detailing_offer_insert);
            }
        }

        $deals_detailingUpload = array(
            'success_rows'    => $inserted,
            'failed_rows'    => (count($data) - $inserted),
            'total_rows'    => count($data)
        );
        DealUpload::where('id', $sheet_id)->update($deals_detailingUpload);
        return response()->json(['status' => "success", "message" => "Deals Detailing file uploaded successfully", "data" => $deals_detailingUpload  ], 200);
    }

    public function washes_upload(Request $request) {
        //dealer access start
        $delar_id = '';
        if(Session::has('dealer_access_id')){
            $token_dealer_id = Session::get('dealer_access_id');
            if(isset($token_dealer_id) && !empty($token_dealer_id)){
                $delar_id = $token_dealer_id;
            }
        }
        //dealer access end

        $validator = Validator::make($request->all(),[
            'deals_bulkupload_file'  => 'required|mimes:xls,xlsx,csv,txt'
        ]);
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $path = $request->file('deals_bulkupload_file')->getRealPath();
            $data = Excel::toArray(new DealsBulkUpload, $request->file('deals_bulkupload_file'));
        }catch (\Exception $e){
            return response()->json(['status' => "failed", "response" => "Invalid File Format"], 400);
        }

        if ($file=$request->file('deals_bulkupload_file')) {
            $extension = $file->extension()?: 'png';
            $destinationPath = public_path() . '/uploads/deals/wash/';
            $safeName = Str::random(10) . '.' . $extension;
            $file->move($destinationPath, $safeName);
            $request['uploaded_file'] = '/uploads/deals/wash/'.$safeName;
        }
        $dealbulkUpload = array(
            'delar_id'    => $delar_id,
            'uploaded_file'    => $request['uploaded_file'],
            'success_rows'    => 0,
            'failed_rows'    => 0,
            'total_rows'    => 0,
            'created_by' => $delar_id,
            'created_at' => date('Y-m-d H:i:s')
        );
        $sheet_id = DealUpload::insertGetId($dealbulkUpload);

        $inserted = 0;
        if(count($data) > 0) {
            foreach($data as $key => $value) {
                foreach($value as $row) {
                    //washes insertion start
                    $washes_insert = array(
                        'title' => $row['title'],
                        'code' => $row['code'],
                        'price' => $row['price'],
                        'quantity' => $row['quantity'],
                        'delar_id' => $delar_id,
                        'deal_id' => 4, // Cleaning Category
                        'description' => $row['description'],
                        //'thumbnail_url' => $row['thumbnail_url'],
                        //'status' => $row['status'],
                        'status' => 1,
                        'created_at' => date('Y-m-d H:i:s')
                    );
                    $wash_id = ItemMaster::insertGetId($washes_insert);
                    
                    //$row['offer'] = json_decode($row['offer'], true);
                    $row['vehicles'] = json_decode($row['vehicles'], true);

                    $washes_offer_insert[] = array(
                        'item_id' => $wash_id,
                        'deal_id' => 4,
                        'discount' => $row['discount'],
                        //'start_date' => $row['start_date'],
                        //'end_date' => $row['end_date'],
                        'start_date' => \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($row['start_date'])->format('Y-m-d'),
                        'end_date' => \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($row['end_date'])->format('Y-m-d'),
                        'description' => $row['offer_description'],
                        'terms' => $row['offer_terms'],
                        'created_at' => date('Y-m-d H:i:s')
                    );
                    //ItemOffer::insert($washes_offer_insert);
                    foreach ($row['vehicles'] as $vehicle)
                    {
                        DealVehicle::insert(array(
                            'item_id' => $wash_id,
                            'deal_id' => 4,
                            'group_id' => $vehicle
                        ));
                    }
                    //washes insertion end
                }
            }
            if(!empty($washes_offer_insert)) {
                $inserted = ItemOffer::insertOrIgnore($washes_offer_insert);
            }
        }
        $deals_washUpload = array(
            'success_rows'    => $inserted,
            'failed_rows'    => (count($data) - $inserted),
            'total_rows'    => count($data)
        );
        DealUpload::where('id', $sheet_id)->update($deals_washUpload);
        return response()->json(['status' => "success", "message" => "Deals Washes file uploaded successfully", "data" => $deals_washUpload  ], 200);
    }

    public function tires_upload(Request $request) {
        //dealer access start
        $delar_id = '';
        if(Session::has('dealer_access_id')){
            $token_dealer_id = Session::get('dealer_access_id');
            if(isset($token_dealer_id) && !empty($token_dealer_id)){
                $delar_id = $token_dealer_id;
            }
        }
        //dealer access end

        $validator = Validator::make($request->all(),[
            'deals_bulkupload_file'  => 'required|mimes:xls,xlsx,csv,txt'
        ]);
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $path = $request->file('deals_bulkupload_file')->getRealPath();
            $data = Excel::toArray(new DealsBulkUpload, $request->file('deals_bulkupload_file'));
        }catch (\Exception $e){
            return response()->json(['status' => "failed", "response" => "Invalid File Format"], 400);
        }

        if ($file=$request->file('deals_bulkupload_file')) {
            $extension = $file->extension()?: 'png';
            $destinationPath = public_path() . '/uploads/deals/tires/';
            $safeName = Str::random(10) . '.' . $extension;
            $file->move($destinationPath, $safeName);
            $request['uploaded_file'] = '/uploads/deals/tires/'.$safeName;
        }
        $dealbulkUpload = array(
            'delar_id'    => $delar_id,
            'uploaded_file'    => $request['uploaded_file'],
            'success_rows'    => 0,
            'failed_rows'    => 0,
            'total_rows'    => 0,
            'created_by' => $delar_id,
            'created_at' => date('Y-m-d H:i:s')
        );
        $sheet_id = DealUpload::insertGetId($dealbulkUpload);

        $inserted = 0;
        if(count($data) > 0) {
            foreach($data as $key => $value) {
                foreach($value as $row) {
                    //tires insertion start
                    $tires_insert = array(
                        'title' => $row['title'],
                        'code' => $row['code'],
                        'price' => $row['price'],
                        'company' => $row['company'],
                        'quantity' => $row['quantity'],
                        'delar_id' => $delar_id,
                        'deal_id' => 2, // tires module
                        'description' => $row['description'],
                        'height' => $row['height'],
                        'width' => $row['width'],
                        'size' => $row['size'],
                        'status' => 1,
                        //'status' => $row['status'],
                        //'thumbnail_url' => $row['thumbnail_url'],
                        'created_at' => date('Y-m-d H:i:s')
                    );
                    $tire_id = ItemMaster::insertGetId($tires_insert);

                    //$row['offer'] = json_decode($row['offer'], true);

                    $tires_offer_insert[] = array(
                        'item_id' => $tire_id,
                        'deal_id' => 2,
                        'discount' => $row['discount'],
                        //'start_date' => $row['start_date'],
                        //'end_date' => $row['end_date'],
                        'start_date' => \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($row['start_date'])->format('Y-m-d'),
                        'end_date' => \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($row['end_date'])->format('Y-m-d'),
                        'description' => $row['offer_description'],
                        'terms' => $row['offer_terms'],
                        'created_at' => date('Y-m-d H:i:s')
                    );
                    //ItemOffer::insert($tires_offer_insert);
                    //tires insertion end
                }
            }
            if(!empty($tires_offer_insert)) {
                $inserted = ItemOffer::insertOrIgnore($tires_offer_insert);
            }
        }
        $deals_tireUpload = array(
            'success_rows'    => $inserted,
            'failed_rows'    => (count($data) - $inserted),
            'total_rows'    => count($data)
        );
        DealUpload::where('id', $sheet_id)->update($deals_tireUpload);
        return response()->json(['status' => "success", "message" => "Deals Tires file uploaded successfully", "data" => $deals_tireUpload  ], 200);
    }

    public function manufacturers_upload(Request $request) {
        //dealer access start
        $delar_id = '';
        if(Session::has('dealer_access_id')){
            $token_dealer_id = Session::get('dealer_access_id');
            if(isset($token_dealer_id) && !empty($token_dealer_id)){
                $delar_id = $token_dealer_id;
            }
        }
        //dealer access end

        $validator = Validator::make($request->all(),[
            'deals_bulkupload_file'  => 'required|mimes:xls,xlsx,csv,txt'
        ]);
        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }
        try{
            $path = $request->file('deals_bulkupload_file')->getRealPath();
            $data = Excel::toArray(new DealsBulkUpload, $request->file('deals_bulkupload_file'));
        }catch (\Exception $e){
            return response()->json(['status' => "failed", "response" => "Invalid File Format"], 400);
        }

        if ($file=$request->file('deals_bulkupload_file')) {
            $extension = $file->extension()?: 'png';
            $destinationPath = public_path() . '/uploads/deals/manufacturers/';
            $safeName = Str::random(10) . '.' . $extension;
            $file->move($destinationPath, $safeName);
            $request['uploaded_file'] = '/uploads/deals/manufacturers/'.$safeName;
        }
        $dealbulkUpload = array(
            'delar_id'    => $delar_id,
            'uploaded_file'    => $request['uploaded_file'],
            'success_rows'    => 0,
            'failed_rows'    => 0,
            'total_rows'    => 0,
            'created_by' => $delar_id,
            'created_at' => date('Y-m-d H:i:s')
        );
        $sheet_id = DealUpload::insertGetId($dealbulkUpload);

        $inserted = 0;
        if(count($data) > 0) {
            foreach($data as $key => $value) {
                foreach($value as $row) {
                    //manufacturers insertion start
                    $row['manufacturers'] = json_decode($row['manufacturers'],true);
                    $manufacture_insert = array(
                        'delar_id' => $delar_id,
                        'quantity' => $row['quantity'],
                        'parts' => $row['parts'],
                        'maintenance' => $row['maintenance'],
                        'accessories' => $row['accessories'],
                        'start_date' => \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($row['start_date'])->format('Y-m-d'),
                        'end_date' => \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($row['end_date'])->format('Y-m-d'),
                        'description' => $row['description'],
                        'terms' => $row['terms'],
                        'created_at' => date('Y-m-d H:i:s'),
                    );
                    $item_id = Maintenance::insertGetId($manufacture_insert);
                    $inserted++;
                    foreach ($row['manufacturers'] as $manufacturer)
                    {
                        ManufacturerGroup::insert(array(
                            'item_id' => $item_id,
                            'deal_id' => 9, // category Mantenance & Services
                            'group_id' => $manufacturer
                        ));
                    }
                    //manufacturers insertion end
                }
            }
        }
        $deals_manufacturersUpload = array(
            'success_rows'    => $inserted,
            'failed_rows'    => (count($data) - $inserted),
            'total_rows'    => count($data)
        );
        DealUpload::where('id', $sheet_id)->update($deals_manufacturersUpload);
        return response()->json(['status' => "success", "message" => "Deals Manufacturers file uploaded successfully", "data" => $deals_manufacturersUpload  ], 200);
    }

    public function manufacturers(Request $request){
        $list = Manufacturer::where('status', '1')->get();
        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    public function vehicle_groups() {
        $list = VehicleGroup::where('status', '1')->get();
        return response()->json([ 'status' => "success", "data" => $list ], 200);
    }

    
}
