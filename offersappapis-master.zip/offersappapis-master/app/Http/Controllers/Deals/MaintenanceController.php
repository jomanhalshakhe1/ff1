<?php

namespace App\Http\Controllers\Deals;

use App\Models\Accounts\Driver;
use App\Http\Controllers\Controller;
use App\Models\Generals\Favourite;
use App\Models\Generals\Role;
use App\Models\Inventory\Maintenance;
use App\Models\Inventory\MaintenanceLog;
use App\Models\Accounts\ManufacturerGroup;
use App\Models\Regulatory\Delar;
use App\Models\Regulatory\Organization;
use App\Models\Accounts\User;
use App\Models\Accounts\Vehicle;
use App\Models\Regulatory\OrgDeal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Session;

class MaintenanceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $consumer_id = Auth::guard('driver')->id();
        $list = Maintenance::with('delar', 'delar.location');
        if($consumer_id){
            $list = $list->leftJoin('favourites', function($join) use($consumer_id){
                        $join->on('maintenances.id', 'favourites.offer_id');
                        $join->where('favourites.deal_id', 9); // 9 - M & S Offers
                        $join->where('favourites.user_id', $consumer_id);
                    })
                    ->where('maintenances.status', 1)
                    ->whereRaw('maintenances.end_date >= (DATE(NOW()) - INTERVAL 7 DAY)');

            if(isset($request->city) && !empty($request->city)){
                $list = $list->join('organizations', 'maintenances.delar_id', 'organizations.id')
                    ->join('locations', 'locations.org_id', 'organizations.id')
                    ->where('locations.city', $request->city);

                $city_id = $request->city;
                $list = $list->with(['delar.location' => function ($query) use ($city_id){
                    $query->where("locations.city", $city_id);
                }]);
            }
        }

        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $portal_user = Auth::id();
            if($portal_user){
                // check for delar
                $login_type_id = Role::where('id', Auth::user()->role_id)->pluck('login_type_id')->first();
                if($login_type_id != 17) // Service Provide Delar
                    $list = $list->where('maintenances.delar_id' , Auth::user()->org_id);
            }
        }

        //dealer access start
        if(Session::has('dealer_access_id')){
            $token_dealer_id = Session::get('dealer_access_id');
            if(isset($token_dealer_id) && !empty($token_dealer_id)){
                $list = $list->where('maintenances.delar_id' , $token_dealer_id);
            }
        }
        //dealer access end

        if($consumer_id){
            $list = $list->select('maintenances.*')
                    ->selectRaw('if(favourites.id is null, 0, 1) as is_favourite')
                    ->distinct();
        }
        else{
            $list = $list->select('maintenances.*')->distinct();
        }


        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $pageno = 1; $pagelength = 10; 
            $totalrecords = $list->orderBy('id', 'desc')->count();
            if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                $pagelength = $request->pagelength;
                $pageno = $request->pageno;
            }
            $list = $list->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();
        }else{
            $list = $list->orderBy('maintenances.id', 'desc')->get();

            if($consumer_id){
                if(count($list) == 0){
                    // if there is no records available with the input request show all records
                    $list = Maintenance::with('delar', 'delar.location')
                                ->leftJoin('favourites', function($join) use($consumer_id){
                                    $join->on('maintenances.id', 'favourites.offer_id');
                                    $join->where('favourites.deal_id', 9); // M & S Offers
                                    $join->where('favourites.user_id', $consumer_id);
                                })
                                ->where('maintenances.status', 1)
                                ->whereRaw('end_date >= (DATE(NOW()) - INTERVAL 7 DAY)')
                                ->select('maintenances.*')
                                ->selectRaw('if(favourites.id is null, 0, 1) as is_favourite')->distinct()
                                ->orderBy('id', 'desc')->get();
                }
            }
        }

        //from response filter by city end
        if(explode('/', $request->route()->getPrefix())[0] == 'api'){
            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            return response()->json(['status' => 'success', 'data' => $data], 200);
        }else{
            $deals = [];
            if(isset($request->city))
                $deals = $this->available_deals($request->city);

            foreach($list as $row){
                $row['is_service_deal'] = Delar::where('id', $row['delar_id'])
                                ->where('company_type', 'M')->where('code', 'PETROMIN')->count();
            }
            return response()->json(['status' => 'success', 'data' => $list, "deals" => $deals], 200);
        }
    }

    public function available_deals($city_id){
        return DB::select("select a.id, a.title, a.title_ar, a.action_type, a.thumbnail_url, a.sort_order, a.status,
              if(count(1) > 0, 1, 0) as is_avaialable
            from deals as a left join org_deals as b on a.id = b.deal_id
            join locations as c on b.org_id = c.org_id
            where c.city = ".$city_id." and a.status = 1
            group by a.id, a.title, a.title_ar, a.action_type, a.thumbnail_url, a.sort_order, a.status;");
    }

    public function petromin_deals($request){

        $org_id = Organization::where('code', 'PETROMIN')->where('company_type', 'D')->pluck('id')->first();
        $request['org_id'] = $org_id;
        $orgDeals = OrgDeal::join('deals', 'deals.id', 'org_deals.deal_id')
            ->where('org_deals.org_id', $org_id)->where('org_deals.status', 1)
            ->where('deals.action_type', 'A')
            ->select('deals.id','deals.title','deals.thumbnail_url')
            ->orderBy('deals.sort_order', 'asc')
            ->get();

        $data = []; $i = 0;
        foreach($orgDeals as $deal){
            $data[$i] = $deal;
            switch ($deal['id']){
                case 2: // Tires
                    $result = (new TireController())->index($request);
                    $data[$i]['offers'] = $result->getData()->data;
                    break;
                case 4: // Car wash
                    $result = (new WashController())->index($request);
                    $data[$i]['offers'] = $result->getData()->data;
                    break;
                case 5: // Car care
                    $result = (new DetailingController())->index($request);
                    $data[$i]['offers'] = $result->getData()->data;
                    break;
                case 6: // Batteries
                    $result = (new BatteryController())->index($request);
                    $data[$i]['offers'] = $result->getData()->data;
                    break;
                case 10: // Oil Changes
                    $result = (new OilchangesController())->index($request);
                    $data[$i]['offers'] = $result->getData()->data;
                    break;
                default: $data[$i]['offers'] = [];
            }
            $i++;
        }

        return $data;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //dealer access start
        if(Session::has('dealer_access_id')){
            $token_dealer_id = Session::get('dealer_access_id');
            if(isset($token_dealer_id) && !empty($token_dealer_id)){
                $request['delar_id'] = $token_dealer_id;
                $request['status'] = 1;
            }
        }
        //dealer access end

        $request['manufacturers'] = json_decode($request['manufacturers'], true);
        $validator = Validator::make($request->all(),
            [
                "manufacturers"    => "required|array|min:1",
                "manufacturers.*"  => "required|distinct|min:1",
                'delar_id' => ['required'],
                'quantity' => 'required|digits_between:1,1000000',
                'parts' => 'required|digits_between:0,100',
                'maintenance' => 'required|digits_between:0,100',
                'accessories' =>'required|digits_between:0,100',
                'start_date' => ['required', 'after_or_equal:'.date('Y-m-d')],
                'end_date' => ['required', 'after_or_equal:start_date'],
                'description' => ['required'],
                'description_ar' => ['required'],
                'terms' => ['required' ],
                'terms_ar' => ['required' ],
            ]
        );


        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try{

            // if(Maintenance::where('delar_id', $request->delar_id)->count()>0){
            //     return response()->json(['status'=>'failed', 'message'=> 'Only one deal can add by each organization'], 400);
            // }

            $request['created_at'] = date('Y-m-d H:i:s');
            $request['created_by'] = Auth::id();
            $item_id = Maintenance::insertGetId($request->except('manufacturers'));

            foreach ($request['manufacturers'] as $manufacturer)
            {
                ManufacturerGroup::insert(array(
                    'item_id' => $item_id,
                    'deal_id' => 9, // category Mantenance & Services
                    'group_id' => $manufacturer,
                    'created_at' => date('Y-m-d H:i:s'),
                    'created_by' => Auth::id(),
                ));
            }

            return response()->json(['status'=>'success', 'message'=> 'Maintenance created successfully'], 200);
        }
        catch (\Exception $e)
        {
            //return $e;
            return response()->json(['status'=>'failed', 'message'=> 'Maintenance creation failed', "error" => $e], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        $list = Maintenance::where('id', $id)
            ->with(['delar', 'manufacturer' => function ($query) use ($id) {
                $query->where('item_id', $id)
                    ->where('deal_id', 9);
            }, 'manufacturer.manufacturers', 'delar.locations' ]);

        //dealer access start
            if(Session::has('dealer_access_id')){
                $token_dealer_id = Session::get('dealer_access_id');
                if(isset($token_dealer_id) && !empty($token_dealer_id)){
                    $list = $list->where('delar_id' , $token_dealer_id);
                }
            }
        //dealer access end
        $list = $list->first();

        $consumer_id = Auth::guard('driver')->id();
        if($consumer_id) {
            $list->is_favourite = Favourite::where('deal_id', 9)
                ->where('user_id', $consumer_id)->where('offer_id', $list->id)->count() > 0 ? 1 : 0;

            $is_service_deal = Delar::where('id', $list['delar_id'])
                ->where('company_type', 'M')->where('code', 'PETROMIN')->count();

            if(isset(request()->city) && $is_service_deal) {
                $list['deals'] = $this->petromin_deals($request);
            }
        }

        return response()->json(['status' => 'success', 'data' => $list], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request['manufacturers'] = json_decode($request['manufacturers'], true);
        $validator = Validator::make($request->all(),
            [
                "manufacturers"    => "required|array|min:1",
                "manufacturers.*"  => "required|distinct|min:1",
                'delar_id' => ['required'],
                'quantity' => 'required|digits_between:1,1000000',
                'parts' => 'required|digits_between:0,100',
                'maintenance' => 'required|digits_between:0,100',
                'accessories' =>'required|digits_between:0,100',
                'start_date' => ['required'],
                'end_date' => ['required', 'after_or_equal:start_date'],
                'description' => ['required'],
                'description_ar' => ['required'],
                'terms' => ['required' ],
                'terms_ar' => ['required' ],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try{

            $request['updated_at'] = date('Y-m-d H:i:s');
            $request['updated_by'] = Auth::id();
            Maintenance::where('id', $id)->update($request->except('manufacturers'));

            ManufacturerGroup::where('item_id' , $id)->where('deal_id' , 9)->delete();

            foreach ($request['manufacturers'] as $manufacturer)
            {
                ManufacturerGroup::insert(array(
                    'item_id' => $id,
                    'deal_id' => 9,
                    'group_id' => $manufacturer,
                    'created_at' => date('Y-m-d H:i:s'),
                    'created_by' => Auth::id(),
                ));
            }

            return response()->json(['status'=>'success', 'message'=> 'Maintenance updated successfully'], 200);
        }
        catch (\Exception $e)
        {
            //return $e;
            return response()->json(['status'=>'failed', 'message'=> 'Maintenance updation failed', "error" => $e ], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function scan_info(Request $request)
    {
        $result=$this->add_transaction($request);

        if($result['status']=='success'){
             $list['transaction'] = $result;
             $data=$result['data'];
            
             $list['item'] = Maintenance::where('id', $request['item_id'])->first();
             $list['delar'] = Organization::where('id', $list['item']['delar_id'])->first();
             $list['manufacturer'] = Organization::where('id', $list['item']['manufacturer_id'])->first();
             $list['user'] = Driver::where('id', $request['driver_id'])->first();
             $list['vehicle'] = Vehicle::where('owner_id', $request['driver_id'])->where('id', $data->vehicle_id)->with('model')->first();

             return response()->json(['status' => 'success', 'data' => $list], 200);
        } else {
             return response()->json($result, 200);
        }
    }

    public function technician_scans()
    {
        try{
            // $list = MaintenanceLog::with('item', 'vehicle', 'vehicle.owner', 'vehicle.colour', 'vehicle.model')
            //         ->orderBy('id', 'desc')->get();

            // $scan_count = MaintenanceLog::where('created_by', Auth::guard('technician')->id())->count();

            $userId=Auth::guard('technician')->id();
            $roleId=Auth::guard('technician')->user()->role_id;
            $orgId=Auth::guard('technician')->user()->org_id;
            
            $list = MaintenanceLog::with('item', 'vehicle', 'vehicle.owner', 'vehicle.colour', 'vehicle.model');
            
            if($roleId==2){
                $list = $list->whereHas('item', function($item) use($orgId){
                    $item->where('delar_id', $orgId);
                });
            } else {
                $list = $list->where('created_by',$userId);
            }

            $scan_count = $list->count();
            $list=$list->orderBy('id', 'desc')->get();

            return response()->json(['status'=>'success', 'data' => $list, 'scan_count' => $scan_count], 200);
        }
        catch (\Exception $e)
        {
            //return $e;
            return response()->json(['status'=>'failed', 'message'=> 'Scanned list not available', 'message_ar'=>'القائمة الممسوحة ضوئيا غير متوفرة'], 400);
        }
    }

    public function total_scans(Request $request)
    {
        try{
            //$list = MaintenanceLog::with('item', 'item.delar', 'vehicle', 'vehicle.owner', 'vehicle.groups')->orderBy('id', 'desc')->get();
            if(explode('/', $request->route()->getPrefix())[0] == 'api'){
                $pageno = 1; $pagelength = 10; 
                $list = MaintenanceLog::with('item', 'item.delar', 'vehicle', 'vehicle.owner', 'vehicle.groups', 'vehicle.owner.fleet_consumer');
                
                if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
                    $pagelength = $request->pagelength;
                    $pageno = $request->pageno;
                }

                $login_type_id = Role::where('id',Auth::user()->role_id)->pluck('login_type_id')->first();
                if($login_type_id == 20) { // M&S Service Company
                    $org_id = Auth::user()->org_id;
                    // $list->whereHas('vehicle', function($driverquery){
                    //     $driverquery->leftjoin('fleet_drivers as fd', 'owner_id', 'fd.driver_id')->where('fd.fleet_id', Auth::user()->org_id);
                    // });

                    $list = $list->whereHas('item', function ($item)  {
                       $item->where('delar_id',Auth::user()->org_id);
                    });
                }


                if($login_type_id == 19) { // Fleet Company
                    $org_id = Auth::user()->org_id;
                    $list->whereHas('vehicle', function($driverquery){
                        $driverquery->leftjoin('fleet_drivers as fd', 'owner_id', 'fd.driver_id')->where('fd.fleet_id', Auth::user()->org_id);
                    }); 
                }


                $totalrecords = $list->orderBy('id', 'desc')->count();

                $list = $list->orderBy('id', 'desc')->skip( ($pageno-1)*$pagelength )->take($pagelength)->get();
            }else{
                $list = MaintenanceLog::with('item', 'item.delar', 'vehicle', 'vehicle.owner', 'vehicle.groups', 'vehicle.owner.fleet_consumer')->orderBy('id', 'desc')->get();
            }
            if(explode('/', $request->route()->getPrefix())[0] == 'api'){
                $data['data'] = $list;
                $data['current_page'] = $pageno;
                $data['total'] = $totalrecords;
                $data['per_page'] = $pagelength;
                return response()->json(['status' => 'success', 'data' => $data], 200);
            }else{
                return response()->json(['status'=>'success', 'data' => $list], 200);
            }
        }
        catch (\Exception $e)
        {
            return response()->json(['status'=>'failed', 'message'=> 'Transaction list failed','message_ar'=>'فشلت قائمة المعاملات', "error"=>$e->getMessage()], 400);
        }
    }

    /**
     * When technician wanted to scan M&S deal
     * @param $request
     * @return $result
     */
    public function add_transaction($request)
    {
        $validator = Validator::make($request->all(),
            [
                'item_id' => ['required'],
                'driver_id' => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return [ 'status' => "failed", "response" => $errors ];
        }

        //Before doing scanning check previously done scanning was completed or not
        $scannedData=MaintenanceLog::where('user_id', $request['driver_id'])
                     ->where('item_id',$request->item_id)
                     ->orderBy('id','desc')
                     ->first();

        if($scannedData && !$scannedData->status){
            return [ 
                'status' => "success",
                "is_open"=>'0', 
                "message" => "This customer have a open transaction, kindly check", 
                "message_ar"=>'هذا العميل لديه معاملة مفتوحة ، يرجى التحقق',
                'data'=>$scannedData
            ];
            
        }

        try{
    		$item = Maintenance::where('id', $request['item_id'])->select('parts', 'maintenance', 'accessories', 'quantity','delar_id','end_date','start_date','status')->first();

            if(!$item)
                return ['status'=>'failed', 'message'=> 'Transaction creation failed',"message_ar"=>'فشل إنشاء رانسال', "error" => 'Item data not found'];

            if(!$item->status){ 
                return array( 'status' => "failed", "message" => "Offer not yet available", "message_ar"=>'العرض غير متوفر بعد' ); 
            }

            if($item->start_date>date("Y-m-d")){ 
                return array( 'status' => "failed", "message" => "Offer not yet available", "message_ar"=>'العرض غير متوفر بعد' ); 
            }

            if($item->end_date<date("Y-m-d")){
                return array( 'status' => "failed", "message" => "Offer was expired", "message_ar"=>'انتهى العرض' ); 
            }

            if(!$item->quantity){
                return array( 'status' => "failed", "message" => "Offer was sold out", "message_ar"=>'تم بيع العرض بالكامل' );
            }


            if($item->delar_id!=Auth::user()->org_id){
                return array( 'status' => "failed", "message" => "You are not authorized to scan other's deals", "message_ar"=>'غير مصرح لك بمسح صفقات الآخرين' );
            }

            $request['parts'] = $item['parts'];
            $request['maintenance'] = $item['maintenance'];
            $request['accessories'] = $item['accessories'];
             
            //Get one vehicle id based on the manufactured 

            $vehiclesList=DB::select("SELECT * FROM vehicles a WHERE a.company IN(SELECT group_id FROM manufacturer_groups where item_id=".$request->item_id.") and a.owner_id=".$request['driver_id']);

            if(!$vehiclesList){
                 return array( 'status' => "failed", "message" => "Customer didn't add any vehicle details for this available item's manufactures list", "message_ar"=>'للم يقم العميل بإضافة أي تفاصيل عن السيارة لقائمة مصنعي هذا العنصر المتوفر');
            }  



            $vehicle_id=$vehiclesList['0']->id;
            $transaction_no = date('Ymd').sprintf('%02d',$request['deal_id']).
                sprintf('%04d',$request['item_id']).mt_rand(1000, 9999);

            $request['transaction_no'] = $transaction_no;
            $request['user_id'] = $request['driver_id'];
            $request['vehicle_id'] = $vehicle_id;
            $request['created_by'] = Auth::guard('technician')->id();
            $request['created_at'] = date('Y-m-d H:i:s');
            $request['status'] = 0;
            
            Maintenance::where('id', $request['item_id'])->decrement('quantity', 1);

            MaintenanceLog::create($request->except('driver_id'));
            
            $data=MaintenanceLog::where('transaction_no', $transaction_no)->first();

            return [
                'status'=>'success',
                'message'=> 'Transaction created successfully',
                'message_ar'=> 'تم إنشاء المعاملة بنجاح',
                'data' => $data
            ];
        } catch (\Exception $e) {
            return [
                'status'=>'failed',
                'message'=> 'Transaction creation failed',
                'message_ar'=> 'فشل إنشاء المعاملة',
                "error" => $e->getMessage()
            ];
        }

    }

    private function available_quantity($request)
    {
        $quantity = Maintenance::where('id', $request['item_id'])->pluck('quantity')->first();

        if($quantity >= $request['quantity'])
            return true;
        else
            return false;
    }

    public function service_cost(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'transaction_no' => ['required'],
                'service_cost' => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        try{
            $update['service_cost'] = $request['service_cost'];
            $update['updated_by'] = Auth::id();
            $res = MaintenanceLog::where('transaction_no', $request['transaction_no'])->update($update);

            return response()->json(['status'=>'success', 'message'=> 'Transaction updated successfully', 'data' => $res], 200);
        }
        catch (\Exception $e)
        {
            //return $e;
            return response()->json(['status'=>'failed', 'message'=> 'Transaction updation failed'], 400);
        }

    }

    public function upload_doc(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'transaction_no' => ['required'],
                'invoice' => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach(json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json([ 'status' => "failed", "response" => $errors ], 400);
        }

        if(config('app.env') == 'local'){
            if ($file=$request->file('invoice')) {
                $extension = $file->extension();
                $destinationPath = public_path() . '/uploads/maintenance/invoice/';
                $safeName = Str::random(10) . '.' . $extension;
                $file->move($destinationPath, $safeName);
                $request['invoice_file'] = '/uploads/maintenance/invoice/'.$safeName;
            }
        }else{
            $file_name = Storage::disk('s3')->put('/maintenance/invoice/', $request->file('invoice'));
            $request['invoice_file'] = Storage::disk('s3')->url($file_name);
        }

        try{
            $update['invoice_file'] = $request['invoice_file'];
            $update['status'] = 1;
            $update['updated_by'] = Auth::id();
            $res = MaintenanceLog::where('transaction_no', $request['transaction_no'])->update($update);

            return response()->json([
                'status'=>'success',
                'message'=> 'Transaction updated successfully',
                'message_ar'=> 'تم تحديث المعاملة بنجاح',
                'data' => $res
            ], 200);
        }
        catch (\Exception $e)
        {
            return response()->json([
                'status'=>'failed',
                'message'=> 'Transaction updation failed',
                'message_ar'=> 'فشل تحديث المعاملة',
            ], 400);
        }

    }

    public function recent_scanned_list()
    {
         try{
            $userId=Auth::guard('technician')->id();
            $roleId=Auth::guard('technician')->user()->role_id;
            $orgId=Auth::guard('technician')->user()->org_id;
            
            $list = MaintenanceLog::with('item', 'vehicle', 'vehicle.owner', 'vehicle.colour', 'vehicle.model');
            
            if($roleId==2){
                $list = $list->whereHas('item', function($item) use($orgId){
                    $item->where('delar_id',$orgId);
                });
            } else {
                $list = $list->where('created_by',$userId);
            }

            $list=$list->orderBy('id', 'desc')->take(10)->skip(0)->get();
            return response()->json(['status'=>'success', 'data' => $list], 200);
        }
        catch (\Exception $e)
        {
           return response()->json(['status'=>'failed', 'message'=> 'Recent scanned list not available', 'message_ar'=>'القائمة الممسوحة ضوئيا مؤخرا غير متوفرة'], 400);
        }
    }

    /**
     * Get all scanned transactions list by service provider or technician
     * @param $request
     * @return \Illuminate\Http\Response
     */

    function scanned_by_partner_transactions(Request $request){

        $userId = $request->user_id;
        $pageno = 1;
        $pagelength = 10;

        $userData = User::where('id', $userId)->first();
        if(!$userData){
              return response()->json(['status' => 'failed', 'message' => 'User information not found'], 400);
        }

        $list = MaintenanceLog::with('driver', 'item','item.delar','scanner');
        $orgId=$userData->org_id;
        
        $list = $list->whereHas('item', function($item) use($orgId){
            $item->where('delar_id',$orgId);
        });

        if ($userData->role_id == 7) {
            $list = $list->where('created_by', $userId);      
        }

        $totalrecords = $list->orderBy('id', 'desc')->count();
        if (isset($request->pagelength, $request->pageno) && !empty($request->pagelength)) {
            $pagelength = $request->pagelength;
            $pageno = $request->pageno;
        }

        $list = $list->orderBy('id', 'desc')->get();
        if (explode('/', $request->route()->getPrefix())[0] == 'api') {
            $data['data'] = $list;
            $data['current_page'] = $pageno;
            $data['total'] = $totalrecords;
            $data['per_page'] = $pagelength;
            $data['user_data'] = $userData;
            return response()->json(['status' => 'success', 'data' => $data], 200);
        } else {
            return response()->json(['status' => 'success', 'data' => $list], 200);
        }
    }

 
    /* Download invoice*/
    function download_invoice($transactionNo){
        $transactionInfo=MaintenanceLog::where('transaction_no', $transactionNo)->first();
        if($transactionInfo){
            if($transactionInfo->invoice_file){
                $filepath = public_path($transactionInfo->invoice_file);

                if(file_exists($filepath)) {
                    //return response()->download($filepath);
                    header('Content-Description: File Transfer');
                    header('Content-Type: application/octet-stream');
                   // header('Content-Type: image/jpeg');
                    header('Content-Disposition: attachment; filename="'.basename($filepath).'"');
                    
                    header('Content-Length: ' . filesize($filepath));
                    flush(); 
                    readfile($filepath);
                    exit;
                }
            } else {
                return "Invoice not found";
            }
        } else {
            return "Invoice not found";
        }
    }
}
