<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Generals\DealController;
use App\Http\Controllers\Users\CreditsController;
use App\Models\Accounts\Payment;
use App\Models\Accounts\PaymentShare;
use App\Models\Accounts\OnsiteLocation;
use App\Models\Accounts\TransactionComment;
use App\Models\Accounts\TransactionDetail;
use App\Models\Accounts\Vehicle;
use App\Models\Generals\City;
use App\Models\Generals\Coupons\Coupon;
use App\Models\Generals\Coupons\CouponLog;
use App\Models\Generals\Deal;
use App\Models\Generals\Lookup;
use App\Models\Generals\Notification;
use App\Models\Generals\NotificationLog;
use App\Models\Generals\Payout;
use App\Models\Generals\RedeemLog;
use App\Models\Inventory\ItemMaster;
use App\Models\Inventory\ItemOffer;
use App\Models\Accounts\Transaction;
use App\Models\Inventory\MaintenanceLog;
use App\Models\Regulatory\Location;
use App\Models\Regulatory\Organization;
use App\Models\Regulatory\TechnicianLocation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use App\Models\Accounts\Driver;
use Excel;
use PDF;
use PDFAR;
use App\Http\Controllers\Generals\SendPushNotification;
use App\Http\Controllers\GeneralController;
use Salla\ZATCA\GenerateQrCode;
use Salla\ZATCA\Tags\InvoiceDate;
use Salla\ZATCA\Tags\InvoiceTaxAmount;
use Salla\ZATCA\Tags\InvoiceTotalAmount;
use Salla\ZATCA\Tags\Seller;
use Salla\ZATCA\Tags\TaxNumber;
use App\Models\Accounts\Credit;
use App\Events\NewOrderPlaced;
use App\Events\RequestOfferAvailability;
use App\Events\OfferRedeemed;
use App\Events\AddressRequested;
use App\Events\sendAddressForOnsite;
use App\Events\cancelTranaction;
use App\Events\offerAvailabilityUpdated;
use App\Events\Emails\RedeemedOfferEmail;
use App\Events\Emails\PurchasedAnOfferEmail;
use App\Events\Emails\OfferAvailabilityStatusForAdmin;
use App\Events\Emails\ConsumerCurrentLocationForAdmin;
use App\Models\Accounts\User;
use App\Http\Controllers\tabby\TabbyController;

class TabbyTransactionController extends Controller
{

 
    /**
     * Store a new transaction
     * Item availability check
     * Find Payment type and paymnet shares
     * Create a transaction
     * Send notification to the respective users
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),
            [
                'deal_id' => ['required'],
                'item_id' => ['required'],
                'offer_id' => ['required'],
                'quantity' => ['required'],
                'payment_with' => ['required'],
                'location_id' => ['required'],
            ]
        );

        if ($validator->fails()) {
            $errors = [];
            foreach (json_decode($validator->messages()) as $key => $value)
                $errors[] = $value[0];
            return response()->json(['status' => "failed", "response" => $errors], 400);
        }

        if (!$this->available_quantity($request->all()))
            return response()->json(['status' => "failed", "response" => "Offer was sold out", "response_ar" => "انتهى العرض"], 400);

        if (isset($request['coupon_id']) && $request['coupon_id'] != ''
            && CouponLog::where('id', $request['coupon_id'])->whereNull('transaction_no')->count() == 0
        ) {
            return response()->json([
                'status' => "failed",
                "message" => "Coupon already redeemed, please try again",
                "message_ar" => "تم استرداد القسيمة بالفعل ، يرجى المحاولة مرة أخرى",
            ], 400);
        }

        try {
            $item = ItemOffer::where('id', $request['offer_id'])->where('item_id', $request['item_id'])->first();

            if ($item['end_date'] < date("Y-m-d"))
                return response()->json([
                    'status' => "failed",
                    "response" => "Offer was expired",
                    "response_ar" => "انتهى العرض"], 400);

            $finder = $this->payment_with_finder($item, $request);

            $payment_on = $finder['payment_on'];
            $request['payment_with'] = $finder['payment_with'];
            $request['price'] = $item['price'];
            $request['discount'] = $item['discount'];
            $request['fleet_id'] = $finder['fleet_id'];

            $transaction_no = date('Ymd') . sprintf('%02d', $request['deal_id']) .
                sprintf('%04d', $request['item_id']) . mt_rand(1000, 9999);

            $request['remarks'] = 'Initiated Payment transaction';

            $request['transaction_no'] = $transaction_no;
            $request['created_by'] = isset($request->customer_id)? $request->customer_id : Auth::guard('driver')->id();
            $request['created_at'] = date('Y-m-d H:i:s');
            if ($item['is_notify']) // notify offer
            {
                if ($payment_on == 7 || $payment_on == 34 || (env('APP_OTP') == 'local' && $payment_on == 33)) {
                    // only on 7 - Credits or 34 - Google Pay or 33 - Apple pay
                    // This is only for direct payments
                    $request['payment_status'] = 'Requests';
                }
            }

            $transactionId=Transaction::insertGetId($request->except('coupon_id','payment_gateway','customer_id'));

            $payment_no = date('Ymd') . sprintf('%02d', $request['deal_id']) . sprintf('%04d', $request['item_id']) . mt_rand(1000, 9999);
            
            $payments = array(
                "payment_no" => $payment_no,
                "transaction_no" => $transaction_no,
                "payment_type" => 2, // Refund Payment
                "payment_on" => $payment_on,
                "amount_by_banking" => $finder['amount_by_banking'],
                "amount_by_credits" => $finder['amount_by_credits'],
                "created_at" => date('Y-m-d H:i:s'),
            );

            Payment::insert($payments);

            $filter_flag = $request['filter_flag'] ?? 0;
            if (isset($request['coupon_id']) && $finder['savings'] > 0) {
                // redeem coupon
                CouponLog::where('id', $request['coupon_id'])
                    ->update(['transaction_no' => $transaction_no, 'savings' => $finder['savings']]);
            }

            $data = $this->create_transaction_bill($transaction_no, $filter_flag);
            if ($finder['payment_with'] == 7) {
                // only by credits
                $this->update_payment_status($transaction_no, $payment_no, $request, $item['is_notify']);
            } else if ($payment_on == 34) {// google pay
                // only by Google Pay
                $this->update_payment_status($transaction_no, $payment_no, $request, $item['is_notify']);
            } else if (env('APP_OTP') == 'local' && $payment_on == 33) {// apple pay
                $this->update_payment_status($transaction_no, $payment_no, $request, $item['is_notify']);
            } else if ($payment_on == 35 && $request->payment_gateway==2) {// Credit card with tabby
                $result=$this->createTabbySession($request, $transaction_no, $transactionId, $finder['amount_by_banking']);

                if($result['status']=='failed'){
                    return response()->json([
                    'status' => 'failed',
                    'message' => $result['message'],
                    ], 400);
                } else {
                   $data['web_url']=$result['url'];
                   return response()->json([
                    'status' => 'success',
                    'message' => 'Session created',
                    'data' => $data,
                    ], 200);
                }

            }

            $request['payment'] = $payments;

            return response()->json([
                'status' => 'success',
                'message' => 'Transaction created successfully',
                'message_ar' => 'تم إنشاء المعاملة بنجاح',
                'data' => $request->all()
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'failed',
                'message' => 'Transaction creation failed',
                'message_ar' => 'فشل إنشاء المعاملة',
                "error" => $e->getMessage()], 400);
        }
    }

 

     /**
     * To find the payment shares and payment type.
     * Payment share will be through banking or credits.
     * Find the Consumer credits and validate payment share to banking or credits
     * Send notitifaction to the consumer & technicians of purchased status
     *
     * @param  $item - Requested item for the transaction
     * @param  $request - it will give requested purchased quantity and payment type
     * @return payment shares, payment type, final price
     */
    public function payment_with_finder($item, $request)
    {

        $dealShare = new DealController();
        $pricing = $dealShare->price_logic($item['price'], $item['discount'], $item['deal_id']);
        $service_cost = $item['service_cost'];

        $serviveQuantity = 1;
        if ($item['deal_id'] == '4' || $item['deal_id'] == '5') { // 4 - Cleaning, 5 - Deatiling
            $serviveQuantity = $request->quantity;
        }

        $filter_flag = $request['filter_flag'] ?? 0;
        $filter_cost = 0;
        if ($filter_flag) {
            $filter_cost = Vehicle::join('vehicle_models', 'vehicles.model', 'vehicle_models.id')
                ->where('vehicles.id', $request['vehicle_id'])
                ->pluck('vehicle_models.filter_price')->first();
        }

        $finalPrice = $pricing['final_price']; // this is having markup price also
        $product_price = $finalPrice * $request['quantity'] + ($service_cost * $serviveQuantity) + $filter_cost;

        $savings = 0;
        if (isset($request['coupon_id']) && $request['coupon_id'] != ''
            && CouponLog::where('id', $request['coupon_id'])->whereNull('transaction_no')->count() > 0
        ) {
            // if coupon applied and not yet redeemed
            $adminShare = $pricing['admin_share'] * $request['quantity'];
            $couponData = CouponLog::where('id', $request['coupon_id'])->first();
            $couponInfo = Coupon::where('id', $couponData->coupon_id)->first();

            if ($couponInfo->coupon_type == 'C') //Credits
            {
                if ($adminShare < $couponInfo->discount)
                    $savings = $adminShare; // if credits are greater than admin share consider as savings
                else
                    $savings = $couponInfo->discount;
            } else if ($couponInfo->coupon_type == 'D') // Discount Percent
                $savings = $adminShare * $couponInfo->discount / 100;

            CouponLog::where('id', $request['coupon_id'])
                ->update([
                    'discount' => $couponInfo->discount,
                    'savings' => $savings,
                ]);
        }

        // Deduct Coupon savings on the final payable amount
        $product_price -= $savings;

        /************** Start Payment Method finder ************/
        $amount_by_banking = $amount_by_credits = 0;
        $payment_with = 7;
        /*
                Credit Account - 7
                Banking - 8
                Credit and Bank Accounts - 9
                Apple Pay - 33
                Google Pay - 34
                Cards - 35
            */

        // with credits or credits + banking
        // update payment amounts
        // Check credit payments are enabled or not
        if (Lookup::where('id', 7)->where('status', 1)->count() > 0) {
            $credit = new CreditsController();
            $user_id=isset($request->customer_id)? $request->customer_id : Auth::guard('driver')->id();
            $accounts=$credit->getCreditsInfo($user_id);
            $credits =$accounts['credits'];
        } else
            $credits = 0;

        if ($product_price <= $credits) {
            $payment_with = 7; // Credit Account
            $amount_by_credits = $product_price;
        } else if ($product_price > $credits) {
            if ($credits == 0)
                $payment_with = 8; // Banking
            else
                $payment_with = 9; // Credit and Bank Accounts
            $amount_by_credits = $credits;
            $amount_by_banking = $product_price - $credits;

            if ($amount_by_banking < 3) {
                // Banking amount should be minimum 3
                if ($amount_by_credits > 0) {
                    // Change banking amount only credits more than 0
                    // credits amount transafered to banking for minimum price
                    $banking = ($product_price < $amount_by_banking + (3 - $amount_by_banking)) ? $product_price : ($amount_by_banking + (3 - $amount_by_banking));
                    $credits = ($amount_by_credits - (3 - $amount_by_banking)) < 0 ? 0 : ($amount_by_credits - (3 - $amount_by_banking));

                    $amount_by_credits = $credits;
                    $amount_by_banking = $banking;
                }
            }
        }

        /************** End Payment Method finder ************/

        return array(
            'product_price' => $product_price,
            'savings' => $savings,
            'finalPrice' => $finalPrice,
            'quantity' => $request['quantity'],
            'payment_with' => $payment_with,
            'payment_on' => $request['payment_with'],
            'amount_by_credits' => $amount_by_credits,
            'amount_by_banking' => $amount_by_banking,
            'fleet_id' => $pricing['fleet_id'],
        );
    }

    private function create_transaction_bill($transaction_no, $filter_flag)
    {

        $trans = Transaction::where('transaction_no', $transaction_no)->first();
        $service_cost = ItemOffer::where('id', $trans->offer_id)->pluck('service_cost')->first();

        $partner_share = $partner_discount = 0;
        if ($trans->fleet_id) {
            $partner = Organization::where('id', $trans->fleet_id)->select('payment_share', 'extra_discount')->first();
            $partner_share = $partner->payment_share;
            $partner_discount = $partner->extra_discount;
        }

        if ($filter_flag) {
            $filter_cost = Vehicle::join('vehicle_models', 'vehicles.model', 'vehicle_models.id')
                ->where('vehicles.id', $trans->vehicle_id)
                ->pluck('vehicle_models.filter_price')->first();
        } else
            $filter_cost = 0;

        $payShare = PaymentShare::latest()->first();
        $admin_share = $payShare->admin_share;

        $markup_price = Deal::where('id', $trans->deal_id)->pluck('markup_price')->first();
        $coupon_savings = CouponLog::where('transaction_no', $trans->transaction_no)->pluck('savings')->first() ?? 0;

        // $joy_share = $admin_share - ($partner_share + $partner_discount);

        $location = Location::where('id', $trans->location_id)->first();
        $delar = Organization::where('id', $location->org_id)->first();
        $item = ItemMaster::where('id', $trans->item_id)->first();
        $offer = ItemOffer::where('id', $trans->offer_id)->first();
        $city = City::where('id', $location->city)->pluck('city')->first();

        $address = $location->street . ', ' . $city . ', ' . $location->district . ', ' . $location->zipcode . ', ' . $delar->email;

        $data = array(
            'transaction_no' => $trans->transaction_no,
            'price' => $trans->price,
            'discount' => $trans->discount,
            'vat' => $payShare->vat,
            'joy_share' => $admin_share,
            'pg_fee' => $payShare->pg_fee,
            'pg_share' => $payShare->pg_share,
            'partner_share' => $partner_share,
            'partner_discount' => $partner_discount,
            'service_cost' => $service_cost,
            'filter_cost' => $filter_cost,
            'markup_price' => $markup_price,
            'coupon_savings' => $coupon_savings,

            'item_name' => $item->title,
            'item_name_ar' => $item->title_ar,
            'dimensions' => $item->dimensions,
            'volt' => $item->volt,
            'ah' => $item->ah,
            'size' => $item->size,
            'height' => $item->height,
            'width' => $item->width,
            'item_description' => $item->description,
            'item_description_ar' => $item->description_ar,
            'thumbnail_url' => $item->thumbnail_url,

            'offer_name' => $offer->title,
            'offer_name_ar' => $offer->title_ar,
            'offer_description' => $offer->description,
            'offer_description_ar' => $offer->description_ar,
            'terms' => $offer->terms,
            'terms_ar' => $offer->terms_ar,
            'end_date' => $offer->end_date,
            'is_notify' => $offer->is_notify,
            'on_site' => $offer->on_site,

            'delar_name' => $delar->org_name,
            'delar_name_ar' => $delar->org_name_ar,
            'delar_address' => $address,
        );

        TransactionDetail::insert($data);

    }


    /**
     * update the payment status of transaction
     * Change the offer quantity on successful paymnets
     * Create Invoice no to the successful transaction
     * Send notitifaction to the consumer & technicians of purchased status
     *
     * @param  $transaction_no - To find the transaction
     * @param  $payment_no - To update the payment status to the transaction
     * @param  $isNotify - To validate the request was notified or not
     * @return true
     */
    public function update_payment_status($transaction_no, $payment_no, $request, $isNotify)
    {
        // Send email notification to purchased order
        try {
            event(new PurchasedAnOfferEmail($transaction_no));
        } catch (\Exception $e) {
            Log::info("Sent email for new purchased order failed");
            Log::error($e->getMessage());
        }

        $paymentData = Payment::where('payment_no', $payment_no)->first();

        // Send notification to consumer , deal admin
        try {
            event(new NewOrderPlaced($transaction_no, 27, $paymentData->amount_by_banking + $paymentData->amount_by_credits));
        } catch (\Exception $e) {
            Log::info("Sent firebase notification for new purchased order failed");
            Log::error($e->getMessage());
        }


        if ($isNotify) {
            try {
                event(new RequestOfferAvailability($transaction_no, 40, $paymentData->amount_by_banking + $paymentData->amount_by_credits));

            } catch (\Exception $e) {
                Log::info("Sent firebase notification for offer availability request");
                Log::error($e->getMessage());
            }
        }

        if ($request['deal_id'] == 6 || $request['deal_id'] == 2) // tires & battaries
            ItemMaster::where('id', $request['item_id'])
                ->update(['quantity' => DB::raw('quantity - ' . $request['quantity'])]);

        ItemOffer::where('id', $request['offer_id'])->where('item_id', $request['item_id'])
            ->update(['quantity' => DB::raw('quantity - ' . $request['quantity'])]);

        Payment::where('payment_no', $payment_no)
            ->update(['payment_status' => 'Successful', 'updated_at' => Date('Y-m-d H:i:s')]);

        $paymentStatus = 'Successful';
        if ($isNotify) {
            $paymentStatus = 'Requests';
        }

        $remarks = 'Payment processing was Successful';

        Transaction::where('transaction_no', $transaction_no)
            ->update(['payment_status' => $paymentStatus, 'updated_at' => Date('Y-m-d H:i:s'), 'remarks' => $remarks]);

        $this->update_transaction_invoice_no($transaction_no);
    }

    private function update_transaction_invoice_no($transaction_id){

        $successCount = Transaction::join('payments', 'payments.transaction_no', 'transactions.transaction_no')
            ->where('transactions.transaction_no', $transaction_id)
            ->whereIn('transactions.payment_status', ['Successful', 'Available'])
            ->where('payments.payment_status', 'Successful')
            ->where('payments.payment_type', '=', 1) // 1 - Main Payment
            ->whereNull('transactions.invoice_no')
            ->count();

        if(!$successCount) // Not Eligible for invoice
            return false;

        $successCount = Transaction::whereNotNull('invoice_no')->count();

        $invoiceNo = 100000000 + $successCount + 1;
        Transaction::where('transaction_no', $transaction_id)->update(['invoice_no' => $invoiceNo]);
        Payment::where('transaction_no', $transaction_id)
            ->where('payment_type', 1) // 1 - Main Payment
            ->update(['invoice_no' => $invoiceNo]);

        // Send Payment success alert
        (new SendPushNotification())->send_success_tran_alert($transaction_id);
    }


    function payPurchasedDeal($transactionNo){
        $tranData=Transaction::where('transaction_no', $transactionNo)->first();

        $tranArray['deal_id']=$tranData->deal_id;
        $tranArray['item_id']=$tranData->item_id;
        $tranArray['offer_id']=$tranData->offer_id;
        $tranArray['quantity']=$tranData->quantity;
        $tranArray['location_id']=$tranData->location_id;
        $tranArray['vehicle_id']=$tranData->vehicle_id;
        $tranArray['payment_with']=35;
        $tranArray['customer_id']=$tranData->created_by;
      
        $paymentData=Payment::where('transaction_no', $transactionNo)->orderBy('id','ASC')->first();

        

        if($paymentData->amount_by_banking>0){

            $transactionArray['payment_on']=$tranArray['payment_with'];
            $transactionArray['updated_at'] = Date('Y-m-d H:i:s');
            Payment::where('transaction_no', $transactionNo)
                    ->update($transactionArray);

            $purchasedAmount=$paymentData->amount_by_banking;

            $result=$this->createTabbySession($tranArray, $transactionNo, $tranData->id, $purchasedAmount);
            if($result['status']=='failed'){
                return response()->json([
                'status' => 'failed',
                'message' => $result['message'],
                ], 400);
            } else {
               $data['web_url']=$result['url'];
               return response()->json([
                'status' => 'success',
                'message' => 'Session created',
                'data' => $data,
                ], 200);
            }
        } else {
             return response()->json([
                'status' => 'failed',
                'message' => "This pending deal is not a banking type",
                ], 400);
        }
    }

    function createTabbySession($request, $transaction_no, $transactionId, $purchasedAmount){
        try{
            
            $url=env("TABBY_URL")."checkout";

            $customerId=isset($request['customer_id']) ? $request['customer_id'] : Auth::guard('driver')->id();
            $customerData=Driver::where('id', $customerId)->first();

           

            $ch = curl_init($url); // Will be provided by Tabby
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $headers=array(
                    'Content-Type: application/json',
                    'Authorization: Bearer '.env('TABBY_PUBLIC_KEY'));

            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $basketId=$transactionId;

            $buyerArray=array(
                  "phone"=>$customerData->contact_no,
                  "email"=>$customerData->email ? $customerData->email : 'card.success@tabby.ai',
                  "name"=>$customerData->first_name
            );
            if($customerData->dob){
                $buyerArray['dob']=$customerData->dob;
            }

            $paymentArray=array(
                "amount"=>$purchasedAmount,
                "currency"=>"SAR",
                "description"=>"Deal Purchase",
                "buyer"=>$buyerArray,
                "meta"=>array(
                      "order_id"=> $basketId, 
                      "customer"=>$customerId ,
                      "item_id"=> $request['item_id'],
                      "offer_id"=> $request['offer_id'],
                      "transaction_no" =>$transaction_no,
                      "deal_id"=>$request['deal_id']
                  )
            );

            $web_url=env('JOY_WEB_LOCAL');
            if(env('IS_TABBY_URL_TYPE')==1){
                $web_url=env('JOY_WEB_STAGING');
            } else if(env('IS_TABBY_URL_TYPE')==2){
                $web_url=env('JOY_WEB_MARKETING');
            } else if(env('IS_TABBY_URL_TYPE')==3){
                $web_url=env('JOY_WEB_LIVE');
            }

            $fields = array(
              "payment" => $paymentArray,
              "lang"=>"en",
              "merchant_code"=>"JoyApp",
              "merchant_urls"=>array(
                "success"=> $web_url."success_transaction/".$transaction_no,
                "cancel"=> $web_url."cancelled_transaction/".$transaction_no,
                "failure"=> $web_url."failed_transaction/".$transaction_no
              ),
              "create_token"=> false,
              "token"=> null        
            );
            $data = json_encode($fields);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
 
            curl_close($ch);
            $res=json_decode($response, true);

            if($res){
                if(!empty($res->status) && $res->status=='error'){
                   return [
                        'status'=>'failed',
                        'message'=> $data->error,
                    ];

                } else {
                    $s=$res['configuration']['available_products']['installments'];
                    $url=$s['0']['web_url'];
                    return ['status'=>'success','url'=>$url]; 
                }
            } else {
                return [
                    'status'=>'failed',
                    'message'=> 'Not yet captured',
                ];
            }

             
            
        } catch (\Exception $e){
            return ['status'=>'failed', 'message'=>$e->getMessage()];
        }
    }

    function createTabbySessionOld($request, $transaction_no, $transactionId, $purchasedAmount){
        try{
            
            $url=env("TABBY_URL")."checkout";

            $customerId=isset($request->customer_id) ? $request->customer_id : Auth::guard('driver')->id();
            $customerData=Driver::where('id', $customerId)->first();

            print_r($customerData);
            exit;

            $ch = curl_init($url); // Will be provided by Tabby
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $headers=array(
                    'Content-Type: application/json',
                    'Authorization: Bearer '.env('TABBY_PUBLIC_KEY'));

            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $basketId=$transactionId;

            $paymentArray=array(
                "amount"=>$purchasedAmount,
                "currency"=>"SAR",
                "description"=>"Deal Purchase",
                "buyer"=>array(
                  "phone"=>$customerData->contact_no,
                  "email"=>$customerData->email ? $customerData->email : 'card.success@tabby.ai',
                  "name"=>$customerData->first_name,
                  "dob"=>$customerData->dob ? $customerData->dob : ''
                ),
                "meta"=>array(
                      "order_id"=> $basketId, 
                      "customer"=>$customerId ,
                      "item_id"=> $request->item_id,
                      "offer_id"=> $request->item_id,
                      "transaction_no" =>$transaction_no,
                      "deal_id"=>$request->deal_id
                  )
            );

            $web_url=env('JOY_WEB_LOCAL');
            if(env('IS_TABBY_URL_TYPE')==1){
                $web_url=env('JOY_WEB_STAGING');
            } else if(env('IS_TABBY_URL_TYPE')==2){
                $web_url=env('JOY_WEB_MARKETING');
            } else if(env('IS_TABBY_URL_TYPE')==3){
                $web_url=env('JOY_WEB_LIVE');
            }

            $fields = array(
              "payment" => $paymentArray,
              "lang"=>"en",
              "merchant_code"=>"JoyApp",
              "merchant_urls"=>array(
                "success"=> $web_url."success_transaction/".$transaction_no,
                "cancel"=> $web_url."cancelled_transaction/".$transaction_no,
                "failure"=> $web_url."failed_transaction/".$transaction_no
              ),
              "create_token"=> false,
              "token"=> null        
            );
            $data = json_encode($fields);

            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);

            curl_close($ch);

            $res=json_decode($response, true);

            $s=$res['configuration']['available_products']['installments'];
            $url=$s['0']['web_url'];
            return ['status'=>'success','url'=>$url]; 
            
        } catch (\Exception $e){
            return ['status'=>'failed', 'message'=>$e->getMessage()];
        }
    }

    /**
     * Findout item requested quantity was available or not
     * Send notitifaction to the consumer on successful payment
     * @param  $offer_id - To find offer available quantity
     * @param  $quantity - Validate requested quantity with available quantity
     * @return Available or Not
     */
    private function available_quantity($request)
    {
        $quantity = ItemOffer::where('id', $request['offer_id'])
            ->where('item_id', $request['item_id'])->pluck('quantity')->first();

        if ($quantity >= $request['quantity'])
            return true;
        else
            return false;
    }

    /*
     * return Tabby create Session input data
     */
    public function get_tabbysession_input($request, $transaction_no, $transactionId, $purchasedAmount)
    {
        // TODO: Prepare Tabby create Session input data

        $url=env("TABBY_URL")."checkout";

        $customerId=isset($request['customer_id']) ? $request['customer_id'] : Auth::guard('driver')->id();
        $customerData=Driver::where('id', $customerId)->first();

        $ch = curl_init($url); // Will be provided by Tabby
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $headers=array(
            'Content-Type: application/json',
            'Authorization: Bearer '.env('TABBY_PUBLIC_KEY'));

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $basketId = $transactionId;

        $buyerArray=array(
            "phone"=>$customerData->contact_no,
            "email"=>$customerData->email,
            "name"=>$customerData->first_name
        );
        if($customerData->dob){
            $buyerArray['dob']=$customerData->dob;
        }

        $paymentArray=array(
            "amount"=> round($purchasedAmount, 2),
            "currency"=>"SAR",
            "description"=>"Deal Purchase",
            "buyer"=>$buyerArray,
            "meta"=>array(
                "order_id"=> $basketId,
                "customer"=>$customerId ,
                "item_id"=> $request['item_id'],
                "offer_id"=> $request['offer_id'],
                "transaction_no" =>$transaction_no,
                "deal_id"=>$request['deal_id']
            )
        );

        $web_url=env('JOY_WEB_LOCAL');
        if(env('IS_TABBY_URL_TYPE')==1){
            $web_url=env('JOY_WEB_STAGING');
        } else if(env('IS_TABBY_URL_TYPE')==2){
            $web_url=env('JOY_WEB_MARKETING');
        } else if(env('IS_TABBY_URL_TYPE')==3){
            $web_url=env('JOY_WEB_LIVE');
        }

        $fields = array(
            "payment" => $paymentArray,
            "lang"=>"en",
            "merchant_code"=>"JoyApp",
            "merchant_urls"=>array(
                "success"=> $web_url."success_transaction/".$transaction_no,
                "cancel"=> $web_url."cancelled_transaction/".$transaction_no,
                "failure"=> $web_url."failed_transaction/".$transaction_no
            ),
            "create_token"=> false,
            "token"=> null,
            "public_key" => env('TABBY_PUBLIC_KEY'),
        );

        return $fields;
    }

    public function captureTabbypayment($pay_id, $purchasedAmount, $action_code = 5){
        try{

            if($action_code == 5) // Capture Payment
                $url= 'https://api.tabby.ai/api/v1/payments/'.$pay_id.'/captures';
            else
                $url= 'https://api.tabby.ai/api/v1/payments/'.$pay_id.'/close';

            $ch = curl_init($url); // Will be provided by Tabby
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $headers=array(
                'Content-Type: application/json',
                'Authorization: Bearer '.env('TABBY_SECRET_KEY'));

            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $fields = array(
                "amount" => $purchasedAmount
            );
            $data = json_encode($fields);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);

            curl_close($ch);
            $res=json_decode($response, true);

            if($res){
                if(!empty($res->status) && $res->status=='error'){
                    return [
                        'status'=>'failed',
                        'message'=> $data->error,
                    ];
                } else {
                    return [
                        'status'=>'success',
                        'message'=> 'Amount was '.($action_code == 5 ? 'captured' : 'cancelled'),
                        'data' => $res
                    ];
                }
            } else {
                return [
                    'status'=>'failed',
                    'message'=> 'Not yet captured',
                ];
            }

        } catch (\Exception $e){
            return ['status'=>'failed', 'message'=>$e->getMessage()];
        }
    }

    /*
     * Access: admin, prefix: api
     * Reference function from send_refund: RefundController
     */
    public function refundTabbypayment($pay_id, $purchasedAmount){
        try{

            $url= 'https://api.tabby.ai/api/v1/payments/'.$pay_id.'/refunds';

            $ch = curl_init($url); // Will be provided by Tabby
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $headers=array(
                'Content-Type: application/json',
                'Authorization: Bearer '.env('TABBY_SECRET_KEY'));

            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $fields = array(
                "amount" => $purchasedAmount
            );
            $data = json_encode($fields);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);

            curl_close($ch);
            $res=json_decode($response, true);

            if($res){
                if(!empty($res->status) && $res->status=='error'){
                    return [
                        'status'=>'failed',
                        'message'=> $data->error,
                    ];
                } else {
                    return [
                        'status'=>'success',
                        'message'=> 'Amount was refunded',
                        'payment_status' => 'Successful',
                        'tranid' => $res->id,
                        'Response' => $res->status,
                        'data' => $res,
                    ];
                }
            } else {
                return [
                    'status'=>'failed',
                    'message'=> 'Not yet refunded',
                ];
            }

        } catch (\Exception $e){
            return ['status'=>'failed', 'message'=>$e->getMessage()];
        }
    }

}