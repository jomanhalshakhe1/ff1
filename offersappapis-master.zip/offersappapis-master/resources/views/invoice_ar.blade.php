<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Invoice</title>
        <style>
            body {
                /*font-family: 'examplefont', sans-serif;*/
                /*font: 400 15px/24px 'examplefont', sans-serif;*/
                font-family: "DejaVu Sans", sans-serif;
            }
            .invoice-header-section {
              min-height: 300px;
              background-color: #FFD58C;
              border-radius: 15px;
            }
            .logo-sectoin {
                padding-top: 20px;
            }
            h4 {
                user-select: auto;
                font-size: 20px;
                font-weight: 500;
                color: #666;
            }

            .invoice-middle-section {
                min-height: 300px;
                background-color: #fff;
            }
            .invoiceFor {
                background-color: #ffffff;
                width: 86%;
                justify-content: center;
                margin: auto;
                position: relative;
                min-height: 119px;
                border-radius: 21px;
                top: -27px;
                margin-top: -27px;
                box-shadow: 7px 6px 7px #f5f5f5;
            }
            .invo-title {
              text-transform: uppercase;
              font-size: 15px;
              padding: 7px 0px;
              color: #999;
            }
            .company-title {
              padding: 7px 0px;
              color: #999;
            }
            .bgColor {
              background-color: #f3f3f3;
              padding: 6px 10px 5px 0px;
              border-radius: 10px;
            }
            .invoiceaddressFor {
                width: 92%;
            }
                  
            .invoice-middle-content {
            }
            .productList {
                border-bottom: 1px solid #eee;

            }
            table th,  td {
                padding: 1em;
                border: 0px solid #f0f0f0 !important;
                align-content: center;
                padding: 7px 0px !important;
                font-size: 14px;
            }
            table tbody tr td {
                background-color: #fff !important;
                font-weight: 500;
                font-size: 16px;
            }
            .payment-cards {
                padding: 20px 0px;
                min-height: 300px;
            }
            .cards-section {
                min-height: 195px;
                background-color: #f1f1f1;
                border-radius: 15px;
            }
            .paydetails-section {
                width: 65%;
            }
            .transText {
                letter-spacing: 1px;
                user-select: auto;
                padding-left: 25px;
                color: #666;
                font-size: 13px;
                padding-bottom: 5px;
            }
            .transID {
                letter-spacing: 1px;
                user-select: auto;
                padding-left: 25px;
            }
            .discountDetails {

            }
            table th, td {
                padding: 1em;
                border: 0px solid #f0f0f0;
                align-content: center;
                padding: 7px 0px !important;
                font-size: 14px;
            }
            .invoice-footer-section {
                min-height: 80px;
                background-color: #fff;
                border-top: 0.1px solid #FFD58C;
            }
            .footer-content{
                padding-top: 20px;
                width: 90%;
                margin: auto;
            }
            .font-weight-500 {
                font-weight: 500 !important;
            }
            .font-weight-600 {
                font-weight: 600 !important;
            }
            .color-td {
                color: #999 !important;
            }
            .border-top-color {
                border-top: 2px solid #FFD58C;
            }
            .border-bottom-color {
                border-bottom: 2px solid #FFD58C;
            }

            .container{
                border: 1px solid #dbdbdb;
                box-shadow:0 5px 10px -0px #cbcbcb;
                width: 100%;
                margin: auto;
            }
            .row {
                display: flex;
                flex-wrap: wrap;
                margin-right: -15px;
                margin-left: -15px;
                text-align: right;
            }
            .pl-10{
                padding-left: 10px;
            }
            .pt-10{
                padding-top: 10px;
            }
            .pull-right{
                float: right;
            }
            .pull-left{
                float: left;
            }
            .pb-1, .py-1 {
                padding-bottom: 0.25rem !important;
            }
            .pt-1, .py-1 {
                padding-top: 0.25rem !important;
            }
            img {
                vertical-align: middle;
                border-style: none;
            }
            .p-5 {
                padding: 0.5rem 3rem 3rem 3rem !important;
            }
            .pt-3, .py-3 {
                padding-top: 1rem !important;
            }
            .pr-3, .px-3 {
                padding-right: 1rem !important;
            }
            .pl-3, .px-3 {
                padding-left: 1rem !important;
            }
            .pl-5, .px-5 {
                padding-left: 2rem !important;
            }
            .pl-12{
                padding-left: 1.2rem !important;
            }
            .pb-2, .py-2 {
                padding-bottom: 0.5rem !important;
            }
            .pt-2, .py-2 {
                padding-top: 0.5rem !important;
            }
            .invoicear-label{
                width: 30%;
                float: right;
            }
            .invoicear-span{
                /*width: 50%;*/
            }

        </style>
    </head>
    <body>
        <!--************* Start new invoice  ************************ -->
        <div class="container">
            <div class="row" style="margin-right: 0px; margin-left: 0px;">
                <div class="col-md-8" style="width:100%;">
                    <div class="invoice-header-section p-5">
                        <div class="row">
                            <div class="col-md-3 pull-right" style="width:100%;">
                                <div class="logo-sectoin pull-right invoicetext">
                                    <img src="{{ asset('assets/images/logo_black_new.png') }}" alt="Logo" style="height:50px;" />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3 pull-left" style="width:30%;">
                                <img width="150" height="150" src=https://chart.apis.google.com/chart?chs=150x150&cht=qr&chl={{$data->transaction_no ?? ''}} alt="{{$data->transaction_no ?? ''}}" />
                            </div>
                            <div class="col-md-9" style="width:70%;">
                                <h4>فاتورة</h4>
                                <div class="invoicetext">
                                    <div class="py-1">
                                        <span class="pl-3 invoicear-label"> ضريبة القيمة المضافة لا :</span>
                                        <span class="font-weight-500 invoicear-span">3140743534000387 </span>
                                    </div>
                                    <div class="py-1">
                                        <span class="pl-3 invoicear-label"> رقم الفاتورة :</span>
                                        <span class="font-weight-500 invoicear-span">{{substr($data->transaction_no, -9)}} </span>
                                    </div>
                                    <div class="py-1">
                                        <span class="pl-3 invoicear-label"> التاريخ والوقت :</span>
                                        <span class="font-weight-500 invoicear-span">{{$data->created_at ? date('d/m/Y, H:i a', strtotime($data->created_at)) : ''}} </span>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>

                    <div class="invoice-middle-section">

                        <div class="invoiceFor pl-12 py-2">
                            <div class="row">
                                <div class="col-md-6 p-2 pull-left" style="width:50%;">
                                    <div class="bgColor" style="width:90%; margin-left:8%;">
                                        <div class="company-title">معلومات الشركة</div>
                                        <div class="invoce-text-content pt-0">
                                            <div class="font-weight-600"> {{$data->item->delar->org_name_ar ?? ''}} </div>
                                            <div class="text-capitalize">
                                                {{$data->item->delar->location->address ?? ''}} 
                                                {{$data->item->delar->location->street ?? ''}}, 
                                                {{$data->item->delar->location->city ?? ''}}, 
                                                {{$data->item->delar->location->district ?? ''}}, 
                                                {{$data->item->delar->location->zipcode ?? ''}}
                                            </div>
                                            <div class="text-lowercase">{{$data->item->delar->email ?? ''}}</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6" style="width:50%;">
                                    <div class="invoiceaddressFor">
                                        <div class="invo-title">فاتورة</div>
                                        <div class="invoce-text-content pt-0">
                                            <div class="font-weight-600"> {{$data->driver->first_name ?? ''}}  </div>
                                            <div class="text-capitalize">{{$data->driver->contact_no ?? ''}}</div>
                                            <div class="text-lowercase">{{$data->driver->email ?? ''}}</div>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>

                        <div class="invoice-middle-content" style="width:90%; margin:auto;">
                            <div class="productList px-3">
                                <div class="items">
                                    <table width="98%" class="products" cellpadding="10" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <td class="text-left color-td">المجموع</td>
                                                <td class="text-left color-td">سعر</td>
                                                <td class="text-left color-td">الكمية.</td>
                                                <td class="text-left color-td">غرض</td>
                                            </tr>
                                        </thead>
                                        <tbody class="pt-3">
                                            <tr>
                                                <td width="20%" class="text-left">{{ number_format($data->price * $data->quantity, 2)}} SAR</td>
                                                <td width="30%" class="text-left">{{ number_format($data->price, 2) ?? ''}}</td>
                                                <td width="10%" class="text-left">{{$data->quantity ?? ''}}</td>
                                                <td width="50%" class="text-left">{{$data->item->title_ar ?? ''}}</td>
                                            </tr>
                                        </tbody>
                                      </table>
                                </div>
                            </div>

                            <div class="payment-cards" style="margin-bottom:50px;">
                                <div class="row px-3">
                                    <div class="col-md-5 pull-left" style="width: 50%;">
                                        <div class="discountDetails paydetails-section">
                                            <table width="100%" cellspacing="0">
                                                <tr>
                                                    <td width="50%" class="color-td">التسعير</td>
                                                    <td width="2%">  </td>
                                                    <td width="48%"></td>
                                                </tr>
                                                <tr>
                                                    <td width="45%" class="font-weight-500">{{ number_format($data->vat, 2)}} SAR</td>
                                                    <td width="2%" class="font-weight-500"> : </td>
                                                    <td width="53%" class="text-right color-td">ضريبة القيمة المضافة {{ round( ($data->vat / $data->final_price )*100 , 2 ) }} %</td>
                                                </tr>
                                                <tr>
                                                    <td width="50%" class="font-weight-500">{{ number_format(($data->price - $data->vat), 2)}} SAR</td>
                                                    <td width="2%" class="font-weight-500"> : </td>
                                                    <td width="47%" class="text-right color-td">سعر</td>
                                                </tr>
                                                <tr>
                                                    <td width="50%" class="font-weight-500">{{ number_format(($data->price - $data->final_price), 2) }} SAR</td>
                                                    <td width="2%" class="font-weight-500"> : </td>
                                                    <td width="47%" class="text-right color-td">خصم</td>
                                                </tr>
                                                <tr>
                                                    <td width="100%" class="text-right color-td" colspan="3"></td>
                                                </tr>
                                                <tr class="border-top-color" style="-webkit-box-shadow: 0px -2px 0px 0px rgba(255 213 140); -moz-box-shadow: 0px -2px 0px 0px rgba(255 213 140); box-shadow: 0px -2px 0px 0px rgba(255 213 140);">
                                                    <td width="50%" class="total font-weight-500 ">{{ number_format($data->final_price, 2) ?? ''}} SAR</td>
                                                    <td width="2%" class="font-weight-500"> : </td>
                                                    <td width="47%" class="total font-weight-500">المجموع</td>
                                                </tr>
                                          </table>
                                        </div>
                                    </div>

                                    <div class="col-md-7" style="width: 50%;">
                                        <div class="cards-section pr-3 pb-2">
                                            <div>
                                                @if(isset($data->payment_with) && $data->payment_with == 12)
                                                    <img src="{{ asset('assets/images/googlepay.png') }}" style="height:20px; padding:25px 5px 15px 25px;">
                                                @elseif(isset($data->payment_with) && $data->payment_with == 11)
                                                    <img src="{{ asset('assets/images/applepay.png') }}" style="height:20px; padding:25px 5px 25px 25px;">
                                                @elseif(isset($data->payment_with) && $data->payment_with == 7)
                                                    <img src="{{ asset('assets/images/walletpay.png') }}" style="height:30px; padding:25px 5px 15px 25px;">
                                                @else
                                                    <img src="{{ asset('assets/images/googlepay.png') }}" style="height:25px; padding:25px 5px 15px 25px;">
                                                @endif                                                
                                            </div>
                                            <div class="transText">رقم المعاملة :</div>
                                            <div class="transID">{{$data->transaction_no ?? ''}}</div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="invoice-footer-section">
                        <div class="footer-content">
                            <div class="row">
                                <div class="col-md-3 pull-left" style="width:30%;text-align:center;">
                                    <div class="email">help@innvohub.com</div>        
                                    <div class="email">www.innvohub.com</div>
                                </div>
                                <div class="col-md-9 pull-right" style="width:65%;">
                                    <img src="{{ asset('assets/images/logo_black_new.png') }}" style="height:50px;">
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!--************* END new invoice  ************************ -->
    </body>
</html>