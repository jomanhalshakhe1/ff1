<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Invoice</title>
        <style>
            body {
                /*font: 400 15px/24px Roboto,Helvetica Neue,sans-serif;*/
                font-family: "DejaVu Sans", sans-serif;
            }
            @page { margin:0px;footer: page-footer; }



            footer {
                position: fixed;
                bottom: -60px;
                left: 0px;
                right: 0px;
                height: 50px;
                font-size: 20px !important;

                text-align: center;
                line-height: 35px;
            }

            .border-bottom{
                border-bottom:1px solid #BFBFBF;
            }

            .footerinfo{
                padding: 10 0px!important;
                margin: 0px 40px;
                border-top: 0.1px solid #FCBC7C;
            }

            .footer-section{
                margin: 0 25px;
                border-top: 0.1px solid #FCBC7C;
            }

            .footerlogo
            {
                width:65%;
                float: left;
                text-align: left;
                vertical-align: middle;
            }

             .footerlogo img
            {
                width: 100px;

            }
            .footersupport{
                width:35%;
                text-align:right;
                float: left;
                color: #999 !important;
                font-size:34px;
            }



            .invoice-header-section {
              min-height: 380px;
              background-color: #243B61;
              border-radius: 15px;
            }
            .logo-sectoin {
                padding-top: 20px;
            }
            .logo-sectoin img{
               width: 80px;
               height: 60px;
            }
            h4 {
                user-select: auto;
                font-size: 16px;
                font-weight: 500;
                /*color: #666;
                */
               color: rgba(238, 238, 238, 0.8);
            }
            .invoice-h4 {
                user-select: auto;
                font-size: 20px;
                font-weight: 500;
                margin-top: 40px;
                color: rgba(235, 242, 255, 0.24);
            }

            .invoice-middle-section {
                min-height: 300px;
                background-color: #f5f5f5;
            }
            .invoiceFor {
                /*background-color: #ffffff;*/
                width: 88%;
                justify-content: center;
                margin: auto;
                position: relative;
                min-height: 119px;
                /*border-radius: 21px;*/
                border-bottom-left-radius: 21px;
                border-bottom-right-radius: 21px;
                border-top-left-radius: 0;
                border-top-right-radius: 0;
                top: -41px;
                border:1px solid #fff;
                box-shadow: 0px #f5f5f5;
            }
            .invo-title {
              text-transform: uppercase;
              font-size: 15px;
              padding: 7px 0px;
              color: #999;
            }
            .company-title {
              padding: 7px 0px;
              color: #999;
            }
            .bgColor {
              background-color: #f3f3f3;
              /*width: 92%;*/
              padding: 6px 5px 5px 11px;
              /*border-radius: 10px;*/
            }
            .title-white{
                color:#fff;
            }

            .invoice-middle-content {
            }
            .productList {
                border-bottom: 1px solid #eee;

            }
            table th,  td {
                padding: 1em;
                border: 0px solid #f0f0f0 !important;
                align-content: center;
                padding: 7px 0px !important;
                font-size: 14px;
            }
            table tbody tr td {
                /*background-color: #fff !important;*/
                font-weight: 500;
                font-size: 16px;
            }
            .payment-cards {
                padding: 20px 0px;
                min-height: 300px;
            }
            .cards-section {
                min-height: 195px;
                background-color: #f1f1f1;
                border-radius: 15px;
                width: 90%;
            }
            .transText {
                letter-spacing: 1px;
                user-select: auto;
                padding-left: 25px;
                color: #666;
                font-size: 13px;
                padding-bottom: 5px;
            }
            .transID {
                letter-spacing: 1px;
                user-select: auto;
                padding-left: 25px;
            }
            .discountDetails {

            }
            table th, td {
                padding: 1em;
                border: 0px solid #f0f0f0;
                align-content: center;
                padding: 7px 0px !important;
                font-size: 14px;
            }
            .invoice-footer-section {
                // min-height: 80px;
                background-color: #fff;
                border-top: 0.1px solid #FCBC7C;
                width: 100%;
                text-align: center;
            }
            .footer-content{
                height: 60px;
                /*padding-top: 20px;*/
                padding-top: 10px;
                width: 90%;
                margin: auto;
            }
            .font-weight-500 {
                font-weight: 500 !important;
            }
            .font-weight-600 {
                font-weight: 600 !important;
            }
            .color-td {
                color: #999 !important;
            }
            .border-top-color {
                border-top: 2px solid #FCBC7C;
            }
            .border-bottom-color {
                border-bottom: 2px solid #FCBC7C;
            }

            .container{
                border: 1px solid #dbdbdb;border-bottom: 0;
                /*box-shadow:0 5px 10px -0px #cbcbcb;*/
                width: 100%;
                margin: auto;
            }
            .row {
                display: flex;
                flex-wrap: wrap;
                margin-right: -15px;
                margin-left: -15px;
            }
            .pl-10{
                padding-left: 10px;
            }
            .pt-10{
                padding-top: 10px;
            }
            .pull-right{
                float: right;
            }
            .pb-1, .py-1 {
                padding-bottom: 0.25rem !important;
            }
            .pt-1, .py-1 {
                padding-top: 0.25rem !important;
            }
            img {
                vertical-align: middle;
                border-style: none;
            }
            .p-5 {
                /*padding: 0.5rem 3rem 3rem 3rem !important;*/
                padding-top: 0.5rem !important;
                padding-left: 3rem !important;
                padding-right: 3rem !important;
            }
            .pt-3, .py-3 {
                padding-top: 1rem !important;
            }
            .pr-3, .px-3 {
                padding-right: 1rem !important;
            }
            .pl-3, .px-3 {
                padding-left: 1rem !important;
            }
            .pl-5, .px-5 {
                padding-left: 2rem !important;
            }
            .pb-2, .py-2 {
                padding-bottom: 0.5rem !important;
            }
            .pt-2, .py-2 {
                padding-top: 0.5rem !important;
            }
            .pull-left{
                float: left;
            }
            .text-left{
                text-align: left;
            }
            .text-center{
                text-align: center;
            }
            .text-right{
                text-align: right;
            }
            .qrcode{
                /*border:2px dashed #000;
                border-radius: 20px;*/
            }
            .bgColor-title{
                border-radius:0px;
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
                margin-left:0px;
                margin-top:10px;
                background-color: #f3f3f3;
                width: 92%;
                padding-left: 10px;
            }
            .bgBorder{
                border-bottom-left-radius: 10px;
                border-bottom-right-radius: 10px;
            }
            .invoicetitles {
                width:95.8%;
                background-color:#f8f8f8;
                border-top-left-radius: 21px;
                border-top-right-radius: 21px;
                margin:auto;
                margin-left:2%;
                margin-right:1.8%;
            }
            .qrdiv1 {
                position: absolute;
                /*background-color: #FCBC7C;*/
                border: 1px solid #000;
                border-radius: 20px;
                height: 148px;
                width: 148px;
            }

            .qrdiv2 {
                position: relative;
                /*background-color: #ffffff;*/
                border-radius: 30px;
                top: -1px;
                left: -1px;
            }

            .general-title{
                font-family: 'Poppins';
                font-style: normal;
                font-weight: 300;
                font-size: 13px;
                line-height: 22px;
                /* or 169% */

                letter-spacing: 0.01em;

                /* grysl */

                color: #707070;
            }

            /* Onsite */

            .framelayout{

            /* Auto layout */

            display: flex;
            flex-direction: table;
            justify-content: center;
            align-items: center;
            padding: 3px 6px;


            width: 77px;
            height: 24px;
            left: 20px;


            background: transparent;
            border: 1px solid #FFC27C;
            box-sizing: border-box;
            border-radius: 6px;
            }


            .framelayout img{
              transform: matrix(-1, 0, 0, 1, 0, 0);
            }


            .onsite
            {
              position: static;
              width: 43px;
              height: 18px;
              left: 28px;
              top: 5px;

              font-family: 'Poppins';
              font-style: normal;
              font-weight: 400;
              font-size: 12px;
              line-height: 19px;
              /* identical to box height */


              color: #FFC27C;

            }

            .localshipping{
              position: static;
              width: 18px;
              height: 18px;
              left: 24px;
              top: 3px;

              transform: matrix(-1, 0, 0, 1, 0, 0);

              /* Inside auto layout */

              flex: none;
              order: 0;
              flex-grow: 0;
              margin: 0px 4px;

            }
            .invoiceinfo-heading{
                font-family: 'Poppins';
                font-style: normal;
                font-weight: 400;
                font-size: 14px;
                line-height: 21px;
                /* identical to box height */


                /* grysl */
                padding: 15px 0px 7px 0px !important;
                border-right:0.5px solid #BFBFBF;
                border-bottom:0.5px solid #BFBFBF;
                color: #707070;
            }
            .invoiceinfo-price{
                font-family: 'Poppins';
                font-style: normal;
                font-weight: 500;
                font-size: 14px;
                line-height: 21px;
                border-bottom:0.5px solid #BFBFBF;
                /* identical to box height */


                /* Semi dark */
                padding-left: 10px;
                color: #393E46;
            }
            .total-price{
                font-family: 'Poppins';
                font-style: normal;
                font-weight: 500;
                font-size: 14px;
                line-height: 21px;
                padding-left: 10px;
                color: #393E46;
            }

            .total{
                font-family: 'Poppins';
                font-style: normal;
                font-weight: 600;
                font-size: 14px;
                line-height: 21px;
                /* identical to box height */
                 padding: 15px 0px 7px 0px !important;
                 border-right:0.5px solid #BFBFBF;
                /* Dark */

                color: #222831;
            }
            .generalinfo{
                font-family: 'Poppins';
            font-style: normal;
            font-weight: 400;
            font-size: 14px;
            line-height: 21px;
            /* identical to box height */
            padding: 20px 60px;

            /* Semi dark */

            color: #393E46;

        } 
        .deductions{
            margin-left: 25px;
            left: 20px;
            color: #393E46;
            line-height: 30px;
        }
        .deductions-amount {
            color: #393E46;
            top: 15px;
        }
        .generalinfo span{
              font-family: 'Poppins';
                font-style: normal;
                font-weight: 600;
                font-size: 14px;
                line-height: 21px;
                text-decoration: underline;
                color: #222831;
        }
        </style>
    </head>
    <body>
        <!--************* Start new invoice  ************************ -->
        <div class="container">
            <div class="row" style="margin-right: 0px; margin-left: 0px;">
                <div class="col-md-8" style="width:100%;background-color: #f5f5f5;height: 100%;">
                    <div class="invoice-header-section p-5">
                        <div class="row" style="width:100%;">
                            <div class="col-md-4 pull-left" style="width:45%;">
                                <div class="logo-sectoin">
                                    <img src="{{ asset('assets/images/partner_logo.png') }}" alt="Logo" style="width: 80px;height: 60px;" />
                                </div>
                            </div>
                            <div class="col-md-8 pull-right" style="width:55%;">
                                <div class="logo-sectoin text-right invoicetext">
                                    
                                    <div class="py-1">
                                        <span class="pl-3 invoice-h4"> INVOICE</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row" style="width:100%;">
                            <div class="col-md-6 pull-left" style="width:50%;">
                                <h4>Joy for Business Services Co.</h4>
                            </div>
                        </div>
                        <div class="row" style="width:100%;">
                            <div class="col-md-6 pull-left" style="width:50%;">
                               
                                <div class="invoicetext">
                                    <table width="100%" cellspacing="0" >
                                        <tr>
                                            <td width="22%"> <h4>Address :</h4></td>
                                            <td width="40%" class="font-weight-600 title-white"> {{$locationData->street." ".$locationData->district." ".$locationData->address}}
                                              <br>  {{$locationData->city."- ".$locationData->zipcode}} </td>
                                        </tr>
                                        <tr>
                                            <td width="22%"> <h4>Bill To: </h4></td>
                                            <td width="40%" class="font-weight-600 title-white">{{$orgData->org_name}} </td>
                                        </tr>
                                        <tr>
                                            <td width="22%"> <h4>Client VAT: </h4></td>
                                            <td width="40%" class="font-weight-600 title-white"> {{$orgData->vat_no}} </td>
                                        </tr>
                                        
                                        
                                    </table>
                                </div>
                            </div>
                            <div class="col-md-6" style="width:50%;">
                               <div class="invoicetext">
                                    <table width="100%" cellspacing="0" >
                                         <tr>
                                            <td width="22%" style="vertical-align: top;display: table-cell;top:0px"> <h4>Credit Note:</h4></td>
                                            <td width="40%" class="font-weight-600 title-white"> {{$invoiceNo}} </td>
                                        </tr>
                                        <tr>
                                            <td width="22%"> <h4>VAT: </h4></td>
                                            <td width="40%" class="font-weight-600 title-white">{{$innvohubOrgData->vat_no}}</td>
                                        </tr>
                                         <tr>
                                            <td width="22%"> <h4>Invoice Date: </h4></td>
                                            <td width="40%" class="font-weight-600 title-white">{{date("dS M, Y h:i A")}}</td>
                                        </tr>
                                        <tr>
                                            <td width="22%"> <h4>For: </h4></td>
                                            <td width="40%" class="font-weight-600 title-white">Joy Application Services’ Sales </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>

                         <div class="row">
                            <div class="col-md-12"  >
                               <hr>

                               <table width="100%" cellspacing="0" style="width:600px;padding-left: 150px;margin-bottom: 30px;" >

                                       @if($from_date!='' && $to_date!="")
                                       <tr>
                                            <td width="35%" class="font-weight-600 title-white">Sales Start Date :</td>
                                            <td width="16%" class="font-weight-600 title-white">{{date('d/m/Y', strtotime($from_date))}}</td>
                                            <td style="width: 30px;"></td>
                                             <td width="30%" class="font-weight-600 title-white">Sales End Date :</td>
                                            <td width="20%" class="font-weight-600 title-white"> {{date('d/m/Y', strtotime($to_date))}}</td>
                                        </tr>
                                       @elseif($from_date!='' && $to_date=="")
                                       <tr>
                                             <td width="35%" class="font-weight-600 title-white">Sales Start Date :</td>
                                            <td width="16%" class="font-weight-600 title-white">{{date('d/m/Y', strtotime($from_date))}}</td>
                                             
                                        </tr>
                                        @elseif($from_date=='' && $to_date!="")
                                       <tr>
                                          
                                            <td style="width: 30px;"></td>
                                             <td width="30%" class="font-weight-600 title-white">Sales End Date :</td>
                                            <td width="20%" class="font-weight-600 title-white"> {{date('d/m/Y', strtotime($to_date))}}</td>
                                        </tr>
                                       @endif
                                    </table>

                            </div>
                        </div>


                        <div class="row">
                            <div class="invoicetitles col-md-12"  style="background-color: #fff;" >
                             

                                 <table width="100%" cellspacing="0" style="border-bottom: 1px solid #BFBFBF;margin: 0px 10px;"  >
                                       <tr class="border-bottom">
                                            <td class="invo-title" width="70%" style="padding: 15px 1px 7px 0px !important;border-right:0.5px solid #BFBFBF;" >Description</td>
                                            <td width="30%" style="padding-left: 10px;" class="invo-title">Amount </td>
                                           
                                        </tr>
                                     
                                    </table>
                               
                            </div>
                        </div>

                    </div>
                    <div >
                    <div class="invoice-middle-section" style="width:100%;">
                        <div class="invoiceFor">
                            <div style="width:100%; display: flex; flex-wrap: wrap;background-color: #fff">
                                
                                 <table width="100%" cellspacing="0" style="margin: 0px 10px;"  >
                                       <tr class="border-bottom"  style="border-bottom: 1px solid #BFBFBF" >
                                            <td class="invoiceinfo-heading" width="70%" >No. of Transactions</td>
                                            <td width="30%" class="invoiceinfo-price">{{$totalTransactions}} </td>
                                           
                                        </tr>
                                       <tr class="border-bottom"  style="border-bottom: 1px solid #BFBFBF" >
                                            <td  class="invoiceinfo-heading" width="70%" >Total Sales</td>
                                            <td width="30%" class="invoiceinfo-price"> {{$totalSales}} </td>
                                           
                                        </tr>
                                        <tr class="border-bottom">
                                            <td  class="invoiceinfo-heading" width="70%" >Deductions
                                            
                                                <table>
                                                    <tr><td width="70%"><ul class="deductions">
                                                    <li>Commission without VAT </li></ul> </td></tr>
                                                    <tr><td><ul class="deductions">
                                                    
                                                    <li>VAT</li>
                                                    
                                                </ul></td></tr>
                                                    <tr><td><ul class="deductions">
                                                  
                                                    <li>Payment Gateway Fees</li>
                                                </ul></td></tr>
                                                </table>

                                            </td>

                                            <td class="invoiceinfo-price" width="30%" >
                                                <div style="height: 100px">&nbsp;</div>
                                                <table>
                                                    <tr><td style="padding:5px 10px 10px 0;" class="deductions-amount">{{number_format($totalWithOutVat,2)}} SAR</td></tr>
                                                    <tr><td style="padding:5px 10px 10px 0;" class="deductions-amount">{{number_format($totalWithVat-$totalWithOutVat,2)}} SAR</td></tr>
                                                    <tr><td style="padding:5px 10px 0px 0;" class="deductions-amount">-{{number_format($totalPgShare,2)}} SAR</td></tr>
                                                </table>

                                            </td>
                                           
                                        </tr>

                                        
                                        
                                        <tr>
                                            <td class="total" >Total Credits</td>
                                            <td width="30%" class="total-price"> {{number_format($totalWithVat-$totalPgShare,2)}} SAR </td>
                                        </tr>
                                    </table>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="general-title" style="padding: 20px 60px;">This is a system generated report as is considered signed and stamped by Joy for Business Services Company. C.R. 4030436161</div>
                <div style="width: 90%; display: table;padding-top: 30px;">
                <div style="width: 80%;float: left;">
                <div class="total" style="padding: 0px 60px;border-right:0px; ">Thank you for your Business!

                </div>
                <div class="generalinfo">For any requirements, Please contact us on: <span>Finance@JoyApp.io</span></div>
            </div>
            <div style="width: 20%;float: left;top:-120px;position: absolute;">
                     <img src="{{$qr_image}}" style="float: right" alt="Logo" /></div>
        </div>
            </div>
            </div>
        </div>
        <!--************* END new invoice  ************************ -->


        
    </body>
</html>


