<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Invoice</title>
    <style>
        body {
            /*font: 400 15px/24px Roboto,Helvetica Neue,sans-serif;*/
            font-family: "DejaVu Sans", sans-serif;
        }
        @page { margin:0px; }
        .invoice-header-section {
            min-height: 380px;
            background-color: #FCBC7C;
            border-radius: 15px;
        }
        .logo-sectoin {
            padding-top: 20px;
        }
        h4 {
            user-select: auto;
            font-size: 20px;
            font-weight: 500;
            color: #666;
        }

        .invoice-middle-section {
            min-height: 300px;
            background-color: #fff;
        }
        .invoiceFor {
            background-color: #ffffff;
            width: 84%;
            justify-content: center;
            margin: auto;
            position: relative;
            min-height: 119px;
            border-radius: 21px;
            top: -40px;
            box-shadow: 7px 6px 7px #f5f5f5;
        }
        .invo-title {
            text-transform: uppercase;
            font-size: 15px;
            padding: 7px 0px;
            color: #999;
        }
        .company-title {
            padding: 7px 0px;
            color: #999;
        }
        .bgColor {
            background-color: #f3f3f3;
            /*width: 92%;*/
            padding: 6px 5px 5px 11px;
            /*border-radius: 10px;*/
        }

        .invoice-middle-content {
        }
        .productList {
            border-bottom: 1px solid #eee;

        }
        table th,  td {
            padding: 1em;
            border: 0px solid #f0f0f0 !important;
            align-content: center;
            padding: 7px 0px !important;
            font-size: 14px;
        }
        table tbody tr td {
            /*background-color: #fff !important;*/
            font-weight: 500;
            font-size: 16px;
        }
        .payment-cards {
            padding: 20px 0px;
            min-height: 300px;
        }
        .cards-section {
            min-height: 195px;
            background-color: #f1f1f1;
            border-radius: 15px;
            width: 90%;
        }
        .transText {
            letter-spacing: 1px;
            user-select: auto;
            padding-left: 25px;
            color: #666;
            font-size: 13px;
            padding-bottom: 5px;
        }
        .transID {
            letter-spacing: 1px;
            user-select: auto;
            padding-left: 25px;
        }
        .discountDetails {

        }
        table th, td {
            padding: 1em;
            border: 0px solid #f0f0f0;
            align-content: center;
            padding: 7px 0px !important;
            font-size: 14px;
        }
        .invoice-footer-section {
        // min-height: 80px;
            background-color: #fff;
            border-top: 0.1px solid #FCBC7C;
            width: 100%;
            text-align: center;
        }
        .footer-content{
            height: 60px;
            /*padding-top: 20px;*/
            padding-top: 10px;
            width: 90%;
            margin: auto;
        }
        .font-weight-500 {
            font-weight: 500 !important;
        }
        .font-weight-600 {
            font-weight: 600 !important;
        }
        .color-td {
            color: #999 !important;
        }
        .border-top-color {
            border-top: 2px solid #FCBC7C;
        }
        .border-bottom-color {
            border-bottom: 2px solid #FCBC7C;
        }

        .container{
            border: 1px solid #dbdbdb;
            box-shadow:0 5px 10px -0px #cbcbcb;
            width: 100%;
            margin: auto;
        }
        .row {
            display: flex;
            flex-wrap: wrap;
            margin-right: -15px;
            margin-left: -15px;
        }
        .pl-10{
            padding-left: 10px;
        }
        .pt-10{
            padding-top: 10px;
        }
        .pull-right{
            float: right;
        }
        .pb-1, .py-1 {
            padding-bottom: 0.25rem !important;
        }
        .pt-1, .py-1 {
            padding-top: 0.25rem !important;
        }
        img {
            vertical-align: middle;
            border-style: none;
        }
        .p-5 {
            /*padding: 0.5rem 3rem 3rem 3rem !important;*/
            padding-top: 0.5rem !important;
            padding-left: 3rem !important;
            padding-right: 3rem !important;
        }
        .pt-3, .py-3 {
            padding-top: 1rem !important;
        }
        .pr-3, .px-3 {
            padding-right: 1rem !important;
        }
        .pl-3, .px-3 {
            padding-left: 1rem !important;
        }
        .pl-5, .px-5 {
            padding-left: 2rem !important;
        }
        .pb-2, .py-2 {
            padding-bottom: 0.5rem !important;
        }
        .pt-2, .py-2 {
            padding-top: 0.5rem !important;
        }
        .pull-left{
            float: left;
        }
        .text-left{
            text-align: left;
        }
        .text-center{
            text-align: center;
        }
        .text-right{
            text-align: right;
        }
        .qrcode{
            /*border:2px dashed #000;
            border-radius: 20px;*/
        }
        .bgColor-title{
            border-radius:0px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            margin-left:0px;
            margin-top:10px;
            background-color: #f3f3f3;
            width: 92%;
            padding-left: 10px;
        }
        .bgBorder{
            border-bottom-left-radius: 10px;
            border-bottom-right-radius: 10px;
        }
        .invoicetitles {
            width:96%;
            background-color:#FFF;
            border-top-left-radius: 21px;
            border-top-right-radius: 21px;
            margin:auto;
            margin-left:2%;
            margin-right:2%;
        }
        .qrdiv1 {
            position: absolute;
            background-color: #FCBC7C;
            border: 1px solid #000;
            border-radius: 20px;
            height: 148px;
            width: 148px;
        }

        .qrdiv2 {
            position: relative;
            background-color: #ffffff;
            border-radius: 30px;
            top: -1px;
            left: -1px;
        }
    </style>
</head>
<body>
<!--************* Start new invoice  ************************ -->
<div class="container">
    <div class="row" style="margin-right: 0px; margin-left: 0px;">
        <div class="col-md-8" style="width:100%;">
            <div class="invoice-header-section p-5">
                <div class="row" style="width:100%;">
                    <div class="col-md-4 pull-left" style="width:45%;">
                        <div class="logo-sectoin">
                            <img src="{{ asset('assets/images/joy_logo_black.png') }}" alt="Logo" style="height:50px;" />
                        </div>
                    </div>
                    <div class="col-md-8 pull-right" style="width:55%;">
                        <div class="logo-sectoin text-right invoicetext">
                            <div class="py-1">
                                <span class="pl-3"> شركة جوي لخدمات الأعمال </span>
                            </div>
                            <div class="py-1">
                                <span class="pl-3"> Joy for Business Services Company</span>
                            </div>
                            <div class="py-1">
                                <span class="pl-3"> جدة - حي السلامة </span>
                            </div>
                            <div class="py-1">
                                <span class="pl-3"> Jeddah - As salamah District </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row" style="width:100%;">
                    <div class="col-md-9 pull-left" style="width:75%;">
                        <h4>Invoice | فاتورة </h4>
                        <div class="invoicetext">
                            <table width="100%" cellspacing="0" style="background-color: #FCBC7C !important;">
                                <tr>
                                    <td width="22%">VAT No.</td>
                                    <td width="3%">|</td>
                                    <td width="30%"> الرقم الضريبي </td>
                                    <td width="40%" class="font-weight-600"> 3140743534000387 </td>
                                </tr>
                                <tr>
                                    <td width="22%">Invoice No.</td>
                                    <td width="3%">|</td>
                                    <td width="30%"> رقم الفاتورة </td>
                                    <td width="40%" class="font-weight-600"> {{$data->invoice_no}} </td>
                                </tr>
                                <tr>
                                    <td width="22%">Date & Time</td>
                                    <td width="3%">|</td>
                                    <td width="30%"> التاريخ والوقت </td>
                                    <td width="40%" class="font-weight-600"> {{$data->created_at ? date('d/m/Y, H:ia', strtotime($data->created_at)) : ''}} </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="col-md-3 pull-right" style="width:24%;">
                    <!-- <img width="150" height="150" src=https://chart.apis.google.com/chart?chs=150x150&cht=qr&chl={{$data->transaction_no ?? ''}} alt="{{$data->transaction_no ?? ''}}" /> -->
                        <div class="qrdiv1">
                            <img width="150" height="150" src=https://image-charts.com/chart?chs=150x150&cht=qr&chl={{ $data->scan_url ?? ''}}&icqrb=FCBC7C alt="{{$data->transaction_no ?? ''}}" class="qrdiv2"/>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="invoicetitles col-md-12">
                        <div class="col-md-6 pull-left" style="width:50%;">
                            <div class="invo-title" style="padding: 15px 0px 7px 15px !important;"> Invoice For | فاتورة</div>
                        </div>
                        <div class="col-md-6 pull-right" style="width:50%;">
                            <div class="bgColor-title pull-left">
                                <div class="company-title"> Service Provider | مقدم الخدمة </div>
                            </div>
                        </div>
                        <!-- <div class="col-md-6 pull-right" style="border-top-left-radius: 21px; border-top-right-radius: 21px; background-color: #f3f3f3; width:48%; margin-top:7px; margin-left:1%;">
                            <div class="company-title" style="padding: 6px 0px 5px 11px;">Company Info <br> معلومات الشركة </div>
                        </div> -->
                    </div>
                </div>

            </div>

            <div class="invoice-middle-section" style="width:100%;">
                <div class="invoiceFor" style="padding: 0rem 1rem 1rem 1rem;">
                    <div class="" style="width:100%; display: flex; flex-wrap: wrap;">
                        <div class="col-md-6 pull-left" style="width:50%;">
                            <!-- <div class="invo-title">Invoice For <br> فاتورة</div> -->
                            <!-- <div class="" style="padding-bottom:5px;"> فاتورة</div> -->
                            <div class="invoce-text-content">
                                <div class="font-weight-600">
                                    {{$data->driver->first_name ?? ''}} {{$data->driver->last_name ?? ''}}
                                </div>
                            <!--
                                        <div class="text-capitalize color-td">{{$data->driver->contact_no ?? ''}}</div>
                                        <div class="text-lowercase color-td">{{$data->driver->email ?? ''}}</div>
                                        -->
                            </div>
                        </div>
                        <div class="col-md-6 p-2 pull-right" style="width:50%;">
                            <div class="bgColor bgBorder">
                                <!-- <div class="company-title">Company Info <br> معلومات الشركة </div> -->
                                <!-- <div class="" style="padding-bottom:5px;"> معلومات الشركة </div> -->
                                <div class="invoce-text-content">
                                    <div class="font-weight-600">
                                    {{$data->item->delar->org_name ?? ''}}
                                    @if(isset($data->item->delar->org_name_ar))
                                        <!--  | {{$data->item->delar->org_name_ar ?? ''}} -->
                                        @endif
                                    </div>
                                <!-- <div class="text-capitalize">{{$data->item->delar->phone ?? ''}}</div> -->
                                    <div class="text-capitalize color-td">
                                        {{$data->item->delar->location->address ?? ''}}
                                        {{$data->item->delar->location->street ?? ''}},
                                        {{$data->item->delar->location->city ?? ''}},
                                        {{$data->item->delar->location->district ?? ''}},
                                        {{$data->item->delar->location->zipcode ?? ''}}
                                    </div>
                                    <div class="text-lowercase">{{$data->item->delar->email ?? ''}}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="invoice-middle-content pt-3" style="width:90%; margin:auto;">
                    <div class="productList px-3">
                        <div class="items">
                            <table width="98%" class="products" cellpadding="10" cellspacing="0">
                                <thead>
                                <tr>
                                    <td class="text-left color-td">Item | غرض </td>
                                    <td class="text-right color-td">Qty. | الكمية </td>
                                    <td class="text-right color-td">Price | سعر </td>
                                    <!-- <td class="text-left color-td">Total / المجموع </td> -->
                                </tr>
                                </thead>
                                <tbody class="pt-3">
                                <tr>
                                    <td width="50%" class="text-left">
                                        {{$data->item->title ?? ''}}
                                        @if(isset($data->item->title_ar))
                                            | {{$data->item->title_ar ?? ''}}
                                        @endif
                                    </td>
                                    <td width="20%" class="text-right">{{$data->quantity ?? ''}}</td>
                                    <td width="30%" class="text-right">{{ number_format($data->price, 2) ?? ''}} sr</td>
                                </tr>

                                @if($data->filter_cost >0)
                                    <tr>
                                        <td width="50%" class="text-left">
                                            Filter Cost | متكلفة الفلتر
                                        </td>
                                        <td width="20%" class="text-right">1</td>
                                        <td width="30%" class="text-right">{{ number_format($data->filter_cost, 2) ?? ''}} SAR</td>
                                    </tr>
                                @endif

                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="payment-cards">
                        <div class="row px-3">
                            <div class="col-md-7 pull-left" style="width: 55%;">
                                <div class="cards-section pb-2">
                                    <div>
                                        @if(isset($data->payment_with) && $data->payment_with == 34)
                                            <img src="{{ asset('assets/images/googlepay.png') }}" style="height:20px; padding:25px 5px 15px 25px;">
                                        @elseif(isset($data->payment_with) && $data->payment_with == 33)
                                            <img src="{{ asset('assets/images/applepay.png') }}" style="height:20px; padding:25px 5px 25px 25px;">
                                        @elseif(isset($data->payment_with) && $data->payment_with == 7)
                                            <img src="{{ asset('assets/images/walletpay.png') }}" style="height:30px; padding:25px 5px 15px 25px;">
                                        @else
                                            <img src="{{ asset('assets/images/googlepay.png') }}" style="height:25px; padding:25px 5px 15px 25px;">
                                        @endif
                                    </div>
                                    <div class="transText"> Transaction ID : </div>
                                    <div class="transID">{{$data->transaction_no ?? ''}}</div>
                                </div>
                            </div>

                            @php
                            if($data->service_cost > 0){
                                $service_cost_without_vat = $data->service_cost - ($data->service_cost - $data->service_cost / ( 1 + $data->vat / 100));
                                $service_cost_vat = $data->service_cost - $data->service_cost / ( 1 + $data->vat / 100);
                            }
                            @endphp

                            <div class="col-md-5 pull-right" style="width: 44%;float:right;">
                                <div class="discountDetails" style="min-height: 195px;">
                                    <table width="100%" cellspacing="0">
                                        <tr>
                                            <td width="100%" class="color-td" style="text-align: right;" colspan="4">Pricing | التسعير </td>
                                        </tr>

                                        <tr>
                                            <td width="30%" class="text-right color-td">Price</td>
                                            <td width="5%" class="text-right color-td">|</td>
                                            <td width="30%" class="text-right color-td">سعر :</td>
                                            <td width="35%" class="font-weight-500" style="text-align: right;">{{ number_format($data->item_price, 2)}} sr</td>
                                        </tr>

                                        @if($data->service_cost >0)
                                            <tr>
                                                <td width="30%" class="text-right color-td">Service Cost</td>
                                                <td width="5%" class="text-right color-td">|</td>
                                                <td width="30%" class="text-right color-td">تكلفة الخدمة </td>
                                                <td width="35%" class="font-weight-500" style="text-align: right;">
                                                    {{ number_format($service_cost_without_vat, 2) }} SAR
                                                </td>
                                            </tr>
                                        @endif

                                        <tr>
                                            <td width="30%" class="text-right color-td">VAT {{number_format($data->vat, 2 )}}% </td>
                                            <td width="5%" class="text-right color-td">|</td>
                                            <td width="30%" class="text-right color-td">%{{number_format($data->vat, 2 )}} الضريبي : </td>
                                            <td width="35%" class="font-weight-500" style="text-align: right;">{{number_format($data->vat_amount, 2 )}} sr</td>
                                        </tr>

                                        <tr>
                                            <td width="30%" class="text-right color-td">Discount</td>
                                            <td width="5%" class="text-right color-td">|</td>
                                            <td width="30%" class="text-right color-td">خصم :</td>
                                            <td width="35%" class="font-weight-500" style="text-align: right;"> - {{ number_format($data->discount_amount, 2) }} sr</td>
                                        </tr>
                                        <tr>
                                            <td width="100%" class="text-right color-td" colspan="4"></td>
                                        </tr>
                                        <tr class="border-top-color" style="-webkit-box-shadow: 0px -2px 0px 0px rgba(255 213 140); -moz-box-shadow: 0px -2px 0px 0px rgba(255 213 140); box-shadow: 0px -2px 0px 0px rgba(255 213 140);">
                                            <td width="30%" class="total text-right font-weight-500">Total</td>
                                            <td width="5%" class="total text-right font-weight-500 color-td">|</td>
                                            <td width="30%" class="total text-right font-weight-500 color-td"> المجموع :</td>
                                            <td width="35%" class="total font-weight-500 " style="text-align: right;">{{ number_format($data->final_price, 2) ?? ''}} sr</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="invoice-footer-section">
                <div class="footer-content">
                    <div class="row">
                        <div class="col-md-9 pull-left" style="width:65%;">
                            <img src="{{ asset('assets/images/logo_black_new.png') }}" style="height:50px;">
                        </div>
                        <div class="col-md-3 pull-right" style="width:30%;text-align:center;">
                            <div class="email color-td">www.joyapp.io</div>
                            <div class="email color-td">help@joyapp.io</div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<!--************* END new invoice  ************************ -->


<!--************* Start refund invoice  ************************ -->
@if($data->revised_quantity > 0)
    <div style="page-break-after:always;"></div>
    <div class="container">
        <div class="row" style="margin-right: 0px; margin-left: 0px;">
            <div class="col-md-8" style="width:100%;">
                <div class="invoice-header-section p-5">
                    <div class="row" style="width:100%;">
                        <div class="col-md-4 pull-left" style="width:45%;">
                            <div class="logo-sectoin">
                                <img src="{{ asset('assets/images/joy_logo_black.png') }}" alt="Logo" style="height:50px;" />
                            </div>
                        </div>
                        <div class="col-md-8 pull-right" style="width:55%;">
                            <div class="logo-sectoin text-right invoicetext">
                                <div class="py-1">
                                    <span class="pl-3"> شركة جوي لخدمات الأعمال </span>
                                </div>
                                <div class="py-1">
                                    <span class="pl-3"> Joy for Business Services Company</span>
                                </div>
                                <div class="py-1">
                                    <span class="pl-3"> جدة - حي السلامة </span>
                                </div>
                                <div class="py-1">
                                    <span class="pl-3"> Jeddah - As salamah District </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row" style="width:100%;">
                        <div class="col-md-9 pull-left" style="width:75%;">
                            <h4>Refund Notification | إشعار دائن </h4>
                            <div class="invoicetext">
                                <table width="100%" cellspacing="0" style="background-color: #FCBC7C !important;">
                                    <tr>
                                        <td width="22%">Notification No.</td>
                                        <td width="3%">|</td>
                                        <td width="30%"> رقم الإشعار</td>
                                        <td width="40%" class="font-weight-600"> {{'R-'.$data->invoice_no}} </td>
                                    </tr>
                                    <tr>
                                        <td width="22%">VAT No.</td>
                                        <td width="3%">|</td>
                                        <td width="30%"> الرقم الضريبي </td>
                                        <td width="40%" class="font-weight-600"> 3140743534000387 </td>
                                    </tr>
                                    <tr>
                                        <td width="22%">Invoice No.</td>
                                        <td width="3%">|</td>
                                        <td width="30%"> رقم الفاتورة </td>
                                        <td width="40%" class="font-weight-600"> {{$data->invoice_no}} </td>
                                    </tr>
                                    <tr>
                                        <td width="22%">Date & Time</td>
                                        <td width="3%">|</td>
                                        <td width="30%"> التاريخ والوقت </td>
                                        <td width="40%" class="font-weight-600"> {{$data->created_at ? date('d/m/Y, H:ia', strtotime($data->created_at)) : ''}} </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <div class="col-md-3 pull-right" style="width:24%;">
                        <!-- <img width="150" height="150" src=https://chart.apis.google.com/chart?chs=150x150&cht=qr&chl={{$data->transaction_no ?? ''}} alt="{{$data->transaction_no ?? ''}}" /> -->
                            <div class="qrdiv1">
                                <img width="150" height="150" src=https://image-charts.com/chart?chs=150x150&cht=qr&chl={{$data->scan_url ?? ''}}&icqrb=FCBC7C alt="{{$data->transaction_no ?? ''}}" class="qrdiv2"/>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="invoicetitles col-md-12">
                            <div class="col-md-6 pull-left" style="width:50%;">
                                <div class="invo-title" style="padding: 15px 0px 7px 15px !important;"> Invoice For | فاتورة</div>
                            </div>
                            <div class="col-md-6 pull-right" style="width:50%;">
                                <div class="bgColor-title pull-left">
                                    <div class="company-title"> Service Provider | مقدم الخدمة </div>
                                </div>
                            </div>
                            <!-- <div class="col-md-6 pull-right" style="border-top-left-radius: 21px; border-top-right-radius: 21px; background-color: #f3f3f3; width:48%; margin-top:7px; margin-left:1%;">
                                <div class="company-title" style="padding: 6px 0px 5px 11px;">Company Info <br> معلومات الشركة </div>
                            </div> -->
                        </div>
                    </div>

                </div>

                <div class="invoice-middle-section" style="width:100%;">
                    <div class="invoiceFor" style="padding: 0rem 1rem 1rem 1rem;">
                        <div class="" style="width:100%; display: flex; flex-wrap: wrap;">
                            <div class="col-md-6 pull-left" style="width:50%;">
                                <!-- <div class="invo-title">Invoice For <br> فاتورة</div> -->
                                <!-- <div class="" style="padding-bottom:5px;"> فاتورة</div> -->
                                <div class="invoce-text-content">
                                    <div class="font-weight-600">
                                        {{$data->driver->first_name ?? ''}} {{$data->driver->last_name ?? ''}}
                                    </div>
                                    <div class="text-capitalize color-td">{{$data->driver->contact_no ?? ''}}</div>
                                    <div class="text-lowercase color-td">{{$data->driver->email ?? ''}}</div>
                                </div>
                            </div>
                            <div class="col-md-6 p-2 pull-right" style="width:50%;">
                                <div class="bgColor bgBorder">
                                    <!-- <div class="company-title">Company Info <br> معلومات الشركة </div> -->
                                    <!-- <div class="" style="padding-bottom:5px;"> معلومات الشركة </div> -->
                                    <div class="invoce-text-content">
                                        <div class="font-weight-600">
                                        {{$data->item->delar->org_name ?? ''}}
                                        @if(isset($data->item->delar->org_name_ar))
                                            <!--  | {{$data->item->delar->org_name_ar ?? ''}} -->
                                            @endif
                                        </div>
                                    <!-- <div class="text-capitalize">{{$data->item->delar->phone ?? ''}}</div> -->
                                        <div class="text-capitalize color-td">
                                            {{$data->item->delar->location->address ?? ''}}
                                            {{$data->item->delar->location->street ?? ''}},
                                            {{$data->item->delar->location->city ?? ''}},
                                            {{$data->item->delar->location->district ?? ''}},
                                            {{$data->item->delar->location->zipcode ?? ''}}
                                        </div>
                                        <div class="text-lowercase">{{$data->item->delar->email ?? ''}}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="invoice-middle-content pt-3" style="width:90%; margin:auto;">
                        <div class="productList px-3">
                            <div class="items">
                                <table width="98%" class="products" cellpadding="10" cellspacing="0">
                                    <thead>
                                    <tr>
                                        <td class="text-left color-td">Item | غرض </td>
                                        <td class="text-right color-td">Qty. | كمية  </td>
                                        <td class="text-right color-td">Price | سعر </td>
                                        <!-- <td class="text-left color-td">Total / المجموع </td> -->
                                    </tr>
                                    </thead>
                                    <tbody class="pt-3">
                                    <tr>
                                        <td width="50%" class="text-left">
                                            {{$data->item->title ?? ''}}
                                            @if(isset($data->item->title_ar))
                                                | {{$data->item->title_ar ?? ''}}
                                            @endif
                                        </td>
                                        <td width="20%" class="text-right">{{$data->revised_quantity ?? ''}}</td>
                                        <td width="30%" class="text-right">{{ number_format($data->price, 2) ?? ''}} sr</td>
                                    <!-- <td width="25%" class="text-left">{{ number_format(($data->price * $data->revised_quantity), 2) }} sr</td> -->
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="payment-cards">
                            <div class="row px-3">
                                <div class="col-md-7 pull-left" style="width: 55%;">
                                    <div class="cards-section pb-2">
                                        <div>
                                            @if(isset($data->payment_with) && $data->payment_with == 34)
                                                <img src="{{ asset('assets/images/googlepay.png') }}" style="height:20px; padding:25px 5px 15px 25px;">
                                            @elseif(isset($data->payment_with) && $data->payment_with == 33)
                                                <img src="{{ asset('assets/images/applepay.png') }}" style="height:20px; padding:25px 5px 25px 25px;">
                                            @elseif(isset($data->payment_with) && $data->payment_with == 7)
                                                <img src="{{ asset('assets/images/walletpay.png') }}" style="height:30px; padding:25px 5px 15px 25px;">
                                            @else
                                                <img src="{{ asset('assets/images/googlepay.png') }}" style="height:25px; padding:25px 5px 15px 25px;">
                                            @endif
                                        </div>
                                        <div class="transText"> Transaction ID : </div>
                                        <div class="transID">{{$data->transaction_no ?? ''}}</div>
                                    </div>
                                </div>
                                <div class="col-md-5 pull-right" style="width: 44%;float:right;">
                                    <div class="discountDetails" style="min-height: 195px;">
                                        <table width="100%" cellspacing="0">
                                            <tr>
                                                <td width="100%" class="color-td" style="text-align: right;" colspan="4">Pricing | التسعير </td>
                                            </tr>
                                            <tr>
                                                <td width="30%" class="text-right color-td">VAT {{number_format($data->vat, 2 )}}% </td>
                                                <td width="5%" class="text-right color-td">|</td>
                                                <td width="30%" class="text-right color-td">%{{number_format($data->vat, 2 )}} الضريبة : </td>
                                                <td width="35%" class="font-weight-500" style="text-align: right;">{{number_format($data->vat_amount * $data->revised_quantity, 2 )}} sr</td>
                                            </tr>
                                            <tr>
                                                <td width="30%" class="text-right color-td">Price</td>
                                                <td width="5%" class="text-right color-td">|</td>
                                                <td width="30%" class="text-right color-td">سعر :</td>
                                                <td width="35%" class="font-weight-500" style="text-align: right;">{{ number_format($data->item_price * $data->revised_quantity , 2)}} sr</td>
                                            </tr>
                                            <tr>
                                                <td width="30%" class="text-right color-td">Discount</td>
                                                <td width="5%" class="text-right color-td">|</td>
                                                <td width="30%" class="text-right color-td">رعس :</td>
                                                <td width="35%" class="font-weight-500" style="text-align: right;"> - {{ number_format($data->discount_amount * $data->revised_quantity, 2) }} sr</td>
                                            </tr>
                                            <tr>
                                                <td width="100%" class="text-right color-td" colspan="4"></td>
                                            </tr>
                                            <tr class="border-top-color" style="-webkit-box-shadow: 0px -2px 0px 0px rgba(255 213 140); -moz-box-shadow: 0px -2px 0px 0px rgba(255 213 140); box-shadow: 0px -2px 0px 0px rgba(255 213 140);">
                                                <td width="30%" class="total text-right font-weight-500">Total</td>
                                                <td width="5%" class="total text-right font-weight-500 color-td">|</td>
                                                <td width="30%" class="total text-right font-weight-500 color-td"> المجموع :</td>
                                                <td width="35%" class="total font-weight-500 " style="text-align: right;">{{ number_format($data->final_price * $data->revised_quantity, 2) ?? ''}} sr</td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="invoice-footer-section">
                    <div class="footer-content">
                        <div class="row">
                            <div class="col-md-9 pull-left" style="width:65%;">
                                <img src="{{ asset('assets/images/logo_black_new.png') }}" style="height:50px;">
                            </div>
                            <div class="col-md-3 pull-right" style="width:30%;text-align:center;">
                                <div class="email color-td">www.joyapp.io</div>
                                <div class="email color-td">help@joyapp.io</div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endif
<!--************* END Fefund invoice  ************************ -->






</body>
</html>