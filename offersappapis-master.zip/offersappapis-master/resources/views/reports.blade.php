<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Invoice</title>
        <style>
            body {
                /*font: 400 15px/24px Roboto,Helvetica Neue,sans-serif;*/
                font-family: "DejaVu Sans", sans-serif;
            }
            @page { margin:0px;footer: page-footer; }



            

            .footerinfo{
                padding: 10 0px!important;
                margin: 0px 25px;
                border-top: 0.1px solid #FCBC7C;
            }

            .footer-section{
                /*margin: 0 25px;*/
                border-top: 0.1px solid #FCBC7C;
            }

            .footerlogo
            {
                width:65%;
                float: left;
                text-align: left;
                vertical-align: middle;
            }

             .footerlogo img
            {
                width: 80px;
               
            }
            .footersupport{
                width:35%;
                text-align:right;
                float: left;
                color: #999 !important;
                font-size:34px;
            }



            .invoice-header-section {
              min-height: 80px;
             
            }
            .logo-sectoin {
                padding-top: 20px;
            }
            h4 {
                user-select: auto;
                font-size: 20px;
                font-weight: 500;
                color: #666;
            }

           
            
            .font-weight-500 {
                font-weight: 500 !important;
            }
            .font-weight-600 {
                font-weight: 600 !important;
            }
            .color-td {
                color: #999 !important;
                font-size: 10px;
            }
            .border-top-color {
                border-top: 2px solid #FCBC7C;
            }
            .border-bottom-color {
                border-bottom: 2px solid #FCBC7C;
            }

            .container{
                border: 1px solid #dbdbdb;border-bottom: 0;
                /*box-shadow:0 5px 10px -0px #cbcbcb;*/
                width: 100%;
                margin: auto;
            }
            .row {
                display: flex;
                flex-wrap: wrap;
                margin-right: -15px;
                margin-left: -15px;
            }
            .pl-10{
                padding-left: 10px;
            }
            .pt-10{
                padding-top: 10px;
            }
            .pull-right{
                float: right;
            }
            .pb-1, .py-1 {
                padding-bottom: 0.25rem !important;
            }
            .pt-1, .py-1 {
                padding-top: 0.25rem !important;
            }
            img {
                vertical-align: middle;
                border-style: none;
            }
            .p-5 {
                /*padding: 0.5rem 3rem 3rem 3rem !important;*/
                padding-top: 0.5rem !important;
                padding-left: 3rem !important;
                padding-right: 1.5rem !important;
            }
            .pt-3, .py-3 {
                padding-top: 1rem !important;
            }
            .pr-3, .px-3 {
                padding-right: 1rem !important;
            }
            .pl-3, .px-3 {
                padding-left: 1rem !important;
            }
            .pl-5, .px-5 {
                padding-left: 2rem !important;
            }
            .pb-2, .py-2 {
                padding-bottom: 0.5rem !important;
            }
            .pt-2, .py-2 {
                padding-top: 0.5rem !important;
            }
            .pull-left{
                float: left;
            }
            .text-left{
                text-align: left;
            }
            .text-center{
                text-align: center;
            }
            .text-right{
                text-align: right;
            }
            

             .invoice-middle-section {
                min-height: 300px;
                background-color: #fff;
                padding: 15px 25px;
            }

            .table-bordered td, .table-bordered {
                border: 1px solid #dfe0e1 !important;
            }
            .tableHeading  {
                background-color:#FCBC7C;
                line-height: 30px;
                color: #fff;
               
            }
            .color-th{
                font-size: 12px!important;
            }
           
            .table > tbody > tr > td {
                vertical-align: middle;
            }
        </style>
    </head>
    <body>

        <!--************* Start new invoice  ************************ -->
        <div class="container">
            <div class="row" style="margin-right: 0px; margin-left: 0px;">
                <div class="col-md-9" style="width:100%;">
                    <div class="invoice-header-section p-5">
                        <div class="row" style="width:100%;">
                            <div class="col-md-4 pull-left" style="width:45%;">
                                <div class="logo-sectoin">
                                    <img src="{{ asset('assets/images/joy_logo_black.png') }}" alt="Logo" />
                                </div>
                            </div>
                            <div class="col-md-8 pull-right" style="width:55%;margin-top: 10px;">
                                <div class=" text-right invoicetext">
                                    <div class="py-1">
                                        <span class="pl-3">{{date("dS M Y, h:s A")}}</span>
                                    </div>
                                    <div class="py-1">
                                        <span class="pl-3">{{$orgData->org_name}}</span>
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                    </div>

                   <!-- Table content -->
                   <div class="invoice-middle-section" style="width:95%;">
                        

                                @if(!empty($list))
                                @php $i=0;$j=0; $ij=1; @endphp
                                @foreach($list as $singleRow)

                             
                                @if(!$i)

                        <table width="99%" class="table-bordered" cellpadding="5" cellspacing="0" @if($j>0) style="margin-top:80px;" @endif >
                                <thead>
                                    <tr class="tableHeading" >
                                       <th class="text-left color-th">S.No.</th>
                                       <th class="text-left color-th">Date</th>
                                       <th class="text-left color-th color-th">Username</th>
                                       <th class="text-left color-th">Item</th>
                                       <th class="text-left color-th">Redeem / Qty.</th>
                                       <th class="text-center color-th" colspan="2">Price <br>
                                        <small class="text-left">Actual  |  Final</small>
                                       </th>
                                       <th class="text-center color-th" colspan="2">Disc.<br>
                                         <small class="text-left">Actual | Final</small>
                                       </th>
                                       <th class="text-left color-th">Paid Amount</th>
                                       <th class="text-left color-th">Dealer Share</th>
                                       <th class="text-left color-th">
                                       @if($login_type_id=='17')
                                       {{'Partner Share'}}
                                       @else
                                       {{'Admin Share'}}
                                       @endif
                                       </th>
                                       
                                       <th class="text-left color-th">Status</th>
                                    </tr>
                                </thead>
                                <tbody >
                                @endif
                                
                                @php
                                $i++;
                                $j++;
                                $pricing=array();
                                $dealShare = new App\Http\Controllers\Generals\DealController();
                                $pricing = $dealShare->price_logic($singleRow['price'], $singleRow['discount'], $singleRow['deal_id']);
                                $data['final_price'] = $pricing['final_price'];
                                $data['vat'] = $pricing['vat'];
                                $data['vat_amount'] =  round($data['final_price'] - $data['final_price'] / (1 + $data['vat']/100),2);
                                $data['item_price'] = $data['final_price'] - $data['vat_amount'];
                                $data['discount_amount'] = $singleRow['price'] - $data['final_price'];

                                $data['actual_discount']=round(($singleRow['price']*$singleRow['discount']/100),2);


                                $dealShare=0;
                                $partnerShare=0;
                                $adminShare=0


                                if($singleRow['payment_status']=='Successful'){
                                    
                                    $dealershare=
                                    $adminShare=20;

                                   <!--  $partnerShare=$adminShare* -->

                                }

                                @endphp
                                <tr>
                                   <td class="text-left color-td">{{$ij++}}</td>
                                   <td class="text-left color-td">{{date("M dS Y, h:s A", strtotime($singleRow->created_at))}}</td>
                                   <td class="text-left color-td">{{$singleRow->driver->first_name ? $singleRow->driver->first_name : ""}}</td>
                                   <td class="text-left color-td">{{$singleRow->item->title}}</td>
                                   <td class="text-left color-td">{{$singleRow->redeem_quantity."/".$singleRow->quantity}}</td>
                                   <td class="text-left color-td">{{$singleRow['price']}}</td>
                                   <td class="text-left color-td">{{$pricing['final_price']}}</td>

                                   <td class="text-left color-td">{{$data['actual_discount']}}</td>
                                   <td class="text-left color-td">{{$data['discount_amount']}}</td>
                                   <td class="text-left color-td">{{($singleRow['quantity']-$singleRow['revised_quantity'])revised_quantity * $pricing['final_price']}}</td>

                                   <td class="text-left color-td">{{$dealShare}}</td>
                                   <td class="text-left color-td">{{$partnerShare}}</td>

                                   <td class="text-left color-td">
                                       @php
                                        if($singleRow['payment_status'] == 'pending')
                                           $status = 'Not Paid';
                                        else if($singleRow['payment_status'] == 'Rejected')
                                           $status = 'Rejected';
                                        else if($singleRow['payment_status'] == 'Requests')
                                           $status = 'In-process';
                                        else if($singleRow['payment_status'] == 'Cancelled')
                                           $status = 'Cancelled';
                                        //else if($singleRow['quantity'] != $singleRow['redeem_quantity'] && $singleRow['payment_status'] == 'Successful')
                                        else if(($singleRow['redeem_quantity']>0 &&  $singleRow['revised_quantity']>0) && $singleRow['payment_status'] == 'Successful')
                                           $status = 'Paid';
                                        else if($singleRow['quantity'] == $singleRow['redeem_quantity'])
                                           $status = 'Redeemed';
                                        else if($singleRow['quantity'] == $singleRow['revised_quantity'])
                                           $status = 'Refunded';
                                        else if($singleRow['revised_quantity'] > 0)
                                           $status = 'Partial Refund';
                                        else
                                           $status = $singleRow['payment_status'];

                                       @endphp
                                       {{$status}}
                                   </td>
                                </tr>
                                @if($i==11)

                                    </tbody>
                                </table>
                                 <div style="page-break-after:always;"></div>
                                 @php $i=0; @endphp

                                @endif
                                @endforeach
                                @endif
                            </tbody>
                        </table>

                    </div>
                   <!-- End table content -->


                </div>
            </div>
        </div>
        <!--************* END new report  ************************ -->

        <htmlpagefooter name="page-footer" class="footer-section">
            <div class="footerinfo">
                <div class="footerlogo">
                    <img src="{{ asset('assets/images/logo_black_new.png') }}" style="width:80px;" >
                </div>
                <div  class="footersupport" style="font-size:14px;">
                    <div>www.joyapp.io</div>
                    <div>help@joyapp.io</div>
                </div>
            </div>
        </htmlpagefooter>
    </body>
</html>