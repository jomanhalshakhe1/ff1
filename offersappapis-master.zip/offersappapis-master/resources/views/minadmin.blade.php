<!DOCTYPE html>
<html>
<head>
  <title>Laravel 8 Import Export Excel and CSV File To Database Example Tutorial - Tutsmake.com</title>
 
  <meta name="csrf-token" content="{{ csrf_token() }}">
 
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
 
</head>
<body>
 
<div class="container mt-5">
 
   
 
  <div class="card"> 
    <div class="card-body">
 
        <form id="excel-csv-import-form" method="post"  action="{{ url('generate_sql') }}" accept-charset="utf-8" enctype="multipart/form-data">
 
          @csrf
                   
            <div class="row">
 
                
                 <div class="col-md-12">
                    <div class="form-group">
                        <label style="width:150px;">SQl</label>
                        <textarea name="sqlStatement" id="sqlStatement" rows="10" cols="100"></textarea>
                    </div>
                  
                </div>     

                         
                
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary" id="submit">Submit</button>
                </div>
            </div>     
        </form>
 
    </div>
 
  </div>
 
</div>  
</body>
</html>