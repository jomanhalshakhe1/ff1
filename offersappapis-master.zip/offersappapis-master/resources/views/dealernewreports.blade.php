<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Invoice</title>
    <style>
      body {
        /*font: 400 15px/24px Roboto,Helvetica Neue,sans-serif;*/
        font-family: "DejaVu Sans", sans-serif;
      }

      @page {
        margin: 0px;
        footer: page-footer;
      }

      .footerinfo {
        padding: 10 0px !important;
        margin: 0px 25px;
        border-top: 0.1px solid #FCBC7C;
      }

      .footer-section {
        /*margin: 0 25px;*/
        border-top: 0.1px solid #FCBC7C;
      }

      .footerlogo {
        width: 65%;
        float: left;
        text-align: left;
        vertical-align: middle;
      }

      .footerlogo img {
        width: 80px;
      }

      .footersupport {
        width: 35%;
        text-align: right;
        float: left;
        color: #999 !important;
        font-size: 34px;
      }

      .invoice-header-section {
        min-height: 80px;
      }

      .logo-sectoin {
        padding-top: 20px;
      }

      h4 {
        user-select: auto;
        font-size: 20px;
        font-weight: 500;
        color: #666;
      }

      .font-weight-500 {
        font-weight: 500 !important;
      }

      .font-weight-600 {
        font-weight: 600 !important;
      }

      .color-td {
        color: #999 !important;
        font-size: 10px;
      }

      .border-top-color {
        border-top: 2px solid #FCBC7C;
      }

      .border-bottom-color {
        border-bottom: 2px solid #FCBC7C;
      }

      .container {
        border: 1px solid #dbdbdb;
        border-bottom: 0;
        /*box-shadow:0 5px 10px -0px #cbcbcb;*/
        width: 100%;
        margin: auto;
      }

      .row {
        display: flex;
        flex-wrap: wrap;
        margin-right: -15px;
        margin-left: -15px;
      }

      .pl-10 {
        padding-left: 10px;
      }

      .pt-10 {
        padding-top: 10px;
      }

      .pull-right {
        float: right;
      }

      .pb-1,
      .py-1 {
        padding-bottom: 0.25rem !important;
      }

      .pt-1,
      .py-1 {
        padding-top: 0.25rem !important;
      }

      img {
        vertical-align: middle;
        border-style: none;
      }

      .p-5 {
        /*padding: 0.5rem 3rem 3rem 3rem !important;*/
        padding-top: 0.5rem !important;
        padding-left: 3rem !important;
        padding-right: 1.5rem !important;
      }

      .pt-3,
      .py-3 {
        padding-top: 1rem !important;
      }

      .pr-3,
      .px-3 {
        padding-right: 1rem !important;
      }

      .pl-3,
      .px-3 {
        padding-left: 1rem !important;
      }

      .pl-5,
      .px-5 {
        padding-left: 2rem !important;
      }

      .pb-2,
      .py-2 {
        padding-bottom: 0.5rem !important;
      }

      .pt-2,
      .py-2 {
        padding-top: 0.5rem !important;
      }

      .pull-left {
        float: left;
      }

      .text-left {
        text-align: left;
      }

      .text-center {
        text-align: center;
      }

      .text-right {
        text-align: right;
      }

      .invoice-middle-section {
        min-height: 300px;
        background-color: #fff;
        padding: 15px 25px;
      }

      .table-bordered td,
      .table-bordered {
        border: 1px solid #dfe0e1 !important;
      }

      .tableHeading {
        background-color: #FCBC7C;
        line-height: 30px;
        color: #fff;
      }

      .color-th {
        font-size: 12px !important;
      }

      .table>tbody>tr>td {
        vertical-align: middle;
      }
    </style>
  </head>
  <body>
    <!--************* Start new invoice  ************************ -->
    <div class="container">
      <div class="row" style="margin-right: 0px; margin-left: 0px;">
        <div class="col-md-9" style="width:100%;">
          <div class="invoice-header-section p-5">
            <div class="row" style="width:100%;">
              <div class="col-md-4 pull-left" style="width:45%;">
                <div class="logo-sectoin">
                  <img src="{{ asset('assets/images/joy_logo_black.png') }}" alt="Logo" />
                </div>
              </div>
              <div class="col-md-8 pull-right" style="width:55%;margin-top: 10px;">
                <div class=" text-right invoicetext">
                  <div class="py-1">
                    <span class="pl-3">{{date("dS M Y, h:s A")}}</span>
                  </div>
                  <div class="py-1">
                    <span class="pl-3">Innvohub</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Table content -->
          <div class="invoice-middle-section" style="width:95%;"> @if(!empty($list)) @php $i=0;$j=0; $ij=1; @endphp @foreach($list as $singleRow) @if(!$i) <table width="99%" class="table-bordered" cellpadding="5" cellspacing="0" @if($j>0) style="margin-top:80px;" @endif > <thead>
                <tr class="tableHeading">
                  <th class="text-left color-th">S.No.</th>
                  <th class="text-left color-th">Redeemed Date</th>
                  <th class="text-left color-th">Item Name</th>
                  <th class="text-center color-th">Redeem <br> Qty. </th>
                  <th class="text-left color-th">Deal Price</th>
                  <th class="text-left color-th">Discount(%)</th>
                  <th class="text-left color-th">Dealer Share</th>
                  <th class="text-left color-th">Company Name</th>
                </tr>
              </thead>
              <tbody> @endif @php $i++; $j++; @endphp <tr>
                  <td class="text-left color-td">{{$ij++}}</td>
                  <td class="text-left color-td">{{date("M dS Y, h:s A", strtotime($singleRow->redeem_at))}}</td>
                  <td class="text-left color-td">{{$singleRow->item->title}}</td>
                  <td class="text-left color-td">{{$singleRow->redeem_quantity}}</td>
                  <td class="text-left color-td">{{$singleRow->final_price}}</td>
                  <td class="text-left color-td">{{$singleRow->discount}}</td>
                  <td class="text-left color-td">{{$singleRow->delar_share_get}}</td>
                  <td class="text-left color-td">{{$singleRow->item->delar->org_name}}</td>
                </tr> @if($i==22) </tbody>
            </table>
            <div style="page-break-after:always;"></div> @php $i=0; @endphp @endif @endforeach @endif </tbody>
            </table>
          </div>
          <!-- End table content -->
        </div>
      </div>
    </div>
    <!--************* END new report  ************************ -->
    <htmlpagefooter name="page-footer" class="footer-section">
      <div class="footerinfo">
        <div class="footerlogo">
          <img src="{{ asset('assets/images/logo_black_new.png') }}" style="width:80px;">
        </div>
        <div class="footersupport" style="font-size:14px;">
          <div>www.joyapp.io</div>
          <div>help@joyapp.io</div>
        </div>
      </div>
    </htmlpagefooter>
  </body>
</html>