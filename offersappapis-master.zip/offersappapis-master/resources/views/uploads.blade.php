<!DOCTYPE html>
<html>
<head>
  <title>Laravel 8 Import Export Excel and CSV File To Database</title>
 
  <meta name="csrf-token" content="{{ csrf_token() }}">
 
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
 
</head>
<body>
 
<div class="container mt-5">
 
   
 
  <div class="card"> 
    <div class="card-body">
 
        <form id="excel-csv-import-form" method="post"  action="{{ url('upload_excel_file') }}" accept-charset="utf-8" enctype="multipart/form-data">
 
          @csrf
                   
            <div class="row">
 
                <div class="col-md-12">
                    <div class="form-group">
                         <label style="width:150px;">Upload Excel FIle</label>
                        <input type="file" name="deals_list" placeholder="Choose file">
                    </div>
                    @error('file')
                        <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                    @enderror
                </div>     

                 <div class="col-md-12">
                    <div class="form-group">
                        <label style="width:150px;">Location Id</label>
                        <input type="number" name="locationId" id="locationId">
                    </div>
                  
                </div>     

                 <div class="col-md-12">
                    <div class="form-group"> <label style="width:150px;">Delear Id</label>
                        <input type="number" name="dealerId" id="dealerId">
                    </div>
                   
                </div>              
                
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary" id="submit">Submit</button>
                </div>
            </div>     
        </form>
 
    </div>
 
  </div>
 
</div>  
</body>
</html>