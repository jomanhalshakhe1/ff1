<html>
<style>
    .brandlogo{
        height: 50px;
        width: auto;
        padding-left: 3%;
        margin-top: 2%;
    }
    .invoicehead{
        padding: 30%;
        height:15px;
    }
    .headcol{
        height:40px;
        background-color: #FFD58C;
    }
    .headtitle{
        font-size: 50px;
        padding: 10px;
    }
    .content{
        padding: 0 3% 0 3%;
    }
    .products thead{
        background: #000;
        color: #fff;
    }

    .products tr:nth-child(even) {
        background-color: #F2F2F2;
    }
    .total{
        background-color: #FFD58C;
        padding: 10px;
    }

    .items{
        border: 1px solid #000;
    }

</style>
<head>
    <img src="{{ url('assets/images/brandlogo.png') }}" class="brandlogo" />

    <table width="100%" >
        <tr class="invoicehead">
            <td width="60%">
                <div class="headcol"></div>
            </td>
            <td width="20%">
                <span class="headtitle">INVOICE</span>
            </td>
            <td width="20%">
                <div class="headcol"></div>
            </td>
        </tr>
    </table>

</head>
<body>
    <div class="content">

        <table width="100%" >
            <tr>
                <td width="40%">
                    Invoice to:
                </td>
                <td width="20%"></td>
                <td width="20%">

                </td>
                <td width="20%">

                </td>
            </tr>
            <tr>
                <td width="40%">
                    {{$data->driver->first_name ?? ''}}
                </td>
                <td width="20%">
                    Invoice#
                </td>
                <td width="10%">
                    {{$data->transaction_no ?? ''}}
                </td>
                <td width="10%" rowspan="2">
                    <img width="300" height="300"
                         src=https://chart.apis.google.com/chart?chs=150x150&cht=qr&chl={{$data->transaction_no}} alt="{{$data->transaction_no}}" />
                </td>
            </tr>
            <tr>
                <td width="40%">
                    {{$data->driver->contact_no ?? ''}}
                </td>
                <td width="20%">
                    Date
                </td>
                <td width="10%">
                    {{$data->created_at ? date('d-m-Y', strtotime($data->created_at)) : ''}}
                </td>
            </tr>
        </table>
        <br>

        <div class="items">
        <table width="100%" class="products" cellpadding="10" cellspacing="0">
            <thead>
                <tr>
                    <td>SL.</td>
                    <td>Item Description</td>
                    <td>Price</td>
                    <td>Qty.</td>
                    <td>Total</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td width="10%">1</td>
                    <td width="50%">{{ $data->item->title ?? '' }}</td>
                    <td width="20%">${{ $data->price ?? '' }}</td>
                    <td width="20%">{{ $data->quantity ?? '' }}</td>
                    <td width="20%">${{ number_format(round($data->price * $data->quantity, 2),2) }}</td>
                </tr>
            </tbody>
        </table>
        </div>

        <table width="100%" cellspacing="0" >
            <tr>
                <td width="40%">
                    Thank you for your bussiness
                </td>
                <td width="30%"></td>
                <td width="15%">Sub Total</td>
                <td width="15%">${{ number_format(round($data->price * $data->quantity, 2),2)  }}</td>
            </tr>
            <tr>
                <td width="40%"></td>
                <td width="30%"></td>
                <td width="15%">Discount</td>
                <td width="15%">{{ $data->item->offer->discount }} %</td>
            </tr>
            <tr>
                <td width="40%"></td>
                <td width="30%"></td>
                <td width="15%">Tax</td>
                <td width="15%">0.00%</td>
            </tr>
            <tr>
                <td width="40%">
                    Terms & Condiations
                </td>
                <td width="20%"></td>
                <td width="20%"></td>
                <td width="20%"></td>
            </tr>
            <tr>
                <td width="60%" colspan="2">
                    {{ $data->item->offer->terms }}
                </td>
                <td width="20%" class="total">Total</td>
                <!-- <td width="20%" class="total">${{ number_format(round($data->price * $data->quantity, 2), 2)  }}</td> -->
                <td width="20%" class="total">${{ number_format(round($data->final_price * $data->quantity, 2), 2)  }}</td>
            </tr>
        </table>
        <br><br>

        <table width="100%" cellspacing="0" >
            <tr>
                <td width="40%">
                    <b>{{ $data->item->delar->org_name ?? ''  }}</b>
                </td>
                <td width="60%"></td>
            </tr>
            <tr>
                <td width="40%">
                    {{ $data->trans_location->street. ',' ?? ''  }}
                    {{ $data->trans_location->city . ', ' ?? ''  }}
                    {{ $data->trans_location->district . ', ' ?? ''  }}
                    {{ $data->trans_location->zipcode ?? ''  }}
                </td>
                <td width="60%"></td>
            </tr>
        </table>

    </div>

    <div>
        <table width="100%" >
            <tr>
                <td width="70%" class="headtitle" style="color: #FFD58C;">_________________</td>
                <td width="20%" class="headtitle">________</td>
                <td width="10%" class="headtitle" style="color: #FFD58C;">______</td>
            </tr>
        </table>
    </div>

    <div class="content">
        <table width="100%"  >
            <tr>
                <td width="10%" style="border-right: 1px solid;"><b>Phone #</b></td>
                <td width="10%" style="border-right: 1px solid;"><b>Address</b></td>
                <td width="10%" style="border-right: 1px solid;"><b>Website</b></td>
                <td width="30%"></td>
                <td width="20%"><b>Authorised Sign</b></td>
                <td width="10%"></td>
            </tr>
        </table>
    </div>

</body>
</html>