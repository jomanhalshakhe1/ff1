<html>
	
	<body>
	<table>
	<p><?php echo $body; ?></p>
			<p>


	</body>
	</html>