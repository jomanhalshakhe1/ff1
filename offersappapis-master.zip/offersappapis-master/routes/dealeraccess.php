<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

/*Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});*/

Route::group(['middleware' => ['dealer_access']], function () {

    Route::prefix('deals')->group(function () {

        Route::prefix('battery')->group(function () {

            Route::get('/', 'Deals\BatteryController@index');
            Route::get('/info/{battery_id}', 'Deals\BatteryController@show');
            Route::post('/add', 'Deals\BatteryController@store');
        });

        Route::prefix('tires')->group(function () {
            Route::get('/', 'Deals\TireController@index');
            Route::get('/info/{battery_id}', 'Deals\TireController@show');
            Route::post('/add', 'Deals\TireController@store');
        });

        Route::prefix('wash')->group(function () {
            Route::get('/', 'Deals\WashController@index');
            Route::get('/info/{wash_id}', 'Deals\WashController@show');
            Route::post('/add', 'Deals\WashController@store');
        });

        Route::prefix('maintenance')->group(function () {
            Route::get('/', 'Deals\MaintenanceController@index');
            Route::get('/info/{maintenance_id}', 'Deals\MaintenanceController@show');
            Route::post('/add', 'Deals\MaintenanceController@store');
        });

        Route::prefix('detailing')->group(function () {
            Route::get('/', 'Deals\DetailingController@index');
            Route::get('/info/{detailing_id}', 'Deals\DetailingController@show');
            Route::post('/add', 'Deals\DetailingController@store');
        });

        Route::prefix('bulkupload')->group(function () {
            Route::post('/battery_upload', 'Deals\BulkUploadController@battery_upload');
            Route::post('/detailing_upload', 'Deals\BulkUploadController@detailing_upload');
            Route::post('/washes_upload', 'Deals\BulkUploadController@washes_upload');
            Route::post('/tires_upload', 'Deals\BulkUploadController@tires_upload');
            Route::post('/manufacturers_upload', 'Deals\BulkUploadController@manufacturers_upload');
            Route::get('/manufacturers', 'Deals\BulkUploadController@manufacturers');
            Route::get('/vehicle_groups', 'Deals\BulkUploadController@vehicle_groups');
        });

    });

    Route::prefix('petromin')->group(function () {

        Route::post('/change_status', 'Users\PetrominController@change_status');
        Route::get('/redeem/{service_id}', 'Users\PetrominController@redeem_service');
        Route::get('/cancel/{service_id}', 'Users\PetrominController@cancel_service');

    });

});


