<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/downloadinvoice/{transaction_no}', 'TransactionController@downloadpdf');
Route::get('/download_public_invoice/{transaction_no}', 'TransactionController@download_public_pdf');
Route::get('/download_mands_invoice/{transaction_no}', 'TransactionController@download_mands_invoice');
Route::get('/invoicepdf/{transaction_no}', 'TransactionController@invoicepdf');
Route::get('/upload_excel', 'ItemController@upload_excel');
Route::get('/upload_tire_images', 'ItemController@upload_tire_images');
Route::post('/upload_excel_file', 'ItemController@upload_excel_file');
Route::get('/upload_aws_bucket', 'ItemController@upload_aws_bucket');
Route::post('/upload_s3_file', 'ItemController@upload_s3_file');
Route::get('/query', 'GeneralController@query');
Route::post('/generate_sql', 'GeneralController@generate_sql');
Route::get('/creditsdetails', 'GeneralController@creditsdetails');
Route::get('/delete_multiple_devices', 'GeneralController@delete_multiple_devices');
Route::get('/logout', 'GeneralController@logout');
