
<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('/request_verification', 'Users\DriverController@request_verification');
Route::post('/signup', 'Users\DriverController@signup');
Route::post('/signin', 'Users\DriverController@signin');

Route::get('/send_otp/{contact_no}/{readotpcode?}', 'Users\DriverController@send_otp');
Route::post('/verify_otp', 'Users\DriverController@verify_otp');
Route::post('/verify_user', 'Users\DriverController@verify_user');
Route::post('/forgotpswd', 'Users\DriverController@forgotpswd');
Route::post('/reset_password', 'Users\DriverController@reset_password');

Route::get('/deals/all', 'Generals\DealController@index');
Route::get('/deals', 'Generals\DealController@deals_list');

Route::post('/changephone_email', 'Users\DriverController@changephone_email');
Route::post('/changephone_verifyotp', 'Users\DriverController@changephone_verifyotp');
Route::post('/change_phone', 'Users\DriverController@change_phone');
Route::post('/update_newphone', 'Users\DriverController@update_newphone');
Route::post('/verify_version', 'Generals\VersionController@verify_version');
Route::post('/exception_logs', 'GeneralController@exception_logs');

//Get all active app navigation urls list
Route::get('/app_navigation_urls', 'Generals\AppNavigationURLsController@active');

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::post('/preferred_language', 'Users\DriverController@preferred_language');

    //Route::get('/logout', 'Users\DriverController@logout');
   /* Delete account */
    Route::post('/delete_account', 'Users\DriverController@delete_account');
    Route::get('/send_otp_delete_account', 'Users\DriverController@send_otp_delete_account');
    Route::post('/verify_delete_account', 'Users\DriverController@verifyDeleteAccountOTP');
    /* End Delete account */


    Route::get('/configuration_details', 'Users\DriverController@configuration_details');

    Route::match(['get', 'post'], '/logout', 'Users\DriverController@logout');
   
    Route::post('/verify_customer_email', 'Notifications\SendEmailNotificationController@verify_customer_email');

    Route::post('/update_profile', 'Users\DriverController@update_profile');
    Route::post('/update_licence', 'Users\DriverController@update_licence');
    Route::post('/update_dp', 'Users\DriverController@update_dp');
    Route::get('/info', 'Users\DriverController@getUserInfo');
    Route::post('/verify_fleet', 'Users\FleetController@verify_fleet');
    Route::post('/delete_verified_company', 'Users\FleetController@deleteVerifiedCompany');
    Route::post('/notifier/add', 'Generals\SendPushNotification@add_notifier');
    Route::get( '/countries_list', 'Generals\CountryController@active_countries');

    Route::prefix('vehicles')->group(function () {
        Route::get('/', 'Users\VehicleController@driver_vehicles');
        Route::post('/add', 'Users\VehicleController@add_driver_vehicles');
        Route::post('/edit', 'Users\VehicleController@edit_driver_vehicles');
        Route::get('/delete/{id}', 'Users\VehicleController@delete_driver_vehicle');
        Route::get('/default/{vehicle_id}', 'Users\VehicleController@update_default_vehicle');
        Route::post('/assign_vin', 'Users\VehicleController@assign_vin');
        Route::post('/assign_plateno', 'Users\VehicleController@assign_plateno');

        Route::get('/makers', 'Generals\VehicleModelController@makers');
        Route::get('/models/{maker_id}', 'Generals\VehicleModelController@models');
        Route::get('/groups/{maker_id}/{model_id}', 'Generals\VehicleModelController@groups');

        Route::get('/groups', 'Generals\VehicleGroupController@active_vehicle_groups');
        Route::get('/colours', 'Users\VehicleController@colours');
    });

    Route::get('/mydeals', 'TransactionController@consumer_deals');
    Route::prefix('transaction')->group(function () {
        Route::get('/info/{transaction_id}', 'TransactionController@show');
        Route::post('/add', 'TransactionController@store');
        Route::post('/requests', 'TransactionController@request_offer');
        Route::post('/transaction_status', 'TransactionController@set_pg_status');
        Route::post('/create_payment', 'TransactionController@create_payment'); // It is using for notify options
        Route::post('/send_address', 'TransactionController@send_address'); 
        Route::get('/cancel_payment/{transaction_id}', 'TransactionController@cancel_payment');
    });

    Route::get('/savings', 'TransactionController@savings');
    //Route::get('/credits', 'Users\CreditsController@consumer_credits');

    Route::match(['get', 'post'], '/credits', 'Users\CreditsController@consumer_credits');

    Route::match(['get', 'post'], 'payment_types', 'Users\CreditsController@payment_types');

    Route::get('/delar/{deal_id}', 'Users\DelarController@delars_list');
    Route::get('/manufacturer', 'Generals\ManufacturerController@index');

    Route::prefix('notifications')->group(function () {
        Route::match(['get', 'post'], '/list', 'Generals\SendPushNotification@notifications_list');
        Route::get('/delete/{id}', 'Generals\SendPushNotification@notification_destroy');
        Route::get('/clear_all', 'Generals\SendPushNotification@allnotification_destroy');
    });
    
    Route::match(['get', 'post'], '/notifications_list', 'Generals\SendPushNotification@notifications_list');
    Route::match(['get', 'post'], '/get_popup_notifications', 'Generals\SendPushNotification@getPopMessages');

    Route::prefix('deals')->group(function () {

        Route::get('/offers/{city_id?}', 'Generals\DealController@all_offers');
        Route::get('/delars/{city_id?}', 'Generals\DealController@all_delars');
        Route::post('/delar_offers', 'Generals\DealController@delar_offers');
        Route::prefix('battery')->group(function () {
            Route::match(['get', 'post'], '/', 'Deals\BatteryController@index');
            Route::match(['get', 'post'], '/info/{battery_id}/{city_id?}/{location_id?}', 'Deals\BatteryController@show');
        });

        Route::prefix('tires')->group(function () {
            Route::match(['get', 'post'], '/', 'Deals\TireController@index');
            Route::match(['get', 'post'], '/info/{tire_id}/{city_id?}/{location_id?}', 'Deals\TireController@show');
        });

        Route::prefix('wash')->group(function () {
            Route::match(['get', 'post'], '/', 'Deals\WashController@index');
            Route::match(['get', 'post'], '/info/{wash_id}/{city_id?}/{location_id?}', 'Deals\WashController@show');
        });

        Route::prefix('maintenance')->group(function () {
            Route::match(['get', 'post'], '/', 'Deals\MaintenanceController@index');
            Route::match(['get', 'post'], '/info/{maintenance_id}', 'Deals\MaintenanceController@show');
        });

        Route::prefix('detailing')->group(function () {
            Route::match(['get', 'post'], '/', 'Deals\DetailingController@index');
            Route::match(['get', 'post'], '/info/{detailing_id}/{city_id?}/{location_id?}', 'Deals\DetailingController@show');
        });

        Route::prefix('oilchanges')->group(function () {
            Route::match(['get', 'post'], '/', 'Deals\OilchangesController@index');
            Route::match(['get', 'post'], '/info/{oilchange_id}/{city_id?}/{location_id?}', 'Deals\OilchangesController@show');
        });

        Route::prefix('petrol')->group(function () {
            Route::get('/', 'Deals\PetrolController@index');
            Route::get('/info/{petrol_id}', 'Deals\PetrolController@show');
        });

        Route::get('/vehicles/{offer_id}', 'Users\VehicleController@deal_vehicles_list');

    });

    Route::prefix('masters')->group(function () {
        Route::prefix('cities')->group(function () {
            Route::get('/', 'Generals\CityController@active_cities');
        });
    });

    Route::prefix('feedback')->group(function () {
        Route::get('/list', 'Generals\FeedbackController@feedback_list');
        Route::get('/info/{id}', 'Generals\FeedbackController@show');
        Route::post('/add', 'Generals\FeedbackController@store');
        Route::post('/edit/{id}', 'Generals\FeedbackController@update');
        Route::get('/delete/{id}', 'Generals\FeedbackController@destroy');
    });

    Route::prefix('offers')->group(function () {
        Route::prefix('favourites')->group(function () {

            //Cron Notifications consumer should need to login
            Route::post('/notification_checker', 'Generals\SendPushNotification@likedoffer_endingsoon');
            
        });
    });
});

