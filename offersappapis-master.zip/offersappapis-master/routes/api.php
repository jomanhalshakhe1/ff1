<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('/deals/all', 'Generals\DealController@index');
Route::get('/deals', 'Generals\DealController@deals_list');
Route::get('/download_dealer_invoice', 'ReportController@dealer_invoice');
Route::get('/download_invoice/{id}', 'ReportController@download_invoice');
Route::get('/download_mands_invoice/{id}', 'Deals\MaintenanceController@download_invoice');
Route::get('/reports/export_all_transactions', 'ReportController@export_all_transactions');
Route::get('/run_cron', 'Notifications\CustomNotificationsController@sendCustomNotificationUsingCron');


Route::prefix('user')->group(function () {
    Route::post('/signup', 'AuthController@signup');
    Route::post('/signin', 'AuthController@signin');
    Route::get('/send_otp/{email}', 'AuthController@send_otp');
    Route::post('/verify_otp', 'AuthController@verify_otp');
    Route::post('/forgotpwd', 'AuthController@forgotpwd');
    Route::post('/forgot_resetpassword', 'AuthController@forgot_resetpassword');
    Route::post('/reset_password', 'AuthController@reset_password');
    Route::get('/userinfo/{id}', 'AuthController@getUserInfo');
    Route::post('/verify_userotp', 'AuthController@verify_userotp');
    // Maker or delar can register here
    Route::post('/register', 'AuthController@register');
    Route::get('/deals', 'Generals\DealController@deals_list');
    Route::get( '/active_cities', 'Generals\CityController@active_cities');
    Route::get( '/active_countries', 'Generals\CountryController@active_countries');
    Route::post( '/member_signup', 'AuthController@member_signup');
});

 //Route::get('/capture_amount', 'tabby\TabbyController@capture_amount');

Route::get('/cancel_payments', 'PaymentController@canceledPayments');

Route::prefix('delar')->group(function () {
    Route::post('/signin', 'AuthController@signin');
    Route::post('/reset_password', 'AuthController@reset_password');
});



Route::group(['middleware' => ['jwt.verify']], function () {

    // Verify Email
    // API for Verify Email for customer
    Route::post('/verify_customer_email', 'Notifications\SendEmailNotificationController@verify_customer_email');
    // API for Verify Email for partner, servicer provider and technician
    Route::post('/verify_user_email', 'Notifications\SendEmailNotificationController@verify_user_email');
    // Verify otp based on user type
    Route::post('/verify_email_otp', 'Notifications\SendEmailNotificationController@verify_email_otp');
    // End Verify email

    Route::post('/search_deals', 'Notifications\CustomNotificationsController@searchDealerDealTitle');

    Route::get('/organization_details/{user_type}', 'Users\AdminController@getOrganizationsList');

    Route::get('/get_driver_or_provider_info/{id}/{user_type}', 'Users\UserController@getDriverOrProviderInfo');

    Route::get('/user_info', 'Users\UserController@getUserInfo');
    Route::post('/edit_profile', 'Users\UserController@update');

    /* Tabby Payment Gateway URLs */

    Route::prefix('tabby')->group(function () {
        Route::post('/get_all_transactions', 'tabby\TabbyController@getAllTabbyTransactionsList');
        Route::get('/info/{paymentId}', 'tabby\TabbyController@getPaymentDataByPaymentId');
        Route::post('/cancel_transaction', 'tabby\TabbyController@cancelTransaction');
        Route::post('/refund_amount', 'tabby\TabbyController@send_refund');
        Route::post('/purchase_deal', 'TabbyTransactionController@store');
        Route::post('/capture_amount', 'tabby\TabbyController@capture_amount');
        Route::post('/pending_transactions', 'tabby\TabbyController@getAllPendingTransactions');
        Route::get('/pay_purchased_deal/{transaction_no}', 'TabbyTransactionController@payPurchasedDeal');
        Route::post('/refund_transaction', 'tabby\TabbyController@getAllRefundedTransactions');
        Route::post('/cancelled_transaction', 'tabby\TabbyController@getAllCancelledTransactions');
    });


    /* End Tabby Payment gateway URLs */


    Route::prefix('slider')->group(function () {
        Route::get('/list', 'Generals\SliderController@index');
        Route::get('/info/{slider_id}', 'Generals\SliderController@show');
        Route::post('/add', 'Generals\SliderController@store');
        Route::post('/edit/{slider_id}', 'Generals\SliderController@update');
    });

    //Route::get('/delar/{deal_id}', 'Users\DelarController@delars_list');

    Route::match(['get', 'post'], '/delar/{deal_id?}', 'Users\DelarController@delars_list');

    Route::get('/active_dealers_list', 'Users\DelarController@active_dealers_list');
    Route::get('/active_partners_list', 'Users\FleetController@active_fleets');
    Route::get('/manufacturer', 'Generals\ManufacturerController@index');

    Route::prefix('deals')->group(function () {

        Route::prefix('battery')->group(function () {
            Route::match(['get', 'post'], '/', 'Deals\BatteryController@index');
            Route::get('/info/{battery_id}', 'Deals\BatteryController@show');
            Route::post('/add', 'Deals\BatteryController@store');
            Route::post('/edit/{delar_id}', 'Deals\BatteryController@update');
        });

        Route::prefix('tires')->group(function () {
            Route::match(['get', 'post'], '/', 'Deals\TireController@index');
            Route::get('/info/{battery_id}', 'Deals\TireController@show');
            Route::post('/add', 'Deals\TireController@store');
            Route::post('/edit/{tires_id}', 'Deals\TireController@update');
        });

        Route::prefix('wash')->group(function () {
            Route::match(['get', 'post'], '/', 'Deals\WashController@index');
            //added wash multiple offers new api calls
            Route::get('/info/{wash_id}', 'Deals\WashController@show');
            Route::post('/add', 'Deals\WashController@store');
            Route::post('/edit/{wash_id}', 'Deals\WashController@update');
            Route::post('/delete/{wash_id}', 'Deals\WashController@destroy');
        });

        Route::prefix('oilchanges')->group(function () {
            Route::match(['get', 'post'], '/', 'Deals\OilchangesController@index');
            //added wash multiple offers new api calls
            Route::get('/info/{item_id}', 'Deals\OilchangesController@show');
            Route::post('/add', 'Deals\OilchangesController@store');
            Route::post('/edit/{item_id}', 'Deals\OilchangesController@update');
            Route::post('/delete/{item_id}', 'Deals\OilchangesController@destroy');
        });

        Route::prefix('maintenance')->group(function () {
            Route::match(['get', 'post'], '/', 'Deals\MaintenanceController@index');
            Route::get('/info/{maintenance_id}', 'Deals\MaintenanceController@show');
            Route::post('/add', 'Deals\MaintenanceController@store');
            Route::post('/edit/{maintenance_id}', 'Deals\MaintenanceController@update');
        });

        Route::prefix('detailing')->group(function () {
            Route::match(['get', 'post'], '/', 'Deals\DetailingController@index');
            Route::get('/info/{detailing_id}', 'Deals\DetailingController@show');
            //added detailing multiple offers new api calls
            Route::post('/add', 'Deals\DetailingController@store');
            Route::post('/edit/{detailing_id}', 'Deals\DetailingController@update');
            Route::post('/delete/{detailing_id}', 'Deals\DetailingController@destroy');
        });

        Route::prefix('petrol')->group(function () {
            Route::match(['get', 'post'], '/', 'Deals\PetrolController@index');
            Route::get('/info/{petrol_id}', 'Deals\PetrolController@show');
            Route::post('/add', 'Deals\PetrolController@store');
            Route::post('/edit/{petrol_id}', 'Deals\PetrolController@update');
        });

        Route::prefix('insurance')->group(function () {
            Route::match(['get', 'post'], '/', 'Deals\InsuranceController@index');
            Route::get('/info/{policy_id}', 'Deals\InsuranceController@show');
            Route::post('/add', 'Deals\InsuranceController@store');
            Route::post('/edit/{policy_id}', 'Deals\InsuranceController@update');
        });

        Route::post('/delete_slider/{item_id}/{slider_id}', 'Generals\SliderController@delete_slider');

    });

    Route::prefix('roles')->group(function () {
        Route::get('/list/{login_type?}', 'Generals\RoleController@index');
        Route::get('/login_types', 'Generals\RoleController@login_types');
        Route::post('/list', 'Generals\RoleController@index');
        Route::get('/active_roles_list/{login_type?}', 'Generals\RoleController@active_roles');
        Route::get('/info/{id}', 'Generals\RoleController@show');
        Route::get('/role_info/{id}', 'Generals\RoleController@getRoleInfo');
        Route::post('/add', 'Generals\RoleController@store');
        Route::post('/edit/{id}', 'Generals\RoleController@update');
        Route::get('/features/{login_type?}', 'Generals\RoleController@features');
        Route::get('/menu', 'Generals\RoleController@user_menu');
    });

    Route::prefix('features')->group(function () {
        Route::get('/list/{login_type}', 'Generals\FeatureController@index');
        Route::get('/info/{id}', 'Generals\FeatureController@show');
        Route::post('/add', 'Generals\FeatureController@store');
        Route::post('/edit/{id}', 'Generals\FeatureController@update');
        Route::get('/destroy/{id}', 'Generals\FeatureController@destroy');
    });

    Route::prefix('accounts')->group(function () {

        Route::get('/deals', 'Generals\DealController@deals_list');

         Route::post('/user_notifications', 'AuthController@partners_resetpassword');


        Route::post('/admin_resetpwd/{admin_id}', 'AuthController@partners_resetpassword');

        Route::get('/get_admin_and_partners',  'Users\UserController@getallpartnerandadmin');

        Route::get('/driver_vehicles/{driver_id}', 'Users\VehicleController@driver_vehicles');

        Route::match(['get', 'post'], '/driver_fleet_companies/{driver_id}', 'Users\FleetController@driver_fleet_companies');

        Route::get('/get_fleet_driver_info/{id}/{customer_id}',  'Users\FleetController@getFleetDriverInfo');

         //Get Devices List
         Route::match(['get', 'post'], '/devices_list/{user_id}', 'Generals\DeviceController@index');


        Route::prefix('admins')->group(function () {
            //Route::get('/', 'Users\AdminController@index');
            //API for all admin's list

            Route::match(['get', 'post'],'/', 'Users\AdminController@index');
            Route::get('/info/{admin_id}', 'Users\AdminController@show');
            Route::post('/add', 'Users\AdminController@store');
            Route::post('/edit/{admin_id}', 'Users\AdminController@update');
            Route::get('/delete/{admin_id}', 'Users\AdminController@destroy');
            Route::get('/dashboard', 'DashboardController@admin_counts');
        });

        Route::prefix('technician')->group(function () {
            Route::match(['get', 'post'], '/', 'Users\TechnicianController@index');
            Route::get('/info/{id}', 'Users\TechnicianController@show');
            Route::post('/add', 'Users\TechnicianController@store');
            Route::post('/edit/{id}', 'Users\TechnicianController@update');

             Route::post('/edit_location/{id}', 'Users\TechnicianController@update_technician_location');

            Route::get('/view_info/{id}', 'Users\TechnicianController@show_info');

            Route::get('/providers_addresses/{id}', 'Users\TechnicianController@providers_addresses');

            Route::post('/active', 'Users\TechnicianController@getActiveTechnicians');

            
        });

        Route::prefix('delar')->group(function () {
            Route::match(['get', 'post'], '/', 'Users\DelarController@index');
            Route::get('/info/{delar_id}', 'Users\DelarController@show');
            Route::post('/add', 'Users\DelarController@store');
            Route::post('/edit/{delar_id}', 'Users\DelarController@update');
            Route::get('/actives', 'Users\DelarController@delar_companies');
            Route::get('/dashboard', 'DashboardController@delar_counts');

            Route::prefix('address')->group(function () {
                Route::get('/{delar_id}', 'Users\DelarController@address');
                Route::get('actives/{delar_id}', 'Users\DelarController@active_locations');
                Route::get('/info/{delar_id}/{address_id}', 'Users\DelarController@address_info');
                Route::post('/add', 'Users\DelarController@add_address');
                Route::post('/edit/{address_id}', 'Users\DelarController@edit_address');
            });

            Route::post('/validate_dealprovider_code', 'Users\DelarController@validate_dealprovider_code');
            Route::get('/adminuser/{maker_id}', 'Users\DelarController@adminuser');
            Route::get('/view_info/{id}', 'Users\DelarController@show_info');
        });

        Route::prefix('maker')->group(function () {
            Route::match(['get', 'post'], '/', 'Users\MakerController@index');
            Route::match(['get', 'post'], '/actives', 'Users\MakerController@active_makers');
            Route::get('/info/{maker_id}', 'Users\MakerController@show');
            Route::post('/add', 'Users\MakerController@store');
            Route::post('/edit/{maker_id}', 'Users\MakerController@update');

            Route::prefix('address')->group(function () {
                Route::get('/{maker_id}', 'Users\MakerController@address');
                Route::get('/info/{maker_id}/{address_id}', 'Users\MakerController@address_info');
                Route::post('/add', 'Users\MakerController@add_address');
                Route::post('/edit/{address_id}', 'Users\MakerController@edit_address');
            });

            Route::post('/validate_mns_code', 'Users\MakerController@validate_mns_code');
            Route::get('/adminuser/{maker_id}', 'Users\MakerController@adminuser');

            Route::get('/view_info/{id}', 'Users\MakerController@show_info');

        });

        Route::prefix('fleet')->group(function () {
            Route::match(['get', 'post'], '/', 'Users\FleetController@index');
            Route::get('/actives', 'Users\FleetController@active_fleets');
            Route::get('/with_customers', 'Users\FleetController@fleet_with_customers');
            Route::get('/info/{fleet_id}', 'Users\FleetController@show');
            Route::get('/view_info/{fleet_id}', 'Users\FleetController@show_info');
            Route::post('/add', 'Users\FleetController@store');
            Route::post('/edit/{fleet_id}', 'Users\FleetController@update');
            Route::get('/fleet_credits/{fleet_id}', 'Users\CreditsController@fleet_credits');

            Route::post('upload_users', 'Users\FleetController@upload_users');
            Route::match(['get', 'post'], 'uploads', 'Users\FleetController@fleet_uploads');
            Route::post('activated_members', 'Users\FleetController@activated_members');
            Route::match(['get', 'post'],'uploaded_members/{upload_id}', 'Users\FleetController@uploaded_members');
            Route::get('active_user_info/{upload_member_id}', 'Users\FleetController@activeUserInfo');
            Route::get('deactive_employee/{fleet_driver_id}', 'Users\FleetController@deactive_employee');

            Route::post('add_partner_employee', 'Users\FleetController@add_partner_employee');    

            Route::post('update_user_info/{upload_member_id}', 'Users\FleetController@updateUserInfo');

            Route::get('/dashboard', 'DashboardController@fleet_counts');
            Route::match(['get', 'post'], '/fleet_employees/{org_id}', 'Users\FleetController@getFleetDriversList');

            Route::post('/add_customerto_fleet', 'Users\FleetController@assign_fleeto_customer');
            Route::post('/edit_customerto_fleet/{id}', 'Users\FleetController@edit_customerto_fleet');

            Route::prefix('groups')->group(function () {
                Route::post('/list', 'Users\ConsumerGroupController@index');
                Route::get('/info/{id}', 'Users\ConsumerGroupController@show');
                Route::post('/add', 'Users\ConsumerGroupController@create');
                Route::post('/edit/{id}', 'Users\ConsumerGroupController@update');

                Route::match(['get', 'post'],'/actives/{fleet_id?}', 'Users\ConsumerGroupController@active_consumer_groups');

                Route::get('/active_groups/{fleet_id}', 'Users\ConsumerGroupController@activeGroupsList');


                Route::prefix('users')->group(function () {
                    Route::post('/assign/{group_id}', 'Users\ConsumerGroupController@assign_users');
                    Route::get('/info/{group_id}', 'Users\ConsumerGroupController@groupuserinfo');
                    Route::get('/unassigned/{group_id}','Users\ConsumerGroupController@unassignedgroupusers');
                });
            });

            Route::get('/adminuser/{maker_id}', 'Users\FleetController@adminuser');
        });

        Route::prefix('customer')->group(function () {
            Route::match(['get', 'post'], '/list', 'Users\DriverController@index');
            Route::match(['get', 'post'], '/notifications_list', 'Generals\NotificationController@getNotificationsList');
            Route::match(['get', 'post'], '/actives', 'Users\DriverController@active_customers');

            Route::post('/deleted', 'Users\DriverController@deleted_customers');

            Route::get('/info/{id}', 'Users\DriverController@show');
            Route::post('/add', 'Users\DriverController@store');
            Route::post('/edit/{id}', 'Users\DriverController@update');
            Route::match(['get', 'post'], '/actives/{fleet_id?}', 'Users\DriverController@active_customers');
            Route::get('/view_info/{id}', 'Users\DriverController@show_info');
            Route::get('/get_customer_fleets_list/{customer_id}',  'Users\DriverController@getFleetDriverInfo');
            Route::match(['get', 'post'], '/groups_list/{customer_id?}', 'Users\ConsumerGroupController@get_customer_groups_list');

            Route::post('/add_group_to_customer', 'Users\ConsumerGroupController@assignGroupDetails');


            Route::prefix('vehicles')->group(function () {
                Route::match(['get', 'post'], '/list', 'Users\VehicleController@get_all_customer_vehicles');

                Route::post('/create', 'Users\VehicleController@create');
                Route::post('/edit/{id}', 'Users\VehicleController@update');
                Route::get('/info/{id}', 'Users\VehicleController@show');

                Route::get('/delete_vehicle/{vehicle_id}', 'Users\VehicleController@delete_driver_vehicle');
            });

            Route::prefix('favourites')->group(function () {
                Route::match(['get', 'post'], '/list', 'Generals\FavouriteController@get_all_customer_favourites');
            });

        });

        Route::prefix('delar_technician')->group(function () {
            Route::match(['get', 'post'], '/', 'Users\DelarTechnicianController@index');
            Route::get('/info/{id}', 'Users\DelarTechnicianController@show');
            Route::post('/add', 'Users\DelarTechnicianController@store');
            Route::post('/edit/{id}', 'Users\DelarTechnicianController@update');
            Route::post('/delete/{id}', 'Users\DelarTechnicianController@destroy');

            Route::get('/view_info/{id}', 'Users\DelarTechnicianController@show_info');
        });

        Route::prefix('graphs')->group(function(){
            Route::get('/total_sales_by_deal/{deal_for?}', 'DashboardController@total_sales_by_deal');

            Route::get('/monthly_active_users', 'DashboardController@monthly_active_users');
            Route::get('/sales_share_by_deal', 'DashboardController@sales_share_by_deal');
            Route::get('/revenue_share_by_deal/{deal_for?}', 'DashboardController@revenue_share_by_deal');

            Route::get('/monthly_sales_by_deal', 'DashboardController@monthly_sales_by_deal');
        });

        Route::post( '/guests', 'Users\GuestController@index');
        Route::post( '/unregistered_devices', 'Users\GuestController@unregistered_devices');
    });

    Route::prefix('finance')->group(function () {

        Route::match(['get', 'post'], '/transactions', 'TransactionController@index');
        Route::post('/approved_by_user', 'TransactionController@approved_by_user_transactions');
        Route::post('/scanned_by_partner', 'Deals\MaintenanceController@scanned_by_partner_transactions');
        Route::match(['get', 'post'], '/requested_transactions', 'TransactionController@transaction_requests');
        Route::match(['get', 'post'], '/approved_list', 'TransactionController@delartech_transactions');
        Route::match(['get', 'post'], '/scanned_transactions', 'TransactionController@delartech_transactions');
        Route::post('/availability', 'TransactionController@update_availability');
        Route::get('/cancelled_requests', 'PaymentController@cancelRequestedItemAvailability');
        Route::get('/request_address/{transaction_id}', 'TransactionController@request_for_address');
        //Change all statuses by admin
        Route::post('/change_status', 'TransactionController@changeTransactionStatusByAdmin');
        
        Route::prefix('maintenance')->group(function () {
            Route::match(['get', 'post'], '/logs', 'Deals\MaintenanceController@total_scans');

            Route::get('/info/{transaction_id}', 'TransactionController@getMAndSTransactionInfo');
        });

        Route::prefix('delars')->group(function () {
            Route::match(['get', 'post'], '/logs', 'TransactionController@delar_transactions');
            Route::match(['get', 'post'], '/consumer_transactions/{customer_id}', 'TransactionController@consumer_transactions');
            Route::get('/transaction_info/{transaction_id}', 'TransactionController@transactionInfo');

             Route::get('/info/{transaction_id}', 'TransactionController@show');

        });

        Route::match(['get', 'post'], '/partner_transactions', 'TransactionController@partner_transactions');

        Route::prefix('transaction')->group(function () {
            Route::get('/info/{transaction_id}', 'TransactionController@show');
            Route::get('/redeem/{transaction_id}', 'TransactionController@approve_transaction_info');
            Route::post('/comments/add', 'TransactionController@add_transaction_comments');
            Route::get('/comments/{transaction_id}', 'TransactionController@transaction_comments');

            Route::get('/urway_status/{transaction_id}', 'PaymentController@find_transaction_status');
        });

        Route::prefix('credits')->group(function () {
            Route::prefix('refunds')->group(function () {
                Route::post('/list', 'Payments\RefundController@index');
                Route::post('/add', 'Payments\RefundController@send_refund');
                Route::get('/info/{transaction_no}', 'Payments\RefundController@refund_info');
            });

            Route::prefix('adjustments')->group(function () {
                Route::post('/list', 'Payments\AdjustmentController@index');
                Route::post('/add', 'Payments\AdjustmentController@send_adjustment');
                Route::get('/info/{transaction_no}', 'Payments\AdjustmentController@adjustment_info');
            });

            Route::prefix('gifts')->group(function () {
                Route::post('/list', 'Users\CreditsController@gifts');
                Route::get('/info/{credit_id}', 'Users\CreditsController@gift_info');
                Route::post('/add', 'Users\CreditsController@send_gift');
                Route::post('/edit/{credit_id}', 'Users\CreditsController@update_gift');
                Route::get('eligible_gift_accounts', 'Users\CreditsController@eligible_gift_accounts');

                Route::get('gift_info/{credit_id}', 'Users\CreditsController@getCustomerGiftsData');

                 Route::post('customers_list', 'Users\CreditsController@gifts_users_list');
            });


            Route::prefix('gift_credits')->group(function () {
                Route::post('/list', 'Payments\GiftsCreditsController@index');
                Route::get('/info/{credit_id}', 'Payments\GiftsCreditsController@gift_info');
                Route::post('/add', 'Payments\GiftsCreditsController@store');
                Route::post('/edit/{credit_id}', 'Payments\GiftsCreditsController@update');
            });
        });

        Route::prefix('payouts')->group(function () {
            Route::post('/list', 'Generals\PayoutController@index');
            Route::get('/info/{payout_id}', 'Generals\PayoutController@show');
            Route::get('/info_by_org/{org_id}', 'Generals\PayoutController@payoutinfo_by_org');
            Route::post('/add', 'Generals\PayoutController@store');
            Route::post('/edit/{payout_id}', 'Generals\PayoutController@update');
            Route::get('/payout_limit/{org_id}', 'Generals\PayoutController@payout_limit');
            Route::post('/unloack_payments', 'Generals\PayoutController@unloack_payments');

        });

        Route::prefix('exchanges')->group(function () {
            Route::post('/list', 'Generals\ExchangeController@index');
            Route::get('/info/{payout_id}', 'Generals\ExchangeController@show');
            Route::post('/add', 'Generals\ExchangeController@store');
            Route::post('/edit/{payout_id}', 'Generals\ExchangeController@update');
            Route::get('/for/{company_type}', 'Generals\ExchangeController@exchanges_for');
        });

        // Api accept either get method or post method
        Route::match(['get', 'post'], '/consumer_accounts', 'Users\CreditsController@consumer_accounts');
        Route::match(['get', 'post'], '/delar_accounts', 'Users\CreditsController@delar_accounts');
        Route::match(['get', 'post'], '/fleet_accounts', 'Users\CreditsController@fleet_accounts');

        Route::post('/feedback_list', 'Generals\FeedbackController@index');

    });

    Route::prefix('notifications')->group(function () {
        Route::prefix('customs')->group(function () {
            Route::match(['get', 'post'], '/list', 'Notifications\CustomNotificationsController@custom_notifications_list');

            Route::post('/send', 'Generals\SendPushNotification@send_custom_notifications');
            
            // Send custom notifications with new formates
            Route::post('/send_notification', 'Notifications\CustomNotificationsController@sendCustomNotifications');

            Route::get('/resend_notification/{notification_id}', 'Notifications\CustomNotificationsController@reSendCustomNotifications');

            Route::get('/info/{notification_id}', 'Notifications\CustomNotificationsController@getCustomerNotificationData');

            Route::post('/notification_users', 'Notifications\CustomNotificationsController@getUsersListForNotification');

            Route::match(['get', 'post'], '/customers_list', 'Notifications\CustomNotificationsController@notifications_users_list');
        });

        Route::prefix('sms')->group(function () {
             Route::post('/list', 'Notifications\SMSNotificationsController@index');
            
            Route::get('/info/{notification_id}', 'Notifications\SMSNotificationsController@show');

           Route::post('/edit/{id}', 'Notifications\SMSNotificationsController@update');

        });

        Route::prefix('formates')->group(function () {
            Route::match(['get', 'post'], '/list', 'Generals\SendPushNotification@formate_notifications_list');
            Route::get('/info/{id}', 'Generals\SendPushNotification@getNotificationData');
            Route::post('/edit/{id}', 'Generals\SendPushNotification@update_notification');
        });
    });

    Route::prefix('masters')->group(function () {
        Route::prefix('manufacturer')->group(function () {
            Route::match(['get', 'post'], '/list', 'Generals\ManufacturerController@list');
            Route::get('/actives', 'Generals\ManufacturerController@active_list');
            Route::get('/info/{manufacturer_id}', 'Generals\ManufacturerController@show');
            Route::post('/add', 'Generals\ManufacturerController@store');
            Route::post('/edit/{manufacturer_id}', 'Generals\ManufacturerController@update');
        });


        //Call coupons apis routes
        Route::prefix('coupons')->group(function () {
            Route::match(['get', 'post'], '/list', 'Generals\CouponsController@index');
            Route::post('/add', 'Generals\CouponsController@store');
            Route::get('/info/{id}', 'Generals\CouponsController@show');
            Route::post('/edit/{id}', 'Generals\CouponsController@update');
            Route::get('/coupon_applied_users/{id}', 'Generals\CouponsController@coupon_applied_users');
        });


        //Call App Navigation apis routes
        Route::prefix('app_navigation_urls')->group(function () {
            Route::match(['get', 'post'], '/list', 'Generals\AppNavigationURLsController@index');
            Route::get( '/actives', 'Generals\AppNavigationURLsController@activeList');
            Route::post('/add', 'Generals\AppNavigationURLsController@store');
            Route::get('/info/{id}', 'Generals\AppNavigationURLsController@show');
            Route::post('/edit/{id}', 'Generals\AppNavigationURLsController@update');
        });

        Route::prefix('email_formates')->group(function () {
            Route::match(['get', 'post'], '/list', 'Generals\EmailController@email_formates_list');
            Route::get('/info/{id}', 'Generals\EmailController@getEmailFormateData');
            Route::post('/edit/{id}', 'Generals\EmailController@updateEmailFormate');
        });


        Route::prefix('vehicle_groups')->group(function () {
            Route::match(['get', 'post'], '/list', 'Generals\VehicleGroupController@index');
            Route::match(['get', 'post'], '/actives', 'Generals\VehicleGroupController@active_vehicle_groups');
            Route::get('/info/{group_id}', 'Generals\VehicleGroupController@show');
            Route::post('/add', 'Generals\VehicleGroupController@store');
            Route::post('/edit/{group_id}', 'Generals\VehicleGroupController@update');

            Route::prefix('models')->group(function () {
                Route::match(['get', 'post'], '/list', 'Generals\VehicleModelController@index');
                 Route::match(['get', 'post'], '/actives', 'Generals\VehicleModelController@active_vehicle_models');

                Route::get('/info/{model_id}', 'Generals\VehicleModelController@show');
                Route::post('/add', 'Generals\VehicleModelController@store');
                Route::post('/edit/{model_id}', 'Generals\VehicleModelController@update');    
            });
        });
        Route::get('/vehicle_model_groups', 'Generals\VehicleModelController@vehicle_model_groups');

        Route::prefix('cities')->group(function () {
            Route::match(['get', 'post'], '/', 'Generals\CityController@index');
            Route::get( '/actives', 'Generals\CityController@active_cities');
            Route::get('/info/{city_id}', 'Generals\CityController@show');
            Route::post('/add', 'Generals\CityController@store');
            Route::post('/edit/{city_id}', 'Generals\CityController@update');
            Route::get('/delete/{city_id}', 'Generals\CityController@destroy');
        });

        Route::prefix('colours')->group(function () {
            Route::match(['get', 'post'], '/', 'Generals\ColoursController@index');
            Route::get( '/actives', 'Generals\ColoursController@active_colours');
            Route::get('/info/{colour_id}', 'Generals\ColoursController@show');
            Route::post('/add', 'Generals\ColoursController@store');
            Route::post('/edit/{colour_id}', 'Generals\ColoursController@update');
            Route::get('/delete/{colour_id}', 'Generals\ColoursController@destroy');
        });

        Route::prefix('countries')->group(function () {
            Route::match(['get', 'post'], '/', 'Generals\CountryController@index');
            Route::get( '/actives', 'Generals\CountryController@active_countries');
            Route::get('/info/{city_id}', 'Generals\CountryController@show');
            Route::post('/add', 'Generals\CountryController@store');
            Route::post('/edit/{city_id}', 'Generals\CountryController@update');
            Route::get('/delete/{city_id}', 'Generals\CountryController@destroy');
        });

        Route::prefix('deals')->group(function () {
            Route::get('/list', 'Generals\DealController@deals_all');
            Route::post('/add', 'Generals\DealController@store');
            Route::get('/info/{deal_id}', 'Generals\DealController@show');
            Route::post('/edit/{deal_id}', 'Generals\DealController@update');
        });

        Route::prefix('payment_gateways')->group(function () {
            Route::match(['get', 'post'], '/list', 'Payments\PaymentGatewayController@index');
            Route::get('/info/{pg_id}', 'Payments\PaymentGatewayController@show');
            Route::post('/add', 'Payments\PaymentGatewayController@store');
            Route::post('/edit/{pg_id}', 'Payments\PaymentGatewayController@update');
        });

        Route::prefix('version')->group(function () {
            Route::post('/list', 'Generals\VersionController@index');
            Route::post('/add', 'Generals\VersionController@store');
            Route::get('/info/{version_id}', 'Generals\VersionController@show');
            Route::post('/edit/{version_id}', 'Generals\VersionController@update');

              //Get total users based on version wise 
            Route::get('/version_wise_users_count', 'Generals\VersionController@getTotalUsersBasedOnVersionNo');

            // Get total users based on the device type
            Route::get('/device_wise_users_count', 'Generals\VersionController@getTotalUsersBasedOnDevice');
        });

        Route::prefix('shares')->group(function () {
            Route::post('/list', 'Generals\PaymentShareController@index');
            Route::post('/add', 'Generals\PaymentShareController@store');
            Route::get('/info/{share_id}', 'Generals\PaymentShareController@show');
            Route::post('/edit/{share_id}', 'Generals\PaymentShareController@update');
            Route::get('/latest', 'Generals\PaymentShareController@latest_payment_share');
        });

        Route::prefix('payment_types')->group(function () {
            Route::post('/', 'Generals\PaymentTypeController@index');
            Route::get('/info/{payment_type_id}', 'Generals\PaymentTypeController@show');
            Route::post('/edit/{payment_type_id}', 'Generals\PaymentTypeController@update');
        });

        Route::post('/upload', 'Generals\VersionController@file_upload');

    });

    Route::prefix('orgdeals')->group(function () {
        Route::get('/list', 'Deals\OrgDealController@index');
        Route::get('/info/{item_id}', 'Deals\OrgDealController@show');
        Route::post('/add', 'Deals\OrgDealController@store');
        Route::post('/edit/{item_id}', 'Deals\OrgDealController@update');
        Route::get('/deals_list', 'Deals\OrgDealController@deals_list');
    });

    Route::prefix('feedback')->group(function () {
        Route::get('/', 'Generals\FeedbackController@index');
        Route::get('/info/{id}', 'Generals\FeedbackController@show');
        Route::post('/add', 'Generals\FeedbackController@store');
        Route::post('/edit/{id}', 'Generals\FeedbackController@update');
        Route::get('/delete/{id}', 'Generals\FeedbackController@destroy');
    });

    Route::prefix('reports')->group(function () {
        //Get All Dealar invoices created by user
        Route::post('/dealer_invoices', 'ReportController@dealer_invoices');
        //Get dealer summary report
        Route::post('/get_dealer_reports', 'ReportController@dealer_reports_summary');
        Route::post('/all_successful_transactions', 'ReportController@getSuccessfulTransactionsDetails');
        Route::post('/get_all_customers', 'ReportController@getCustomersList');
        Route::post('/get_all_guest_customers', 'ReportController@getGuestCustomersList');
        Route::post('/get_total_sales_by_item', 'ReportController@total_sales_by_item');
        Route::post('/download_dealer_report_invoice', 'ReportController@download_dealer_report_invoice');
        Route::post('/dealer_payouts', 'ReportController@company_payouts');
        //Partner summary
        Route::post('/get_partner_reports', 'ReportController@partner_reports');

        Route::prefix('graphs')->group(function () {
            Route::post('/get_signup_customers', 'ReportController@getSignupsCustomersInfo');
            Route::post('/get_deleted_customers', 'ReportController@getDeletedAccountCustomersInfo');
            Route::post('/get_guest_users', 'ReportController@getGuestUsersInfo');
            Route::post('/get_transactions_list', 'ReportController@getTransactionsInfo');
            Route::post('/get_transaction_types_list', 'ReportController@getTransactionTypesInfo');
            Route::post('/get_active_customers', 'ReportController@getActiveUsersInfo');
            Route::post('/get_morethan_transactions', 'ReportController@getTransactionsMoreThanInfo');
            Route::post('/get_giftcredits_transactions', 'ReportController@getGiftCreditsUsersCountInfo');
            Route::post('/get_refunds_counts', 'ReportController@getRefundedCountInfo');     
        });

    });

    // Petromin apis
    Route::prefix('petromin')->group(function () {

        Route::get('/services/due', 'Users\PetrominController@index');
        Route::get('/services/add/{transaction_id}', 'Users\PetrominController@add_service');
        Route::get('/services/info/{service_id}', 'Users\PetrominController@show');
        Route::get('/services/delete/{service_id}', 'Users\PetrominController@destroy');

        Route::get('/drivers', 'Users\PetrominController@drivers_list');
        Route::get('/drivers/add', 'Users\PetrominController@add_driver');

        Route::get('/vehicles', 'Users\PetrominController@vehicles_list');
        Route::get('/vehicles/add', 'Users\PetrominController@add_vehicle');
    });

});

//Download reports
Route::prefix('reports')->group(function () {

    //Download summary report for dealer route
    Route::get('/download_dealer_summary_report', 'ReportController@download_dealer_report_summary');

    //download total sales by item
    Route::get('/export_total_sales_by_item', 'ReportController@exportTotalSalesByItem');

    Route::get('/export_all_customers', 'ReportController@export_all_customers');

    //Download company payouts list
    Route::get('/download_payouts','ReportController@download_payouts');
    //Download partner summary
    Route::get('/download_partner_report', 'ReportController@download_partner_report_summary');
    //get each partner invoice
    Route::post('/parter_invoice','ReportController@download_partner_report_invoice');

    Route::get('/download_payout_details','ReportController@download_payout_details');
  
});

Route::get('/downloadinvoice/{transaction_no}', 'TransactionController@downloadpdf');
//Route::post('/fcmtesting', 'TransactionController@fcmtesting');
Route::post('/fcmtesting', 'Generals\SendPushNotification@fcmtesting');
Route::get('/smstesting/{phone}', 'Generals\SendPushNotification@smstesting');
Route::get('/sendtestnotify', 'Generals\SendPushNotification@sendTestNotify');

    Route::prefix('notifications')->group(function () {
        Route::match(['get', 'post'], '/list', 'Generals\SendPushNotification@notifications_list');
        Route::get('/delete/{id}', 'Generals\SendPushNotification@notification_destroy');
        
        // manual Notifications;
        Route::post('/newoffer_added', 'Generals\SendPushNotification@newoffer_added');

    });
Route::match(['get', 'post'], '/notifications_list', 'Generals\SendPushNotification@notifications_list');


//Cron
// auto cancel transaction which are pending or failed after 48 hours
Route::post('/transactions_autocancel', 'Generals\SendPushNotification@transactions_autocancel');
    
//Cron + Notifications 
Route::post('/likedoffer_endingsoon', 'Generals\SendPushNotification@likedoffer_endingsoon'); //consumer login
Route::get('/unredeemed_offersend', 'Generals\SendPushNotification@unredeemed_offersend');
Route::get('/paid_unredeemed_offersend', 'Generals\SendPushNotification@paid_unredeemed_offersend');
Route::get('/incomplete_paymentfordeal', 'Generals\SendPushNotification@incomplete_paymentfordeal');
Route::get('/offer_expiry_warning', 'Generals\SendPushNotification@offer_expiry_warning');


