<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});


Route::post('/signup', 'Users\TechnicianController@signup');
Route::post('/signin', 'Users\TechnicianController@signin');
Route::get('/send_otp/{contact_no}', 'Users\TechnicianController@send_otp');
Route::post('/verify_otp', 'Users\TechnicianController@verify_otp');
Route::post('/verify_user', 'Users\TechnicianController@verify_user');
Route::post('/forgotpswd', 'Users\TechnicianController@forgotpswd');
Route::post('/reset_password', 'Users\TechnicianController@reset_password');

Route::post('/changephone_email', 'Users\TechnicianController@changephone_email');
Route::post('/changephone_verifyotp', 'Users\TechnicianController@changephone_verifyotp');
Route::post('/change_phone', 'Users\TechnicianController@change_phone');
Route::post('/update_newphone', 'Users\TechnicianController@update_newphone');
Route::post('/exception_logs', 'GeneralController@exception_logs');
Route::get( '/app_navigation_urls', 'Generals\AppNavigationURLsController@activeList');

Route::group(['middleware' => ['jwt.verify']], function () {
    
    Route::post('/preferred_language', 'Users\DelarController@preferred_language');

    Route::get('/user_info', 'Users\UserController@getUserInfo');
    Route::post('/update_dp', 'Users\TechnicianController@update_dp');
    Route::get('/partner_counters', 'TransactionController@partner_counters');

    Route::match(['get', 'post'], '/logout', 'Users\TechnicianController@logout');

    /* Delete Account */
    Route::post('/delete_account', 'Users\TechnicianController@delete_account');

    Route::match(['get', 'post'], '/send_otp_delete_account', 'Users\TechnicianController@send_otp_delete_account');
   
    Route::post('/verify_delete_account', 'Users\TechnicianController@verifyDeleteAccountOTP');
    /*End Delete Account */

    Route::prefix('transaction')->group(function () {
        Route::get('/requests', 'TransactionController@transaction_requests');
        Route::post('/availability', 'TransactionController@update_availability');
        Route::get('/list', 'TransactionController@delartech_transactions');
        Route::get('/info/{transaction_id}', 'TransactionController@requests_info');
        Route::get('/requests/info/{transaction_id}', 'TransactionController@requests_info');
        Route::post('/approve', 'TransactionController@approve_transaction');
        Route::get('/redeem/{transaction_id}', 'TransactionController@approve_transaction_info');
        Route::get('/scanners/{transaction_id}', 'Users\TechnicianController@eligible_technicians'); // Testing

        Route::get('/recent_transactions', 'TransactionController@recent_transactions');
        Route::get('/slots', 'TransactionController@transaction_slots');

        Route::get('/request_address/{transaction_id}', 'TransactionController@request_for_address');
        Route::get('/enquiry/{trans_id}', 'PaymentController@find_transaction_status');
    });

    Route::match(['get', 'post'], '/partner_notifications_list', 'Generals\SendPushNotification@notifications_list');

    Route::match(['get', 'post'], '/get_popup_notifications', 'Generals\SendPushNotification@getPopMessages');
    
    Route::prefix('notifications')->group(function () {
        //Route::match(['get', 'post'], '/list', 'Generals\SendPushNotification@notifications_list'); // not used 04/03/22
        Route::get('/delete/{id}', 'Generals\SendPushNotification@notification_destroy');
        Route::get('/clear_all', 'Generals\SendPushNotification@allnotification_destroy');
    });

    Route::prefix('feedback')->group(function () {
        Route::get('/list', 'Generals\FeedbackController@feedback_list');
        Route::get('/info/{id}', 'Generals\FeedbackController@show');
        Route::post('/add', 'Generals\FeedbackController@store');
        Route::post('/edit/{id}', 'Generals\FeedbackController@update');
        Route::get('/delete/{id}', 'Generals\FeedbackController@destroy');
    });
    
});